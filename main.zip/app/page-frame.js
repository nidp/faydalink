var __mainPageFrameReady__=window.__mainPageFrameReady__||function(){};
var __pageFrameStartTime__=__pageFrameStartTime__||Date.now(); 
var __webviewId__=__webviewId__;
var __layer__='view';
var __maAppCode__=__maAppCode__||{}; 
var __MAML_GLOBAL__=__MAML_GLOBAL__||{entrys:{},defines:{},modules:{},sjs_init:false};
var __maI18nResource__=__maI18nResource__||{};
(function (i18nRes) {
  // Merge i18n resource in subpackage scenario
  var newI18nRes={"en-US":{"test":"test messages","test2":"test message 2, {label}, {label2}","nested":"nested message: {test}","nested2":"nested message2: {obj.nested.value}","toggle":"Toggle locale","navigate":"Navigate to Log","window.title":"I18n","log":"log","cancelEvent":"cancel localChange event","selectTest":"{gender, select, male {male} female {female} other {other}}","selectTestNest":"{mood, select, good {{how} day!} sad {{how} day.} other {Whatever!}}","component":"Component","ui":"UI","api":"API","framework":"Framework","index.test":"Test fallback","navigate2":"Navigation 2nd"},"zh-CN":{"test":"Test Messages","test2":"Test message 2, {label}, {label2}","nested":"Nested Messages: {test}","nested2":"Nested message 2: {obj.nested.value}","toggle":"Switch Language","navigate":"redirect ","window.title":"Internationalization","log":"log","cancelEvent":"Listening event for canceling language change","selectTest":"{gender, select, male  female  other }","selectTestNest":"{mood, select, good {{how}Weather!} sad {{how}Weather.} other {other!}}","component":"component","ui":"extension component","api":"interface","framework":"framework","index.test":"alternate","navigate2":"Navigation 2"}};
  for(var locale in newI18nRes){
    if(i18nRes[locale]){
      for(var key in newI18nRes[locale]){
        i18nRes[locale][key] = newI18nRes[locale][key];
      }
    }else{
      i18nRes[locale]=newI18nRes[locale];
    }
  }
})(__maI18nResource__)


/* maml-transpiler v23.3.0 2023-03-29 16:31:41 */
window.__maml_transpiler_version__='v23.3.0'
var $gmac,$gaic={}
$gma=function(path,global){
  if(typeof global==='undefined')global={};
  function _ac(parent,child){if(typeof(child)!='undefined')parent.children.push(child);} // appendChild
  function _cvn(key){ // createVirtualNode
    if(typeof(key)!='undefined')return {tag:'virtual','maKey':key,children:[]};
    return {tag:'virtual',children:[]};
  }
  function _ctn(tag){ // createTagNode
    $gmac++;
    if($gmac>=16000) throw 'Dom count exceeds maximum 16000.';
    return {tag:tag.substr(0,3)=='ma-'?tag:'ma-'+tag,attr:{},children:[],n:[]}
  }
  function _rtw(msg){console.warn("[MAML runtime warn][$gma] "+msg)} // runtimeWarn
  $gmal={warn:console.warn,info:console.log,error:console.error}
  function $gmah(){
    function fn(){}
    fn.prototype={
      hn:function(obj){ // object has new value
        if(typeof(obj)=='object'){
          var cnt=0,any=false;
          for(var x in obj){
            any|=x==='__value__';
            cnt++;
            if(cnt>2)break;
          }
          return cnt==2&&any&&obj.hasOwnProperty('__maspec__');
        }
        return false;
      },
      nh:function(obj,special){ // new has new value object
        return {__value__:obj,__maspec__:special?special:true}
      },
      rv:function(obj){ // readValue
        return this.hn(obj)?this.rv(obj.__value__):obj;
      }
    }
    return new fn;
  }
  mah=$gmah();
  function $gstack(s){
    var t=s.split('\n '+' '+' '+' ');
    for(var i=0;i<t.length;++i){
      if(0==i) continue;
      if(")"===t[i][t[i].length-1])
      t[i]=t[i].replace(/\s\(.*\)$/,"");
      else t[i]="at anonymous function";
    }
    return t.join('\n '+' '+' '+' ');
  }
  function $gdc(o,p,r){ // deep copy
    o=mah.rv(o);
    if(o===null||o===undefined) return o;
    if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
    if(o.constructor===Object){
      var copy={};
      for(var key in o){
        if(o.hasOwnProperty(key))copy[undefined===p?key.substring(4):p+key]=$gdc(o[key],p,r);
      }
      return copy;
    }
    if(o.constructor===Date){
      var copy=new Date();
      copy.setTime(o.getTime());
      return copy;
    }
    if(o.constructor===Array){
      var copy=[];
      for(var index=0;index<o.length;index++)copy.push($gdc(o[index],p,r));
      return copy;
    }
    if(r&&o.constructor===Function){
      if (r==1)return $gdc(o(),undefined,2);
      if (r==2)return o;
    }
    if(o.constructor===RegExp){
      var m="";
      if(o.global)m+="g";
      if(o.ignoreCase)m+="i";
      if(o.multiline)m+="m";
      return new RegExp(o.source,m);
    }
    return null;
  }
  function $gmart(should_pass_type_info){
    function arithmeticEval(ops,e,s,g,o){
      var rop=ops[0][1],_f=false;
      var _a,_b,_c,_d,_aa,_bb;
      switch(rop){
        case '?:':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):rev(ops[3],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '&&':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):mah.rv(_a);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '||':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?mah.rv(_a):rev(ops[2],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '+':case '*':case '/':case '%':case '|':case '^':case '&':case '===':case '==':case '!=':case '!==':case '>=':case '<=':case '>':case '<':case '<<':case '>>':
          _a=rev(ops[1],e,s,g,o,_f);
          _b=rev(ops[2],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          switch(rop){
            case '+':
              _d=mah.rv(_a)+mah.rv(_b);
              break;
            case '*':
              _d=mah.rv(_a)*mah.rv(_b);
              break;
            case '/':
              _d=mah.rv(_a)/mah.rv(_b);
              break;
            case '%':
              _d=mah.rv(_a)%mah.rv(_b);
              break;
            case '|':
              _d=mah.rv(_a)|mah.rv(_b);
              break;
            case '^':
              _d=mah.rv(_a)^mah.rv(_b);
              break;
            case '&':
              _d=mah.rv(_a)&mah.rv(_b);
              break;
            case '===':
              _d=mah.rv(_a)===mah.rv(_b);
              break;
            case '==':
              _d=mah.rv(_a)==mah.rv(_b);
              break;
            case '!=':
              _d=mah.rv(_a)!=mah.rv(_b);
              break;
            case '!==':
              _d=mah.rv(_a)!==mah.rv(_b);
              break;
            case '>=':
              _d=mah.rv(_a)>=mah.rv(_b);
              break;
            case '<=':
              _d=mah.rv(_a)<=mah.rv(_b);
              break;
            case '>':
              _d=mah.rv(_a)>mah.rv(_b);
              break;
            case '<':
              _d=mah.rv(_a)<mah.rv(_b);
              break;
            case '<<':
              _d=mah.rv(_a)<<mah.rv(_b);
              break;
            case '>>':
              _d=mah.rv(_a)>>mah.rv(_b);
              break;
            default:
              break;
          }
          return _c?mah.nh(_d,"c"):_d;
        case '-':
          _a=ops.length===3?rev(ops[1],e,s,g,o,_f):0;
          _b=ops.length===3?rev(ops[2],e,s,g,o,_f):rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          _d=_c?mah.rv(_a)-mah.rv(_b):_a-_b;
          return _c?mah.nh(_d,"c"):_d;
        case '!':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=!mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        case '~':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=~mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        default:
          $gmal.warn('unrecognized op'+rop);
      }
    }
    function rev(ops,e,s,g,o,newap){
      var op=ops[0],_f=false;
      if(typeof newap!=="undefined")o.ap=newap;
      if(typeof(op)==='object'){
        var vop=op[0];
        var _a,_aa,_b,_bb,_c,_d,_s,_e,_ta,_tb,_td;
        switch(vop){
          case 2: // LogicalExpression|ConditionalExpression|UnaryExpression|BinaryExpression
            return arithmeticEval(ops,e,s,g,o);
          case 4: // ArrayExpression
            return rev(ops[1],e,s,g,o,_f);
          case 5: // ArrayMember
            switch(ops.length){
              case 2: // one member
                return should_pass_type_info?[rev(ops[1],e,s,g,o,_f)]:[mah.rv(rev(ops[1],e,s,g,o,_f))];
              case 1: // empty
                return [];
              default: // more members
                _a=rev(ops[1],e,s,g,o,_f);
                _a.push(should_pass_type_info?rev(ops[2],e,s,g,o,_f):mah.rv(rev(ops[2],e,s,g,o,_f)));
                return _a;
            }
          case 6: // MemberExpression
            _a=rev(ops[1],e,s,g,o);
            var ap=o.ap;
            _ta=mah.hn(_a);
            _aa=_ta?mah.rv(_a):_a;
            o.is_affected|=_ta;
            if(should_pass_type_info){
              if(_aa===null||typeof(_aa)==='undefined'){
                return _ta?mah.nh(undefined,'e'):undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return (_ta||_tb)?mah.nh(undefined,'e'):undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return (_ta||_tb)?(_td?_d:mah.nh(_d,'e')):_d;
            }else{
              if(_aa===null||typeof(_aa)==='undefined'){
                return undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return _td?mah.rv(_d):_d;
            }
          case 7: // Identifier
            switch(ops[1][0]){
              case 11: // CompoundExpression
                o.is_affected|=mah.hn(g);
                return g;
              case 3: // StaticString
                _s=mah.rv(s);
                _e=mah.rv(e);
                _b=ops[1][1];
                if(g&&g.f&&g.f.hasOwnProperty(_b)){
                  _a=g.f;
                  o.ap=true;
                }else{
                  _a=_s&&_s.hasOwnProperty(_b)?s:_e&&(_e.hasOwnProperty(_b)?e:undefined);
                }
                if(should_pass_type_info){
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    _d=_ta&&!_td?mah.nh(_d,'e'):_d;
                    return _d;
                  }
                }else{
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    return mah.rv(_d);
                  }
                }
                return undefined;
            }
            break;
          case 8: // ObjectProperty
            _a={};
            _a[ops[1]]=rev(ops[2],e,s,g,o,_f);
            return _a;
          case 9: // ObjectExpression
            _a=rev(ops[1],e,s,g,o,_f);
            _b=rev(ops[2],e,s,g,o,_f);
            function merge(_a,_b,_ow){
              _ta=mah.hn(_a);
              _tb=mah.hn(_b);
              _aa=mah.rv(_a);
              _bb=mah.rv(_b);
              if(should_pass_type_info){
                if(_tb){
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=mah.nh(_bb[k],'e');
                  }
                }else{
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=_bb[k];
                  }
                }
              }else{
                for(var k in _bb){
                  if(_ow||_aa.hasOwnProperty(k))_aa[k]=mah.rv(_bb[k]);
                }
              }
              return _a;
            }
            var _c=_a,_ow=true
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10){
              _a=_b,_b=_c,_ow=false
            }
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10)return merge(merge({},_a,_ow),_b,_ow);
            else return merge(_a,_b,_ow);
          case 10: // SpreadProperty
            return should_pass_type_info?rev(ops[1],e,s,g,o,_f):mah.rv(rev(ops[1],e,s,g,o,_f));
          case 12: // CallExpression
            var _r;
            _a=rev(ops[1],e,s,g,o);
            if(!o.ap)return should_pass_type_info&&mah.hn(_a)?mah.nh(_r,'f'):_r;
            var ap=o.ap;
            _b=rev(ops[2],e,s,g,o,_f);
            o.ap=ap;
            _ta=mah.hn(_a);
            _tb=_ca(_b);
            _aa=mah.rv(_a);
            _bb=mah.rv(_b);
            snap_bb=$gdc(_bb,"sjs_");
            try{
              _r=typeof _aa==="function"?$gdc(_aa.apply(null,snap_bb)):undefined;
            }catch(e){
              e.message=e.message.replace(/sjs_/g,"");
              e.stack=e.stack.substring(0,e.stack.indexOf("\n",e.stack.lastIndexOf("at sjs_")));
              e.stack=e.stack.replace(/\ssjs_/g," ");
              e.stack=$gstack(e.stack);
              e.stack += "\n "+" "+" "+" at " + path;
              if(window.__layer__==='view')console.error(e);
              _r=undefined;
            }
            return should_pass_type_info&&(_tb||_ta)?mah.nh(_r,'f'):_r;
        }
      }else{
        if(op===3||op===1) // StaticConstant
          return ops[1];
        else if(op===11){ // CompoundExpression
          var _a='';
          for(var index=1;index<ops.length;index++){
            var xp=mah.rv(rev(ops[index],e,s,g,o,_f));
            _a+=typeof(xp)==='undefined'?'':xp;
          }
          return _a;
        }
      }
    }
    return rev;
  }
  gra=$gmart(true);
  grb=$gmart(false);
  function mfor(to_iter,func,env,_s,global,father,itemname,indexname,keyname){
    var _n=!mah.hn(to_iter);
    var scope=mah.rv(_s);
    var full=Object.prototype.toString.call(mah.rv(to_iter));
    var type=full[8];
    var old_index=scope[indexname];
    var old_item=scope[itemname];
    var has_old_index=scope.hasOwnProperty(indexname);
    var has_old_item=scope.hasOwnProperty(itemname);

    if(type==='N'&&full[10]==='l')type='X';
    var _y;
    if(_n){
      if(type==='A'){
        for(var index=0;index<to_iter.length;index++){
          scope[itemname]=to_iter[index];
          scope[indexname]=mah.nh(index,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[index])):_cvn(mah.rv(mah.rv(to_iter[index])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in to_iter){
          scope[itemname]=to_iter[k];
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[k])):_cvn(mah.rv(mah.rv(to_iter[k])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<to_iter.length;i++){
          scope[itemname]=to_iter[i];
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<to_iter;i++){
          scope[itemname]=i;
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }else{
      var r_to_iter=mah.rv(to_iter);
      var r_iter_item,iter_item;
      if(type==='A'){
        for(var i=0;i<r_to_iter.length;i++){
          iter_item=r_to_iter[i];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(i,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in r_to_iter){
          iter_item=r_to_iter[k];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<r_to_iter.length;i++){
          scope[itemname]=mah.nh(r_to_iter[i],'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<r_to_iter;i++){
          scope[itemname]=mah.nh(i,'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }
    if(has_old_index){
      scope[indexname]=old_index;
    }else{
      delete scope[indexname];
    }
    if(has_old_item){
      scope[itemname]=old_item;
    }else{
      delete scope[itemname];
    }
  }
  function _ca(obj){
    if(mah.hn(obj))return true;
    if(typeof obj!=="object")return false;
    for(var i in obj){
      if(obj.hasOwnProperty(i)){
        if(_ca(obj[i]))return true;
      }
    }
    return false;
  }
  function _setAttr(z,node,attrname,opindex,env,scope,global){
    var o={},raw=grb(z[opindex],env,scope,global,o),value=$gdc(raw,"",2);
    if(o.is_affected||_ca(raw))node.n.push(attrname); // new attr
    node.attr[attrname]=value;
  }
  function _o(z,opindex,env,scope,global){
    var nothing={};
    return grb(z[opindex],env,scope,global,nothing);
  }
  function _1(z,opindex,env,scope,global){
    var nothing={};
    return gra(z[opindex],env,scope,global,nothing);
  }
  function _2(z,opindex,func,env,scope,global,father,itemname,indexname,keyname){
    var to_iter=_1(z,opindex,env,scope,global,father,itemname,indexname,keyname);
    mfor(to_iter,func,env,scope,global,father,itemname,indexname,keyname);
  }
  function _setAttrs(z,tag,attrs,env,scope,global){
    var t=_ctn(tag),base=0;
    for(var i=0;i<attrs.length;i+=2){
      if(attrs[i+1]<0){
        t.attr[attrs[i]]=true;
      }else{
        _setAttr(z,t,attrs[i],base+attrs[i+1],env,scope,global);
        if(base===0)base=attrs[i+1];
      }
    }
    return t;
  }

  var sjs_init=function(){
    if(!__MAML_GLOBAL__.sjs_init){
      sjs_Object();sjs_Function();sjs_Array();sjs_String();sjs_Boolean();sjs_Number();sjs_Math();sjs_Date();sjs_RegExp();
    }
    __MAML_GLOBAL__.sjs_init=true;
  };
  var sjs_Object=function(){
    Object.defineProperty(Object.prototype,"sjs_constructor",{writable:true,value:"Object"})
    Object.defineProperty(Object.prototype,"sjs_toString",{writable:true,value:function(){return "[object Object]"}})
  }
  var sjs_Function=function(){
    Object.defineProperty(Function.prototype,"sjs_constructor",{writable:true,value:"Function"})
    Object.defineProperty(Function.prototype,"sjs_toString",{writable:true,value:function(){return "[function Function]"}})
    Object.defineProperty(Function.prototype,"sjs_length",{get:function(){return this.length;},set:function(){}});
  }
  var sjs_Array=function(){
    Object.defineProperty(Array.prototype,"sjs_constructor",{writable:true,value:"Array"})
    Object.defineProperty(Array.prototype,"sjs_toString",{writable:true,value:function(){return this.nv_join();}})
    Object.defineProperty(Array.prototype,"sjs_join",{writable:true,value:function(s){
      s=undefined==s?',':s;var r="";
      for(var i=0;i<this.length;++i){
        if(0!=i)r+=s;
        if(null==this[i]||undefined==this[i])r+='';
        else if(this[i].nv_constructor==="Array"&&typeof this[i]=='object')r+=this[i].nv_join();
        else if(typeof this[i]=='function')r+=this[i].nv_toString();
        else r+=this[i].toString();
      }
      return r;
    }})
    Object.defineProperty(Array.prototype,"sjs_concat",{writable:true,value:Array.prototype.concat})
    Object.defineProperty(Array.prototype,"sjs_pop",{writable:true,value:Array.prototype.pop})
    Object.defineProperty(Array.prototype,"sjs_push",{writable:true,value:Array.prototype.push})
    Object.defineProperty(Array.prototype,"sjs_reverse",{writable:true,value:Array.prototype.reverse})
    Object.defineProperty(Array.prototype,"sjs_shift",{writable:true,value:Array.prototype.shift})
    Object.defineProperty(Array.prototype,"sjs_slice",{writable:true,value:Array.prototype.slice})
    Object.defineProperty(Array.prototype,"sjs_sort",{writable:true,value:Array.prototype.sort})
    Object.defineProperty(Array.prototype,"sjs_splice",{writable:true,value:Array.prototype.splice})
    Object.defineProperty(Array.prototype,"sjs_unshift",{writable:true,value:Array.prototype.unshift})
    Object.defineProperty(Array.prototype,"sjs_indexOf",{writable:true,value:Array.prototype.indexOf})
    Object.defineProperty(Array.prototype,"sjs_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
    Object.defineProperty(Array.prototype,"sjs_every",{writable:true,value:Array.prototype.every})
    Object.defineProperty(Array.prototype,"sjs_some",{writable:true,value:Array.prototype.some})
    Object.defineProperty(Array.prototype,"sjs_forEach",{writable:true,value:Array.prototype.forEach})
    Object.defineProperty(Array.prototype,"sjs_map",{writable:true,value:Array.prototype.map})
    Object.defineProperty(Array.prototype,"sjs_filter",{writable:true,value:Array.prototype.filter})
    Object.defineProperty(Array.prototype,"sjs_reduce",{writable:true,value:Array.prototype.reduce})
    Object.defineProperty(Array.prototype,"sjs_reduceRight",{writable:true,value:Array.prototype.reduceRight})
    Object.defineProperty(Array.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_String=function(){
    Object.defineProperty(String.prototype,"sjs_constructor",{writable:true,value:"String"})
    Object.defineProperty(String.prototype,"sjs_toString",{writable:true,value:String.prototype.toString})
    Object.defineProperty(String.prototype,"sjs_valueOf",{writable:true,value:String.prototype.valueOf})
    Object.defineProperty(String.prototype,"sjs_charAt",{writable:true,value:String.prototype.charAt})
    Object.defineProperty(String.prototype,"sjs_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
    Object.defineProperty(String.prototype,"sjs_concat",{writable:true,value:String.prototype.concat})
    Object.defineProperty(String.prototype,"sjs_indexOf",{writable:true,value:String.prototype.indexOf})
    Object.defineProperty(String.prototype,"sjs_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
    Object.defineProperty(String.prototype,"sjs_localeCompare",{writable:true,value:String.prototype.localeCompare})
    Object.defineProperty(String.prototype,"sjs_match",{writable:true,value:String.prototype.match})
    Object.defineProperty(String.prototype,"sjs_replace",{writable:true,value:String.prototype.replace})
    Object.defineProperty(String.prototype,"sjs_search",{writable:true,value:String.prototype.search})
    Object.defineProperty(String.prototype,"sjs_slice",{writable:true,value:String.prototype.slice})
    Object.defineProperty(String.prototype,"sjs_split",{writable:true,value:String.prototype.split})
    Object.defineProperty(String.prototype,"sjs_substring",{writable:true,value:String.prototype.substring})
    Object.defineProperty(String.prototype,"sjs_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
    Object.defineProperty(String.prototype,"sjs_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
    Object.defineProperty(String.prototype,"sjs_trim",{writable:true,value:String.prototype.trim})
    Object.defineProperty(String.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_Boolean=function(){
    Object.defineProperty(Boolean.prototype,"sjs_constructor",{writable:true,value:"Boolean"})
    Object.defineProperty(Boolean.prototype,"sjs_toString",{writable:true,value:Boolean.prototype.toString})
    Object.defineProperty(Boolean.prototype,"sjs_valueOf",{writable:true,value:Boolean.prototype.valueOf})
  }
  var sjs_Number=function(){
    Object.defineProperty(Number,"sjs_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
    Object.defineProperty(Number,"sjs_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
    Object.defineProperty(Number,"sjs_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
    Object.defineProperty(Number,"sjs_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
    Object.defineProperty(Number.prototype,"sjs_constructor",{writable:true,value:"Number"})
    Object.defineProperty(Number.prototype,"sjs_toString",{writable:true,value:Number.prototype.toString})
    Object.defineProperty(Number.prototype,"sjs_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
    Object.defineProperty(Number.prototype,"sjs_valueOf",{writable:true,value:Number.prototype.valueOf})
    Object.defineProperty(Number.prototype,"sjs_toFixed",{writable:true,value:Number.prototype.toFixed})
    Object.defineProperty(Number.prototype,"sjs_toExponential",{writable:true,value:Number.prototype.toExponential})
    Object.defineProperty(Number.prototype,"sjs_toPrecision",{writable:true,value:Number.prototype.toPrecision})
  }
  var sjs_Math=function(){
    Object.defineProperty(Math,"sjs_E",{writable:false,value:Math.E})
    Object.defineProperty(Math,"sjs_LN10",{writable:false,value:Math.LN10})
    Object.defineProperty(Math,"sjs_LN2",{writable:false,value:Math.LN2})
    Object.defineProperty(Math,"sjs_LOG2E",{writable:false,value:Math.LOG2E})
    Object.defineProperty(Math,"sjs_LOG10E",{writable:false,value:Math.LOG10E})
    Object.defineProperty(Math,"sjs_PI",{writable:false,value:Math.PI})
    Object.defineProperty(Math,"sjs_SQRT1_2",{writable:false,value:Math.SQRT1_2})
    Object.defineProperty(Math,"sjs_SQRT2",{writable:false,value:Math.SQRT2})
    Object.defineProperty(Math,"sjs_abs",{writable:false,value:Math.abs})
    Object.defineProperty(Math,"sjs_acos",{writable:false,value:Math.acos})
    Object.defineProperty(Math,"sjs_asin",{writable:false,value:Math.asin})
    Object.defineProperty(Math,"sjs_atan",{writable:false,value:Math.atan})
    Object.defineProperty(Math,"sjs_atan2",{writable:false,value:Math.atan2})
    Object.defineProperty(Math,"sjs_ceil",{writable:false,value:Math.ceil})
    Object.defineProperty(Math,"sjs_cos",{writable:false,value:Math.cos})
    Object.defineProperty(Math,"sjs_exp",{writable:false,value:Math.exp})
    Object.defineProperty(Math,"sjs_floor",{writable:false,value:Math.floor})
    Object.defineProperty(Math,"sjs_log",{writable:false,value:Math.log})
    Object.defineProperty(Math,"sjs_max",{writable:false,value:Math.max})
    Object.defineProperty(Math,"sjs_min",{writable:false,value:Math.min})
    Object.defineProperty(Math,"sjs_pow",{writable:false,value:Math.pow})
    Object.defineProperty(Math,"sjs_random",{writable:false,value:Math.random})
    Object.defineProperty(Math,"sjs_round",{writable:false,value:Math.round})
    Object.defineProperty(Math,"sjs_sin",{writable:false,value:Math.sin})
    Object.defineProperty(Math,"sjs_sqrt",{writable:false,value:Math.sqrt})
    Object.defineProperty(Math,"sjs_tan",{writable:false,value:Math.tan})
  }
  var sjs_Date=function(){
    Object.defineProperty(Date.prototype,"sjs_constructor",{writable:true,value:"Date"})
    Object.defineProperty(Date,"sjs_parse",{writable:true,value:Date.parse})
    Object.defineProperty(Date,"sjs_UTC",{writable:true,value:Date.UTC})
    Object.defineProperty(Date,"sjs_now",{writable:true,value:Date.now})
    Object.defineProperty(Date.prototype,"sjs_toString",{writable:true,value:Date.prototype.toString})
    Object.defineProperty(Date.prototype,"sjs_toDateString",{writable:true,value:Date.prototype.toDateString})
    Object.defineProperty(Date.prototype,"sjs_toTimeString",{writable:true,value:Date.prototype.toTimeString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
    Object.defineProperty(Date.prototype,"sjs_valueOf",{writable:true,value:Date.prototype.valueOf})
    Object.defineProperty(Date.prototype,"sjs_getTime",{writable:true,value:Date.prototype.getTime})
    Object.defineProperty(Date.prototype,"sjs_getFullYear",{writable:true,value:Date.prototype.getFullYear})
    Object.defineProperty(Date.prototype,"sjs_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_getMonth",{writable:true,value:Date.prototype.getMonth})
    Object.defineProperty(Date.prototype,"sjs_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_getDate",{writable:true,value:Date.prototype.getDate})
    Object.defineProperty(Date.prototype,"sjs_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
    Object.defineProperty(Date.prototype,"sjs_getDay",{writable:true,value:Date.prototype.getDay})
    Object.defineProperty(Date.prototype,"sjs_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
    Object.defineProperty(Date.prototype,"sjs_getHours",{writable:true,value:Date.prototype.getHours})
    Object.defineProperty(Date.prototype,"sjs_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
    Object.defineProperty(Date.prototype,"sjs_getMinutes",{writable:true,value:Date.prototype.getMinutes})
    Object.defineProperty(Date.prototype,"sjs_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_getSeconds",{writable:true,value:Date.prototype.getSeconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
    Object.defineProperty(Date.prototype,"sjs_setTime",{writable:true,value:Date.prototype.setTime})
    Object.defineProperty(Date.prototype,"sjs_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setSeconds",{writable:true,value:Date.prototype.setSeconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_setMinutes",{writable:true,value:Date.prototype.setMinutes})
    Object.defineProperty(Date.prototype,"sjs_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_setHours",{writable:true,value:Date.prototype.setHours})
    Object.defineProperty(Date.prototype,"sjs_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
    Object.defineProperty(Date.prototype,"sjs_setDate",{writable:true,value:Date.prototype.setDate})
    Object.defineProperty(Date.prototype,"sjs_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
    Object.defineProperty(Date.prototype,"sjs_setMonth",{writable:true,value:Date.prototype.setMonth})
    Object.defineProperty(Date.prototype,"sjs_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_setFullYear",{writable:true,value:Date.prototype.setFullYear})
    Object.defineProperty(Date.prototype,"sjs_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_toUTCString",{writable:true,value:Date.prototype.toUTCString})
    Object.defineProperty(Date.prototype,"sjs_toISOString",{writable:true,value:Date.prototype.toISOString})
    Object.defineProperty(Date.prototype,"sjs_toJSON",{writable:true,value:Date.prototype.toJSON})
  }
  var sjs_RegExp=function(){
    Object.defineProperty(RegExp.prototype,"sjs_constructor",{writable:true,value:"RegExp"})
    Object.defineProperty(RegExp.prototype,"sjs_exec",{writable:true,value:RegExp.prototype.exec})
    Object.defineProperty(RegExp.prototype,"sjs_test",{writable:true,value:RegExp.prototype.test})
    Object.defineProperty(RegExp.prototype,"sjs_toString",{writable:true,value:RegExp.prototype.toString})
    Object.defineProperty(RegExp.prototype,"sjs_source",{get:function(){return this.source;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_global",{get:function(){return this.global;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_multiline",{get:function(){return this.multiline;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
  }
  sjs_init();
  // sjs global object or function
  var sjs_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date,args));}
  var sjs_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp,args));}
  var sjs_console={sjs_log:function(){if(window.__layer__==='view'){var res="[SJS runtime info] ";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}}}
  var sjs_parseInt=parseInt,sjs_parseFloat=parseFloat,sjs_isNaN=isNaN,sjs_isFinite=isFinite,sjs_decodeURI=decodeURI,sjs_decodeURIComponent=decodeURIComponent,sjs_encodeURI=encodeURI,sjs_encodeURIComponent=encodeURIComponent;
  var sjs_JSON={
    sjs_stringify:function(o){return JSON.stringify($gdc(o));},
    sjs_parse:function(s){
      if(s===undefined)return undefined;
      return $gdc(JSON.parse(s),'sjs_');
    }
  }
  function _ck(k){return null==k?undefined:'number'===typeof k?k:"sjs_"+k} // compute key for sjs a[key]

  function _grp(path,e,me){if(path[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=path.split('/');for(var index=0;index<ppart.length;index++){if(ppart[index]=='..')mepart.pop();else if(ppart[index]=='.'||!ppart[index])continue;else mepart.push(ppart[index]);}path=mepart.join('/');}if(me[0]=='.'&&path[0]=='/')path='.'+path;if(e[path])return path;if(e[path+'.maml'])return path+'.maml';} // getRelativePath

  function _ai(i,path,e,me,r,c){var rp=_grp(path,e,me);if(rp)i.push(rp);else{i.push('');_rtw(me+':import:'+r+':'+c+': Path `'+path+'` not found from `'+me+'`.')}} // import

  function _gapi(e, path) {
    if (!path) return [];
    if ($gaic[path]) {
      return $gaic[path];
    }
    var ret = [],
      qq = [],
      hh = 0,
      tt = 0,
      put = {},
      visited = {};
    qq.push(path);
    visited[path] = true;
    tt++;
    while (hh < tt) {
      var a = qq[hh++];
      for (var index = 0; index < e[a].ic.length; index++) {
        var nd = e[a].ic[index];
        var np = _grp(nd, e, a);
        if (np && !visited[np]) {
          visited[np] = true;
          qq.push(np);
          tt++;
        }
      }
      for (var index = 0; a != path && index < e[a].ti.length; index++) {
        var ni = e[a].ti[index];
        var nm = _grp(ni, e, a);
        if (nm && !put[nm]) {
        }
      }
    }
    $gaic[path] = ret;
    return ret;
  }

  function _gd(p, c, e, d) {
    if (!c) return;
    if (d[p][c]) return d[p][c];
    for (var index = e[p].i.length - 1; index >= 0; index--) {
      if (e[p].i[index] && d[e[p].i[index]][c]) return d[e[p].i[index]][c];
    }
    for (var index = e[p].ti.length - 1; index >= 0; index--) {
      var q = _grp(e[p].ti[index], e, p);
      if (q && d[q][c]) return d[q][c];
    }
    var api = _gapi(e, p);
    for (var index = 0; index < api.length; index++) {
      if (api[index] && d[api[index]][c]) return d[api[index]][c];
    }
    for (var key = e[p].j.length - 1; key >= 0; key--)
      if (e[p].j[key]) {
        for (var qlen = e[e[p].j[key]].ti.length - 1; qlen >= 0; qlen--) {
          var tt = _grp(e[e[p].j[key]].ti[qlen], e, p);
          if (tt && d[tt][c]) {
            return d[tt][c];
          }
        }
      }
  }
  
  var $ixc = {};
  function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_rtw('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_rtw(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}} // include
  function _w(tn,f,line,c){_rtw(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}

  var e_=__MAML_GLOBAL__.entrys||{},d_=__MAML_GLOBAL__.defines||{},f_=__MAML_GLOBAL__.modules||{},p_={};
  if(window.i18n&&!f_.i18n){ // init sjs i18n api, remove arguments property sjs prefix
    f_.i18n={}
    for(var k in i18n){
      (function(k){ // simulate for loop let
        var key=k
        i18n['sjs_'+k]=i18n[k]
        if(typeof i18n[k]==="function"){
          i18n['sjs_'+k]=function(){return i18n[key].apply(null,$gdc(Array.prototype.slice.call(arguments)))}
          f_.i18n[k]=i18n['sjs_'+k]
        }else{
          i18n['sjs_'+k]=i18n[k]
          f_.i18n[k]=i18n[k]
        }
      })(k)
    }
  }
  __MAML_GLOBAL__.ops_cached=__MAML_GLOBAL__.ops_cached||{};
  __MAML_GLOBAL__.ops_set=__MAML_GLOBAL__.ops_set||{};
  __MAML_GLOBAL__.ops_init=__MAML_GLOBAL__.ops_init||{};
  var z=__MAML_GLOBAL__.ops_set.$gma||[];
  
  function gz$gma_1(){
    if(__MAML_GLOBAL__.ops_cached.$gma_1)return __MAML_GLOBAL__.ops_cached.$gma_1
    __MAML_GLOBAL__.ops_cached.$gma_1=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'onChildMethod']);
      Z([3,'A subcomponent invokes its subcomponent method']);
      Z([3,'trigger']);
      Z([11,[[7],[3,"text"]],[3,'\r\n        Subcomponent page component. Click to invoke the parent component method to display the subcomponents of the subcomponent']]);
      Z([[7],[3,"isDispalyItem"]]);
      Z([[7],[3,"list"]]);
      Z([3,'item']);
      Z([3,'name']);
      Z([3,'onMyEvent']);
      Z([3,'test_color']);
      Z([[7],[3,"item"]])
    })(__MAML_GLOBAL__.ops_cached.$gma_1);
    return __MAML_GLOBAL__.ops_cached.$gma_1
  }
  function gz$gma_2(){
    if(__MAML_GLOBAL__.ops_cached.$gma_2)return __MAML_GLOBAL__.ops_cached.$gma_2
    __MAML_GLOBAL__.ops_cached.$gma_2=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'trigger']);
      Z([3,'Subassembly of Subassembly'])
    })(__MAML_GLOBAL__.ops_cached.$gma_2);
    return __MAML_GLOBAL__.ops_cached.$gma_2
  }
  function gz$gma_3(){
    if(__MAML_GLOBAL__.ops_cached.$gma_3)return __MAML_GLOBAL__.ops_cached.$gma_3
    __MAML_GLOBAL__.ops_cached.$gma_3=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'box']);
      Z([3,'head']);
      Z([[8],"title",[1,"I am a custom componentA，My presentation is light orange"]]);
      Z([3,'addCount']);
      Z([3,'Click me to add 2 each time']);
      Z([11,[[7],[3,"count"]]]);
      Z([[6],[[7],[3,"detail"]],[3,"list"]]);
      Z([3,'item']);
      Z([3,'name']);
      Z([3,'background: #7fffd4']);
      Z([[7],[3,"item"]])
    })(__MAML_GLOBAL__.ops_cached.$gma_3);
    return __MAML_GLOBAL__.ops_cached.$gma_3
  }
  function gz$gma_4(){
    if(__MAML_GLOBAL__.ops_cached.$gma_4)return __MAML_GLOBAL__.ops_cached.$gma_4
    __MAML_GLOBAL__.ops_cached.$gma_4=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'child-box']);
      Z([3,'head']);
      Z([[8],"title",[1,"I am a subcomponent of custom component A，My color is light green"]]);
      Z([3,'addCount']);
      Z([3,'Click me to add 3 each time']);
      Z([11,[[7],[3,"count"]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_4);
    return __MAML_GLOBAL__.ops_cached.$gma_4
  }
  function gz$gma_5(){
    if(__MAML_GLOBAL__.ops_cached.$gma_5)return __MAML_GLOBAL__.ops_cached.$gma_5
    __MAML_GLOBAL__.ops_cached.$gma_5=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'onChildMethod']);
      Z([3,'A subcomponent invokes its subcomponent method']);
      Z([3,'trigger']);
      Z([11,[[7],[3,"text"]],[3,'\r\n        Subcomponent page component. Click to invoke the parent component method to display the subcomponents of the subcomponent']]);
      Z([[7],[3,"isDispalyItem"]]);
      Z([[7],[3,"list"]]);
      Z([3,'item']);
      Z([3,'name']);
      Z([3,'onMyEvent']);
      Z([3,'test_color']);
      Z([[7],[3,"item"]])
    })(__MAML_GLOBAL__.ops_cached.$gma_5);
    return __MAML_GLOBAL__.ops_cached.$gma_5
  }
  function gz$gma_6(){
    if(__MAML_GLOBAL__.ops_cached.$gma_6)return __MAML_GLOBAL__.ops_cached.$gma_6
    __MAML_GLOBAL__.ops_cached.$gma_6=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'trigger']);
      Z([3,'Subassembly of Subassembly'])
    })(__MAML_GLOBAL__.ops_cached.$gma_6);
    return __MAML_GLOBAL__.ops_cached.$gma_6
  }
  function gz$gma_7(){
    if(__MAML_GLOBAL__.ops_cached.$gma_7)return __MAML_GLOBAL__.ops_cached.$gma_7
    __MAML_GLOBAL__.ops_cached.$gma_7=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'box']);
      Z([3,'head']);
      Z([[8],"title",[1,"I am a custom componentA，My presentation is light orange"]]);
      Z([3,'addCount']);
      Z([3,'Click me to add 2 each time']);
      Z([11,[[7],[3,"count"]]]);
      Z([[6],[[7],[3,"detail"]],[3,"list"]]);
      Z([3,'item']);
      Z([3,'name']);
      Z([3,'background: #7fffd4']);
      Z([[7],[3,"item"]])
    })(__MAML_GLOBAL__.ops_cached.$gma_7);
    return __MAML_GLOBAL__.ops_cached.$gma_7
  }
  function gz$gma_8(){
    if(__MAML_GLOBAL__.ops_cached.$gma_8)return __MAML_GLOBAL__.ops_cached.$gma_8
    __MAML_GLOBAL__.ops_cached.$gma_8=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'child-box']);
      Z([3,'head']);
      Z([[8],"title",[1,"I am a subcomponent of custom component A，My color is light green"]]);
      Z([3,'addCount']);
      Z([3,'Click me to add 3 each time']);
      Z([11,[[7],[3,"count"]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_8);
    return __MAML_GLOBAL__.ops_cached.$gma_8
  }
  function gz$gma_9(){
    if(__MAML_GLOBAL__.ops_cached.$gma_9)return __MAML_GLOBAL__.ops_cached.$gma_9
    __MAML_GLOBAL__.ops_cached.$gma_9=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[9],[[8],"title",[1,"application-event"]],[[8],"desc",[1,"Application-level events"]]]);
      Z([3,'page-body']);
      Z([3,'onAppShow']);
      Z([3,'onAppShow1']);
      Z([3,'primary']);
      Z([3,'offAppShow']);
      Z([3,'onAppHide']);
      Z([3,'offAppHide']);
      Z([3,'onError']);
      Z([3,'offError']);
      Z([3,'Error']);
      Z([3,'text-area']);
      Z([3,'message']);
      Z([3,'white-space: pre-line;']);
      Z([11,[[7],[3,"detail"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_9);
    return __MAML_GLOBAL__.ops_cached.$gma_9
  }
  function gz$gma_10(){
    if(__MAML_GLOBAL__.ops_cached.$gma_10)return __MAML_GLOBAL__.ops_cached.$gma_10
    __MAML_GLOBAL__.ops_cached.$gma_10=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"canIUse"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'body-center contentAPI']);
      Z([11,[3,'The API result is:'],[[7],[3,"success"]]]);
      Z([3,'popapi1']);
      Z([3,'primary']);
      Z([3,'request.object.method.GET']);
      Z([3,'popapi2']);
      Z([3,'request.object.method.OPTI']);
      Z([3,'popapi3']);
      Z([3,'request.object.method']);
      Z([3,'popapi4']);
      Z([3,'request.object.meth']);
      Z([3,'popapi5']);
      Z([3,'request.object']);
      Z([3,'popapi6']);
      Z([3,'request.obj']);
      Z([3,'popapi7']);
      Z([3,'request']);
      Z([3,'popapi8']);
      Z([3,'reque']);
      Z([3,'body-center contentBtn']);
      Z([11,[3,'Component results are:'],[[7],[3,"popcom"]]]);
      Z([3,'popcom1']);
      Z([3,'button.size.default']);
      Z([3,'popcom2']);
      Z([3,'button.size.defau']);
      Z([3,'popcom3']);
      Z([3,'button.size']);
      Z([3,'popcom4']);
      Z([3,'button.si']);
      Z([3,'popcom5']);
      Z([3,'button']);
      Z([3,'popcom6']);
      Z([3,'butt']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_10);
    return __MAML_GLOBAL__.ops_cached.$gma_10
  }
  function gz$gma_11(){
    if(__MAML_GLOBAL__.ops_cached.$gma_11)return __MAML_GLOBAL__.ops_cached.$gma_11
    __MAML_GLOBAL__.ops_cached.$gma_11=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"chooseContact"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'chooseContact']);
      Z([3,'default']);
      Z([3,'Select Contact']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_11);
    return __MAML_GLOBAL__.ops_cached.$gma_11
  }
  function gz$gma_12(){
    if(__MAML_GLOBAL__.ops_cached.$gma_12)return __MAML_GLOBAL__.ops_cached.$gma_12
    __MAML_GLOBAL__.ops_cached.$gma_12=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"compressImage"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'widthFix']);
      Z([[7],[3,"src"]]);
      Z([3,'width: 300px;']);
      Z([3,'compressImage']);
      Z([3,'compress']);
      Z([3,'Compressed Picture']);
      Z([3,'compressImageFail']);
      Z([3,'compressFail']);
      Z([3,'Compressed Picture:The src is empty']);
      Z([[2,"!"],[[2,"!"],[[7],[3,"info"]]]]);
      Z([3,'result']);
      Z([3,'info']);
      Z([11,[[7],[3,"info"]]]);
      Z([[2,"!"],[[2,"!"],[[7],[3,"filePath"]]]]);
      Z([3,'filePath']);
      Z([11,[[7],[3,"filePath"]]]);
      Z([[2,"!"],[[2,"!"],[[7],[3,"complete"]]]]);
      Z([3,'nbsp']);
      Z([11,[[7],[3,"complete"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_12);
    return __MAML_GLOBAL__.ops_cached.$gma_12
  }
  function gz$gma_13(){
    if(__MAML_GLOBAL__.ops_cached.$gma_13)return __MAML_GLOBAL__.ops_cached.$gma_13
    __MAML_GLOBAL__.ops_cached.$gma_13=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"downloadFile"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'popdownloadFile']);
      Z([3,'downloadFile']);
      Z([3,'primary']);
      Z([3,'Downloading files']);
      Z([3,'downloadFail']);
      Z([3,'The download address is empty']);
      Z([3,'body-view']);
      Z([3,'Switching to the Public Network']);
      Z([3,'isPublicNetChange']);
      Z([[7],[3,"isPublicNet"]]);
      Z([[2,"!"],[[2,"!"],[[7],[3,"info"]]]]);
      Z([3,'result']);
      Z([3,'Returned information']);
      Z([3,'info']);
      Z([11,[[7],[3,"info"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_13);
    return __MAML_GLOBAL__.ops_cached.$gma_13
  }
  function gz$gma_14(){
    if(__MAML_GLOBAL__.ops_cached.$gma_14)return __MAML_GLOBAL__.ops_cached.$gma_14
    __MAML_GLOBAL__.ops_cached.$gma_14=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"saveFile"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'page-body-info']);
      Z([[2,"!="], [[7],[3,"tempFilePath"]], [1,""]]);
      Z([3,'image']);
      Z([3,'aspectFit']);
      Z([[7],[3,"tempFilePath"]]);
      Z([[2,"&&"],[[2,"==="], [[7],[3,"tempFilePath"]], [1,""]],[[2,"!="], [[7],[3,"savedFilePath"]], [1,""]]]);
      Z([[7],[3,"savedFilePath"]]);
      Z([[2,"&&"],[[2,"==="], [[7],[3,"tempFilePath"]], [1,""]],[[2,"==="], [[7],[3,"savedFilePath"]], [1,""]]]);
      Z([3,'chooseImage']);
      Z([3,'image-plus image-plus-nb']);
      Z([3,'image-plus-horizontal']);
      Z([3,'image-plus-vertical']);
      Z([3,'image-plus-text']);
      Z([3,'Please select a file']);
      Z([3,'btn-area']);
      Z([3,'saveFile']);
      Z([3,'primary']);
      Z([3,'Save the file']);
      Z([3,'clear']);
      Z([3,'getFileInfo']);
      Z([3,'Obtaining File Information']);
      Z([3,'getSavedFileInfo']);
      Z([3,'Obtaining Local File Information']);
      Z([3,'getSavedFileList']);
      Z([3,'removeSavedFile']);
      Z([3,'Deleting Local Cache Files']);
      Z([3,'text-area']);
      Z([3,'detail']);
      Z([11,[[7],[3,"detail"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_14);
    return __MAML_GLOBAL__.ops_cached.$gma_14
  }
  function gz$gma_15(){
    if(__MAML_GLOBAL__.ops_cached.$gma_15)return __MAML_GLOBAL__.ops_cached.$gma_15
    __MAML_GLOBAL__.ops_cached.$gma_15=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"getBatteryInfo"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'ma-cells ma-cells_after-title']);
      Z([3,'ma-cell ma-cell_input']);
      Z([3,'ma-cell__hd']);
      Z([3,'ma-label']);
      Z([3,'Current battery level']);
      Z([3,'ma-cell__bd']);
      Z([3,'ma-input battery']);
      Z([1,true]);
      Z([3,'Not obtained']);
      Z([3,'text']);
      Z([[7],[3,"level"]]);
      Z([3,'Battery mode']);
      Z([3,'ma-input']);
      Z([[7],[3,"isCharging"]]);
      Z([3,'getBatteryInfo']);
      Z([3,'primary']);
      Z([3,'Obtaining Battery Level Information']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_15);
    return __MAML_GLOBAL__.ops_cached.$gma_15
  }
  function gz$gma_16(){
    if(__MAML_GLOBAL__.ops_cached.$gma_16)return __MAML_GLOBAL__.ops_cached.$gma_16
    __MAML_GLOBAL__.ops_cached.$gma_16=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"getImageInfo"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'widthFix']);
      Z([[7],[3,"src"]]);
      Z([3,'width: 300px;']);
      Z([[7],[3,"netSrc"]]);
      Z([3,'getImageInfo']);
      Z([3,'getImageInfo2']);
      Z([3,'getImageInfoNet']);
      Z([3,'Obtaining Network Image Information']);
      Z([3,'getImageInfoFail']);
      Z([3,'ImageInfoFail']);
      Z([3,'Obtaining Image Information:The src is empty']);
      Z([[2,"!"],[[2,"!"],[[7],[3,"info"]]]]);
      Z([3,'result']);
      Z([3,'info']);
      Z([11,[[7],[3,"info"]]]);
      Z([[2,"!"],[[2,"!"],[[7],[3,"complete"]]]]);
      Z([3,'nbsp']);
      Z([11,[[7],[3,"complete"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_16);
    return __MAML_GLOBAL__.ops_cached.$gma_16
  }
  function gz$gma_17(){
    if(__MAML_GLOBAL__.ops_cached.$gma_17)return __MAML_GLOBAL__.ops_cached.$gma_17
    __MAML_GLOBAL__.ops_cached.$gma_17=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[9],[[8],"title",[1,"ma.getLocation"]],[[8],"desc",[1,"Obtain the current geographical location and speed"]]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'page-body-info']);
      Z([3,'page-body-text-small']);
      Z([3,'Longitude and latitude of the current position']);
      Z([[2,"==="], [[7],[3,"hasLocation"]], [1,false]]);
      Z([3,'page-body-text']);
      Z([3,'Not obtained']);
      Z([[2,"==="], [[7],[3,"hasLocation"]], [1,true]]);
      Z([3,'page-body-text-location']);
      Z([3,'result']);
      Z([11,[3,'E: '],[[6],[[6],[[7],[3,"location"]],[3,"longitude"]],[1,0]],[3,'°'],[[6],[[6],[[7],[3,"location"]],[3,"longitude"]],[1,1]],[3,'′']]);
      Z([11,[3,'N: '],[[6],[[6],[[7],[3,"location"]],[3,"latitude"]],[1,0]],[3,'°'],[[6],[[6],[[7],[3,"location"]],[3,"latitude"]],[1,1]],[3,'′']]);
      Z([3,'btn-area']);
      Z([3,'getLocation']);
      Z([3,'primary']);
      Z([3,'Get Location']);
      Z([3,'clear']);
      Z([3,'left empty']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_17);
    return __MAML_GLOBAL__.ops_cached.$gma_17
  }
  function gz$gma_18(){
    if(__MAML_GLOBAL__.ops_cached.$gma_18)return __MAML_GLOBAL__.ops_cached.$gma_18
    __MAML_GLOBAL__.ops_cached.$gma_18=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"getNetworkType"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'The network type is：']);
      Z([3,'weui-cells']);
      Z([3,'weui-cell']);
      Z([3,'weui-cell__bd']);
      Z([11,[[7],[3,"network"]]]);
      Z([11,[[7],[3,"complete"]]]);
      Z([3,'getNetworkType']);
      Z([3,'default']);
      Z([3,'Obtain the network type']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_18);
    return __MAML_GLOBAL__.ops_cached.$gma_18
  }
  function gz$gma_19(){
    if(__MAML_GLOBAL__.ops_cached.$gma_19)return __MAML_GLOBAL__.ops_cached.$gma_19
    __MAML_GLOBAL__.ops_cached.$gma_19=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"getSystemInfo"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'mobile phone model']);
      Z([3,'weui-cell__bd']);
      Z([3,'weui-input phoneModel']);
      Z([1,true]);
      Z([3,'Not obtained']);
      Z([3,'text']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"model"]]);
      Z([3,'language']);
      Z([3,'weui-input phonelanguage']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"language"]]);
      Z([3,'Screen width']);
      Z([3,'weui-input phonescreenWidth']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"screenWidth"]]);
      Z([3,'screen height']);
      Z([3,'weui-input phonescreenHeight']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"screenHeight"]]);
      Z([3,'Available window width']);
      Z([3,'weui-input phonewindowWidth']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"windowWidth"]]);
      Z([3,'Available height of window']);
      Z([3,'weui-input phonewindowHeight']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"windowHeight"]]);
      Z([3,'DPI']);
      Z([3,'weui-input phonepixelRatio']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"pixelRatio"]]);
      Z([3,'Status bar height']);
      Z([3,'weui-input phonestatusBarHeight']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"statusBarHeight"]]);
      Z([3,'system information']);
      Z([3,'weui-input phonesystem']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"system"]]);
      Z([3,'device brand']);
      Z([3,'weui-input phonebrand']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"brand"]]);
      Z([3,'btn-area']);
      Z([3,'getSystemInfoSync']);
      Z([3,'getSystemInfo']);
      Z([3,'primary']);
      Z([3,'Synchronize the system information of the mobile phone and update the system information 3 seconds later']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_19);
    return __MAML_GLOBAL__.ops_cached.$gma_19
  }
  function gz$gma_20(){
    if(__MAML_GLOBAL__.ops_cached.$gma_20)return __MAML_GLOBAL__.ops_cached.$gma_20
    __MAML_GLOBAL__.ops_cached.$gma_20=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"getSystemInfo"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'mobile phone model']);
      Z([3,'weui-cell__bd']);
      Z([3,'weui-input phoneModel']);
      Z([1,true]);
      Z([3,'Not obtained']);
      Z([3,'text']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"model"]]);
      Z([3,'language']);
      Z([3,'weui-input phonelanguage']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"language"]]);
      Z([3,'Screen width']);
      Z([3,'weui-input phonescreenWidth']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"screenWidth"]]);
      Z([3,'screen height']);
      Z([3,'weui-input phonescreenHeight']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"screenHeight"]]);
      Z([3,'Available window width']);
      Z([3,'weui-input phonewindowWidth']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"windowWidth"]]);
      Z([3,'Available height of window']);
      Z([3,'weui-input phonewindowHeight']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"windowHeight"]]);
      Z([3,'DPI']);
      Z([3,'weui-input phonepixelRatio']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"pixelRatio"]]);
      Z([3,'Status bar height']);
      Z([3,'weui-input phonestatusBarHeight']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"statusBarHeight"]]);
      Z([3,'system info']);
      Z([3,'weui-input phonesystem']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"system"]]);
      Z([3,'device brand']);
      Z([3,'weui-input phonebrand']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"brand"]]);
      Z([3,'btn-area']);
      Z([3,'getSystemInfo']);
      Z([3,'primary']);
      Z([3,'Obtaining Mobile Phone System Information']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_20);
    return __MAML_GLOBAL__.ops_cached.$gma_20
  }
  function gz$gma_21(){
    if(__MAML_GLOBAL__.ops_cached.$gma_21)return __MAML_GLOBAL__.ops_cached.$gma_21
    __MAML_GLOBAL__.ops_cached.$gma_21=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"getmenuButtonPosInfo"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'width']);
      Z([3,'weui-cell__bd']);
      Z([3,'weui-input']);
      Z([1,true]);
      Z([3,'Not obtained']);
      Z([3,'text']);
      Z([[6],[[7],[3,"menuButtonPosInfo"]],[3,"width"]]);
      Z([3,'height']);
      Z([[6],[[7],[3,"menuButtonPosInfo"]],[3,"height"]]);
      Z([3,'upper boundary coordinate']);
      Z([[6],[[7],[3,"menuButtonPosInfo"]],[3,"top"]]);
      Z([3,'Right boundary coordinate']);
      Z([[6],[[7],[3,"menuButtonPosInfo"]],[3,"right"]]);
      Z([3,'lower boundary coordinate']);
      Z([[6],[[7],[3,"menuButtonPosInfo"]],[3,"bottom"]]);
      Z([3,'Left boundary coordinate']);
      Z([[6],[[7],[3,"menuButtonPosInfo"]],[3,"left"]]);
      Z([3,'btn-area']);
      Z([3,'getMenuButtonPosInfo']);
      Z([3,'primary']);
      Z([3,'Obtains the layout position information of a menu button']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_21);
    return __MAML_GLOBAL__.ops_cached.$gma_21
  }
  function gz$gma_22(){
    if(__MAML_GLOBAL__.ops_cached.$gma_22)return __MAML_GLOBAL__.ops_cached.$gma_22
    __MAML_GLOBAL__.ops_cached.$gma_22=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[9],[[8],"title",[1,"gyroscope"]],[[8],"desc",[1,"Monitor gyroscope changes"]]]);
      Z([3,'page-body']);
      Z([3,'startGyroscope']);
      Z([3,'primary']);
      Z([3,'Start monitoring gyroscope data']);
      Z([3,'stopGyroscope']);
      Z([3,'Stop monitoring gyroscope data']);
      Z([3,'onGyroscopeChange']);
      Z([3,'Monitor gyroscope data change events']);
      Z([3,'offGyroscopeChange']);
      Z([3,'Cancel the monitoring of gyro data change events']);
      Z([3,'text-area']);
      Z([11,[[7],[3,"detail"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_22);
    return __MAML_GLOBAL__.ops_cached.$gma_22
  }
  function gz$gma_23(){
    if(__MAML_GLOBAL__.ops_cached.$gma_23)return __MAML_GLOBAL__.ops_cached.$gma_23
    __MAML_GLOBAL__.ops_cached.$gma_23=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"hideKeyboard"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'weui-cells__title']);
      Z([3,'Focus on the text box below to pop up the keyboard，The keyboard is automatically hidden after 5 seconds']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'unsetAutoHide']);
      Z([3,'setAutoHide']);
      Z([3,'weui-input']);
      Z([3,'After the keyboard is ejected，Auto hide after 5 seconds']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_23);
    return __MAML_GLOBAL__.ops_cached.$gma_23
  }
  function gz$gma_24(){
    if(__MAML_GLOBAL__.ops_cached.$gma_24)return __MAML_GLOBAL__.ops_cached.$gma_24
    __MAML_GLOBAL__.ops_cached.$gma_24=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"toast"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'popLoading']);
      Z([3,'loadingToast']);
      Z([3,'primary']);
      Z([3,'The Loading dialog box is displayed']);
      Z([3,'weui-cells']);
      Z([3,'weui-cell']);
      Z([3,'weui-cell__bd']);
      Z([11,[[7],[3,"result"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_24);
    return __MAML_GLOBAL__.ops_cached.$gma_24
  }
  function gz$gma_25(){
    if(__MAML_GLOBAL__.ops_cached.$gma_25)return __MAML_GLOBAL__.ops_cached.$gma_25
    __MAML_GLOBAL__.ops_cached.$gma_25=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"makePhoneCall"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'desc']);
      Z([3,'Please enter your phone number below']);
      Z([3,'bindInput']);
      Z([3,'phoneNum']);
      Z([3,'input']);
      Z([3,'number']);
      Z([3,'btn-area']);
      Z([3,'makePhoneCall']);
      Z([[7],[3,"disabled"]]);
      Z([3,'primary']);
      Z([3,'call']);
      Z([3,'makePhoneCallFail']);
      Z([3,'nophoneNumber']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_25);
    return __MAML_GLOBAL__.ops_cached.$gma_25
  }
  function gz$gma_26(){
    if(__MAML_GLOBAL__.ops_cached.$gma_26)return __MAML_GLOBAL__.ops_cached.$gma_26
    __MAML_GLOBAL__.ops_cached.$gma_26=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"choose/previewImage"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'image credit']);
      Z([3,'weui-cell__bd']);
      Z([3,'sourceTypeChange']);
      Z([3,'selector']);
      Z([[7],[3,"sourceType"]]);
      Z([[7],[3,"sourceTypeIndex"]]);
      Z([3,'weui-input']);
      Z([11,[[6],[[7],[3,"sourceType"]],[[7],[3,"sourceTypeIndex"]]]]);
      Z([3,'image quality']);
      Z([3,'sizeTypeChange']);
      Z([[7],[3,"sizeType"]]);
      Z([[7],[3,"sizeTypeIndex"]]);
      Z([11,[[6],[[7],[3,"sizeType"]],[[7],[3,"sizeTypeIndex"]]]]);
      Z([3,'quantitative restriction']);
      Z([3,'countChange']);
      Z([[7],[3,"count"]]);
      Z([[7],[3,"countIndex"]]);
      Z([11,[[6],[[7],[3,"count"]],[[7],[3,"countIndex"]]]]);
      Z([3,'weui-cells']);
      Z([3,'weui-cell']);
      Z([3,'weui-uploader']);
      Z([3,'weui-uploader__hd']);
      Z([3,'weui-uploader__title']);
      Z([3,'Touch to preview the selected picture']);
      Z([3,'weui-uploader__info']);
      Z([11,[[6],[[7],[3,"imageList"]],[3,"length"]],[3,'/'],[[6],[[7],[3,"count"]],[[7],[3,"countIndex"]]]]);
      Z([3,'weui-uploader__bd']);
      Z([3,'weui-uploader__files']);
      Z([[7],[3,"imageList"]]);
      Z([3,'image']);
      Z([3,'weui-uploader__file']);
      Z([3,'previewImage']);
      Z([3,'weui-uploader__img']);
      Z([[7],[3,"image"]]);
      Z([3,'weui-uploader__input-box']);
      Z([3,'chooseImage']);
      Z([3,'weui-uploader__input']);
      Z([3,'saveImage']);
      Z([3,'saveImg']);
      Z([3,'Save Picture']);
      Z([3,'previewImage2']);
      Z([3,'previewImageNet']);
      Z([3,'Previewing Network Pictures']);
      Z([3,'previewImageFail']);
      Z([3,'previewFail']);
      Z([3,'Preview Picture:The urls is empty']);
      Z([[2,"!"],[[2,"!"],[[7],[3,"info"]]]]);
      Z([3,'result']);
      Z([3,'info']);
      Z([11,[[7],[3,"info"]]]);
      Z([[2,"!"],[[2,"!"],[[7],[3,"complete"]]]]);
      Z([3,'nbsp']);
      Z([11,[[7],[3,"complete"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_26);
    return __MAML_GLOBAL__.ops_cached.$gma_26
  }
  function gz$gma_27(){
    if(__MAML_GLOBAL__.ops_cached.$gma_27)return __MAML_GLOBAL__.ops_cached.$gma_27
    __MAML_GLOBAL__.ops_cached.$gma_27=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[9],[[8],"title",[1,"onMemoryWarning"]],[[8],"desc",[1,"Interception Performance Changes"]]]);
      Z([3,'page-body']);
      Z([3,'onMemoryWarning']);
      Z([3,'primary']);
      Z([3,'Registering a Listener']);
      Z([3,'offMemoryWarning']);
      Z([3,'Delete a listener']);
      Z([3,'offAll']);
      Z([3,'simulateMemoryWarning']);
      Z([3,'Simulating the Memory Alarm IOS']);
      Z([3,'text-area']);
      Z([11,[[7],[3,"detail"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_27);
    return __MAML_GLOBAL__.ops_cached.$gma_27
  }
  function gz$gma_28(){
    if(__MAML_GLOBAL__.ops_cached.$gma_28)return __MAML_GLOBAL__.ops_cached.$gma_28
    __MAML_GLOBAL__.ops_cached.$gma_28=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"showModal"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'modalSuccess']);
      Z([3,'showModal']);
      Z([3,'primary']);
      Z([3,'modal dialog box']);
      Z([3,'showModal2']);
      Z([3,'confirmText More than four words']);
      Z([3,'showModalEditable']);
      Z([3,'editableIstrue']);
      Z([[2,"!"],[[2,"!"],[[7],[3,"info"]]]]);
      Z([3,'result']);
      Z([11,[[7],[3,"info"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_28);
    return __MAML_GLOBAL__.ops_cached.$gma_28
  }
  function gz$gma_29(){
    if(__MAML_GLOBAL__.ops_cached.$gma_29)return __MAML_GLOBAL__.ops_cached.$gma_29
    __MAML_GLOBAL__.ops_cached.$gma_29=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"navigateTo"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'newPage']);
      Z([3,'new Page']);
      Z([3,'eventChannel']);
      Z([3,'navigateTo']);
      Z([3,'primary']);
      Z([3,'other-navigator-hover']);
      Z([3,'navigateBack']);
      Z([3,'returnPage']);
      Z([3,'default']);
      Z([3,'Return'])
    })(__MAML_GLOBAL__.ops_cached.$gma_29);
    return __MAML_GLOBAL__.ops_cached.$gma_29
  }
  function gz$gma_30(){
    if(__MAML_GLOBAL__.ops_cached.$gma_30)return __MAML_GLOBAL__.ops_cached.$gma_30
    __MAML_GLOBAL__.ops_cached.$gma_30=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"navigate"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'wrapper']);
      Z([3,'Retain the current page and switch to a page in the application. However, the tabbar page cannot be displayed.']);
      Z([3,'navigateTo']);
      Z([3,'primary']);
      Z([3,'Closes the current page and returns to the previous page or multi-level pages.']);
      Z([3,'navigateBack']);
      Z([3,'Close the current page and go to a page in the application. However, the tabbar page cannot be redirected.']);
      Z([3,'redirectTo']);
      Z([3,'The TabBar page is displayed and all non-tabBar pages are closed.']);
      Z([3,'switchTab']);
      Z([3,'Close all pages and open a page in the app.']);
      Z([3,'reLaunch']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_30);
    return __MAML_GLOBAL__.ops_cached.$gma_30
  }
  function gz$gma_31(){
    if(__MAML_GLOBAL__.ops_cached.$gma_31)return __MAML_GLOBAL__.ops_cached.$gma_31
    __MAML_GLOBAL__.ops_cached.$gma_31=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"redirect"]]);
      Z([3,'wrapper navigatorPage']);
      Z([3,'A page']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_31);
    return __MAML_GLOBAL__.ops_cached.$gma_31
  }
  function gz$gma_32(){
    if(__MAML_GLOBAL__.ops_cached.$gma_32)return __MAML_GLOBAL__.ops_cached.$gma_32
    __MAML_GLOBAL__.ops_cached.$gma_32=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[9],[[8],"title",[1,"onNetworkStatusChange"]],[[8],"desc",[1,"Monitors network signal changes"]]]);
      Z([3,'page-body']);
      Z([3,'onNetworkStatusChange']);
      Z([3,'primary']);
      Z([3,'Registering a Listener']);
      Z([3,'offNetworkStatusChange']);
      Z([3,'Deleting a Listener']);
      Z([3,'text-area']);
      Z([11,[[7],[3,"detail"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_32);
    return __MAML_GLOBAL__.ops_cached.$gma_32
  }
  function gz$gma_33(){
    if(__MAML_GLOBAL__.ops_cached.$gma_33)return __MAML_GLOBAL__.ops_cached.$gma_33
    __MAML_GLOBAL__.ops_cached.$gma_33=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"openDocument"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'openDocument']);
      Z([3,'primary']);
      Z([3,'Open a file']);
      Z([3,'body-view']);
      Z([3,'Switching to the Public Network']);
      Z([3,'isPublicNetChange']);
      Z([[7],[3,"isPublicNet"]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_33);
    return __MAML_GLOBAL__.ops_cached.$gma_33
  }
  function gz$gma_34(){
    if(__MAML_GLOBAL__.ops_cached.$gma_34)return __MAML_GLOBAL__.ops_cached.$gma_34
    __MAML_GLOBAL__.ops_cached.$gma_34=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"pullDownRefresh"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'startPullDownRefresh']);
      Z([3,'PullDownRefresh']);
      Z([3,'stopPullDownRefresh']);
      Z([3,'StopPullDownRefresh']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_34);
    return __MAML_GLOBAL__.ops_cached.$gma_34
  }
  function gz$gma_35(){
    if(__MAML_GLOBAL__.ops_cached.$gma_35)return __MAML_GLOBAL__.ops_cached.$gma_35
    __MAML_GLOBAL__.ops_cached.$gma_35=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"request"]]);
      Z([3,'page-body']);
      Z([3,'page-body-wording']);
      Z([3,'page-body-text']);
      Z([11,[[7],[3,"text"]]]);
      Z([3,'btn-area']);
      Z([3,'makeRequest']);
      Z([3,'getRequest']);
      Z([[7],[3,"buttonDisabled"]]);
      Z([[7],[3,"loading"]]);
      Z([3,'primary']);
      Z([3,'request(GET) - get location']);
      Z([3,'makePostRequest']);
      Z([3,'postRequest']);
      Z([[7],[3,"buttonPostDisabled"]]);
      Z([[7],[3,"PostLoading"]]);
      Z([3,'request(POST)- get token']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_35);
    return __MAML_GLOBAL__.ops_cached.$gma_35
  }
  function gz$gma_36(){
    if(__MAML_GLOBAL__.ops_cached.$gma_36)return __MAML_GLOBAL__.ops_cached.$gma_36
    __MAML_GLOBAL__.ops_cached.$gma_36=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"scanCode"]]);
      Z([3,'page-body']);
      Z([3,'weui-cells__title']);
      Z([3,'QR code scanning result']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell']);
      Z([3,'weui-cell__bd result']);
      Z([11,[[7],[3,"result"]]]);
      Z([3,'weui-cell__bd']);
      Z([11,[[7],[3,"complete"]]]);
      Z([3,'btn-area']);
      Z([3,'scanCode']);
      Z([3,'primary']);
      Z([3,'Sweep']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_36);
    return __MAML_GLOBAL__.ops_cached.$gma_36
  }
  function gz$gma_37(){
    if(__MAML_GLOBAL__.ops_cached.$gma_37)return __MAML_GLOBAL__.ops_cached.$gma_37
    __MAML_GLOBAL__.ops_cached.$gma_37=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"get/set/ScreenBrightness"]]);
      Z([3,'page-body']);
      Z([3,'page-body-info']);
      Z([3,'page-body-title']);
      Z([3,'Current screen brightness']);
      Z([3,'page-body-text-screen-brightness']);
      Z([11,[[7],[3,"screenBrightness"]]]);
      Z([3,'page-section page-section-gap']);
      Z([3,'page-section-title']);
      Z([3,'Set screen brightness']);
      Z([3,'body-view']);
      Z([3,'changeBrightness']);
      Z([3,'brightness']);
      Z([3,'1']);
      Z([3,'0']);
      Z([3,'0.1']);
      Z([[7],[3,"screenBrightness"]]);
      Z([3,'setKeepScreenOn']);
      Z([3,'screenBrightness']);
      Z([3,'primary']);
      Z([3,'Set the screen to be steady on']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_37);
    return __MAML_GLOBAL__.ops_cached.$gma_37
  }
  function gz$gma_38(){
    if(__MAML_GLOBAL__.ops_cached.$gma_38)return __MAML_GLOBAL__.ops_cached.$gma_38
    __MAML_GLOBAL__.ops_cached.$gma_38=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"setBackground"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'style']);
      Z([3,'weui-cell__bd']);
      Z([3,'textStyleChange']);
      Z([3,'weui-input']);
      Z([3,'textStyle']);
      Z([3,'PleaseEnter textStyle']);
      Z([3,'text']);
      Z([[7],[3,"textStyle"]]);
      Z([3,'background colo']);
      Z([3,'backgroundColorChange']);
      Z([3,'backgroundColor']);
      Z([3,'PleaseEnter backgroundColor']);
      Z([[7],[3,"backgroundColor"]]);
      Z([3,'btn-area']);
      Z([3,'setBackgroundTextStyle']);
      Z([3,'Setting the Loading Style']);
      Z([3,'setBackgroundColor']);
      Z([3,'Sets the window background color']);
      Z([3,'dropDown']);
      Z([3,'onPullDownRefresh']);
      Z([3,'primary']);
      Z([3,'pull to refresh']);
      Z([3,'text-area']);
      Z([3,'message']);
      Z([3,'white-space: pre-line;']);
      Z([11,[[7],[3,"detail"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_38);
    return __MAML_GLOBAL__.ops_cached.$gma_38
  }
  function gz$gma_39(){
    if(__MAML_GLOBAL__.ops_cached.$gma_39)return __MAML_GLOBAL__.ops_cached.$gma_39
    __MAML_GLOBAL__.ops_cached.$gma_39=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"setNavigationBarColor"]]);
      Z([3,'setNavigationBarColor']);
      Z([3,'page-body']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'Foreground color value']);
      Z([3,'weui-cell__bd']);
      Z([3,'frontColorChange']);
      Z([3,'weui-input']);
      Z([3,'frontColor']);
      Z([3,'Please enter a hexadecimal color']);
      Z([3,'text']);
      Z([[7],[3,"frontColor"]]);
      Z([3,'Background color value']);
      Z([3,'backgroundColorChange']);
      Z([3,'backgroundColor']);
      Z([[7],[3,"backgroundColor"]]);
      Z([3,'btn-area']);
      Z([3,'submit']);
      Z([3,'primary']);
      Z([3,'set']);
      Z([3,'text-area']);
      Z([3,'message']);
      Z([3,'white-space: pre-line;']);
      Z([11,[[7],[3,"detail"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_39);
    return __MAML_GLOBAL__.ops_cached.$gma_39
  }
  function gz$gma_40(){
    if(__MAML_GLOBAL__.ops_cached.$gma_40)return __MAML_GLOBAL__.ops_cached.$gma_40
    __MAML_GLOBAL__.ops_cached.$gma_40=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"setNavigationBarTitle"]]);
      Z([3,'setNavigationBarTitle']);
      Z([3,'page-body']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'Page Title']);
      Z([3,'weui-cell__bd']);
      Z([3,'weui-input']);
      Z([3,'title']);
      Z([3,'Enter the page title and click Settings']);
      Z([3,'text']);
      Z([3,'btn-area']);
      Z([3,'submit']);
      Z([3,'primary']);
      Z([3,'set']);
      Z([3,'setNavigationBarTitleFail']);
      Z([3,'No title setting']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_40);
    return __MAML_GLOBAL__.ops_cached.$gma_40
  }
  function gz$gma_41(){
    if(__MAML_GLOBAL__.ops_cached.$gma_41)return __MAML_GLOBAL__.ops_cached.$gma_41
    __MAML_GLOBAL__.ops_cached.$gma_41=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"action-sheet"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'actionSheetTap']);
      Z([3,'showActionSheet']);
      Z([3,'primary']);
      Z([3,'The action sheet is displayed']);
      Z([3,'showActionSheetFail']);
      Z([3,'The value of itemList is greater than 6']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_41);
    return __MAML_GLOBAL__.ops_cached.$gma_41
  }
  function gz$gma_42(){
    if(__MAML_GLOBAL__.ops_cached.$gma_42)return __MAML_GLOBAL__.ops_cached.$gma_42
    __MAML_GLOBAL__.ops_cached.$gma_42=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"get/set/clearStorage"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'ma-cells ma-cells_after-title']);
      Z([3,'ma-cell ma-cell_input']);
      Z([3,'ma-cell__hd']);
      Z([3,'ma-label']);
      Z([3,'key']);
      Z([3,'ma-cell__bd']);
      Z([3,'keyChange']);
      Z([3,'ma-input']);
      Z([3,'Enter a key']);
      Z([3,'text']);
      Z([[7],[3,"key"]]);
      Z([3,'value']);
      Z([3,'dataChange']);
      Z([3,'-1']);
      Z([3,'data']);
      Z([3,'Enter a value']);
      Z([[7],[3,"data"]]);
      Z([3,'btn-area']);
      Z([3,'setStorage']);
      Z([3,'primary']);
      Z([3,'Synchronizing Storage Data']);
      Z([3,'getStorage']);
      Z([3,'Read data synchronously']);
      Z([3,'clearStorage']);
      Z([3,'Clearing Data']);
      Z([3,'setStorageWithObj']);
      Z([3,'setStorageJson']);
      Z([3,'Synchronize storage objects {a:1,b:2}']);
      Z([3,'setStorageWithObjArray']);
      Z([3,'setStorageJsonArray']);
      Z([3,'Synchronous storage with array JSON']);
      Z([3,'getStorageWithObj']);
      Z([3,'']);
      Z([3,'Synchronous Read Object {a:1,b:2}']);
      Z([3,'setStorageWithDate']);
      Z([3,'setStorageDate']);
      Z([3,'Synchronize Storage Date Object']);
      Z([3,'getStorageWithDate']);
      Z([3,'getStorageDate']);
      Z([3,'Synchronous Read Date Object']);
      Z([3,'setStorageWithAarryBuffer']);
      Z([3,'setStoragefun']);
      Z([3,'Synchronous Storage Unsupported Type']);
      Z([3,'getStorageWithAarryBuffer']);
      Z([3,'getStoragefun']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_42);
    return __MAML_GLOBAL__.ops_cached.$gma_42
  }
  function gz$gma_43(){
    if(__MAML_GLOBAL__.ops_cached.$gma_43)return __MAML_GLOBAL__.ops_cached.$gma_43
    __MAML_GLOBAL__.ops_cached.$gma_43=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"get/set/clearStorage"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'ma-cells ma-cells_after-title']);
      Z([3,'ma-cell ma-cell_input']);
      Z([3,'ma-cell__hd']);
      Z([3,'ma-label']);
      Z([3,'key']);
      Z([3,'ma-cell__bd']);
      Z([3,'keyChange']);
      Z([3,'ma-input']);
      Z([3,'Enter a key']);
      Z([3,'text']);
      Z([[7],[3,"key"]]);
      Z([3,'value']);
      Z([3,'dataChange']);
      Z([3,'data']);
      Z([3,'Enter a value']);
      Z([[7],[3,"data"]]);
      Z([3,'btn-area']);
      Z([3,'setStorage']);
      Z([3,'primary']);
      Z([3,'stored data']);
      Z([3,'getStorage']);
      Z([3,'Read Data']);
      Z([3,'getStorageInfo']);
      Z([3,'Obtains the current storage']);
      Z([3,'removeStorage']);
      Z([3,'Remove Data']);
      Z([3,'clearStorage']);
      Z([3,'Clearing Data']);
      Z([3,'setStorageWithObj']);
      Z([3,'Storage objects {a:1,b:2}']);
      Z([3,'getStorageWithObj']);
      Z([3,'Read object {a:1,b:2}']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_43);
    return __MAML_GLOBAL__.ops_cached.$gma_43
  }
  function gz$gma_44(){
    if(__MAML_GLOBAL__.ops_cached.$gma_44)return __MAML_GLOBAL__.ops_cached.$gma_44
    __MAML_GLOBAL__.ops_cached.$gma_44=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"toast"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'popSuccess']);
      Z([3,'successToast']);
      Z([3,'primary']);
      Z([3,'Success']);
      Z([3,'popError']);
      Z([3,'errorToast']);
      Z([3,'warn']);
      Z([3,'failed']);
      Z([3,'popLoading']);
      Z([3,'loadingToast']);
      Z([3,'default']);
      Z([3,'wait']);
      Z([3,'popimage']);
      Z([3,'imgToast']);
      Z([3,'Image']);
      Z([3,'popOther']);
      Z([3,'otherToast']);
      Z([3,'Other']);
      Z([3,'mask']);
      Z([3,'maskToast']);
      Z([3,'Show Mask']);
      Z([3,'close']);
      Z([3,'closeToast']);
      Z([3,'Close the dialog box']);
      Z([3,'Enter text to display']);
      Z([3,'margin-top: 20px; border: 1px solid #1aad19;']);
      Z([[7],[3,"toastTitle"]]);
      Z([3,'popInput']);
      Z([3,'inputToast']);
      Z([3,'Show entered text']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_44);
    return __MAML_GLOBAL__.ops_cached.$gma_44
  }
  function gz$gma_45(){
    if(__MAML_GLOBAL__.ops_cached.$gma_45)return __MAML_GLOBAL__.ops_cached.$gma_45
    __MAML_GLOBAL__.ops_cached.$gma_45=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"uploadFile"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'popuploadFile']);
      Z([3,'uploadFile']);
      Z([3,'UploadAFile']);
      Z([3,'UploadAFile：nameNull']);
      Z([3,'uploadFile2']);
      Z([3,'UploadAFile：urlNull']);
      Z([3,'uploadFile3']);
      Z([3,'UploadAFile：filePathNull']);
      Z([[2,"!"],[[2,"!"],[[7],[3,"info"]]]]);
      Z([3,'result']);
      Z([3,'-1']);
      Z([[7],[3,"info"]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_45);
    return __MAML_GLOBAL__.ops_cached.$gma_45
  }
  function gz$gma_46(){
    if(__MAML_GLOBAL__.ops_cached.$gma_46)return __MAML_GLOBAL__.ops_cached.$gma_46
    __MAML_GLOBAL__.ops_cached.$gma_46=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"vibrate"]]);
      Z([3,'page-body']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'Vibration intensity']);
      Z([3,'weui-cell__bd']);
      Z([3,'typeChange']);
      Z([3,'selector']);
      Z([[7],[3,"type"]]);
      Z([[7],[3,"typeIndex"]]);
      Z([3,'weui-input']);
      Z([11,[[6],[[7],[3,"type"]],[[7],[3,"typeIndex"]]]]);
      Z([3,'btn-area']);
      Z([3,'vibrateLong']);
      Z([3,'primary']);
      Z([3,'long vibration']);
      Z([3,'vibrateShort']);
      Z([3,'default']);
      Z([3,'short vibration']);
      Z([3,'weui-cell']);
      Z([3,'weui-cell__bd result']);
      Z([11,[[7],[3,"result"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_46);
    return __MAML_GLOBAL__.ops_cached.$gma_46
  }
  function gz$gma_47(){
    if(__MAML_GLOBAL__.ops_cached.$gma_47)return __MAML_GLOBAL__.ops_cached.$gma_47
    __MAML_GLOBAL__.ops_cached.$gma_47=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"WebSocket"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell']);
      Z([3,'weui-cell__bd']);
      Z([3,'ws url']);
      Z([3,'weui-cell__ft']);
      Z([3,'wsurl']);
      Z([3,'Enter the WS service address']);
      Z([3,'width: 80%; text-align: left']);
      Z([[7],[3,"wsUrl"]]);
      Z([3,'code (when disabled)']);
      Z([3,'closecode']);
      Z([3,'Enter the close status code']);
      Z([3,'width: 62%; text-align: left']);
      Z([3,'number']);
      Z([[7],[3,"closeCode"]]);
      Z([3,'reason (when disabled)']);
      Z([3,'closereason']);
      Z([3,'Enter the close reaso']);
      Z([[7],[3,"closeReason"]]);
      Z([3,'weui-cell weui-cell_switch']);
      Z([3,'SocketStatus']);
      Z([3,'toggleSocket']);
      Z([[2,"!"],[[7],[3,"hasLogin"]]]);
      Z([3,'message']);
      Z([3,'websockermsg']);
      Z([3,'Enter a message to send']);
      Z([[7],[3,"messageToSend"]]);
      Z([3,'btn-area']);
      Z([3,'sendMessage']);
      Z([3,'send']);
      Z([[7],[3,"loading"]]);
      Z([3,'40']);
      Z([3,'primary']);
      Z([3,'Click me to send']);
      Z([3,' weui-cell my-cell']);
      Z([3,'API fail callback error information:']);
      Z([3,'weui-cell__ft my-weui-cell__ft']);
      Z([3,'apifail']);
      Z([11,[[7],[3,"errMsg"]]]);
      Z([3,'Intercepted Data OnOpen：']);
      Z([3,'openmsg']);
      Z([11,[[7],[3,"onOpenData"]]]);
      Z([3,'weui-cell my-cell']);
      Z([3,'weui-cell__bd ']);
      Z([3,'Intercepted Data OnClose：']);
      Z([3,'closemsg']);
      Z([11,[[7],[3,"onCloseData"]]]);
      Z([3,'Intercepted Data OnMessage: (communication message)']);
      Z([3,'onmsg']);
      Z([11,[[7],[3,"onMessageData"]]]);
      Z([3,'Intercepted Data OnError: (error information)']);
      Z([3,'OnError']);
      Z([11,[[7],[3,"onErrorData"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_47);
    return __MAML_GLOBAL__.ops_cached.$gma_47
  }
  function gz$gma_48(){
    if(__MAML_GLOBAL__.ops_cached.$gma_48)return __MAML_GLOBAL__.ops_cached.$gma_48
    __MAML_GLOBAL__.ops_cached.$gma_48=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'page-foot']);
      Z([3,'none']);
      Z([3,'switchTab']);
      Z([3,'/page/tabbar/component/index']);
      Z([3,'icon-foot']);
      Z([3,'../../../../image/icon_foot.png'])
    })(__MAML_GLOBAL__.ops_cached.$gma_48);
    return __MAML_GLOBAL__.ops_cached.$gma_48
  }
  function gz$gma_49(){
    if(__MAML_GLOBAL__.ops_cached.$gma_49)return __MAML_GLOBAL__.ops_cached.$gma_49
    __MAML_GLOBAL__.ops_cached.$gma_49=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'page-head']);
      Z([3,'page-head-title']);
      Z([11,[[7],[3,"title"]]]);
      Z([3,'page-head-line']);
      Z([[7],[3,"desc"]]);
      Z([3,'page-head-desc']);
      Z([11,[[7],[3,"desc"]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_49);
    return __MAML_GLOBAL__.ops_cached.$gma_49
  }
  function gz$gma_50(){
    if(__MAML_GLOBAL__.ops_cached.$gma_50)return __MAML_GLOBAL__.ops_cached.$gma_50
    __MAML_GLOBAL__.ops_cached.$gma_50=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"audio"]]);
      Z([3,'page-body']);
      Z([3,'page-section page-section-gap']);
      Z([3,'text-align: center;']);
      Z([[7],[3,"author"]]);
      Z([3,'bindended']);
      Z([3,'binderror']);
      Z([3,'bindpause']);
      Z([3,'bindplay']);
      Z([3,'bindtimeupdate']);
      Z([[7],[3,"controls"]]);
      Z([3,'myAudio']);
      Z([[7],[3,"loop"]]);
      Z([[7],[3,"name"]]);
      Z([[7],[3,"poster"]]);
      Z([[7],[3,"src"]]);
      Z([3,'text-align: left']);
      Z([3,'section section_gap']);
      Z([3,'section__title']);
      Z([3,'playout']);
      Z([3,'body-view playbutton']);
      Z([3,'playAudio']);
      Z([3,'pause']);
      Z([3,'body-view pausebutton']);
      Z([3,'pauseAudio']);
      Z([3,'Progress jump']);
      Z([3,'body-view seekbutton']);
      Z([3,'seekAudio']);
      Z([3,'Jump to 30 seconds']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_50);
    return __MAML_GLOBAL__.ops_cached.$gma_50
  }
  function gz$gma_51(){
    if(__MAML_GLOBAL__.ops_cached.$gma_51)return __MAML_GLOBAL__.ops_cached.$gma_51
    __MAML_GLOBAL__.ops_cached.$gma_51=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"button"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'buttonContainer']);
      Z([3,'hoverclass']);
      Z([3,'200']);
      Z([3,'5000']);
      Z([3,'btn-area1']);
      Z([3,'default']);
      Z([3,'primary']);
      Z([3,'Main operations on the page Normal']);
      Z([3,'btn-area2']);
      Z([3,'true']);
      Z([3,'Main operations on the page Loading']);
      Z([3,'btn-area3']);
      Z([3,'Main operations on the page Disabled']);
      Z([3,'btn-area4']);
      Z([3,'buttonHoverclass']);
      Z([3,'2000']);
      Z([3,'1000']);
      Z([3,'Page Minor Operations Normal']);
      Z([3,'btn-area5']);
      Z([3,'Page Minor Operations Disabled']);
      Z([3,'btn-area6']);
      Z([3,'false']);
      Z([3,'none']);
      Z([3,'warn']);
      Z([3,'Warning operations Normal']);
      Z([3,'btn-area7']);
      Z([3,'Warning operations Disabled']);
      Z([3,'btn-area8']);
      Z([3,'button-hover']);
      Z([3,'Page Minor Operations hover']);
      Z([3,'button-sp-area']);
      Z([3,'button-sp-area1']);
      Z([3,'button']);
      Z([3,'button-sp-area2']);
      Z([3,'Non-Clickable Buttons']);
      Z([3,'button-sp-area3']);
      Z([3,'button-sp-area4']);
      Z([3,'mini-btn mini-btn1']);
      Z([3,'mini']);
      Z([3,'mini-btn mini-btn2']);
      Z([3,'mini-btn mini-btn3']);
      Z([3,'button-area-abnormal']);
      Z([3,'3000']);
      Z([3,'button-area-abnormal1']);
      Z([3,'abc']);
      Z([3,'Invalid value test button 1']);
      Z([3,'button-area-abnormal2']);
      Z([3,'123']);
      Z([3,'Invalid value test button 2']);
      Z([3,'button-area-abnormal3']);
      Z([3,'Invalid value test button 3']);
      Z([3,'button-area-abnormal4']);
      Z([3,'Invalid value test button 4']);
      Z([3,'button-area-abnormal5']);
      Z([3,'Invalid value test button 5']);
      Z([3,'button-area-abnormal6']);
      Z([3,'Invalid value test button 6']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_51);
    return __MAML_GLOBAL__.ops_cached.$gma_51
  }
  function gz$gma_52(){
    if(__MAML_GLOBAL__.ops_cached.$gma_52)return __MAML_GLOBAL__.ops_cached.$gma_52
    __MAML_GLOBAL__.ops_cached.$gma_52=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"Camera"]]);
      Z([3,'error']);
      Z([3,'stop']);
      Z([[7],[3,"position"]]);
      Z([[7],[3,"flash"]]);
      Z([3,'width: 100%; height: 300px;']);
      Z([3,'takePhoto']);
      Z([3,'takephoto']);
      Z([3,'primary']);
      Z([3,'TakeAphoto']);
      Z([3,'takePosition']);
      Z([3,'SwitchCameras']);
      Z([3,'takeFlash']);
      Z([3,'TurnOnTheFlash']);
      Z([3,'preview']);
      Z([[7],[3,"src"]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_52);
    return __MAML_GLOBAL__.ops_cached.$gma_52
  }
  function gz$gma_53(){
    if(__MAML_GLOBAL__.ops_cached.$gma_53)return __MAML_GLOBAL__.ops_cached.$gma_53
    __MAML_GLOBAL__.ops_cached.$gma_53=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"checkbox"]]);
      Z([3,'page-body']);
      Z([3,'page-section page-section-gap']);
      Z([3,'page-section-title']);
      Z([3,'default styl']);
      Z([3,'checkbox']);
      Z([3,'true']);
      Z([3,'checkbox1']);
      Z([3,'#09BB07']);
      Z([3,'cb']);
      Z([3,'checked']);
      Z([3,'checkbox2']);
      Z([3,'Unchecked']);
      Z([3,'page-section']);
      Z([3,'Recommended display style']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'checkboxChange']);
      Z([[7],[3,"items"]]);
      Z([[6],[[7],[3,"item"]],[3,"value"]]);
      Z([3,'weui-cell weui-check__label']);
      Z([3,'weui-cell__hd']);
      Z([[6],[[7],[3,"item"]],[3,"checked"]]);
      Z([11,[3,'checkbox-'],[[6],[[7],[3,"item"]],[3,"value"]]]);
      Z([3,'pink']);
      Z([3,'weui-cell__bd']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_53);
    return __MAML_GLOBAL__.ops_cached.$gma_53
  }
  function gz$gma_54(){
    if(__MAML_GLOBAL__.ops_cached.$gma_54)return __MAML_GLOBAL__.ops_cached.$gma_54
    __MAML_GLOBAL__.ops_cached.$gma_54=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"cover-image"]]);
      Z([3,'error']);
      Z([3,'back']);
      Z([3,'off']);
      Z([3,'width: 100%; height: 300px;']);
      Z([3,'cover-image']);
      Z([3,'https://img.jianbihua.com/sites/default/files/styles/photo640x425logofull/public/images/2020-08/20200824151352_903065.jpg']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_54);
    return __MAML_GLOBAL__.ops_cached.$gma_54
  }
  function gz$gma_55(){
    if(__MAML_GLOBAL__.ops_cached.$gma_55)return __MAML_GLOBAL__.ops_cached.$gma_55
    __MAML_GLOBAL__.ops_cached.$gma_55=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"cover-view"]]);
      Z([3,'changeColor']);
      Z([3,'12345']);
      Z([3,'error']);
      Z([3,'back']);
      Z([3,'off']);
      Z([3,'width: 100%; height: 720rpx;']);
      Z([3,'cover-view']);
      Z([11,[3,'c-cover-view '],[[7],[3,"red"]]]);
      Z([3,'This is red']);
      Z([3,'c-cover-view green']);
      Z([3,'This is green']);
      Z([3,'c-cover-view yellow']);
      Z([3,'This is yellow']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_55);
    return __MAML_GLOBAL__.ops_cached.$gma_55
  }
  function gz$gma_56(){
    if(__MAML_GLOBAL__.ops_cached.$gma_56)return __MAML_GLOBAL__.ops_cached.$gma_56
    __MAML_GLOBAL__.ops_cached.$gma_56=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"form"]]);
      Z([3,'page-body']);
      Z([3,'reset']);
      Z([3,'submit']);
      Z([3,'form']);
      Z([3,'page-section page-section-gap']);
      Z([3,'page-section-title']);
      Z([3,'switch']);
      Z([3,'radio']);
      Z([3,'radioGroup']);
      Z([3,'radio1']);
      Z([3,'Option1']);
      Z([3,'radio2']);
      Z([3,'Option2']);
      Z([3,'checkbox']);
      Z([3,'checkboxGroup']);
      Z([3,'checkbox1']);
      Z([3,'checkbox2']);
      Z([3,'slider']);
      Z([3,'slider1']);
      Z([3,'true']);
      Z([3,'50']);
      Z([3,'page-section']);
      Z([3,'input']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__bd']);
      Z([3,'weui-input']);
      Z([3,'input1']);
      Z([3,'This is an input box']);
      Z([3,'btn-area']);
      Z([3,'primary']);
      Z([3,'Submit']);
      Z([3,'Reset']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_56);
    return __MAML_GLOBAL__.ops_cached.$gma_56
  }
  function gz$gma_57(){
    if(__MAML_GLOBAL__.ops_cached.$gma_57)return __MAML_GLOBAL__.ops_cached.$gma_57
    __MAML_GLOBAL__.ops_cached.$gma_57=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"icon"]]);
      Z([3,'icon-box']);
      Z([3,'icon-box-img icon1']);
      Z([3,'93']);
      Z([3,'success']);
      Z([3,'icon-box-ctn']);
      Z([3,'icon-box-title']);
      Z([3,'icon-box-desc']);
      Z([3,'Used to indicate that the operation completed successfully.']);
      Z([3,'icon-box-img icon2']);
      Z([3,'info']);
      Z([3,'Indicates the information prompt. It is also used to intercept operations without conditions, prompting users of required information.']);
      Z([3,'icon-box-img icon3']);
      Z([3,'#C9C9C9']);
      Z([3,'warn']);
      Z([3,'Indicates the situation that will result in certain consequences after the operation. Also used to indicate negative results due to system reasons']);
      Z([3,'icon-box-img icon4']);
      Z([3,'Strong warning']);
      Z([3,'Indicates the negative result caused by the user. Also used to indicate that the operation will result in irreparable consequences.']);
      Z([3,'icon-box-img icon5']);
      Z([3,'waiting']);
      Z([3,'This parameter indicates that the user needs to wait for the result.']);
      Z([3,'icon-small-wrp']);
      Z([3,'icon-small']);
      Z([3,'23']);
      Z([3,'Multi-Selection Control Icon_Selected']);
      Z([3,'Used in a multi-selection control to indicate that the item has been selected.']);
      Z([3,'icon-small icon6']);
      Z([3,'circle']);
      Z([3,'Multi-Selection Control Icon_Not Selected']);
      Z([3,'Used in the multi-selection control to indicate that the item can be selected but has not been selected.']);
      Z([3,'Error message']);
      Z([3,'Used to indicate an error in a form']);
      Z([3,'icon-small icon7']);
      Z([3,'success_no_circle']);
      Z([3,'Radio Control Icon_Selected']);
      Z([3,'Used in a radio control to indicate that the item has been selected.']);
      Z([3,'icon-small icon8']);
      Z([3,'download']);
      Z([3,'Used to indicate downloadable']);
      Z([3,'icon-small icon9']);
      Z([3,'info_circle']);
      Z([3,'Used to indicate an information prompt in a form']);
      Z([3,'icon-small icon10']);
      Z([3,'cancel']);
      Z([3,'Stop or Shut Down']);
      Z([3,'Used in a form to indicate shutdown or stop']);
      Z([3,'icon-small icon11']);
      Z([3,'14']);
      Z([3,'search']);
      Z([3,'Used in search controls, indicating that searchable']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_57);
    return __MAML_GLOBAL__.ops_cached.$gma_57
  }
  function gz$gma_58(){
    if(__MAML_GLOBAL__.ops_cached.$gma_58)return __MAML_GLOBAL__.ops_cached.$gma_58
    __MAML_GLOBAL__.ops_cached.$gma_58=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"image"]]);
      Z([3,'page-body']);
      Z([[7],[3,"array"]]);
      Z([3,'item']);
      Z([3,'page-section page-section-gap']);
      Z([3,'page-section-title']);
      Z([11,[[6],[[7],[3,"item"]],[3,"text"]]]);
      Z([3,'page-section-ctn']);
      Z([3,'binderror']);
      Z([3,'bindload']);
      Z([11,[3,'image'],[[7],[3,"index"]]]);
      Z([[6],[[7],[3,"item"]],[3,"mode"]]);
      Z([[7],[3,"src"]]);
      Z([3,'widthFix：width200px，The width-to-height ratio remains unchanged.']);
      Z([3,'image-widthFix']);
      Z([3,'widthFix']);
      Z([3,'heightFix：height200px，The width-to-height ratio remains unchanged.']);
      Z([3,'image-heightFix']);
      Z([3,'heightFix']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_58);
    return __MAML_GLOBAL__.ops_cached.$gma_58
  }
  function gz$gma_59(){
    if(__MAML_GLOBAL__.ops_cached.$gma_59)return __MAML_GLOBAL__.ops_cached.$gma_59
    __MAML_GLOBAL__.ops_cached.$gma_59=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"input"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'weui-cells__title']);
      Z([3,'disabled input']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-input input0']);
      Z([3,'true']);
      Z([3,'This is an inoperable input.']);
      Z([3,'Input that can be auto-focused']);
      Z([3,'bindblur']);
      Z([3,'bindconfirm']);
      Z([3,'bindfocus']);
      Z([3,'weui-input input16']);
      Z([3,'done']);
      Z([3,'Will get focus']);
      Z([3,'3']);
      Z([3,'1']);
      Z([3,'Display focus range']);
      Z([3,'Input that controls the maximum input length.']);
      Z([3,'weui-input input1']);
      Z([3,'12']);
      Z([3,'The value contains a maximum of 10 characters.']);
      Z([3,'1234567890111']);
      Z([3,'weui-cells__title inputvalue']);
      Z([11,[3,'Obtain input values in real time:'],[[7],[3,"inputValue"]]]);
      Z([3,'bindKeyInput']);
      Z([3,'weui-input input2']);
      Z([3,'Synchronize input to view']);
      Z([3,'Controls the input.']);
      Z([3,'bindReplaceInput']);
      Z([3,'weui-input input3']);
      Z([3,'Two consecutive ones become two.']);
      Z([3,'Directly return the input of the character string.']);
      Z([3,'bindinput']);
      Z([3,'weui-input input4']);
      Z([3,'Directly return a character string.']);
      Z([3,'digit']);
      Z([3,'Digital input']);
      Z([3,'weui-input input5']);
      Z([3,'This is a number entry box.']);
      Z([3,'number']);
      Z([3,'Password input']);
      Z([3,'weui-input input6']);
      Z([3,'This is a password entry box.']);
      Z([3,'text']);
      Z([3,'Input that controls the color of the placeholder']);
      Z([3,'weui-input input8']);
      Z([3,'Placeholder font is red']);
      Z([3,'placeholderclass']);
      Z([3,'color:#F76260']);
      Z([3,'Input that does not collapse when you click the lower right corner of the keyboard']);
      Z([3,'weui-input']);
      Z([3,'Keep the keyboard unstuck']);
      Z([3,'weui-cells__title inputmode']);
      Z([11,[3,'The input value of bidirectional binding is '],[[7],[3,"modelValue"]]]);
      Z([3,'weui-input input9']);
      Z([[7],[3,"modelValue"]]);
      Z([3,'ID Card Input Keyboard']);
      Z([3,'weui-input input10']);
      Z([3,'idcard']);
      Z([3,'Password Security Keyboard']);
      Z([3,'weui-input input11']);
      Z([3,'safe-password']);
      Z([3,'Nickname Entry Keyboard']);
      Z([3,'weui-input input12']);
      Z([3,'nickname']);
      Z([3,'Automatic test input 1']);
      Z([3,'weui-input input13']);
      Z([3,'search']);
      Z([3,'Auto input 1_placeholder style']);
      Z([3,'font-size:20px;font-weight:800']);
      Z([3,'Automatic test input 2']);
      Z([3,'weui-input input14']);
      Z([3,'send']);
      Z([3,'Automatic input 2_confirmType']);
      Z([3,'Automatic test input 3']);
      Z([3,'weui-input input15']);
      Z([3,'next']);
      Z([3,'AutoInput 3_placeholder Style Class']);
      Z([3,'Automatic test input 4']);
      Z([3,'go']);
      Z([3,'Automated Input 4']);
      Z([3,'Automatic test input 5']);
      Z([3,'false']);
      Z([3,'weui-input input17']);
      Z([3,'2']);
      Z([3,'Automated Input 5']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_59);
    return __MAML_GLOBAL__.ops_cached.$gma_59
  }
  function gz$gma_60(){
    if(__MAML_GLOBAL__.ops_cached.$gma_60)return __MAML_GLOBAL__.ops_cached.$gma_60
    __MAML_GLOBAL__.ops_cached.$gma_60=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"label"]]);
      Z([3,'page-body']);
      Z([3,'page-section page-section-gap']);
      Z([3,'page-section-title']);
      Z([3,'The form component is in the label.']);
      Z([3,'checkboxChange']);
      Z([3,'group']);
      Z([3,'checkboxGroup']);
      Z([[7],[3,"checkboxItems"]]);
      Z([3,'label-1']);
      Z([3,'label1']);
      Z([[6],[[7],[3,"item"]],[3,"checked"]]);
      Z([3,'checkbox1']);
      Z([[6],[[7],[3,"item"]],[3,"name"]]);
      Z([3,'label-1-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"value"]]]);
      Z([3,'label Use for to identify form components']);
      Z([3,'radioChange']);
      Z([3,'radioGroup']);
      Z([[7],[3,"radioItems"]]);
      Z([3,'label-2']);
      Z([3,'pink']);
      Z([3,'label-2-text']);
      Z([[6],[[7],[3,"item"]],[3,"value"]]);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([3,'Select the first label if there are multiple labels.']);
      Z([3,'label-3']);
      Z([3,'checkbox-3']);
      Z([3,'checkbox2']);
      Z([3,'Option 1']);
      Z([3,'checkbox3']);
      Z([3,'label-3-text']);
      Z([3,'Click the text under the label and select the first check box by default.']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_60);
    return __MAML_GLOBAL__.ops_cached.$gma_60
  }
  function gz$gma_61(){
    if(__MAML_GLOBAL__.ops_cached.$gma_61)return __MAML_GLOBAL__.ops_cached.$gma_61
    __MAML_GLOBAL__.ops_cached.$gma_61=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"navigate"]]);
      Z([3,'page-body']);
      Z([3,'']);
      Z([3,'false']);
      Z([3,'Page 1']);
      Z([3,'btn-area']);
      Z([3,'2']);
      Z([3,'other-navigator-hover']);
      Z([3,'navigateBack']);
      Z([3,'default']);
      Z([3,'Return to Home Page']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_61);
    return __MAML_GLOBAL__.ops_cached.$gma_61
  }
  function gz$gma_62(){
    if(__MAML_GLOBAL__.ops_cached.$gma_62)return __MAML_GLOBAL__.ops_cached.$gma_62
    __MAML_GLOBAL__.ops_cached.$gma_62=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"navigator"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'navigator']);
      Z([3,'navigate']);
      Z([3,'default']);
      Z([3,'navigateTopage1']);
      Z([3,'other-navigator-hover']);
      Z([3,'redirect']);
      Z([3,'redirectTopage2']);
      Z([3,'custom-navigator-hover']);
      Z([3,'switchTab']);
      Z([3,'/page/tabbar/component/index']);
      Z([3,'reLaunch']);
      Z([3,'reLaunchTopage3']);
      Z([3,'1']);
      Z([3,'navigateBack']);
      Z([3,'Return']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_62);
    return __MAML_GLOBAL__.ops_cached.$gma_62
  }
  function gz$gma_63(){
    if(__MAML_GLOBAL__.ops_cached.$gma_63)return __MAML_GLOBAL__.ops_cached.$gma_63
    __MAML_GLOBAL__.ops_cached.$gma_63=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"redirect"]]);
      Z([3,'page-body']);
      Z([3,'page 2']);
      Z([3,'btn-area']);
      Z([3,'navigateBack']);
      Z([3,'default']);
      Z([3,'return']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_63);
    return __MAML_GLOBAL__.ops_cached.$gma_63
  }
  function gz$gma_64(){
    if(__MAML_GLOBAL__.ops_cached.$gma_64)return __MAML_GLOBAL__.ops_cached.$gma_64
    __MAML_GLOBAL__.ops_cached.$gma_64=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"reLaunch"]]);
      Z([3,'page-body']);
      Z([3,'page 3']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_64);
    return __MAML_GLOBAL__.ops_cached.$gma_64
  }
  function gz$gma_65(){
    if(__MAML_GLOBAL__.ops_cached.$gma_65)return __MAML_GLOBAL__.ops_cached.$gma_65
    __MAML_GLOBAL__.ops_cached.$gma_65=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"picker-view"]]);
      Z([3,'content']);
      Z([3,'date']);
      Z([11,[[7],[3,"year"]],[3,'year'],[[7],[3,"month"]],[3,'month'],[[7],[3,"day"]],[3,'day']]);
      Z([3,'bindChange']);
      Z([3,'bindpickend']);
      Z([3,'bindpickstart']);
      Z([3,'pickerView']);
      Z([3,'indicatorClass']);
      Z([3,'height: 50px;']);
      Z([3,'maskClass']);
      Z([3,'background-color: #cd2b2b']);
      Z([[7],[3,"value"]]);
      Z([[7],[3,"years"]]);
      Z([3,'line-height: 50px']);
      Z([11,[[7],[3,"item"]],[3,'year']]);
      Z([[7],[3,"months"]]);
      Z([11,[[7],[3,"item"]],[3,'month']]);
      Z([[7],[3,"days"]]);
      Z([11,[[7],[3,"item"]],[3,'day']]);
      Z([11,[3,'bindpickstart count: '],[[7],[3,"bindpickstartCount"]]]);
      Z([11,[3,'bindpickend count: '],[[7],[3,"bindpickendCount"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_65);
    return __MAML_GLOBAL__.ops_cached.$gma_65
  }
  function gz$gma_66(){
    if(__MAML_GLOBAL__.ops_cached.$gma_66)return __MAML_GLOBAL__.ops_cached.$gma_66
    __MAML_GLOBAL__.ops_cached.$gma_66=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"picker"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'reset']);
      Z([3,'submit']);
      Z([3,'weui-cells__title']);
      Z([3,'General Selector']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'current selection']);
      Z([3,'weui-cell__bd']);
      Z([3,'bindcancel']);
      Z([3,'bindPickerChange']);
      Z([3,'title']);
      Z([3,'picker1']);
      Z([[7],[3,"array"]]);
      Z([[7],[3,"index"]]);
      Z([3,'weui-input']);
      Z([11,[[6],[[7],[3,"array"]],[[7],[3,"index"]]]]);
      Z([3,'Selector disabled']);
      Z([3,'true']);
      Z([3,'picker1_disabled']);
      Z([11,[[6],[[7],[3,"array"]],[1,0]]]);
      Z([3,'Common selector with range-key set']);
      Z([3,'bindPickerChangeForRangeKey']);
      Z([3,'picker1_rangekey']);
      Z([[7],[3,"objectArray"]]);
      Z([3,'name']);
      Z([[7],[3,"rangeKeyIndex"]]);
      Z([11,[[6],[[6],[[7],[3,"objectArray"]],[[7],[3,"rangeKeyIndex"]]],[1,"name"]]]);
      Z([3,'multi-column selector']);
      Z([3,'bindMultiPickerChange']);
      Z([3,'bindMultiPickerColumnChange']);
      Z([3,'multiSelector']);
      Z([3,'picker2']);
      Z([[7],[3,"multiArray"]]);
      Z([[7],[3,"multiIndex"]]);
      Z([11,[[7],[3,"multiSelectRes"]]]);
      Z([3,'Time Selector']);
      Z([3,'bindTimeChange']);
      Z([3,'21:01']);
      Z([3,'time']);
      Z([3,'picker3']);
      Z([3,'09:01']);
      Z([[7],[3,"time"]]);
      Z([11,[[7],[3,"time"]]]);
      Z([3,'Date Picker']);
      Z([3,'bindDateChange']);
      Z([3,'2017-09-01']);
      Z([3,'date']);
      Z([3,'picker4']);
      Z([3,'2015-09-01']);
      Z([[7],[3,"date"]]);
      Z([11,[[7],[3,"date"]]]);
      Z([3,'Select only the date picker for the year and month']);
      Z([3,'bindDateMonthChange']);
      Z([3,'2017-09']);
      Z([3,'month']);
      Z([3,'picker4_month']);
      Z([3,'2015-09']);
      Z([[7],[3,"date_month"]]);
      Z([11,[[7],[3,"date_month"]]]);
      Z([3,'Province/city selector']);
      Z([3,'bindRegionChange']);
      Z([[7],[3,"customItem"]]);
      Z([3,'region']);
      Z([3,'picker5']);
      Z([[7],[3,"region"]]);
      Z([11,[[6],[[7],[3,"region"]],[1,0]],[3,'，'],[[6],[[7],[3,"region"]],[1,1]],[3,'，'],[[6],[[7],[3,"region"]],[1,2]]]);
      Z([3,'btn-area']);
      Z([3,'primary']);
      Z([3,'Submit']);
      Z([3,'Reset']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_66);
    return __MAML_GLOBAL__.ops_cached.$gma_66
  }
  function gz$gma_67(){
    if(__MAML_GLOBAL__.ops_cached.$gma_67)return __MAML_GLOBAL__.ops_cached.$gma_67
    __MAML_GLOBAL__.ops_cached.$gma_67=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"progress"]]);
      Z([3,'page-body']);
      Z([3,'default style']);
      Z([3,'progress-box1']);
      Z([3,'ma-progress1']);
      Z([3,'20']);
      Z([3,'true']);
      Z([3,'2']);
      Z([3,'Bind the activeend event, which is invoked after the animation is complete.']);
      Z([3,'progress-box2']);
      Z([3,'activeend']);
      Z([3,'ma-progress2']);
      Z([[7],[3,"percent"]]);
      Z([3,'4']);
      Z([3,'Changeable style']);
      Z([3,'progress-box3']);
      Z([3,'pink']);
      Z([3,'yellow']);
      Z([3,'80']);
      Z([3,'ma-progress3']);
      Z([3,'60']);
      Z([3,'Animation from the beginning']);
      Z([3,'progress-box4']);
      Z([3,'backwards']);
      Z([3,'ma-progress4']);
      Z([3,'30']);
      Z([3,'The animation continues from the last end point.']);
      Z([3,'progress-box5']);
      Z([3,'forwards']);
      Z([3,'ma-progress5']);
      Z([3,'bindtap']);
      Z([3,'progress-box6']);
      Z([3,'Change the progress.']);
      Z([3,'Automated test 1']);
      Z([3,'progress-box7']);
      Z([3,'false']);
      Z([3,'ma-progress7']);
      Z([3,'Automated test 2']);
      Z([3,'progress-box8']);
      Z([3,'ma-progress8']);
      Z([3,'40']);
      Z([3,'abc']);
      Z([3,'Automated test 3']);
      Z([3,'progress-box9']);
      Z([3,'ma-progress9']);
      Z([3,'Automatic test show-info temporary']);
      Z([3,'progress-box10']);
      Z([3,'10px']);
      Z([3,'ma-progress10']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_67);
    return __MAML_GLOBAL__.ops_cached.$gma_67
  }
  function gz$gma_68(){
    if(__MAML_GLOBAL__.ops_cached.$gma_68)return __MAML_GLOBAL__.ops_cached.$gma_68
    __MAML_GLOBAL__.ops_cached.$gma_68=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"radio"]]);
      Z([3,'page-body']);
      Z([3,'page-section page-section-gap']);
      Z([3,'page-section-title']);
      Z([3,'default style']);
      Z([3,'radio']);
      Z([3,'true']);
      Z([3,'radio1']);
      Z([3,'r1']);
      Z([3,'checked']);
      Z([3,'radio2']);
      Z([3,'r2']);
      Z([3,'Unchecked']);
      Z([3,'radio3']);
      Z([3,'r3']);
      Z([3,'disabled']);
      Z([3,'456']);
      Z([3,'radio4']);
      Z([3,'red123']);
      Z([3,'123']);
      Z([3,'r4']);
      Z([3,'Invalid attribute.']);
      Z([3,'page-section']);
      Z([3,'Recommended display style']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'radioChange']);
      Z([[7],[3,"items"]]);
      Z([[6],[[7],[3,"item"]],[3,"value"]]);
      Z([3,'weui-cell weui-check__label']);
      Z([3,'weui-cell__hd']);
      Z([[6],[[7],[3,"item"]],[3,"checked"]]);
      Z([11,[3,'radio-'],[[6],[[7],[3,"item"]],[3,"value"]]]);
      Z([3,'pink']);
      Z([3,'weui-cell__bd']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_68);
    return __MAML_GLOBAL__.ops_cached.$gma_68
  }
  function gz$gma_69(){
    if(__MAML_GLOBAL__.ops_cached.$gma_69)return __MAML_GLOBAL__.ops_cached.$gma_69
    __MAML_GLOBAL__.ops_cached.$gma_69=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"rich-text"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'page-section-title']);
      Z([3,'Simple HTML String Rendering']);
      Z([3,'rich-text-wrp']);
      Z([3,'rich-text1']);
      Z([[7],[3,"html"]]);
      Z([3,'nbsp']);
      Z([3,'Simple Node List Rendering']);
      Z([[7],[3,"nodes"]]);
      Z([3,'Complex HTML String Rendering']);
      Z([[7],[3,"html2"]]);
      Z([3,'Complex Node List Rendering']);
      Z([[7],[3,"nodes2"]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_69);
    return __MAML_GLOBAL__.ops_cached.$gma_69
  }
  function gz$gma_70(){
    if(__MAML_GLOBAL__.ops_cached.$gma_70)return __MAML_GLOBAL__.ops_cached.$gma_70
    __MAML_GLOBAL__.ops_cached.$gma_70=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"scroll-view"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'page-section-title']);
      Z([3,'Vertical Scroll\nVertical scrolling']);
      Z([3,'page-section-spacing']);
      Z([3,'binddragend']);
      Z([3,'binddragging']);
      Z([3,'binddragstart']);
      Z([3,'scroll']);
      Z([3,'lower']);
      Z([3,'upper']);
      Z([3,'scroll-view']);
      Z([3,'true']);
      Z([3,'100']);
      Z([[7],[3,"toView"]]);
      Z([[7],[3,"scrollTop"]]);
      Z([11,[3,'height:'],[[7],[3,"scrollItemHeight"]],[3,'px']]);
      Z([[7],[3,"order"]]);
      Z([3,'item']);
      Z([3,'index']);
      Z([[7],[3,"item"]]);
      Z([11,[3,'scroll-view-item '],[[6],[[7],[3,"item"]],[3,"class"]]]);
      Z([11,[3,'v-'],[[6],[[7],[3,"item"]],[3,"index"]]]);
      Z([3,'button-area']);
      Z([3,'moveTo']);
      Z([[6],[[7],[3,"item"]],[3,"index"]]);
      Z([3,'mini']);
      Z([3,'primary']);
      Z([11,[3,'Scroll to '],[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([3,'scrollToTop']);
      Z([3,'setVposBtn']);
      Z([3,'100px']);
      Z([3,'101']);
      Z([3,'preScrollToUpperBtn']);
      Z([3,'upperThreshold + 1px']);
      Z([3,'99']);
      Z([3,'postScrollToUpperBtn']);
      Z([3,'upperThreshold - 1px']);
      Z([3,'preScrollToLowerBtn']);
      Z([3,'lowerThreshold + 1px']);
      Z([3,'postScrollToLowerBtn']);
      Z([3,'lowerThreshold - 1px']);
      Z([3,'bindscrolltoupperCount']);
      Z([11,[3,'bindscrolltoupper count (V\x26H): '],[[7],[3,"bindscrolltoupperCount"]]]);
      Z([3,'bindscrolltolowerCount']);
      Z([11,[3,'bindscrolltolower count (V\x26H): '],[[7],[3,"bindscrolltolowerCount"]]]);
      Z([3,'bindscrollCount']);
      Z([11,[3,'bindscroll count (V\x26H): '],[[7],[3,"bindscrollCount"]]]);
      Z([3,'binddragstartCount']);
      Z([11,[3,'binddragstart count (H): '],[[7],[3,"binddragstartCount"]]]);
      Z([3,'binddraggingCount']);
      Z([11,[3,'binddragging count (H): '],[[7],[3,"binddraggingCount"]]]);
      Z([3,'binddragendCount']);
      Z([11,[3,'binddragend count (H): '],[[7],[3,"binddragendCount"]]]);
      Z([3,'Horizontal Scroll\nHorizontal scrolling']);
      Z([3,'scroll-view_H']);
      Z([[7],[3,"scrollLeft"]]);
      Z([3,'width: 100%']);
      Z([11,[3,'scroll-view-item_H '],[[6],[[7],[3,"item"]],[3,"class"]]]);
      Z([11,[3,'h-'],[[6],[[7],[3,"item"]],[3,"index"]]]);
      Z([3,'page-section-title setPosition']);
      Z([3,'Set the position of the scroll bar\n']);
      Z([3,'scrollToLeft']);
      Z([3,'setHposBtn1']);
      Z([3,'far left']);
      Z([3,'scrollToLeft2']);
      Z([3,'setHposBtn2']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_70);
    return __MAML_GLOBAL__.ops_cached.$gma_70
  }
  function gz$gma_71(){
    if(__MAML_GLOBAL__.ops_cached.$gma_71)return __MAML_GLOBAL__.ops_cached.$gma_71
    __MAML_GLOBAL__.ops_cached.$gma_71=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"slider"]]);
      Z([3,'date']);
      Z([11,[3,'Slider oblongation'],[[6],[[6],[[7],[3,"e"]],[3,"detail"]],[3,"value"]]]);
      Z([3,'changeslide']);
      Z([11,[3,'Trigger the change event:'],[[7],[3,"isChange"]]]);
      Z([3,'changeslideing']);
      Z([11,[3,'Trigger the change event:'],[[7],[3,"isChanging"]]]);
      Z([3,'page-body']);
      Z([3,'page-section page-section-gap']);
      Z([3,'page-section-title']);
      Z([3,'Set the step']);
      Z([3,'body-view']);
      Z([3,'green']);
      Z([3,'yellow']);
      Z([3,'slider1change']);
      Z([3,'slider1changing']);
      Z([3,'pink']);
      Z([3,'12']);
      Z([3,'slider1']);
      Z([3,'true']);
      Z([[7],[3,"isChange"]]);
      Z([3,'change-slider1 test-span']);
      Z([3,'change slider1']);
      Z([[7],[3,"isChanging"]]);
      Z([3,'changing-slider1 test-span']);
      Z([3,'changing slider1']);
      Z([3,'Displays the current value']);
      Z([3,'slider2change']);
      Z([3,'slider2changing']);
      Z([3,'slider2']);
      Z([3,'5']);
      Z([3,'50']);
      Z([3,'Set Min/Max']);
      Z([3,'slider3change']);
      Z([3,'slider3']);
      Z([3,'200']);
      Z([3,'100']);
      Z([3,'Automatic test of attributes such as min']);
      Z([3,'slider4change']);
      Z([3,'11']);
      Z([3,'slider4']);
      Z([3,'abc']);
      Z([3,'3']);
      Z([3,'The max attribute of the automatic test is not moved. Do not use this attribute for other attributes']);
      Z([3,'slider5change']);
      Z([3,'29']);
      Z([3,'slider5']);
      Z([3,'Auto Test Disable Attribute 1']);
      Z([3,'slider6change']);
      Z([3,'slider6']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_71);
    return __MAML_GLOBAL__.ops_cached.$gma_71
  }
  function gz$gma_72(){
    if(__MAML_GLOBAL__.ops_cached.$gma_72)return __MAML_GLOBAL__.ops_cached.$gma_72
    __MAML_GLOBAL__.ops_cached.$gma_72=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"swiper"]]);
      Z([3,'page-body']);
      Z([3,'page-section page-section-spacing swiper page-swiper']);
      Z([[7],[3,"autoplay"]]);
      Z([[7],[3,"circular"]]);
      Z([[7],[3,"duration"]]);
      Z([[7],[3,"easingFunction"]]);
      Z([[7],[3,"indicatorActiveColor"]]);
      Z([[7],[3,"indicatorColor"]]);
      Z([[7],[3,"indicatorDots"]]);
      Z([[7],[3,"interval"]]);
      Z([[7],[3,"vertical"]]);
      Z([[7],[3,"background"]]);
      Z([3,'*this']);
      Z([11,[3,'swiper-item '],[[7],[3,"item"]]]);
      Z([3,'page-section']);
      Z([3,'margin-top: 40rpx;margin-bottom: 0;']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_switch']);
      Z([3,'weui-cell__bd']);
      Z([3,'Indicating Point']);
      Z([3,'weui-cell__ft swiper-dot']);
      Z([3,'changeIndicatorDots']);
      Z([3,'Autoplay']);
      Z([3,'weui-cell__ft swiper-autoplay']);
      Z([3,'changeAutoplay']);
      Z([3,'page-section page-section-spacing']);
      Z([3,'page-section-title']);
      Z([3,'Slide Switching Duration(ms)']);
      Z([3,'info']);
      Z([11,[[7],[3,"duration"]]]);
      Z([3,'durationChange']);
      Z([3,'swiper-duration']);
      Z([3,'2000']);
      Z([3,'500']);
      Z([3,'Auto-play interval(ms)']);
      Z([11,[[7],[3,"interval"]]]);
      Z([3,'intervalChange']);
      Z([3,'swiper-interval']);
      Z([3,'10000']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_72);
    return __MAML_GLOBAL__.ops_cached.$gma_72
  }
  function gz$gma_73(){
    if(__MAML_GLOBAL__.ops_cached.$gma_73)return __MAML_GLOBAL__.ops_cached.$gma_73
    __MAML_GLOBAL__.ops_cached.$gma_73=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"switch"]]);
      Z([3,'page-body']);
      Z([3,'page-section page-section-gap']);
      Z([3,'page-section-title']);
      Z([3,'Default switch style']);
      Z([3,'body-view']);
      Z([3,'switch1Change']);
      Z([3,'switch1']);
      Z([[7],[3,"isClicked"]]);
      Z([3,'test-span']);
      Z([3,'switch bind change']);
      Z([3,'Checkbox Style']);
      Z([3,'switch2Change']);
      Z([3,'true']);
      Z([3,'switch2']);
      Z([3,'checkbox']);
      Z([3,'Customizing the Switch Color']);
      Z([3,'#000000']);
      Z([3,'switch3']);
      Z([3,'switch4']);
      Z([3,'Disable the switch']);
      Z([3,'switch5']);
      Z([3,'switch6']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_73);
    return __MAML_GLOBAL__.ops_cached.$gma_73
  }
  function gz$gma_74(){
    if(__MAML_GLOBAL__.ops_cached.$gma_74)return __MAML_GLOBAL__.ops_cached.$gma_74
    __MAML_GLOBAL__.ops_cached.$gma_74=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"text"]]);
      Z([3,'page-body']);
      Z([3,'page-section page-section-spacing']);
      Z([3,'text-box']);
      Z([[7],[3,"scrollTop"]]);
      Z([3,'true']);
      Z([3,'text1']);
      Z([[7],[3,"decode"]]);
      Z([3,'emsp']);
      Z([[7],[3,"userSelect"]]);
      Z([11,[[7],[3,"text"]]]);
      Z([3,'text2']);
      Z([3,'ensp']);
      Z([3,'ChineseCharacters spaceensp']);
      Z([3,'text3']);
      Z([3,'nbsp']);
      Z([3,'false']);
      Z([3,'ChineseCharacters spacenbsp']);
      Z([3,'text4']);
      Z([3,'ChineseCharacters spaceemsp']);
      Z([3,'text5']);
      Z([3,'abc']);
      Z([3,'123']);
      Z([3,'ChineseCharacters InvalidSpace']);
      Z([3,'add']);
      Z([3,'addline']);
      Z([[2,"!"],[[7],[3,"canAdd"]]]);
      Z([3,'add line']);
      Z([3,'remove']);
      Z([[2,"!"],[[7],[3,"canRemove"]]]);
      Z([3,'remove line']);
      Z([3,'setDecode']);
      Z([3,'btn-decode']);
      Z([3,'set decode']);
      Z([3,'setUserSelect']);
      Z([3,'btn-user-select']);
      Z([3,'set user select']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_74);
    return __MAML_GLOBAL__.ops_cached.$gma_74
  }
  function gz$gma_75(){
    if(__MAML_GLOBAL__.ops_cached.$gma_75)return __MAML_GLOBAL__.ops_cached.$gma_75
    __MAML_GLOBAL__.ops_cached.$gma_75=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"textarea"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'page-section-title']);
      Z([3,'The height of the input area is adaptive, and the scroll bar is not displayed']);
      Z([3,'textarea-wrp']);
      Z([3,'true']);
      Z([3,'bindblur']);
      Z([3,'bindconfirm']);
      Z([3,'bindfocus']);
      Z([3,'bindinput']);
      Z([3,'bindlinechange']);
      Z([3,'textarea1']);
      Z([3,'color:#4ba9f9f5;font-size:16px;']);
      Z([3,'height:30px']);
      Z([3,'This is a textarea with autofocus.']);
      Z([3,'textarea2']);
      Z([3,'10']);
      Z([3,'3']);
      Z([3,'1']);
      Z([3,'height: 3em']);
      Z([3,'auto-focus']);
      Z([3,'page-section3']);
      Z([3,'page-section-title2']);
      Z([3,'Automatic Test Textarea']);
      Z([3,'textarea3']);
      Z([3,'Automatic test of disabled textarea3']);
      Z([3,'textarea4']);
      Z([3,'Automatic Test Textarea4']);
      Z([3,'textarea5']);
      Z([3,'Automated Test 5']);
      Z([3,'placeholderClass']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_75);
    return __MAML_GLOBAL__.ops_cached.$gma_75
  }
  function gz$gma_76(){
    if(__MAML_GLOBAL__.ops_cached.$gma_76)return __MAML_GLOBAL__.ops_cached.$gma_76
    __MAML_GLOBAL__.ops_cached.$gma_76=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"video"]]);
      Z([3,'page-body']);
      Z([3,'page-section tc']);
      Z([[7],[3,"autoplay"]]);
      Z([3,'bindended']);
      Z([3,'binderror']);
      Z([3,'bindpause']);
      Z([3,'bindplay']);
      Z([3,'bindtimeupdate']);
      Z([[7],[3,"controls"]]);
      Z([[7],[3,"hidden"]]);
      Z([3,'myVideo']);
      Z([[7],[3,"loop"]]);
      Z([[7],[3,"muted"]]);
      Z([[7],[3,"objectFit"]]);
      Z([[7],[3,"poster"]]);
      Z([[7],[3,"src"]]);
      Z([3,'weui-cells']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'JumpLocation']);
      Z([3,'weui-cell__bd']);
      Z([3,'false']);
      Z([3,'bindInput']);
      Z([3,'weui-input']);
      Z([3,'Enter the specified location here']);
      Z([3,'text']);
      Z([[7],[3,"position"]]);
      Z([3,'btn-area']);
      Z([3,'play']);
      Z([3,'page-body-button play']);
      Z([3,'primary']);
      Z([3,'playout']);
      Z([3,'pause']);
      Z([3,'page-body-button pause']);
      Z([3,'seek']);
      Z([3,'page-body-button seek']);
      Z([3,'Jump to a specified position (unit:second)']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_76);
    return __MAML_GLOBAL__.ops_cached.$gma_76
  }
  function gz$gma_77(){
    if(__MAML_GLOBAL__.ops_cached.$gma_77)return __MAML_GLOBAL__.ops_cached.$gma_77
    __MAML_GLOBAL__.ops_cached.$gma_77=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"view"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'page-section-title']);
      Z([3,'flex-direction: row\nHorizontal layout']);
      Z([3,'page-section-spacing']);
      Z([3,'hoverclass']);
      Z([3,'200']);
      Z([3,'1000']);
      Z([3,'flex-wrp']);
      Z([3,'flex-direction:row;']);
      Z([3,'flex-item demo-text-1']);
      Z([3,'true']);
      Z([3,'flex-item demo-text-2']);
      Z([3,'flex-item demo-text-3']);
      Z([3,'flex-direction: column\nVertical Layout']);
      Z([3,'flex-direction:column;']);
      Z([3,'flex-item flex-item-V demo-text-1']);
      Z([3,'flex-item flex-item-V demo-text-2']);
      Z([3,'flex-item flex-item-V demo-text-3']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_77);
    return __MAML_GLOBAL__.ops_cached.$gma_77
  }
  function gz$gma_78(){
    if(__MAML_GLOBAL__.ops_cached.$gma_78)return __MAML_GLOBAL__.ops_cached.$gma_78
    __MAML_GLOBAL__.ops_cached.$gma_78=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'https://www.bing.com/'])
    })(__MAML_GLOBAL__.ops_cached.$gma_78);
    return __MAML_GLOBAL__.ops_cached.$gma_78
  }
  function gz$gma_79(){
    if(__MAML_GLOBAL__.ops_cached.$gma_79)return __MAML_GLOBAL__.ops_cached.$gma_79
    __MAML_GLOBAL__.ops_cached.$gma_79=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'onMyEvent']);
      Z([[7],[3,"detail"]]);
      Z([3,'test1']);
      Z([[7],[3,"propTest"]]);
      Z([3,'showSlot']);
      Z([3,'slot scene']);
      Z([3,'clickButton']);
      Z([3,'Parent page component, which invokes the subcomponent method']);
      Z([3,'clickSelf']);
      Z([3,'No parent-child communication']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_79);
    return __MAML_GLOBAL__.ops_cached.$gma_79
  }
  function gz$gma_80(){
    if(__MAML_GLOBAL__.ops_cached.$gma_80)return __MAML_GLOBAL__.ops_cached.$gma_80
    __MAML_GLOBAL__.ops_cached.$gma_80=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'text-align:center']);
      Z([3,'head']);
      Z([[8],"title",[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"window.title"]]]]);
      Z([3,'page-body']);
      Z([11,[3,'Current locale: '],[[12],[[6],[[7],[3,"i18n"]],[3,"getLocale"]],[[5]]]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"test"]]]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[[5],[1,"test2"]],[[9],[[8],"label",[1,"sample"]],[[8],"label2",[[7],[3,"value"]]]]]]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[[5],[1,"nested"]],[[8],"test",[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"test"]]]]]]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[[5],[1,"nested2"]],[[7],[3,"value2"]]]]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"index.test"]]]]);
      Z([3,'buttonArea']);
      Z([3,'toggleLocale']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"toggle"]]]]);
      Z([3,'nativate']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"navigate"]]]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"navigate2"]]]]);
      Z([3,'cancel']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"cancelEvent"]]]]);
      Z([3,'page-section']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'height:46px']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'select']);
      Z([3,'weui-cell__bd']);
      Z([3,'bindPickerChange']);
      Z([3,'select I18N']);
      Z([3,'picker']);
      Z([[7],[3,"array"]]);
      Z([[7],[3,"index"]]);
      Z([11,[[6],[[7],[3,"array"]],[[7],[3,"index"]]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_80);
    return __MAML_GLOBAL__.ops_cached.$gma_80
  }
  function gz$gma_81(){
    if(__MAML_GLOBAL__.ops_cached.$gma_81)return __MAML_GLOBAL__.ops_cached.$gma_81
    __MAML_GLOBAL__.ops_cached.$gma_81=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'text-align:center']);
      Z([3,'head']);
      Z([[8],"title",[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"log"]]]]);
      Z([3,'page-body']);
      Z([11,[3,'Locale: '],[[12],[[6],[[7],[3,"customi18nModule"]],[3,"getLocale"]],[[5]]]]);
      Z([11,[[12],[[6],[[7],[3,"customi18nModule"]],[3,"t"]],[[5],[1,"test"]]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_81);
    return __MAML_GLOBAL__.ops_cached.$gma_81
  }
  function gz$gma_82(){
    if(__MAML_GLOBAL__.ops_cached.$gma_82)return __MAML_GLOBAL__.ops_cached.$gma_82
    __MAML_GLOBAL__.ops_cached.$gma_82=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"sjs application: drag-and-drop process"]]);
      Z([[6],[[7],[3,"comm"]],[3,"liveTouchmove"]]);
      Z([3,'enterLive liveMove']);
      Z([3,'top:202px;left:100px']);
      Z([[6],[[7],[3,"comm"]],[3,"clickLive"]]);
      Z([3,'live-block']);
      Z([3,'border:1px solid blue']);
      Z([3,'liveEnter-img']);
      Z([3,'aspectFit']);
      Z([3,'../../../../image/demo.jpg']);
      Z([3,'liveTouchmove']);
      Z([[7],[3,"windowHeight"]]);
      Z([[7],[3,"windowWidth"]]);
      Z([[7],[3,"style"]]);
      Z([3,'border:1px solid red']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_82);
    return __MAML_GLOBAL__.ops_cached.$gma_82
  }
  function gz$gma_83(){
    if(__MAML_GLOBAL__.ops_cached.$gma_83)return __MAML_GLOBAL__.ops_cached.$gma_83
    __MAML_GLOBAL__.ops_cached.$gma_83=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"sjs application:filter-time format"]]);
      Z([3,'label']);
      Z([3,'Current timestamp:']);
      Z([11,[[7],[3,"timestamp"]]]);
      Z([3,'yyyy-MM-dd：']);
      Z([11,[[12],[[6],[[7],[3,"common_filter"]],[3,"dateFormat"]],[[5],[[5],[[7],[3,"timestamp"]]],[1,"yyyy-MM-dd"]]]]);
      Z([3,'yyyy-MM-dd hh:mm:ss：']);
      Z([11,[[12],[[6],[[7],[3,"common_filter"]],[3,"dateFormat"]],[[5],[[7],[3,"timestamp"]]]]]);
      Z([3,'btn-area']);
      Z([3,'getTime']);
      Z([3,'primary']);
      Z([3,'RefreshTime']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_83);
    return __MAML_GLOBAL__.ops_cached.$gma_83
  }
  function gz$gma_84(){
    if(__MAML_GLOBAL__.ops_cached.$gma_84)return __MAML_GLOBAL__.ops_cached.$gma_84
    __MAML_GLOBAL__.ops_cached.$gma_84=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"tabBar"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'showTabBarRedDot']);
      Z([3,'tabBarRedDot']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasShownTabBarRedDot"]]],[1,"Show red dots"],[1,"Remove Red Dots"]]]);
      Z([3,'customStyle']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasCustomedStyle"]]],[1,"Custom Tab Styles"],[1,"Remove Custom Styles"]]]);
      Z([3,'customItem']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasCustomedItem"]]],[1,"Customizing Tab Information"],[1,"Remove Custom Information"]]]);
      Z([3,'hideTabBar']);
      Z([3,'showOrHideTabBar']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasHiddenTabBar"]]],[1,"Hide TabBar"],[1,"Show TabBar"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_84);
    return __MAML_GLOBAL__.ops_cached.$gma_84
  }
  function gz$gma_85(){
    if(__MAML_GLOBAL__.ops_cached.$gma_85)return __MAML_GLOBAL__.ops_cached.$gma_85
    __MAML_GLOBAL__.ops_cached.$gma_85=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([[7],[3,"isSetTabBarPage"]]);
      Z([3,'leaveSetTabBarPage']);
      Z([3,'index']);
      Z([3,'index-hd']);
      Z([3,'index-desc']);
      Z([3,'following describes the API capability of the applet. For details about the attribute parameters, see the applet development document.']);
      Z([3,'index-bd']);
      Z([3,'kind-list']);
      Z([[7],[3,"list"]]);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'kind-list-item']);
      Z([3,'kindToggle']);
      Z([11,[3,'kind-list-item-hd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-hd-show"],[1,""]]]);
      Z([3,'kind-list-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([11,[3,'kind-list-img kind-list-img-'],[[6],[[7],[3,"item"]],[3,"id"]]]);
      Z([11,[3,'/page/tabbar/resources/api/kind/'],[[6],[[7],[3,"item"]],[3,"id"]],[3,'.png']]);
      Z([11,[3,'kind-list-item-bd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-bd-show"],[1,""]]]);
      Z([11,[3,'navigator-box '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"navigator-box-show"],[1,""]]]);
      Z([[6],[[7],[3,"item"]],[3,"pages"]]);
      Z([3,'page']);
      Z([3,'*item']);
      Z([[2,"!=="], [[6],[[7],[3,"page"]],[3,"url"]], [1,"set-tab-bar/set-tab-bar"]]);
      Z([3,'navigator']);
      Z([11,[3,'/page/API/pages/'],[[6],[[7],[3,"page"]],[3,"url"]]]);
      Z([3,'navigator-content']);
      Z([[6],[[7],[3,"page"]],[3,"id"]]);
      Z([11,[[6],[[7],[3,"page"]],[3,"zh"]]]);
      Z([3,'navigator-arrow']);
      Z([3,'enterSetTabBarPage'])
    })(__MAML_GLOBAL__.ops_cached.$gma_85);
    return __MAML_GLOBAL__.ops_cached.$gma_85
  }
  function gz$gma_86(){
    if(__MAML_GLOBAL__.ops_cached.$gma_86)return __MAML_GLOBAL__.ops_cached.$gma_86
    __MAML_GLOBAL__.ops_cached.$gma_86=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'index']);
      Z([3,'index-hd']);
      Z([3,'index-desc']);
      Z([3,'The following describes the capabilities of the applet component. For details about the attributes and parameters, see the applet development document.']);
      Z([3,'index-bd']);
      Z([3,'kind-list']);
      Z([[7],[3,"list"]]);
      Z([3,'item']);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'kind-list-item']);
      Z([3,'kindToggle']);
      Z([11,[3,'kind-list-'],[[6],[[7],[3,"item"]],[3,"id"]],[3,' kind-list-item-hd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-hd-show"],[1,""]]]);
      Z([3,'kind-list-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([[2,"!=="], [[6],[[7],[3,"item"]],[3,"id"]], [1,"page-meta"]]);
      Z([11,[3,'kind-list-img kind-list-img-'],[[6],[[7],[3,"item"]],[3,"id"]]]);
      Z([11,[3,'/page/tabbar/resources/component/kind/'],[[6],[[7],[3,"item"]],[3,"id"]],[3,'.png']]);
      Z([11,[3,'kind-list-item-bd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-bd-show"],[1,""]]]);
      Z([11,[3,'navigator-box '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"navigator-box-show"],[1,""]]]);
      Z([[6],[[7],[3,"item"]],[3,"pages"]]);
      Z([3,'page']);
      Z([3,'*item']);
      Z([11,[3,'navigator navigator-'],[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([11,[3,'navigator-'],[[6],[[7],[3,"page"]],[3,"id"]]]);
      Z([11,[3,'/page/component/pages/'],[[6],[[7],[3,"page"]],[3,"name"]],[3,'/'],[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([3,'navigator-content']);
      Z([[6],[[7],[3,"page"]],[3,"id"]]);
      Z([11,[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([3,'navigator-arrow'])
    })(__MAML_GLOBAL__.ops_cached.$gma_86);
    return __MAML_GLOBAL__.ops_cached.$gma_86
  }
  function gz$gma_87(){
    if(__MAML_GLOBAL__.ops_cached.$gma_87)return __MAML_GLOBAL__.ops_cached.$gma_87
    __MAML_GLOBAL__.ops_cached.$gma_87=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'index']);
      Z([3,'index-hd']);
      Z([3,'index-desc']);
      Z([3,'The following describes the applet framework capability. For details about the attributes and parameters, see the applet development document。']);
      Z([3,'index-bd']);
      Z([3,'kind-list']);
      Z([[7],[3,"list"]]);
      Z([3,'item']);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'kind-list-item']);
      Z([3,'kindToggle']);
      Z([11,[3,'kind-list-'],[[6],[[7],[3,"item"]],[3,"id"]],[3,' kind-list-item-hd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-hd-show"],[1,""]]]);
      Z([3,'kind-list-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([11,[3,'kind-list-item-bd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-bd-show"],[1,""]]]);
      Z([11,[3,'navigator-box '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"navigator-box-show"],[1,""]]]);
      Z([[6],[[7],[3,"item"]],[3,"pages"]]);
      Z([3,'page']);
      Z([3,'*item']);
      Z([11,[3,'navigator navigator-'],[[7],[3,"page"]]]);
      Z([11,[3,'/page/framework/pages/'],[[7],[3,"page"]],[3,'/'],[[7],[3,"page"]]]);
      Z([3,'navigator-content']);
      Z([11,[[7],[3,"page"]]]);
      Z([3,'navigator-arrow'])
    })(__MAML_GLOBAL__.ops_cached.$gma_87);
    return __MAML_GLOBAL__.ops_cached.$gma_87
  }
  function gz$gma_88(){
    if(__MAML_GLOBAL__.ops_cached.$gma_88)return __MAML_GLOBAL__.ops_cached.$gma_88
    __MAML_GLOBAL__.ops_cached.$gma_88=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'page-foot']);
      Z([3,'none']);
      Z([3,'switchTab']);
      Z([3,'/page/tabbar/component/index']);
      Z([3,'icon-foot']);
      Z([3,'../../../../image/icon_foot.png'])
    })(__MAML_GLOBAL__.ops_cached.$gma_88);
    return __MAML_GLOBAL__.ops_cached.$gma_88
  }
  function gz$gma_89(){
    if(__MAML_GLOBAL__.ops_cached.$gma_89)return __MAML_GLOBAL__.ops_cached.$gma_89
    __MAML_GLOBAL__.ops_cached.$gma_89=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'page-head']);
      Z([3,'page-head-title']);
      Z([11,[[7],[3,"title"]]]);
      Z([3,'page-head-line']);
      Z([[7],[3,"desc"]]);
      Z([3,'page-head-desc']);
      Z([11,[[7],[3,"desc"]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_89);
    return __MAML_GLOBAL__.ops_cached.$gma_89
  }
  function gz$gma_90(){
    if(__MAML_GLOBAL__.ops_cached.$gma_90)return __MAML_GLOBAL__.ops_cached.$gma_90
    __MAML_GLOBAL__.ops_cached.$gma_90=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"tabBar"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'showTabBarRedDot']);
      Z([3,'tabBarRedDot']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasShownTabBarRedDot"]]],[1,"Show red dots"],[1,"Remove Red Dots"]]]);
      Z([3,'customStyle']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasCustomedStyle"]]],[1,"Custom Tab Styles"],[1,"Remove Custom Styles"]]]);
      Z([3,'customItem']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasCustomedItem"]]],[1,"Customizing Tab Information"],[1,"Remove Custom Information"]]]);
      Z([3,'hideTabBar']);
      Z([3,'showOrHideTabBar']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasHiddenTabBar"]]],[1,"Hide TabBar"],[1,"Show TabBar"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_90);
    return __MAML_GLOBAL__.ops_cached.$gma_90
  }
  function gz$gma_91(){
    if(__MAML_GLOBAL__.ops_cached.$gma_91)return __MAML_GLOBAL__.ops_cached.$gma_91
    __MAML_GLOBAL__.ops_cached.$gma_91=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([[7],[3,"isSetTabBarPage"]]);
      Z([3,'leaveSetTabBarPage']);
      Z([3,'index']);
      Z([3,'index-hd']);
      Z([3,'index-desc']);
      Z([3,'The following describes the API capability of the applet. For details about the attribute parameters, see the applet development document.']);
      Z([3,'index-bd']);
      Z([3,'kind-list']);
      Z([[7],[3,"list"]]);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'kind-list-item']);
      Z([3,'kindToggle']);
      Z([11,[3,'kind-list-item-hd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-hd-show"],[1,""]]]);
      Z([3,'kind-list-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([11,[3,'kind-list-img kind-list-img-'],[[6],[[7],[3,"item"]],[3,"id"]]]);
      Z([11,[3,'/page/tabbar/resources/api/kind/'],[[6],[[7],[3,"item"]],[3,"id"]],[3,'.png']]);
      Z([11,[3,'kind-list-item-bd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-bd-show"],[1,""]]]);
      Z([11,[3,'navigator-box '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"navigator-box-show"],[1,""]]]);
      Z([[6],[[7],[3,"item"]],[3,"pages"]]);
      Z([3,'page']);
      Z([3,'*item']);
      Z([[2,"!=="], [[6],[[7],[3,"page"]],[3,"url"]], [1,"set-tab-bar/set-tab-bar"]]);
      Z([3,'navigator']);
      Z([11,[3,'/page/API/pages/'],[[6],[[7],[3,"page"]],[3,"url"]]]);
      Z([3,'navigator-content']);
      Z([[6],[[7],[3,"page"]],[3,"id"]]);
      Z([11,[[6],[[7],[3,"page"]],[3,"zh"]]]);
      Z([3,'navigator-arrow']);
      Z([3,'enterSetTabBarPage'])
    })(__MAML_GLOBAL__.ops_cached.$gma_91);
    return __MAML_GLOBAL__.ops_cached.$gma_91
  }
  function gz$gma_92(){
    if(__MAML_GLOBAL__.ops_cached.$gma_92)return __MAML_GLOBAL__.ops_cached.$gma_92
    __MAML_GLOBAL__.ops_cached.$gma_92=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'index']);
      Z([3,'index-hd']);
      Z([3,'index-desc']);
      Z([3,'The following describes the capabilities of the applet component. For details about the attributes and parameters, see the applet development document.']);
      Z([3,'index-bd']);
      Z([3,'kind-list']);
      Z([[7],[3,"list"]]);
      Z([3,'item']);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'kind-list-item']);
      Z([3,'kindToggle']);
      Z([11,[3,'kind-list-'],[[6],[[7],[3,"item"]],[3,"id"]],[3,' kind-list-item-hd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-hd-show"],[1,""]]]);
      Z([3,'kind-list-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([[2,"!=="], [[6],[[7],[3,"item"]],[3,"id"]], [1,"page-meta"]]);
      Z([11,[3,'kind-list-img kind-list-img-'],[[6],[[7],[3,"item"]],[3,"id"]]]);
      Z([11,[3,'/page/tabbar/resources/component/kind/'],[[6],[[7],[3,"item"]],[3,"id"]],[3,'.png']]);
      Z([11,[3,'kind-list-item-bd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-bd-show"],[1,""]]]);
      Z([11,[3,'navigator-box '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"navigator-box-show"],[1,""]]]);
      Z([[6],[[7],[3,"item"]],[3,"pages"]]);
      Z([3,'page']);
      Z([3,'*item']);
      Z([11,[3,'navigator navigator-'],[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([11,[3,'navigator-'],[[6],[[7],[3,"page"]],[3,"id"]]]);
      Z([11,[3,'/page/component/pages/'],[[6],[[7],[3,"page"]],[3,"name"]],[3,'/'],[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([3,'navigator-content']);
      Z([[6],[[7],[3,"page"]],[3,"id"]]);
      Z([11,[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([3,'navigator-arrow'])
    })(__MAML_GLOBAL__.ops_cached.$gma_92);
    return __MAML_GLOBAL__.ops_cached.$gma_92
  }
  function gz$gma_93(){
    if(__MAML_GLOBAL__.ops_cached.$gma_93)return __MAML_GLOBAL__.ops_cached.$gma_93
    __MAML_GLOBAL__.ops_cached.$gma_93=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'index']);
      Z([3,'index-hd']);
      Z([3,'index-desc']);
      Z([3,'The following describes the applet framework capability. For details about the attributes and parameters, see the applet development document。']);
      Z([3,'index-bd']);
      Z([3,'kind-list']);
      Z([[7],[3,"list"]]);
      Z([3,'item']);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'kind-list-item']);
      Z([3,'kindToggle']);
      Z([11,[3,'kind-list-'],[[6],[[7],[3,"item"]],[3,"id"]],[3,' kind-list-item-hd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-hd-show"],[1,""]]]);
      Z([3,'kind-list-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([11,[3,'kind-list-item-bd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-bd-show"],[1,""]]]);
      Z([11,[3,'navigator-box '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"navigator-box-show"],[1,""]]]);
      Z([[6],[[7],[3,"item"]],[3,"pages"]]);
      Z([3,'page']);
      Z([3,'*item']);
      Z([11,[3,'navigator navigator-'],[[7],[3,"page"]]]);
      Z([11,[3,'/page/framework/pages/'],[[7],[3,"page"]],[3,'/'],[[7],[3,"page"]]]);
      Z([3,'navigator-content']);
      Z([11,[[7],[3,"page"]]]);
      Z([3,'navigator-arrow'])
    })(__MAML_GLOBAL__.ops_cached.$gma_93);
    return __MAML_GLOBAL__.ops_cached.$gma_93
  }
  function gz$gma_94(){
    if(__MAML_GLOBAL__.ops_cached.$gma_94)return __MAML_GLOBAL__.ops_cached.$gma_94
    __MAML_GLOBAL__.ops_cached.$gma_94=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'index']);
      Z([3,'true']);
      Z([3,'https://maps.googleapis.com/maps/api/js?key\x3d\x26callback\x3dinitMap\x26v\x3dweekly']);
      Z([3,'./index']);
      Z([3,'googleMap']);
      Z([3,'Loading']);
      Z([3,'http://127.0.0.1:5500/public/index.html']);
      Z([3,'index-bd']);
      Z([3,'kind-list']);
      Z([[7],[3,"list"]]);
      Z([3,'item']);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'kind-list-item']);
      Z([3,'kindToggle']);
      Z([11,[3,'kind-list-'],[[6],[[7],[3,"item"]],[3,"id"]],[3,' kind-list-item-hd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-hd-show"],[1,""]]]);
      Z([3,'kind-list-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([[2,"!=="], [[6],[[7],[3,"item"]],[3,"id"]], [1,"page-meta"]]);
      Z([11,[3,'kind-list-img kind-list-img-'],[[6],[[7],[3,"item"]],[3,"id"]]]);
      Z([11,[3,'/page/tabbar/resources/component/kind/'],[[6],[[7],[3,"item"]],[3,"id"]],[3,'.png']]);
      Z([11,[3,'kind-list-item-bd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-bd-show"],[1,""]]]);
      Z([11,[3,'navigator-box '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"navigator-box-show"],[1,""]]]);
      Z([[6],[[7],[3,"item"]],[3,"pages"]]);
      Z([3,'page']);
      Z([3,'*item']);
      Z([11,[3,'navigator navigator-'],[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([11,[3,'navigator-'],[[6],[[7],[3,"page"]],[3,"id"]]]);
      Z([11,[3,'/page/component/pages/'],[[6],[[7],[3,"page"]],[3,"name"]],[3,'/'],[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([3,'navigator-content']);
      Z([[6],[[7],[3,"page"]],[3,"id"]]);
      Z([11,[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([3,'navigator-arrow'])
    })(__MAML_GLOBAL__.ops_cached.$gma_94);
    return __MAML_GLOBAL__.ops_cached.$gma_94
  }
  __MAML_GLOBAL__.ops_set.$gma=z;
  __MAML_GLOBAL__.ops_init.$gma=true;
  
  var sjs_require=function(){
    var smm={"p_./macle_demo_EN/page/framework/pages/macle-sub-i18n/i18n.sjs":sm_0,"p_./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.sjs":sm_1,"p_./macle_demo_EN/page/util/common.sjs":sm_2,"p_./page/util/common.sjs":sm_3}; // sjs modules map
    var smem={}; // sjs modules exports map
    return function(mp){ // module path
      if(mp[0]==='p'&&mp[1]==='_'&&f_[mp.slice(2)])return f_[mp.slice(2)];
      return function(){
        if(!smm[mp]) return undefined;
        try{
          if(!smem[mp])smem[mp]=smm[mp]();
          return smem[mp];
        }catch(e){
          e.message=e.message.replace(/sjs_/g,'');
          var t = e.stack.substring(0,e.stack.lastIndexOf(mp));
          e.stack = t.substring(0,t.lastIndexOf('\n'));
          e.stack = e.stack.replace(/\ssjs_/g,' ');
          e.stack = $gstack(e.stack);
          e.stack += '\n    at ' + mp.substring(2);
          console.error(e);
        }
      }
    }
  }()
  f_['./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml']={};
  f_['./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml']['customi18nModule']=f_['./macle_demo_EN/page/framework/pages/macle-sub-i18n/i18n.sjs']||sjs_require("p_./macle_demo_EN/page/framework/pages/macle-sub-i18n/i18n.sjs");
  f_['./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml']['customi18nModule']();
  f_['./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml']={};
  f_['./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml']['comm']=f_['./macle_demo_EN/page/util/common.sjs']||sjs_require("p_./macle_demo_EN/page/util/common.sjs");
  f_['./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml']['comm']();
  f_['./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml']={};
  f_['./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml']['common_filter']=f_['./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.sjs']||sjs_require("p_./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.sjs");
  f_['./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml']['common_filter']();
  f_['./macle_demo_EN/page/framework/pages/macle-sub-i18n/i18n.sjs']=sjs_require("p_./macle_demo_EN/page/framework/pages/macle-sub-i18n/i18n.sjs");
  function sm_0(){var sjs_module={sjs_exports:{}};function sjs_t(sjs_str,sjs_arr){return i18n.sjs_t(sjs_str,sjs_arr)}function sjs_getLocale(sjs_str,sjs_arr){return i18n.sjs_getLocale(sjs_str,sjs_arr)}sjs_module.sjs_exports={sjs_t:sjs_t,sjs_getLocale:sjs_getLocale};return sjs_module.sjs_exports;}
  f_['./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.sjs']=sjs_require("p_./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.sjs");
  function sm_1(){var sjs_module={sjs_exports:{}};function sjs_dateFormat(sjs_timestamp,sjs_format){if(!sjs_format){sjs_format="yyyy-MM-dd hh:mm:ss"}sjs_timestamp=sjs_parseInt(sjs_timestamp);var sjs_realDate=sjs_getDate(sjs_timestamp);function sjs_timeFormat(sjs_num){return sjs_num<10?"0"+sjs_num:sjs_num}var sjs_date=[["M+",sjs_timeFormat(sjs_realDate.sjs_getMonth()+1)],["d+",sjs_timeFormat(sjs_realDate.sjs_getDate())],["h+",sjs_timeFormat(sjs_realDate.sjs_getHours())],["m+",sjs_timeFormat(sjs_realDate.sjs_getMinutes())],["s+",sjs_timeFormat(sjs_realDate.sjs_getSeconds())],["q+",Math.sjs_floor((sjs_realDate.sjs_getMonth()+3)/3)]];var sjs_regYear=sjs_getRegExp("(y+)","i");var sjs_reg1=sjs_regYear.sjs_exec(sjs_format);if(sjs_reg1){sjs_format=sjs_format.sjs_replace(sjs_reg1[1],(sjs_realDate.sjs_getFullYear()+"").sjs_substring(4-sjs_reg1[1].sjs_length))}for(var sjs_i=0;sjs_i<sjs_date.sjs_length;sjs_i++){var sjs_k=sjs_date[_ck(sjs_i)][0];var sjs_v=sjs_date[_ck(sjs_i)][1];var sjs_reg2=sjs_getRegExp("("+sjs_k+")").sjs_exec(sjs_format);if(sjs_reg2){sjs_format=sjs_format.sjs_replace(sjs_reg2[1],sjs_reg2[1].sjs_length==1?sjs_v:("00"+sjs_v).sjs_substring((""+sjs_v).sjs_length))}}return sjs_format}sjs_module.sjs_exports={sjs_dateFormat:sjs_dateFormat};return sjs_module.sjs_exports;}
  f_['./macle_demo_EN/page/util/common.sjs']=sjs_require("p_./macle_demo_EN/page/util/common.sjs");
  function sm_2(){var sjs_module={sjs_exports:{}};var sjs_starLeft=0;var sjs_starTop=0;var sjs_starX=0;var sjs_starY=0;function sjs_liveTouchmove(sjs_event,sjs_ownerInstance){var sjs_left=0,sjs_top=0;var sjs_diffX=0,sjs_diffY=0;if(sjs_event.sjs_type==="touchstart"){sjs_starLeft=sjs_event.sjs_currentTarget.sjs_offsetLeft;sjs_starTop=sjs_event.sjs_currentTarget.sjs_offsetTop;sjs_starX=sjs_event.sjs_changedTouches[0].sjs_clientX;sjs_starY=sjs_event.sjs_changedTouches[0].sjs_clientY;sjs_left=sjs_starLeft;sjs_top=sjs_starTop}else{sjs_diffX=sjs_event.sjs_changedTouches[0].sjs_clientX-sjs_starX;sjs_diffY=sjs_event.sjs_changedTouches[0].sjs_clientY-sjs_starY;sjs_left=sjs_starLeft+sjs_diffX;sjs_top=sjs_starTop+sjs_diffY}sjs_left=sjs_left+"px";var sjs_instance=sjs_ownerInstance.sjs_selectComponent(".liveMove");sjs_instance.sjs_setStyle({sjs_left:sjs_left,sjs_top:sjs_top+"px"})}function sjs_clickLive(sjs_event,sjs_ownerInstance){sjs_ownerInstance.sjs_callMethod("bindEnter")}sjs_module.sjs_exports={sjs_liveTouchmove:sjs_liveTouchmove,sjs_clickLive:sjs_clickLive};return sjs_module.sjs_exports;}
  f_['./page/util/common.sjs']=sjs_require("p_./page/util/common.sjs");
  function sm_3(){var sjs_module={sjs_exports:{}};var sjs_starLeft=0;var sjs_starTop=0;var sjs_starX=0;var sjs_starY=0;function sjs_liveTouchmove(sjs_event,sjs_ownerInstance){var sjs_left=0,sjs_top=0;var sjs_diffX=0,sjs_diffY=0;if(sjs_event.sjs_type==="touchstart"){sjs_starLeft=sjs_event.sjs_currentTarget.sjs_offsetLeft;sjs_starTop=sjs_event.sjs_currentTarget.sjs_offsetTop;sjs_starX=sjs_event.sjs_changedTouches[0].sjs_clientX;sjs_starY=sjs_event.sjs_changedTouches[0].sjs_clientY;sjs_left=sjs_starLeft;sjs_top=sjs_starTop}else{sjs_diffX=sjs_event.sjs_changedTouches[0].sjs_clientX-sjs_starX;sjs_diffY=sjs_event.sjs_changedTouches[0].sjs_clientY-sjs_starY;sjs_left=sjs_starLeft+sjs_diffX;sjs_top=sjs_starTop+sjs_diffY}sjs_left=sjs_left+"px";var sjs_instance=sjs_ownerInstance.sjs_selectComponent(".liveMove");sjs_instance.sjs_setStyle({sjs_left:sjs_left,sjs_top:sjs_top+"px"})}function sjs_clickLive(sjs_event,sjs_ownerInstance){sjs_ownerInstance.sjs_callMethod("bindEnter")}sjs_module.sjs_exports={sjs_liveTouchmove:sjs_liveTouchmove,sjs_clickLive:sjs_clickLive};return sjs_module.sjs_exports;}

  
  d_["./component/communication-detail/index.maml"]={};
  var m0=function(e,s,r,gg){
    var z=gz$gma_1()
    var oB=e_["./component/communication-detail/index.maml"].i;_ai(oB,'../../page/common/head.maml',e_,'./component/communication-detail/index.maml',0,0);var oD=_ctn("view");var oE=_ctn("button");_setAttr(z,oE,'bindtap',0,e,s,gg);var oF=_o(z,1,e,s,gg);_ac(oE,oF);_ac(oD,oE);var oG=_ctn("button");_setAttr(z,oG,'bindtap',2,e,s,gg);var oH=_o(z,3,e,s,gg);_ac(oG,oH);_ac(oD,oG);var oI=_cvn();if(_o(z,4,e,s,gg)){oI.maVkey=1;var oJ=_ctn("view");var oL=_cvn();var oM=function(oQ,oP,oO,gg){var oN=_setAttrs(z,"detailItem",["bind:myevent",8,"class",1,"item",2],oQ,oP,gg);_ac(oO,oN);return oO;};_2(z,5,oM,e,s,gg,oL,"item","index",'name');_ac(oJ,oL);var oS=_ctn("slot");_ac(oJ,oS);_ac(oI,oJ);} _ac(oD,oI);_ac(r,oD);oB.pop();
    return r;
  };
  e_["./component/communication-detail/index.maml"]={f:m0,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./component/communication-detailItem/index.maml"]={};
  var m1=function(e,s,r,gg){
    var z=gz$gma_2()
    var oT=e_["./component/communication-detailItem/index.maml"].i;_ai(oT,'../../page/common/head.maml',e_,'./component/communication-detailItem/index.maml',0,0);var oV=_ctn("view");var oW=_ctn("button");_setAttr(z,oW,'bindtap',0,e,s,gg);var oX=_o(z,1,e,s,gg);_ac(oW,oX);_ac(oV,oW);_ac(r,oV);oT.pop();
    return r;
  };
  e_["./component/communication-detailItem/index.maml"]={f:m1,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./component/detail/index.maml"]={};
  var m2=function(e,s,r,gg){
    var z=gz$gma_3()
    var oY=e_["./component/detail/index.maml"].i;_ai(oY,'../../page/common/head.maml',e_,'./component/detail/index.maml',0,0);var oa=_ctn("view");_setAttr(z,oa,'class',0,e,s,gg);var ob=_cvn();
    var oc=_o(z,1,e,s,gg);
    var od=_gd('./component/detail/index.maml',oc,e_,d_);
    if(od){
      var oe=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      od(oe,oe,ob,gg);
      gg.f=tgf;
    }else{
      _w(oc,'./component/detail/index.maml',0,0);
    }
    _ac(oa,ob);var of=_ctn("button");_setAttr(z,of,'bindtap',3,e,s,gg);var og=_o(z,4,e,s,gg);_ac(of,og);_ac(oa,of);var oh=_ctn("button");var oi=_o(z,5,e,s,gg);_ac(oh,oi);_ac(oa,oh);var oj=_cvn();var ok=function(oo,on,om,gg){var ol=_ctn("view");_setAttr(z,ol,'style',9,oo,on,gg);var oq=_ctn("detailItem");_setAttr(z,oq,'item',10,oo,on,gg);_ac(ol,oq);_ac(om,ol);return om;};_2(z,6,ok,e,s,gg,oj,"item","index",'name');_ac(oa,oj);_ac(r,oa);oY.pop();
    return r;
  };
  e_["./component/detail/index.maml"]={f:m2,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./component/detailItem/index.maml"]={};
  var m3=function(e,s,r,gg){
    var z=gz$gma_4()
    var or=e_["./component/detailItem/index.maml"].i;_ai(or,'../../page/common/head.maml',e_,'./component/detailItem/index.maml',0,0);var ot=_ctn("view");_setAttr(z,ot,'class',0,e,s,gg);var ou=_cvn();
    var ov=_o(z,1,e,s,gg);
    var ow=_gd('./component/detailItem/index.maml',ov,e_,d_);
    if(ow){
      var ox=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ow(ox,ox,ou,gg);
      gg.f=tgf;
    }else{
      _w(ov,'./component/detailItem/index.maml',0,0);
    }
    _ac(ot,ou);var oy=_ctn("button");_setAttr(z,oy,'bindtap',3,e,s,gg);var oz=_o(z,4,e,s,gg);_ac(oy,oz);_ac(ot,oy);var o_=_ctn("button");var oAB=_o(z,5,e,s,gg);_ac(o_,oAB);_ac(ot,o_);_ac(r,ot);or.pop();
    return r;
  };
  e_["./component/detailItem/index.maml"]={f:m3,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./macle_demo_EN/component/communication-detail/index.maml"]={};
  var m4=function(e,s,r,gg){
    var z=gz$gma_5()
    var oBB=e_["./macle_demo_EN/component/communication-detail/index.maml"].i;_ai(oBB,'../../page/common/head.maml',e_,'./macle_demo_EN/component/communication-detail/index.maml',0,0);var oDB=_ctn("view");var oEB=_ctn("button");_setAttr(z,oEB,'bindtap',0,e,s,gg);var oFB=_o(z,1,e,s,gg);_ac(oEB,oFB);_ac(oDB,oEB);var oGB=_ctn("button");_setAttr(z,oGB,'bindtap',2,e,s,gg);var oHB=_o(z,3,e,s,gg);_ac(oGB,oHB);_ac(oDB,oGB);var oIB=_cvn();if(_o(z,4,e,s,gg)){oIB.maVkey=1;var oJB=_ctn("view");var oLB=_cvn();var oMB=function(oQB,oPB,oOB,gg){var oNB=_setAttrs(z,"detailItem",["bind:myevent",8,"class",1,"item",2],oQB,oPB,gg);_ac(oOB,oNB);return oOB;};_2(z,5,oMB,e,s,gg,oLB,"item","index",'name');_ac(oJB,oLB);var oSB=_ctn("slot");_ac(oJB,oSB);_ac(oIB,oJB);} _ac(oDB,oIB);_ac(r,oDB);oBB.pop();
    return r;
  };
  e_["./macle_demo_EN/component/communication-detail/index.maml"]={f:m4,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./macle_demo_EN/component/communication-detailItem/index.maml"]={};
  var m5=function(e,s,r,gg){
    var z=gz$gma_6()
    var oTB=e_["./macle_demo_EN/component/communication-detailItem/index.maml"].i;_ai(oTB,'../../page/common/head.maml',e_,'./macle_demo_EN/component/communication-detailItem/index.maml',0,0);var oVB=_ctn("view");var oWB=_ctn("button");_setAttr(z,oWB,'bindtap',0,e,s,gg);var oXB=_o(z,1,e,s,gg);_ac(oWB,oXB);_ac(oVB,oWB);_ac(r,oVB);oTB.pop();
    return r;
  };
  e_["./macle_demo_EN/component/communication-detailItem/index.maml"]={f:m5,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./macle_demo_EN/component/detail/index.maml"]={};
  var m6=function(e,s,r,gg){
    var z=gz$gma_7()
    var oYB=e_["./macle_demo_EN/component/detail/index.maml"].i;_ai(oYB,'../../page/common/head.maml',e_,'./macle_demo_EN/component/detail/index.maml',0,0);var oaB=_ctn("view");_setAttr(z,oaB,'class',0,e,s,gg);var obB=_cvn();
    var ocB=_o(z,1,e,s,gg);
    var odB=_gd('./macle_demo_EN/component/detail/index.maml',ocB,e_,d_);
    if(odB){
      var oeB=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      odB(oeB,oeB,obB,gg);
      gg.f=tgf;
    }else{
      _w(ocB,'./macle_demo_EN/component/detail/index.maml',0,0);
    }
    _ac(oaB,obB);var ofB=_ctn("button");_setAttr(z,ofB,'bindtap',3,e,s,gg);var ogB=_o(z,4,e,s,gg);_ac(ofB,ogB);_ac(oaB,ofB);var ohB=_ctn("button");var oiB=_o(z,5,e,s,gg);_ac(ohB,oiB);_ac(oaB,ohB);var ojB=_cvn();var okB=function(ooB,onB,omB,gg){var olB=_ctn("view");_setAttr(z,olB,'style',9,ooB,onB,gg);var oqB=_ctn("detailItem");_setAttr(z,oqB,'item',10,ooB,onB,gg);_ac(olB,oqB);_ac(omB,olB);return omB;};_2(z,6,okB,e,s,gg,ojB,"item","index",'name');_ac(oaB,ojB);_ac(r,oaB);oYB.pop();
    return r;
  };
  e_["./macle_demo_EN/component/detail/index.maml"]={f:m6,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./macle_demo_EN/component/detailItem/index.maml"]={};
  var m7=function(e,s,r,gg){
    var z=gz$gma_8()
    var orB=e_["./macle_demo_EN/component/detailItem/index.maml"].i;_ai(orB,'../../page/common/head.maml',e_,'./macle_demo_EN/component/detailItem/index.maml',0,0);var otB=_ctn("view");_setAttr(z,otB,'class',0,e,s,gg);var ouB=_cvn();
    var ovB=_o(z,1,e,s,gg);
    var owB=_gd('./macle_demo_EN/component/detailItem/index.maml',ovB,e_,d_);
    if(owB){
      var oxB=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      owB(oxB,oxB,ouB,gg);
      gg.f=tgf;
    }else{
      _w(ovB,'./macle_demo_EN/component/detailItem/index.maml',0,0);
    }
    _ac(otB,ouB);var oyB=_ctn("button");_setAttr(z,oyB,'bindtap',3,e,s,gg);var ozB=_o(z,4,e,s,gg);_ac(oyB,ozB);_ac(otB,oyB);var o_B=_ctn("button");var oAC=_o(z,5,e,s,gg);_ac(o_B,oAC);_ac(otB,o_B);_ac(r,otB);orB.pop();
    return r;
  };
  e_["./macle_demo_EN/component/detailItem/index.maml"]={f:m7,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/application-event/application-event.maml"]={};
  var m8=function(e,s,r,gg){
    var z=gz$gma_9()
    var oBC=e_["./macle_demo_EN/page/API/pages/application-event/application-event.maml"].i;_ai(oBC,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/application-event/application-event.maml',0,0);_ai(oBC,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/application-event/application-event.maml',0,0);var oEC=_ctn("view");_setAttr(z,oEC,'class',0,e,s,gg);var oFC=_cvn();
    var oGC=_o(z,1,e,s,gg);
    var oHC=_gd('./macle_demo_EN/page/API/pages/application-event/application-event.maml',oGC,e_,d_);
    if(oHC){
      var oIC=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oHC(oIC,oIC,oFC,gg);
      gg.f=tgf;
    }else{
      _w(oGC,'./macle_demo_EN/page/API/pages/application-event/application-event.maml',0,0);
    }
    _ac(oEC,oFC);var oJC=_ctn("view");_setAttr(z,oJC,'class',3,e,s,gg);var oKC=_setAttrs(z,"button",["bindtap",4,"class",1,"type",2],e,s,gg);var oLC=_o(z,4,e,s,gg);_ac(oKC,oLC);_ac(oJC,oKC);var oMC=_setAttrs(z,"button",["type",6,"bindtap",1,"class",1],e,s,gg);var oNC=_o(z,7,e,s,gg);_ac(oMC,oNC);_ac(oJC,oMC);var oOC=_setAttrs(z,"button",["type",6,"bindtap",2,"class",2],e,s,gg);var oPC=_o(z,8,e,s,gg);_ac(oOC,oPC);_ac(oJC,oOC);var oQC=_setAttrs(z,"button",["type",6,"bindtap",3,"class",3],e,s,gg);var oRC=_o(z,9,e,s,gg);_ac(oQC,oRC);_ac(oJC,oQC);var oSC=_setAttrs(z,"button",["type",6,"bindtap",4,"class",4],e,s,gg);var oTC=_o(z,10,e,s,gg);_ac(oSC,oTC);_ac(oJC,oSC);var oUC=_setAttrs(z,"button",["type",6,"bindtap",5,"class",5],e,s,gg);var oVC=_o(z,11,e,s,gg);_ac(oUC,oVC);_ac(oJC,oUC);var oWC=_setAttrs(z,"button",["type",6,"bindtap",6,"class",6],e,s,gg);var oXC=_o(z,12,e,s,gg);_ac(oWC,oXC);_ac(oJC,oWC);_ac(oEC,oJC);var oYC=_ctn("view");_setAttr(z,oYC,'class',13,e,s,gg);var oZC=_setAttrs(z,"view",["class",14,"style",1],e,s,gg);var oaC=_o(z,16,e,s,gg);_ac(oZC,oaC);_ac(oYC,oZC);_ac(oEC,oYC);var obC=_cvn();
    var ocC=_o(z,17,e,s,gg);
    var odC=_gd('./macle_demo_EN/page/API/pages/application-event/application-event.maml',ocC,e_,d_);
    if(odC){
      var oeC={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      odC(oeC,oeC,obC,gg);
      gg.f=tgf;
    }else{
      _w(ocC,'./macle_demo_EN/page/API/pages/application-event/application-event.maml',0,0);
    }
    _ac(oEC,obC);_ac(r,oEC);oBC.pop();oBC.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/application-event/application-event.maml"]={f:m8,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/canIUse/canIUse.maml"]={};
  var m9=function(e,s,r,gg){
    var z=gz$gma_10()
    var ofC=e_["./macle_demo_EN/page/API/pages/canIUse/canIUse.maml"].i;_ai(ofC,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/canIUse/canIUse.maml',0,0);_ai(ofC,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/canIUse/canIUse.maml',0,0);var oiC=_ctn("view");_setAttr(z,oiC,'class',0,e,s,gg);var ojC=_cvn();
    var okC=_o(z,1,e,s,gg);
    var olC=_gd('./macle_demo_EN/page/API/pages/canIUse/canIUse.maml',okC,e_,d_);
    if(olC){
      var omC=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      olC(omC,omC,ojC,gg);
      gg.f=tgf;
    }else{
      _w(okC,'./macle_demo_EN/page/API/pages/canIUse/canIUse.maml',0,0);
    }
    _ac(oiC,ojC);var onC=_ctn("view");_setAttr(z,onC,'class',3,e,s,gg);var ooC=_ctn("view");_setAttr(z,ooC,'class',4,e,s,gg);var opC=_ctn("view");_setAttr(z,opC,'class',5,e,s,gg);var oqC=_o(z,6,e,s,gg);_ac(opC,oqC);_ac(ooC,opC);var orC=_setAttrs(z,"button",["bindtap",7,"class",0,"type",1],e,s,gg);var osC=_o(z,9,e,s,gg);_ac(orC,osC);_ac(ooC,orC);var otC=_setAttrs(z,"button",["type",8,"bindtap",2,"class",2],e,s,gg);var ouC=_o(z,11,e,s,gg);_ac(otC,ouC);_ac(ooC,otC);var ovC=_setAttrs(z,"button",["type",8,"bindtap",4,"class",4],e,s,gg);var owC=_o(z,13,e,s,gg);_ac(ovC,owC);_ac(ooC,ovC);var oxC=_setAttrs(z,"button",["type",8,"bindtap",6,"class",6],e,s,gg);var oyC=_o(z,15,e,s,gg);_ac(oxC,oyC);_ac(ooC,oxC);var ozC=_setAttrs(z,"button",["type",8,"bindtap",8,"class",8],e,s,gg);var o_C=_o(z,17,e,s,gg);_ac(ozC,o_C);_ac(ooC,ozC);var oAD=_setAttrs(z,"button",["type",8,"bindtap",10,"class",10],e,s,gg);var oBD=_o(z,19,e,s,gg);_ac(oAD,oBD);_ac(ooC,oAD);var oCD=_setAttrs(z,"button",["type",8,"bindtap",12,"class",12],e,s,gg);var oDD=_o(z,21,e,s,gg);_ac(oCD,oDD);_ac(ooC,oCD);var oED=_setAttrs(z,"button",["type",8,"bindtap",14,"class",14],e,s,gg);var oFD=_o(z,23,e,s,gg);_ac(oED,oFD);_ac(ooC,oED);var oGD=_ctn("view");_setAttr(z,oGD,'class',24,e,s,gg);var oHD=_o(z,25,e,s,gg);_ac(oGD,oHD);_ac(ooC,oGD);var oID=_setAttrs(z,"button",["type",8,"bindtap",18,"class",18],e,s,gg);var oJD=_o(z,27,e,s,gg);_ac(oID,oJD);_ac(ooC,oID);var oKD=_setAttrs(z,"button",["type",8,"bindtap",20,"class",20],e,s,gg);var oLD=_o(z,29,e,s,gg);_ac(oKD,oLD);_ac(ooC,oKD);var oMD=_setAttrs(z,"button",["type",8,"bindtap",22,"class",22],e,s,gg);var oND=_o(z,31,e,s,gg);_ac(oMD,oND);_ac(ooC,oMD);var oOD=_setAttrs(z,"button",["type",8,"bindtap",24,"class",24],e,s,gg);var oPD=_o(z,33,e,s,gg);_ac(oOD,oPD);_ac(ooC,oOD);var oQD=_setAttrs(z,"button",["type",8,"bindtap",26,"class",26],e,s,gg);var oRD=_o(z,35,e,s,gg);_ac(oQD,oRD);_ac(ooC,oQD);var oSD=_setAttrs(z,"button",["type",8,"bindtap",28,"class",28],e,s,gg);var oTD=_o(z,37,e,s,gg);_ac(oSD,oTD);_ac(ooC,oSD);_ac(onC,ooC);_ac(oiC,onC);var oUD=_cvn();
    var oVD=_o(z,38,e,s,gg);
    var oWD=_gd('./macle_demo_EN/page/API/pages/canIUse/canIUse.maml',oVD,e_,d_);
    if(oWD){
      var oXD={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oWD(oXD,oXD,oUD,gg);
      gg.f=tgf;
    }else{
      _w(oVD,'./macle_demo_EN/page/API/pages/canIUse/canIUse.maml',0,0);
    }
    _ac(oiC,oUD);_ac(r,oiC);ofC.pop();ofC.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/canIUse/canIUse.maml"]={f:m9,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml"]={};
  var m10=function(e,s,r,gg){
    var z=gz$gma_11()
    var oYD=e_["./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml"].i;_ai(oYD,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml',0,0);_ai(oYD,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml',0,0);var obD=_ctn("view");_setAttr(z,obD,'class',0,e,s,gg);var ocD=_cvn();
    var odD=_o(z,1,e,s,gg);
    var oeD=_gd('./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml',odD,e_,d_);
    if(oeD){
      var ofD=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oeD(ofD,ofD,ocD,gg);
      gg.f=tgf;
    }else{
      _w(odD,'./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml',0,0);
    }
    _ac(obD,ocD);var ogD=_ctn("view");_setAttr(z,ogD,'class',3,e,s,gg);var ohD=_ctn("view");_setAttr(z,ohD,'class',4,e,s,gg);var oiD=_setAttrs(z,"button",["bindtap",5,"type",1],e,s,gg);var ojD=_o(z,7,e,s,gg);_ac(oiD,ojD);_ac(ohD,oiD);_ac(ogD,ohD);_ac(obD,ogD);var okD=_cvn();
    var olD=_o(z,8,e,s,gg);
    var omD=_gd('./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml',olD,e_,d_);
    if(omD){
      var onD={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      omD(onD,onD,okD,gg);
      gg.f=tgf;
    }else{
      _w(olD,'./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml',0,0);
    }
    _ac(obD,okD);_ac(r,obD);oYD.pop();oYD.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml"]={f:m10,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/compressImage/compressImage.maml"]={};
  var m11=function(e,s,r,gg){
    var z=gz$gma_12()
    var ooD=e_["./macle_demo_EN/page/API/pages/compressImage/compressImage.maml"].i;_ai(ooD,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/compressImage/compressImage.maml',0,0);_ai(ooD,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/compressImage/compressImage.maml',0,0);var orD=_ctn("view");_setAttr(z,orD,'class',0,e,s,gg);var osD=_cvn();
    var otD=_o(z,1,e,s,gg);
    var ouD=_gd('./macle_demo_EN/page/API/pages/compressImage/compressImage.maml',otD,e_,d_);
    if(ouD){
      var ovD=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ouD(ovD,ovD,osD,gg);
      gg.f=tgf;
    }else{
      _w(otD,'./macle_demo_EN/page/API/pages/compressImage/compressImage.maml',0,0);
    }
    _ac(orD,osD);var owD=_ctn("view");_setAttr(z,owD,'class',3,e,s,gg);var oxD=_ctn("form");var oyD=_ctn("view");_setAttr(z,oyD,'class',4,e,s,gg);var ozD=_ctn("view");var o_D=_setAttrs(z,"image",["mode",5,"src",1,"style",2],e,s,gg);_ac(ozD,o_D);var oAE=_setAttrs(z,"button",["bindtap",8,"class",1],e,s,gg);var oBE=_o(z,10,e,s,gg);_ac(oAE,oBE);_ac(ozD,oAE);var oCE=_setAttrs(z,"button",["bindtap",11,"class",1],e,s,gg);var oDE=_o(z,13,e,s,gg);_ac(oCE,oDE);_ac(ozD,oCE);_ac(oyD,ozD);var oEE=_cvn();if(_o(z,14,e,s,gg)){oEE.maVkey=1;var oFE=_ctn("view");_setAttr(z,oFE,'class',15,e,s,gg);var oHE=_ctn("text");_setAttr(z,oHE,'class',16,e,s,gg);var oIE=_o(z,17,e,s,gg);_ac(oHE,oIE);_ac(oFE,oHE);_ac(oEE,oFE);} _ac(oyD,oEE);var oJE=_cvn();if(_o(z,18,e,s,gg)){oJE.maVkey=1;var oKE=_ctn("view");var oME=_ctn("text");_setAttr(z,oME,'class',19,e,s,gg);var oNE=_o(z,20,e,s,gg);_ac(oME,oNE);_ac(oKE,oME);_ac(oJE,oKE);} _ac(oyD,oJE);var oOE=_cvn();if(_o(z,21,e,s,gg)){oOE.maVkey=1;var oPE=_ctn("view");var oRE=_ctn("text");_setAttr(z,oRE,'space',22,e,s,gg);var oSE=_o(z,23,e,s,gg);_ac(oRE,oSE);_ac(oPE,oRE);_ac(oOE,oPE);} _ac(oyD,oOE);_ac(oxD,oyD);_ac(owD,oxD);_ac(orD,owD);var oTE=_cvn();
    var oUE=_o(z,24,e,s,gg);
    var oVE=_gd('./macle_demo_EN/page/API/pages/compressImage/compressImage.maml',oUE,e_,d_);
    if(oVE){
      var oWE={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oVE(oWE,oWE,oTE,gg);
      gg.f=tgf;
    }else{
      _w(oUE,'./macle_demo_EN/page/API/pages/compressImage/compressImage.maml',0,0);
    }
    _ac(orD,oTE);_ac(r,orD);ooD.pop();ooD.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/compressImage/compressImage.maml"]={f:m11,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml"]={};
  var m12=function(e,s,r,gg){
    var z=gz$gma_13()
    var oXE=e_["./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml"].i;_ai(oXE,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml',0,0);_ai(oXE,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml',0,0);var oaE=_ctn("view");_setAttr(z,oaE,'class',0,e,s,gg);var obE=_cvn();
    var ocE=_o(z,1,e,s,gg);
    var odE=_gd('./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml',ocE,e_,d_);
    if(odE){
      var oeE=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      odE(oeE,oeE,obE,gg);
      gg.f=tgf;
    }else{
      _w(ocE,'./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml',0,0);
    }
    _ac(oaE,obE);var ofE=_ctn("view");_setAttr(z,ofE,'class',3,e,s,gg);var ogE=_ctn("view");_setAttr(z,ogE,'class',4,e,s,gg);var ohE=_setAttrs(z,"button",["bindtap",5,"class",1,"type",2],e,s,gg);var oiE=_o(z,8,e,s,gg);_ac(ohE,oiE);_ac(ogE,ohE);var ojE=_setAttrs(z,"button",["bindtap",6,"type",1,"class",3],e,s,gg);var okE=_o(z,10,e,s,gg);_ac(ojE,okE);_ac(ogE,ojE);_ac(ofE,ogE);var olE=_ctn("view");_setAttr(z,olE,'class',11,e,s,gg);var omE=_ctn("text");var onE=_o(z,12,e,s,gg);_ac(omE,onE);_ac(olE,omE);var ooE=_setAttrs(z,"switch",["bindchange",13,"checked",1],e,s,gg);_ac(olE,ooE);_ac(ofE,olE);var opE=_cvn();if(_o(z,15,e,s,gg)){opE.maVkey=1;var oqE=_ctn("view");_setAttr(z,oqE,'class',16,e,s,gg);var osE=_ctn("text");_setAttr(z,osE,'class',16,e,s,gg);var otE=_o(z,17,e,s,gg);_ac(osE,otE);_ac(oqE,osE);var ouE=_ctn("text");_setAttr(z,ouE,'class',18,e,s,gg);var ovE=_o(z,19,e,s,gg);_ac(ouE,ovE);_ac(oqE,ouE);_ac(opE,oqE);} _ac(ofE,opE);_ac(oaE,ofE);var owE=_cvn();
    var oxE=_o(z,20,e,s,gg);
    var oyE=_gd('./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml',oxE,e_,d_);
    if(oyE){
      var ozE={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oyE(ozE,ozE,owE,gg);
      gg.f=tgf;
    }else{
      _w(oxE,'./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml',0,0);
    }
    _ac(oaE,owE);_ac(r,oaE);oXE.pop();oXE.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml"]={f:m12,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/file/file.maml"]={};
  var m13=function(e,s,r,gg){
    var z=gz$gma_14()
    var o_E=e_["./macle_demo_EN/page/API/pages/file/file.maml"].i;_ai(o_E,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/file/file.maml',0,0);_ai(o_E,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/file/file.maml',0,0);var oCF=_ctn("view");_setAttr(z,oCF,'class',0,e,s,gg);var oDF=_cvn();
    var oEF=_o(z,1,e,s,gg);
    var oFF=_gd('./macle_demo_EN/page/API/pages/file/file.maml',oEF,e_,d_);
    if(oFF){
      var oGF=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oFF(oGF,oGF,oDF,gg);
      gg.f=tgf;
    }else{
      _w(oEF,'./macle_demo_EN/page/API/pages/file/file.maml',0,0);
    }
    _ac(oCF,oDF);var oHF=_ctn("view");_setAttr(z,oHF,'class',3,e,s,gg);var oIF=_ctn("view");_setAttr(z,oIF,'class',4,e,s,gg);var oJF=_ctn("view");_setAttr(z,oJF,'class',5,e,s,gg);var oKF=_cvn();if(_o(z,6,e,s,gg)){oKF.maVkey=1;var oNF=_setAttrs(z,"image",["class",7,"mode",1,"src",2],e,s,gg);_ac(oKF,oNF);} _ac(oJF,oKF);var oOF=_cvn();if(_o(z,10,e,s,gg)){oOF.maVkey=1;var oRF=_setAttrs(z,"image",["class",7,"mode",1,"src",4],e,s,gg);_ac(oOF,oRF);} _ac(oJF,oOF);var oSF=_cvn();if(_o(z,12,e,s,gg)){oSF.maVkey=1;var oVF=_setAttrs(z,"view",["bindtap",13,"class",1],e,s,gg);var oWF=_ctn("view");_setAttr(z,oWF,'class',15,e,s,gg);_ac(oVF,oWF);var oXF=_ctn("view");_setAttr(z,oXF,'class',16,e,s,gg);_ac(oVF,oXF);_ac(oSF,oVF);var oYF=_ctn("view");_setAttr(z,oYF,'class',17,e,s,gg);var oZF=_o(z,18,e,s,gg);_ac(oYF,oZF);_ac(oSF,oYF);} _ac(oJF,oSF);_ac(oIF,oJF);var oaF=_ctn("view");_setAttr(z,oaF,'class',19,e,s,gg);var obF=_setAttrs(z,"button",["bindtap",20,"type",1],e,s,gg);var ocF=_o(z,22,e,s,gg);_ac(obF,ocF);_ac(oaF,obF);var odF=_ctn("button");_setAttr(z,odF,'bindtap',23,e,s,gg);var oeF=_o(z,23,e,s,gg);_ac(odF,oeF);_ac(oaF,odF);var ofF=_setAttrs(z,"button",["type",21,"bindtap",3],e,s,gg);var ogF=_o(z,25,e,s,gg);_ac(ofF,ogF);_ac(oaF,ofF);var ohF=_setAttrs(z,"button",["type",21,"bindtap",5],e,s,gg);var oiF=_o(z,27,e,s,gg);_ac(ohF,oiF);_ac(oaF,ohF);var ojF=_setAttrs(z,"button",["type",21,"bindtap",7],e,s,gg);var okF=_o(z,27,e,s,gg);_ac(ojF,okF);_ac(oaF,ojF);var olF=_setAttrs(z,"button",["type",21,"bindtap",8],e,s,gg);var omF=_o(z,30,e,s,gg);_ac(olF,omF);_ac(oaF,olF);_ac(oIF,oaF);var onF=_ctn("view");_setAttr(z,onF,'class',31,e,s,gg);var ooF=_ctn("view");var opF=_o(z,32,e,s,gg);_ac(ooF,opF);_ac(onF,ooF);var oqF=_ctn("text");var orF=_o(z,33,e,s,gg);_ac(oqF,orF);_ac(onF,oqF);_ac(oIF,onF);_ac(oHF,oIF);_ac(oCF,oHF);var osF=_cvn();
    var otF=_o(z,34,e,s,gg);
    var ouF=_gd('./macle_demo_EN/page/API/pages/file/file.maml',otF,e_,d_);
    if(ouF){
      var ovF={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ouF(ovF,ovF,osF,gg);
      gg.f=tgf;
    }else{
      _w(otF,'./macle_demo_EN/page/API/pages/file/file.maml',0,0);
    }
    _ac(oCF,osF);_ac(r,oCF);o_E.pop();o_E.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/file/file.maml"]={f:m13,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml"]={};
  var m14=function(e,s,r,gg){
    var z=gz$gma_15()
    var owF=e_["./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml"].i;_ai(owF,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml',0,0);_ai(owF,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml',0,0);var ozF=_ctn("view");_setAttr(z,ozF,'class',0,e,s,gg);var o_F=_cvn();
    var oAG=_o(z,1,e,s,gg);
    var oBG=_gd('./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml',oAG,e_,d_);
    if(oBG){
      var oCG=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oBG(oCG,oCG,o_F,gg);
      gg.f=tgf;
    }else{
      _w(oAG,'./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml',0,0);
    }
    _ac(ozF,o_F);var oDG=_ctn("view");_setAttr(z,oDG,'class',3,e,s,gg);var oEG=_ctn("view");_setAttr(z,oEG,'class',4,e,s,gg);var oFG=_ctn("view");_setAttr(z,oFG,'class',5,e,s,gg);var oGG=_ctn("view");_setAttr(z,oGG,'class',6,e,s,gg);var oHG=_ctn("view");_setAttr(z,oHG,'class',7,e,s,gg);var oIG=_ctn("view");_setAttr(z,oIG,'class',8,e,s,gg);var oJG=_o(z,9,e,s,gg);_ac(oIG,oJG);_ac(oHG,oIG);_ac(oGG,oHG);var oKG=_ctn("view");_setAttr(z,oKG,'class',10,e,s,gg);var oLG=_setAttrs(z,"input",["class",11,"disabled",1,"placeholder",2,"type",3,"value",4],e,s,gg);_ac(oKG,oLG);_ac(oGG,oKG);_ac(oFG,oGG);var oMG=_ctn("view");_setAttr(z,oMG,'class',6,e,s,gg);var oNG=_ctn("view");_setAttr(z,oNG,'class',7,e,s,gg);var oOG=_ctn("view");_setAttr(z,oOG,'class',8,e,s,gg);var oPG=_o(z,16,e,s,gg);_ac(oOG,oPG);_ac(oNG,oOG);_ac(oMG,oNG);var oQG=_ctn("view");_setAttr(z,oQG,'class',10,e,s,gg);var oRG=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",5,"value",6],e,s,gg);_ac(oQG,oRG);_ac(oMG,oQG);_ac(oFG,oMG);_ac(oEG,oFG);var oSG=_setAttrs(z,"button",["bind:tap",19,"class",0,"type",1],e,s,gg);var oTG=_o(z,21,e,s,gg);_ac(oSG,oTG);_ac(oEG,oSG);_ac(oDG,oEG);_ac(ozF,oDG);var oUG=_cvn();
    var oVG=_o(z,22,e,s,gg);
    var oWG=_gd('./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml',oVG,e_,d_);
    if(oWG){
      var oXG={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oWG(oXG,oXG,oUG,gg);
      gg.f=tgf;
    }else{
      _w(oVG,'./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml',0,0);
    }
    _ac(ozF,oUG);_ac(r,ozF);owF.pop();owF.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml"]={f:m14,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml"]={};
  var m15=function(e,s,r,gg){
    var z=gz$gma_16()
    var oYG=e_["./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml"].i;_ai(oYG,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml',0,0);_ai(oYG,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml',0,0);var obG=_ctn("view");_setAttr(z,obG,'class',0,e,s,gg);var ocG=_cvn();
    var odG=_o(z,1,e,s,gg);
    var oeG=_gd('./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml',odG,e_,d_);
    if(oeG){
      var ofG=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oeG(ofG,ofG,ocG,gg);
      gg.f=tgf;
    }else{
      _w(odG,'./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml',0,0);
    }
    _ac(obG,ocG);var ogG=_ctn("view");_setAttr(z,ogG,'class',3,e,s,gg);var ohG=_ctn("form");var oiG=_ctn("view");_setAttr(z,oiG,'class',4,e,s,gg);var ojG=_ctn("view");var okG=_setAttrs(z,"image",["mode",5,"src",1,"style",2],e,s,gg);_ac(ojG,okG);var olG=_setAttrs(z,"image",["mode",5,"style",2,"src",3],e,s,gg);_ac(ojG,olG);var omG=_setAttrs(z,"button",["bindtap",9,"class",0],e,s,gg);var onG=_o(z,9,e,s,gg);_ac(omG,onG);_ac(ojG,omG);var ooG=_setAttrs(z,"button",["bindtap",10,"class",1],e,s,gg);var opG=_o(z,12,e,s,gg);_ac(ooG,opG);_ac(ojG,ooG);var oqG=_setAttrs(z,"button",["bindtap",13,"class",1],e,s,gg);var orG=_o(z,15,e,s,gg);_ac(oqG,orG);_ac(ojG,oqG);_ac(oiG,ojG);var osG=_cvn();if(_o(z,16,e,s,gg)){osG.maVkey=1;var otG=_ctn("view");_setAttr(z,otG,'class',17,e,s,gg);var ovG=_ctn("text");_setAttr(z,ovG,'class',18,e,s,gg);var owG=_o(z,19,e,s,gg);_ac(ovG,owG);_ac(otG,ovG);_ac(osG,otG);} _ac(oiG,osG);var oxG=_cvn();if(_o(z,20,e,s,gg)){oxG.maVkey=1;var oyG=_ctn("view");_setAttr(z,oyG,'class',17,e,s,gg);var o_G=_ctn("text");_setAttr(z,o_G,'space',21,e,s,gg);var oAH=_o(z,22,e,s,gg);_ac(o_G,oAH);_ac(oyG,o_G);_ac(oxG,oyG);} _ac(oiG,oxG);_ac(ohG,oiG);_ac(ogG,ohG);_ac(obG,ogG);var oBH=_cvn();
    var oCH=_o(z,23,e,s,gg);
    var oDH=_gd('./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml',oCH,e_,d_);
    if(oDH){
      var oEH={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oDH(oEH,oEH,oBH,gg);
      gg.f=tgf;
    }else{
      _w(oCH,'./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml',0,0);
    }
    _ac(obG,oBH);_ac(r,obG);oYG.pop();oYG.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml"]={f:m15,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/get-location/get-location.maml"]={};
  var m16=function(e,s,r,gg){
    var z=gz$gma_17()
    var oFH=e_["./macle_demo_EN/page/API/pages/get-location/get-location.maml"].i;_ai(oFH,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/get-location/get-location.maml',0,0);_ai(oFH,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/get-location/get-location.maml',0,0);var oIH=_ctn("view");_setAttr(z,oIH,'class',0,e,s,gg);var oJH=_cvn();
    var oKH=_o(z,1,e,s,gg);
    var oLH=_gd('./macle_demo_EN/page/API/pages/get-location/get-location.maml',oKH,e_,d_);
    if(oLH){
      var oMH=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oLH(oMH,oMH,oJH,gg);
      gg.f=tgf;
    }else{
      _w(oKH,'./macle_demo_EN/page/API/pages/get-location/get-location.maml',0,0);
    }
    _ac(oIH,oJH);var oNH=_ctn("view");_setAttr(z,oNH,'class',3,e,s,gg);var oOH=_ctn("view");_setAttr(z,oOH,'class',4,e,s,gg);var oPH=_ctn("view");_setAttr(z,oPH,'class',5,e,s,gg);var oQH=_ctn("text");_setAttr(z,oQH,'class',6,e,s,gg);var oRH=_o(z,7,e,s,gg);_ac(oQH,oRH);_ac(oPH,oQH);var oSH=_cvn();if(_o(z,8,e,s,gg)){oSH.maVkey=1;var oVH=_ctn("text");_setAttr(z,oVH,'class',9,e,s,gg);var oWH=_o(z,10,e,s,gg);_ac(oVH,oWH);_ac(oSH,oVH);} _ac(oPH,oSH);var oXH=_cvn();if(_o(z,11,e,s,gg)){oXH.maVkey=1;var oaH=_ctn("view");_setAttr(z,oaH,'class',12,e,s,gg);var obH=_ctn("text");_setAttr(z,obH,'class',13,e,s,gg);var ocH=_o(z,14,e,s,gg);_ac(obH,ocH);_ac(oaH,obH);var odH=_ctn("text");var oeH=_o(z,15,e,s,gg);_ac(odH,oeH);_ac(oaH,odH);_ac(oXH,oaH);} _ac(oPH,oXH);_ac(oOH,oPH);var ofH=_ctn("view");_setAttr(z,ofH,'class',16,e,s,gg);var ogH=_setAttrs(z,"button",["bindtap",17,"class",0,"type",1],e,s,gg);var ohH=_o(z,19,e,s,gg);_ac(ogH,ohH);_ac(ofH,ogH);var oiH=_setAttrs(z,"button",["bindtap",20,"class",0],e,s,gg);var ojH=_o(z,21,e,s,gg);_ac(oiH,ojH);_ac(ofH,oiH);_ac(oOH,ofH);_ac(oNH,oOH);_ac(oIH,oNH);var okH=_cvn();
    var olH=_o(z,22,e,s,gg);
    var omH=_gd('./macle_demo_EN/page/API/pages/get-location/get-location.maml',olH,e_,d_);
    if(omH){
      var onH={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      omH(onH,onH,okH,gg);
      gg.f=tgf;
    }else{
      _w(olH,'./macle_demo_EN/page/API/pages/get-location/get-location.maml',0,0);
    }
    _ac(oIH,okH);_ac(r,oIH);oFH.pop();oFH.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/get-location/get-location.maml"]={f:m16,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml"]={};
  var m17=function(e,s,r,gg){
    var z=gz$gma_18()
    var ooH=e_["./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml"].i;_ai(ooH,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml',0,0);_ai(ooH,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml',0,0);var orH=_ctn("view");_setAttr(z,orH,'class',0,e,s,gg);var osH=_cvn();
    var otH=_o(z,1,e,s,gg);
    var ouH=_gd('./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml',otH,e_,d_);
    if(ouH){
      var ovH=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ouH(ovH,ovH,osH,gg);
      gg.f=tgf;
    }else{
      _w(otH,'./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml',0,0);
    }
    _ac(orH,osH);var owH=_ctn("view");_setAttr(z,owH,'class',3,e,s,gg);var oxH=_ctn("view");_setAttr(z,oxH,'class',4,e,s,gg);var oyH=_ctn("view");var ozH=_o(z,5,e,s,gg);_ac(oyH,ozH);_ac(oxH,oyH);var o_H=_ctn("view");_setAttr(z,o_H,'class',6,e,s,gg);var oAI=_ctn("view");_setAttr(z,oAI,'class',7,e,s,gg);var oBI=_ctn("view");_setAttr(z,oBI,'class',8,e,s,gg);var oCI=_o(z,9,e,s,gg);_ac(oBI,oCI);_ac(oAI,oBI);_ac(o_H,oAI);var oDI=_ctn("view");_setAttr(z,oDI,'class',7,e,s,gg);var oEI=_ctn("view");_setAttr(z,oEI,'class',8,e,s,gg);var oFI=_o(z,10,e,s,gg);_ac(oEI,oFI);_ac(oDI,oEI);_ac(o_H,oDI);_ac(oxH,o_H);var oGI=_setAttrs(z,"button",["bindtap",11,"type",1],e,s,gg);var oHI=_o(z,13,e,s,gg);_ac(oGI,oHI);_ac(oxH,oGI);_ac(owH,oxH);_ac(orH,owH);var oII=_cvn();
    var oJI=_o(z,14,e,s,gg);
    var oKI=_gd('./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml',oJI,e_,d_);
    if(oKI){
      var oLI={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oKI(oLI,oLI,oII,gg);
      gg.f=tgf;
    }else{
      _w(oJI,'./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml',0,0);
    }
    _ac(orH,oII);_ac(r,orH);ooH.pop();ooH.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml"]={f:m17,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml"]={};
  var m18=function(e,s,r,gg){
    var z=gz$gma_19()
    var oMI=e_["./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml"].i;_ai(oMI,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml',0,0);_ai(oMI,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml',0,0);var oPI=_ctn("view");_setAttr(z,oPI,'class',0,e,s,gg);var oQI=_cvn();
    var oRI=_o(z,1,e,s,gg);
    var oSI=_gd('./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml',oRI,e_,d_);
    if(oSI){
      var oTI=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oSI(oTI,oTI,oQI,gg);
      gg.f=tgf;
    }else{
      _w(oRI,'./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml',0,0);
    }
    _ac(oPI,oQI);var oUI=_ctn("view");_setAttr(z,oUI,'class',3,e,s,gg);var oVI=_ctn("view");_setAttr(z,oVI,'class',4,e,s,gg);var oWI=_ctn("view");_setAttr(z,oWI,'class',5,e,s,gg);var oXI=_ctn("view");_setAttr(z,oXI,'class',6,e,s,gg);var oYI=_ctn("view");_setAttr(z,oYI,'class',7,e,s,gg);var oZI=_ctn("view");_setAttr(z,oZI,'class',8,e,s,gg);var oaI=_o(z,9,e,s,gg);_ac(oZI,oaI);_ac(oYI,oZI);_ac(oXI,oYI);var obI=_ctn("view");_setAttr(z,obI,'class',10,e,s,gg);var ocI=_setAttrs(z,"input",["class",11,"disabled",1,"placeholder",2,"type",3,"value",4],e,s,gg);_ac(obI,ocI);_ac(oXI,obI);_ac(oWI,oXI);var odI=_ctn("view");_setAttr(z,odI,'class',6,e,s,gg);var oeI=_ctn("view");_setAttr(z,oeI,'class',7,e,s,gg);var ofI=_ctn("view");_setAttr(z,ofI,'class',8,e,s,gg);var ogI=_o(z,16,e,s,gg);_ac(ofI,ogI);_ac(oeI,ofI);_ac(odI,oeI);var ohI=_ctn("view");_setAttr(z,ohI,'class',10,e,s,gg);var oiI=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",5,"value",6],e,s,gg);_ac(ohI,oiI);_ac(odI,ohI);_ac(oWI,odI);var ojI=_ctn("view");_setAttr(z,ojI,'class',6,e,s,gg);var okI=_ctn("view");_setAttr(z,okI,'class',7,e,s,gg);var olI=_ctn("view");_setAttr(z,olI,'class',8,e,s,gg);var omI=_o(z,19,e,s,gg);_ac(olI,omI);_ac(okI,olI);_ac(ojI,okI);var onI=_ctn("view");_setAttr(z,onI,'class',10,e,s,gg);var ooI=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",8,"value",9],e,s,gg);_ac(onI,ooI);_ac(ojI,onI);_ac(oWI,ojI);var opI=_ctn("view");_setAttr(z,opI,'class',6,e,s,gg);var oqI=_ctn("view");_setAttr(z,oqI,'class',7,e,s,gg);var orI=_ctn("view");_setAttr(z,orI,'class',8,e,s,gg);var osI=_o(z,22,e,s,gg);_ac(orI,osI);_ac(oqI,orI);_ac(opI,oqI);var otI=_ctn("view");_setAttr(z,otI,'class',10,e,s,gg);var ouI=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",11,"value",12],e,s,gg);_ac(otI,ouI);_ac(opI,otI);_ac(oWI,opI);var ovI=_ctn("view");_setAttr(z,ovI,'class',6,e,s,gg);var owI=_ctn("view");_setAttr(z,owI,'class',7,e,s,gg);var oxI=_ctn("view");_setAttr(z,oxI,'class',8,e,s,gg);var oyI=_o(z,25,e,s,gg);_ac(oxI,oyI);_ac(owI,oxI);_ac(ovI,owI);var ozI=_ctn("view");_setAttr(z,ozI,'class',10,e,s,gg);var o_I=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",14,"value",15],e,s,gg);_ac(ozI,o_I);_ac(ovI,ozI);_ac(oWI,ovI);var oAJ=_ctn("view");_setAttr(z,oAJ,'class',6,e,s,gg);var oBJ=_ctn("view");_setAttr(z,oBJ,'class',7,e,s,gg);var oCJ=_ctn("view");_setAttr(z,oCJ,'class',8,e,s,gg);var oDJ=_o(z,28,e,s,gg);_ac(oCJ,oDJ);_ac(oBJ,oCJ);_ac(oAJ,oBJ);var oEJ=_ctn("view");_setAttr(z,oEJ,'class',10,e,s,gg);var oFJ=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",17,"value",18],e,s,gg);_ac(oEJ,oFJ);_ac(oAJ,oEJ);_ac(oWI,oAJ);var oGJ=_ctn("view");_setAttr(z,oGJ,'class',6,e,s,gg);var oHJ=_ctn("view");_setAttr(z,oHJ,'class',7,e,s,gg);var oIJ=_ctn("view");_setAttr(z,oIJ,'class',8,e,s,gg);var oJJ=_o(z,31,e,s,gg);_ac(oIJ,oJJ);_ac(oHJ,oIJ);_ac(oGJ,oHJ);var oKJ=_ctn("view");_setAttr(z,oKJ,'class',10,e,s,gg);var oLJ=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",20,"value",21],e,s,gg);_ac(oKJ,oLJ);_ac(oGJ,oKJ);_ac(oWI,oGJ);var oMJ=_ctn("view");_setAttr(z,oMJ,'class',6,e,s,gg);var oNJ=_ctn("view");_setAttr(z,oNJ,'class',7,e,s,gg);var oOJ=_ctn("view");_setAttr(z,oOJ,'class',8,e,s,gg);var oPJ=_o(z,34,e,s,gg);_ac(oOJ,oPJ);_ac(oNJ,oOJ);_ac(oMJ,oNJ);var oQJ=_ctn("view");_setAttr(z,oQJ,'class',10,e,s,gg);var oRJ=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",23,"value",24],e,s,gg);_ac(oQJ,oRJ);_ac(oMJ,oQJ);_ac(oWI,oMJ);var oSJ=_ctn("view");_setAttr(z,oSJ,'class',6,e,s,gg);var oTJ=_ctn("view");_setAttr(z,oTJ,'class',7,e,s,gg);var oUJ=_ctn("view");_setAttr(z,oUJ,'class',8,e,s,gg);var oVJ=_o(z,37,e,s,gg);_ac(oUJ,oVJ);_ac(oTJ,oUJ);_ac(oSJ,oTJ);var oWJ=_ctn("view");_setAttr(z,oWJ,'class',10,e,s,gg);var oXJ=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",26,"value",27],e,s,gg);_ac(oWJ,oXJ);_ac(oSJ,oWJ);_ac(oWI,oSJ);var oYJ=_ctn("view");_setAttr(z,oYJ,'class',6,e,s,gg);var oZJ=_ctn("view");_setAttr(z,oZJ,'class',7,e,s,gg);var oaJ=_ctn("view");_setAttr(z,oaJ,'class',8,e,s,gg);var obJ=_o(z,40,e,s,gg);_ac(oaJ,obJ);_ac(oZJ,oaJ);_ac(oYJ,oZJ);var ocJ=_ctn("view");_setAttr(z,ocJ,'class',10,e,s,gg);var odJ=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",29,"value",30],e,s,gg);_ac(ocJ,odJ);_ac(oYJ,ocJ);_ac(oWI,oYJ);_ac(oVI,oWI);var oeJ=_ctn("view");_setAttr(z,oeJ,'class',43,e,s,gg);var ofJ=_setAttrs(z,"button",["bindtap",44,"class",1,"type",2],e,s,gg);var ogJ=_o(z,47,e,s,gg);_ac(ofJ,ogJ);_ac(oeJ,ofJ);_ac(oVI,oeJ);_ac(oUI,oVI);_ac(oPI,oUI);var ohJ=_cvn();
    var oiJ=_o(z,48,e,s,gg);
    var ojJ=_gd('./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml',oiJ,e_,d_);
    if(ojJ){
      var okJ={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ojJ(okJ,okJ,ohJ,gg);
      gg.f=tgf;
    }else{
      _w(oiJ,'./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml',0,0);
    }
    _ac(oPI,ohJ);_ac(r,oPI);oMI.pop();oMI.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml"]={f:m18,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml"]={};
  var m19=function(e,s,r,gg){
    var z=gz$gma_20()
    var olJ=e_["./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml"].i;_ai(olJ,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml',0,0);_ai(olJ,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml',0,0);var ooJ=_ctn("view");_setAttr(z,ooJ,'class',0,e,s,gg);var opJ=_cvn();
    var oqJ=_o(z,1,e,s,gg);
    var orJ=_gd('./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml',oqJ,e_,d_);
    if(orJ){
      var osJ=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      orJ(osJ,osJ,opJ,gg);
      gg.f=tgf;
    }else{
      _w(oqJ,'./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml',0,0);
    }
    _ac(ooJ,opJ);var otJ=_ctn("view");_setAttr(z,otJ,'class',3,e,s,gg);var ouJ=_ctn("view");_setAttr(z,ouJ,'class',4,e,s,gg);var ovJ=_ctn("view");_setAttr(z,ovJ,'class',5,e,s,gg);var owJ=_ctn("view");_setAttr(z,owJ,'class',6,e,s,gg);var oxJ=_ctn("view");_setAttr(z,oxJ,'class',7,e,s,gg);var oyJ=_ctn("view");_setAttr(z,oyJ,'class',8,e,s,gg);var ozJ=_o(z,9,e,s,gg);_ac(oyJ,ozJ);_ac(oxJ,oyJ);_ac(owJ,oxJ);var o_J=_ctn("view");_setAttr(z,o_J,'class',10,e,s,gg);var oAK=_setAttrs(z,"input",["class",11,"disabled",1,"placeholder",2,"type",3,"value",4],e,s,gg);_ac(o_J,oAK);_ac(owJ,o_J);_ac(ovJ,owJ);var oBK=_ctn("view");_setAttr(z,oBK,'class',6,e,s,gg);var oCK=_ctn("view");_setAttr(z,oCK,'class',7,e,s,gg);var oDK=_ctn("view");_setAttr(z,oDK,'class',8,e,s,gg);var oEK=_o(z,16,e,s,gg);_ac(oDK,oEK);_ac(oCK,oDK);_ac(oBK,oCK);var oFK=_ctn("view");_setAttr(z,oFK,'class',10,e,s,gg);var oGK=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",5,"value",6],e,s,gg);_ac(oFK,oGK);_ac(oBK,oFK);_ac(ovJ,oBK);var oHK=_ctn("view");_setAttr(z,oHK,'class',6,e,s,gg);var oIK=_ctn("view");_setAttr(z,oIK,'class',7,e,s,gg);var oJK=_ctn("view");_setAttr(z,oJK,'class',8,e,s,gg);var oKK=_o(z,19,e,s,gg);_ac(oJK,oKK);_ac(oIK,oJK);_ac(oHK,oIK);var oLK=_ctn("view");_setAttr(z,oLK,'class',10,e,s,gg);var oMK=_setAttrs(z,"input",["disabled",12,"type",2,"placeholder",7,"class",8,"value",9],e,s,gg);_ac(oLK,oMK);_ac(oHK,oLK);_ac(ovJ,oHK);var oNK=_ctn("view");_setAttr(z,oNK,'class',6,e,s,gg);var oOK=_ctn("view");_setAttr(z,oOK,'class',7,e,s,gg);var oPK=_ctn("view");_setAttr(z,oPK,'class',8,e,s,gg);var oQK=_o(z,22,e,s,gg);_ac(oPK,oQK);_ac(oOK,oPK);_ac(oNK,oOK);var oRK=_ctn("view");_setAttr(z,oRK,'class',10,e,s,gg);var oSK=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",11,"value",12],e,s,gg);_ac(oRK,oSK);_ac(oNK,oRK);_ac(ovJ,oNK);var oTK=_ctn("view");_setAttr(z,oTK,'class',6,e,s,gg);var oUK=_ctn("view");_setAttr(z,oUK,'class',7,e,s,gg);var oVK=_ctn("view");_setAttr(z,oVK,'class',8,e,s,gg);var oWK=_o(z,25,e,s,gg);_ac(oVK,oWK);_ac(oUK,oVK);_ac(oTK,oUK);var oXK=_ctn("view");_setAttr(z,oXK,'class',10,e,s,gg);var oYK=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",14,"value",15],e,s,gg);_ac(oXK,oYK);_ac(oTK,oXK);_ac(ovJ,oTK);var oZK=_ctn("view");_setAttr(z,oZK,'class',6,e,s,gg);var oaK=_ctn("view");_setAttr(z,oaK,'class',7,e,s,gg);var obK=_ctn("view");_setAttr(z,obK,'class',8,e,s,gg);var ocK=_o(z,28,e,s,gg);_ac(obK,ocK);_ac(oaK,obK);_ac(oZK,oaK);var odK=_ctn("view");_setAttr(z,odK,'class',10,e,s,gg);var oeK=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",17,"value",18],e,s,gg);_ac(odK,oeK);_ac(oZK,odK);_ac(ovJ,oZK);var ofK=_ctn("view");_setAttr(z,ofK,'class',6,e,s,gg);var ogK=_ctn("view");_setAttr(z,ogK,'class',7,e,s,gg);var ohK=_ctn("view");_setAttr(z,ohK,'class',8,e,s,gg);var oiK=_o(z,31,e,s,gg);_ac(ohK,oiK);_ac(ogK,ohK);_ac(ofK,ogK);var ojK=_ctn("view");_setAttr(z,ojK,'class',10,e,s,gg);var okK=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",20,"value",21],e,s,gg);_ac(ojK,okK);_ac(ofK,ojK);_ac(ovJ,ofK);var olK=_ctn("view");_setAttr(z,olK,'class',6,e,s,gg);var omK=_ctn("view");_setAttr(z,omK,'class',7,e,s,gg);var onK=_ctn("view");_setAttr(z,onK,'class',8,e,s,gg);var ooK=_o(z,34,e,s,gg);_ac(onK,ooK);_ac(omK,onK);_ac(olK,omK);var opK=_ctn("view");_setAttr(z,opK,'class',10,e,s,gg);var oqK=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",23,"value",24],e,s,gg);_ac(opK,oqK);_ac(olK,opK);_ac(ovJ,olK);var orK=_ctn("view");_setAttr(z,orK,'class',6,e,s,gg);var osK=_ctn("view");_setAttr(z,osK,'class',7,e,s,gg);var otK=_ctn("view");_setAttr(z,otK,'class',8,e,s,gg);var ouK=_o(z,37,e,s,gg);_ac(otK,ouK);_ac(osK,otK);_ac(orK,osK);var ovK=_ctn("view");_setAttr(z,ovK,'class',10,e,s,gg);var owK=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",26,"value",27],e,s,gg);_ac(ovK,owK);_ac(orK,ovK);_ac(ovJ,orK);var oxK=_ctn("view");_setAttr(z,oxK,'class',6,e,s,gg);var oyK=_ctn("view");_setAttr(z,oyK,'class',7,e,s,gg);var ozK=_ctn("view");_setAttr(z,ozK,'class',8,e,s,gg);var o_K=_o(z,40,e,s,gg);_ac(ozK,o_K);_ac(oyK,ozK);_ac(oxK,oyK);var oAL=_ctn("view");_setAttr(z,oAL,'class',10,e,s,gg);var oBL=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",29,"value",30],e,s,gg);_ac(oAL,oBL);_ac(oxK,oAL);_ac(ovJ,oxK);_ac(ouJ,ovJ);var oCL=_ctn("view");_setAttr(z,oCL,'class',43,e,s,gg);var oDL=_setAttrs(z,"button",["bindtap",44,"class",0,"type",1],e,s,gg);var oEL=_o(z,46,e,s,gg);_ac(oDL,oEL);_ac(oCL,oDL);_ac(ouJ,oCL);_ac(otJ,ouJ);_ac(ooJ,otJ);var oFL=_cvn();
    var oGL=_o(z,47,e,s,gg);
    var oHL=_gd('./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml',oGL,e_,d_);
    if(oHL){
      var oIL={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oHL(oIL,oIL,oFL,gg);
      gg.f=tgf;
    }else{
      _w(oGL,'./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml',0,0);
    }
    _ac(ooJ,oFL);_ac(r,ooJ);olJ.pop();olJ.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml"]={f:m19,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml"]={};
  var m20=function(e,s,r,gg){
    var z=gz$gma_21()
    var oJL=e_["./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml"].i;_ai(oJL,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml',0,0);_ai(oJL,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml',0,0);var oML=_ctn("view");_setAttr(z,oML,'class',0,e,s,gg);var oNL=_cvn();
    var oOL=_o(z,1,e,s,gg);
    var oPL=_gd('./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml',oOL,e_,d_);
    if(oPL){
      var oQL=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oPL(oQL,oQL,oNL,gg);
      gg.f=tgf;
    }else{
      _w(oOL,'./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml',0,0);
    }
    _ac(oML,oNL);var oRL=_ctn("view");_setAttr(z,oRL,'class',3,e,s,gg);var oSL=_ctn("view");_setAttr(z,oSL,'class',4,e,s,gg);var oTL=_ctn("view");_setAttr(z,oTL,'class',5,e,s,gg);var oUL=_ctn("view");_setAttr(z,oUL,'class',6,e,s,gg);var oVL=_ctn("view");_setAttr(z,oVL,'class',7,e,s,gg);var oWL=_ctn("view");_setAttr(z,oWL,'class',8,e,s,gg);var oXL=_o(z,9,e,s,gg);_ac(oWL,oXL);_ac(oVL,oWL);_ac(oUL,oVL);var oYL=_ctn("view");_setAttr(z,oYL,'class',10,e,s,gg);var oZL=_setAttrs(z,"input",["class",11,"disabled",1,"placeholder",2,"type",3,"value",4],e,s,gg);_ac(oYL,oZL);_ac(oUL,oYL);_ac(oTL,oUL);var oaL=_ctn("view");_setAttr(z,oaL,'class',6,e,s,gg);var obL=_ctn("view");_setAttr(z,obL,'class',7,e,s,gg);var ocL=_ctn("view");_setAttr(z,ocL,'class',8,e,s,gg);var odL=_o(z,16,e,s,gg);_ac(ocL,odL);_ac(obL,ocL);_ac(oaL,obL);var oeL=_ctn("view");_setAttr(z,oeL,'class',10,e,s,gg);var ofL=_setAttrs(z,"input",["class",11,"disabled",1,"placeholder",2,"type",3,"value",6],e,s,gg);_ac(oeL,ofL);_ac(oaL,oeL);_ac(oTL,oaL);var ogL=_ctn("view");_setAttr(z,ogL,'class',6,e,s,gg);var ohL=_ctn("view");_setAttr(z,ohL,'class',7,e,s,gg);var oiL=_ctn("view");_setAttr(z,oiL,'class',8,e,s,gg);var ojL=_o(z,18,e,s,gg);_ac(oiL,ojL);_ac(ohL,oiL);_ac(ogL,ohL);var okL=_ctn("view");_setAttr(z,okL,'class',10,e,s,gg);var olL=_setAttrs(z,"input",["class",11,"disabled",1,"placeholder",2,"type",3,"value",8],e,s,gg);_ac(okL,olL);_ac(ogL,okL);_ac(oTL,ogL);var omL=_ctn("view");_setAttr(z,omL,'class',6,e,s,gg);var onL=_ctn("view");_setAttr(z,onL,'class',7,e,s,gg);var ooL=_ctn("view");_setAttr(z,ooL,'class',8,e,s,gg);var opL=_o(z,20,e,s,gg);_ac(ooL,opL);_ac(onL,ooL);_ac(omL,onL);var oqL=_ctn("view");_setAttr(z,oqL,'class',10,e,s,gg);var orL=_setAttrs(z,"input",["class",11,"disabled",1,"placeholder",2,"type",3,"value",10],e,s,gg);_ac(oqL,orL);_ac(omL,oqL);_ac(oTL,omL);var osL=_ctn("view");_setAttr(z,osL,'class',6,e,s,gg);var otL=_ctn("view");_setAttr(z,otL,'class',7,e,s,gg);var ouL=_ctn("view");_setAttr(z,ouL,'class',8,e,s,gg);var ovL=_o(z,22,e,s,gg);_ac(ouL,ovL);_ac(otL,ouL);_ac(osL,otL);var owL=_ctn("view");_setAttr(z,owL,'class',10,e,s,gg);var oxL=_setAttrs(z,"input",["class",11,"disabled",1,"placeholder",2,"type",3,"value",12],e,s,gg);_ac(owL,oxL);_ac(osL,owL);_ac(oTL,osL);var oyL=_ctn("view");_setAttr(z,oyL,'class',6,e,s,gg);var ozL=_ctn("view");_setAttr(z,ozL,'class',7,e,s,gg);var o_L=_ctn("view");_setAttr(z,o_L,'class',8,e,s,gg);var oAM=_o(z,24,e,s,gg);_ac(o_L,oAM);_ac(ozL,o_L);_ac(oyL,ozL);var oBM=_ctn("view");_setAttr(z,oBM,'class',10,e,s,gg);var oCM=_setAttrs(z,"input",["class",11,"disabled",1,"placeholder",2,"type",3,"value",14],e,s,gg);_ac(oBM,oCM);_ac(oyL,oBM);_ac(oTL,oyL);_ac(oSL,oTL);var oDM=_ctn("view");_setAttr(z,oDM,'class',26,e,s,gg);var oEM=_setAttrs(z,"button",["bindtap",27,"type",1],e,s,gg);var oFM=_o(z,29,e,s,gg);_ac(oEM,oFM);_ac(oDM,oEM);_ac(oSL,oDM);_ac(oRL,oSL);_ac(oML,oRL);var oGM=_cvn();
    var oHM=_o(z,30,e,s,gg);
    var oIM=_gd('./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml',oHM,e_,d_);
    if(oIM){
      var oJM={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oIM(oJM,oJM,oGM,gg);
      gg.f=tgf;
    }else{
      _w(oHM,'./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml',0,0);
    }
    _ac(oML,oGM);_ac(r,oML);oJL.pop();oJL.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml"]={f:m20,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml"]={};
  var m21=function(e,s,r,gg){
    var z=gz$gma_22()
    var oKM=e_["./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml"].i;_ai(oKM,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml',0,0);_ai(oKM,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml',0,0);var oNM=_ctn("view");_setAttr(z,oNM,'class',0,e,s,gg);var oOM=_cvn();
    var oPM=_o(z,1,e,s,gg);
    var oQM=_gd('./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml',oPM,e_,d_);
    if(oQM){
      var oRM=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oQM(oRM,oRM,oOM,gg);
      gg.f=tgf;
    }else{
      _w(oPM,'./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml',0,0);
    }
    _ac(oNM,oOM);var oSM=_ctn("view");_setAttr(z,oSM,'class',3,e,s,gg);var oTM=_setAttrs(z,"button",["bindtap",4,"type",1],e,s,gg);var oUM=_o(z,6,e,s,gg);_ac(oTM,oUM);_ac(oSM,oTM);var oVM=_setAttrs(z,"button",["type",5,"bindtap",2],e,s,gg);var oWM=_o(z,8,e,s,gg);_ac(oVM,oWM);_ac(oSM,oVM);var oXM=_setAttrs(z,"button",["type",5,"bindtap",4],e,s,gg);var oYM=_o(z,10,e,s,gg);_ac(oXM,oYM);_ac(oSM,oXM);var oZM=_setAttrs(z,"button",["type",5,"bindtap",6],e,s,gg);var oaM=_o(z,12,e,s,gg);_ac(oZM,oaM);_ac(oSM,oZM);var obM=_ctn("view");_setAttr(z,obM,'class',13,e,s,gg);var ocM=_ctn("text");var odM=_o(z,14,e,s,gg);_ac(ocM,odM);_ac(obM,ocM);_ac(oSM,obM);_ac(oNM,oSM);var oeM=_cvn();
    var ofM=_o(z,15,e,s,gg);
    var ogM=_gd('./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml',ofM,e_,d_);
    if(ogM){
      var ohM={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ogM(ohM,ohM,oeM,gg);
      gg.f=tgf;
    }else{
      _w(ofM,'./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml',0,0);
    }
    _ac(oNM,oeM);_ac(r,oNM);oKM.pop();oKM.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml"]={f:m21,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml"]={};
  var m22=function(e,s,r,gg){
    var z=gz$gma_23()
    var oiM=e_["./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml"].i;_ai(oiM,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml',0,0);_ai(oiM,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml',0,0);var olM=_ctn("view");_setAttr(z,olM,'class',0,e,s,gg);var omM=_cvn();
    var onM=_o(z,1,e,s,gg);
    var ooM=_gd('./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml',onM,e_,d_);
    if(ooM){
      var opM=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ooM(opM,opM,omM,gg);
      gg.f=tgf;
    }else{
      _w(onM,'./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml',0,0);
    }
    _ac(olM,omM);var oqM=_ctn("view");_setAttr(z,oqM,'class',3,e,s,gg);var orM=_ctn("view");_setAttr(z,orM,'class',4,e,s,gg);var osM=_ctn("view");_setAttr(z,osM,'class',5,e,s,gg);var otM=_o(z,6,e,s,gg);_ac(osM,otM);_ac(orM,osM);var ouM=_ctn("view");_setAttr(z,ouM,'class',7,e,s,gg);var ovM=_ctn("view");_setAttr(z,ovM,'class',8,e,s,gg);var owM=_setAttrs(z,"input",["bindblur",9,"bindfocus",1,"class",2,"placeholder",3],e,s,gg);_ac(ovM,owM);_ac(ouM,ovM);_ac(orM,ouM);_ac(oqM,orM);_ac(olM,oqM);var oxM=_cvn();
    var oyM=_o(z,13,e,s,gg);
    var ozM=_gd('./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml',oyM,e_,d_);
    if(ozM){
      var o_M={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ozM(o_M,o_M,oxM,gg);
      gg.f=tgf;
    }else{
      _w(oyM,'./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml',0,0);
    }
    _ac(olM,oxM);_ac(r,olM);oiM.pop();oiM.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml"]={f:m22,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/loading/loading.maml"]={};
  var m23=function(e,s,r,gg){
    var z=gz$gma_24()
    var oAN=e_["./macle_demo_EN/page/API/pages/loading/loading.maml"].i;_ai(oAN,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/loading/loading.maml',0,0);_ai(oAN,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/loading/loading.maml',0,0);var oDN=_ctn("view");_setAttr(z,oDN,'class',0,e,s,gg);var oEN=_cvn();
    var oFN=_o(z,1,e,s,gg);
    var oGN=_gd('./macle_demo_EN/page/API/pages/loading/loading.maml',oFN,e_,d_);
    if(oGN){
      var oHN=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oGN(oHN,oHN,oEN,gg);
      gg.f=tgf;
    }else{
      _w(oFN,'./macle_demo_EN/page/API/pages/loading/loading.maml',0,0);
    }
    _ac(oDN,oEN);var oIN=_ctn("view");_setAttr(z,oIN,'class',3,e,s,gg);var oJN=_ctn("view");_setAttr(z,oJN,'class',4,e,s,gg);var oKN=_setAttrs(z,"button",["bindtap",5,"class",1,"type",2],e,s,gg);var oLN=_o(z,8,e,s,gg);_ac(oKN,oLN);_ac(oJN,oKN);var oMN=_ctn("view");_setAttr(z,oMN,'class',9,e,s,gg);var oNN=_ctn("view");_setAttr(z,oNN,'class',10,e,s,gg);var oON=_ctn("view");_setAttr(z,oON,'class',11,e,s,gg);var oPN=_o(z,12,e,s,gg);_ac(oON,oPN);_ac(oNN,oON);_ac(oMN,oNN);_ac(oJN,oMN);_ac(oIN,oJN);_ac(oDN,oIN);var oQN=_cvn();
    var oRN=_o(z,13,e,s,gg);
    var oSN=_gd('./macle_demo_EN/page/API/pages/loading/loading.maml',oRN,e_,d_);
    if(oSN){
      var oTN={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oSN(oTN,oTN,oQN,gg);
      gg.f=tgf;
    }else{
      _w(oRN,'./macle_demo_EN/page/API/pages/loading/loading.maml',0,0);
    }
    _ac(oDN,oQN);_ac(r,oDN);oAN.pop();oAN.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/loading/loading.maml"]={f:m23,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml"]={};
  var m24=function(e,s,r,gg){
    var z=gz$gma_25()
    var oUN=e_["./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml"].i;_ai(oUN,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml',0,0);_ai(oUN,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml',0,0);var oXN=_ctn("view");_setAttr(z,oXN,'class',0,e,s,gg);var oYN=_cvn();
    var oZN=_o(z,1,e,s,gg);
    var oaN=_gd('./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml',oZN,e_,d_);
    if(oaN){
      var obN=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oaN(obN,obN,oYN,gg);
      gg.f=tgf;
    }else{
      _w(oZN,'./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml',0,0);
    }
    _ac(oXN,oYN);var ocN=_ctn("view");_setAttr(z,ocN,'class',3,e,s,gg);var odN=_ctn("view");_setAttr(z,odN,'class',4,e,s,gg);var oeN=_ctn("view");_setAttr(z,oeN,'class',5,e,s,gg);var ofN=_o(z,6,e,s,gg);_ac(oeN,ofN);_ac(odN,oeN);var ogN=_setAttrs(z,"input",["bindinput",7,"id",1,"name",2,"type",3],e,s,gg);_ac(odN,ogN);var ohN=_ctn("view");_setAttr(z,ohN,'class',11,e,s,gg);var oiN=_setAttrs(z,"button",["bindtap",12,"class",0,"disabled",1,"type",2],e,s,gg);var ojN=_o(z,15,e,s,gg);_ac(oiN,ojN);_ac(ohN,oiN);var okN=_setAttrs(z,"button",["type",14,"bindtap",2,"class",2],e,s,gg);var olN=_o(z,17,e,s,gg);_ac(okN,olN);_ac(ohN,okN);_ac(odN,ohN);_ac(ocN,odN);_ac(oXN,ocN);var omN=_cvn();
    var onN=_o(z,18,e,s,gg);
    var ooN=_gd('./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml',onN,e_,d_);
    if(ooN){
      var opN={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ooN(opN,opN,omN,gg);
      gg.f=tgf;
    }else{
      _w(onN,'./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml',0,0);
    }
    _ac(oXN,omN);_ac(r,oXN);oUN.pop();oUN.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml"]={f:m24,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml"]={};
  var m25=function(e,s,r,gg){
    var z=gz$gma_26()
    var oqN=e_["./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml"].i;_ai(oqN,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml',0,0);_ai(oqN,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml',0,0);var otN=_ctn("view");_setAttr(z,otN,'class',0,e,s,gg);var ouN=_cvn();
    var ovN=_o(z,1,e,s,gg);
    var owN=_gd('./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml',ovN,e_,d_);
    if(owN){
      var oxN=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      owN(oxN,oxN,ouN,gg);
      gg.f=tgf;
    }else{
      _w(ovN,'./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml',0,0);
    }
    _ac(otN,ouN);var oyN=_ctn("view");_setAttr(z,oyN,'class',3,e,s,gg);var ozN=_ctn("form");var o_N=_ctn("view");_setAttr(z,o_N,'class',4,e,s,gg);var oAO=_ctn("view");_setAttr(z,oAO,'class',5,e,s,gg);var oBO=_ctn("view");_setAttr(z,oBO,'class',6,e,s,gg);var oCO=_ctn("view");_setAttr(z,oCO,'class',7,e,s,gg);var oDO=_ctn("view");_setAttr(z,oDO,'class',8,e,s,gg);var oEO=_o(z,9,e,s,gg);_ac(oDO,oEO);_ac(oCO,oDO);_ac(oBO,oCO);var oFO=_ctn("view");_setAttr(z,oFO,'class',10,e,s,gg);var oGO=_setAttrs(z,"picker",["bindchange",11,"mode",1,"range",2,"value",3],e,s,gg);var oHO=_ctn("view");_setAttr(z,oHO,'class',15,e,s,gg);var oIO=_o(z,16,e,s,gg);_ac(oHO,oIO);_ac(oGO,oHO);_ac(oFO,oGO);_ac(oBO,oFO);_ac(oAO,oBO);var oJO=_ctn("view");_setAttr(z,oJO,'class',6,e,s,gg);var oKO=_ctn("view");_setAttr(z,oKO,'class',7,e,s,gg);var oLO=_ctn("view");_setAttr(z,oLO,'class',8,e,s,gg);var oMO=_o(z,17,e,s,gg);_ac(oLO,oMO);_ac(oKO,oLO);_ac(oJO,oKO);var oNO=_ctn("view");_setAttr(z,oNO,'class',10,e,s,gg);var oOO=_setAttrs(z,"picker",["mode",12,"bindchange",6,"range",7,"value",8],e,s,gg);var oPO=_ctn("view");_setAttr(z,oPO,'class',15,e,s,gg);var oQO=_o(z,21,e,s,gg);_ac(oPO,oQO);_ac(oOO,oPO);_ac(oNO,oOO);_ac(oJO,oNO);_ac(oAO,oJO);var oRO=_ctn("view");_setAttr(z,oRO,'class',6,e,s,gg);var oSO=_ctn("view");_setAttr(z,oSO,'class',7,e,s,gg);var oTO=_ctn("view");_setAttr(z,oTO,'class',8,e,s,gg);var oUO=_o(z,22,e,s,gg);_ac(oTO,oUO);_ac(oSO,oTO);_ac(oRO,oSO);var oVO=_ctn("view");_setAttr(z,oVO,'class',10,e,s,gg);var oWO=_setAttrs(z,"picker",["mode",12,"bindchange",11,"range",12,"value",13],e,s,gg);var oXO=_ctn("view");_setAttr(z,oXO,'class',15,e,s,gg);var oYO=_o(z,26,e,s,gg);_ac(oXO,oYO);_ac(oWO,oXO);_ac(oVO,oWO);_ac(oRO,oVO);_ac(oAO,oRO);_ac(o_N,oAO);var oZO=_ctn("view");_setAttr(z,oZO,'class',27,e,s,gg);var oaO=_ctn("view");_setAttr(z,oaO,'class',28,e,s,gg);var obO=_ctn("view");_setAttr(z,obO,'class',10,e,s,gg);var ocO=_ctn("view");_setAttr(z,ocO,'class',29,e,s,gg);var odO=_ctn("view");_setAttr(z,odO,'class',30,e,s,gg);var oeO=_ctn("view");_setAttr(z,oeO,'class',31,e,s,gg);var ofO=_o(z,32,e,s,gg);_ac(oeO,ofO);_ac(odO,oeO);var ogO=_ctn("view");_setAttr(z,ogO,'class',33,e,s,gg);var ohO=_o(z,34,e,s,gg);_ac(ogO,ohO);_ac(odO,ogO);_ac(ocO,odO);var oiO=_ctn("view");_setAttr(z,oiO,'class',35,e,s,gg);var ojO=_ctn("view");_setAttr(z,ojO,'class',36,e,s,gg);var okO=_cvn();var olO=function(opO,ooO,onO,gg){var orO=_ctn("view");_setAttr(z,orO,'class',39,opO,ooO,gg);var osO=_setAttrs(z,"image",["bindtap",40,"class",1,"data-src",2,"src",2],opO,ooO,gg);_ac(orO,osO);_ac(onO,orO);return onO;};_2(z,37,olO,e,s,gg,okO,"image","index",'');_ac(ojO,okO);_ac(oiO,ojO);var otO=_ctn("view");_setAttr(z,otO,'class',43,e,s,gg);var ouO=_setAttrs(z,"view",["bindtap",44,"class",1],e,s,gg);_ac(otO,ouO);_ac(oiO,otO);_ac(ocO,oiO);_ac(obO,ocO);_ac(oaO,obO);_ac(oZO,oaO);_ac(o_N,oZO);var ovO=_ctn("view");var owO=_setAttrs(z,"button",["bindtap",46,"class",1],e,s,gg);var oxO=_o(z,48,e,s,gg);_ac(owO,oxO);_ac(ovO,owO);var oyO=_setAttrs(z,"button",["bindtap",49,"class",1],e,s,gg);var ozO=_o(z,51,e,s,gg);_ac(oyO,ozO);_ac(ovO,oyO);var o_O=_setAttrs(z,"button",["bindtap",52,"class",1],e,s,gg);var oAP=_o(z,54,e,s,gg);_ac(o_O,oAP);_ac(ovO,o_O);_ac(o_N,ovO);var oBP=_cvn();if(_o(z,55,e,s,gg)){oBP.maVkey=1;var oCP=_ctn("view");_setAttr(z,oCP,'class',56,e,s,gg);var oEP=_ctn("text");_setAttr(z,oEP,'class',57,e,s,gg);var oFP=_o(z,58,e,s,gg);_ac(oEP,oFP);_ac(oCP,oEP);_ac(oBP,oCP);} _ac(o_N,oBP);var oGP=_cvn();if(_o(z,59,e,s,gg)){oGP.maVkey=1;var oHP=_ctn("view");_setAttr(z,oHP,'class',56,e,s,gg);var oJP=_ctn("text");_setAttr(z,oJP,'space',60,e,s,gg);var oKP=_o(z,61,e,s,gg);_ac(oJP,oKP);_ac(oHP,oJP);_ac(oGP,oHP);} _ac(o_N,oGP);_ac(ozN,o_N);_ac(oyN,ozN);_ac(otN,oyN);var oLP=_cvn();
    var oMP=_o(z,62,e,s,gg);
    var oNP=_gd('./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml',oMP,e_,d_);
    if(oNP){
      var oOP={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oNP(oOP,oOP,oLP,gg);
      gg.f=tgf;
    }else{
      _w(oMP,'./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml',0,0);
    }
    _ac(otN,oLP);_ac(r,otN);oqN.pop();oqN.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml"]={f:m25,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml"]={};
  var m26=function(e,s,r,gg){
    var z=gz$gma_27()
    var oPP=e_["./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml"].i;_ai(oPP,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml',0,0);_ai(oPP,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml',0,0);var oSP=_ctn("view");_setAttr(z,oSP,'class',0,e,s,gg);var oTP=_cvn();
    var oUP=_o(z,1,e,s,gg);
    var oVP=_gd('./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml',oUP,e_,d_);
    if(oVP){
      var oWP=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oVP(oWP,oWP,oTP,gg);
      gg.f=tgf;
    }else{
      _w(oUP,'./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml',0,0);
    }
    _ac(oSP,oTP);var oXP=_ctn("view");_setAttr(z,oXP,'class',3,e,s,gg);var oYP=_setAttrs(z,"button",["bindtap",4,"type",1],e,s,gg);var oZP=_o(z,6,e,s,gg);_ac(oYP,oZP);_ac(oXP,oYP);var oaP=_setAttrs(z,"button",["type",5,"bindtap",2],e,s,gg);var obP=_o(z,8,e,s,gg);_ac(oaP,obP);_ac(oXP,oaP);var ocP=_setAttrs(z,"button",["type",5,"bindtap",4],e,s,gg);var odP=_o(z,9,e,s,gg);_ac(ocP,odP);_ac(oXP,ocP);var oeP=_setAttrs(z,"button",["type",5,"bindtap",5],e,s,gg);var ofP=_o(z,11,e,s,gg);_ac(oeP,ofP);_ac(oXP,oeP);_ac(oSP,oXP);var ogP=_ctn("view");_setAttr(z,ogP,'class',12,e,s,gg);var ohP=_ctn("text");var oiP=_o(z,13,e,s,gg);_ac(ohP,oiP);_ac(ogP,ohP);_ac(oSP,ogP);var ojP=_cvn();
    var okP=_o(z,14,e,s,gg);
    var olP=_gd('./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml',okP,e_,d_);
    if(olP){
      var omP={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      olP(omP,omP,ojP,gg);
      gg.f=tgf;
    }else{
      _w(okP,'./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml',0,0);
    }
    _ac(oSP,ojP);_ac(r,oSP);oPP.pop();oPP.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml"]={f:m26,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/modal/modal.maml"]={};
  var m27=function(e,s,r,gg){
    var z=gz$gma_28()
    var onP=e_["./macle_demo_EN/page/API/pages/modal/modal.maml"].i;_ai(onP,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/modal/modal.maml',0,0);_ai(onP,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/modal/modal.maml',0,0);var oqP=_ctn("view");_setAttr(z,oqP,'class',0,e,s,gg);var orP=_cvn();
    var osP=_o(z,1,e,s,gg);
    var otP=_gd('./macle_demo_EN/page/API/pages/modal/modal.maml',osP,e_,d_);
    if(otP){
      var ouP=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      otP(ouP,ouP,orP,gg);
      gg.f=tgf;
    }else{
      _w(osP,'./macle_demo_EN/page/API/pages/modal/modal.maml',0,0);
    }
    _ac(oqP,orP);var ovP=_ctn("view");_setAttr(z,ovP,'class',3,e,s,gg);var owP=_ctn("view");_setAttr(z,owP,'class',4,e,s,gg);var oxP=_setAttrs(z,"button",["bindtap",5,"class",1,"type",2],e,s,gg);var oyP=_o(z,8,e,s,gg);_ac(oxP,oyP);_ac(owP,oxP);var ozP=_setAttrs(z,"button",["type",7,"bindtap",2,"class",2],e,s,gg);var o_P=_o(z,10,e,s,gg);_ac(ozP,o_P);_ac(owP,ozP);var oAQ=_setAttrs(z,"button",["type",7,"bindtap",4,"class",4],e,s,gg);var oBQ=_o(z,12,e,s,gg);_ac(oAQ,oBQ);_ac(owP,oAQ);_ac(ovP,owP);var oCQ=_cvn();if(_o(z,13,e,s,gg)){oCQ.maVkey=1;var oDQ=_ctn("view");_setAttr(z,oDQ,'class',14,e,s,gg);var oFQ=_ctn("text");_setAttr(z,oFQ,'class',14,e,s,gg);var oGQ=_o(z,15,e,s,gg);_ac(oFQ,oGQ);_ac(oDQ,oFQ);_ac(oCQ,oDQ);} _ac(ovP,oCQ);_ac(oqP,ovP);var oHQ=_cvn();
    var oIQ=_o(z,16,e,s,gg);
    var oJQ=_gd('./macle_demo_EN/page/API/pages/modal/modal.maml',oIQ,e_,d_);
    if(oJQ){
      var oKQ={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oJQ(oKQ,oKQ,oHQ,gg);
      gg.f=tgf;
    }else{
      _w(oIQ,'./macle_demo_EN/page/API/pages/modal/modal.maml',0,0);
    }
    _ac(oqP,oHQ);_ac(r,oqP);onP.pop();onP.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/modal/modal.maml"]={f:m27,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/navigator/navigate.maml"]={};
  var m28=function(e,s,r,gg){
    var z=gz$gma_29()
    var oLQ=e_["./macle_demo_EN/page/API/pages/navigator/navigate.maml"].i;_ai(oLQ,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/navigator/navigate.maml',0,0);_ai(oLQ,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/navigator/navigate.maml',0,0);var oOQ=_ctn("view");_setAttr(z,oOQ,'class',0,e,s,gg);var oPQ=_cvn();
    var oQQ=_o(z,1,e,s,gg);
    var oRQ=_gd('./macle_demo_EN/page/API/pages/navigator/navigate.maml',oQQ,e_,d_);
    if(oRQ){
      var oSQ=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oRQ(oSQ,oSQ,oPQ,gg);
      gg.f=tgf;
    }else{
      _w(oQQ,'./macle_demo_EN/page/API/pages/navigator/navigate.maml',0,0);
    }
    _ac(oOQ,oPQ);var oTQ=_ctn("view");_setAttr(z,oTQ,'class',3,e,s,gg);var oUQ=_ctn("view");_setAttr(z,oUQ,'class',4,e,s,gg);var oVQ=_ctn("text");_setAttr(z,oVQ,'class',5,e,s,gg);var oWQ=_o(z,6,e,s,gg);_ac(oVQ,oWQ);_ac(oUQ,oVQ);var oXQ=_setAttrs(z,"button",["bindtap",7,"class",1,"type",2],e,s,gg);var oYQ=_o(z,7,e,s,gg);_ac(oXQ,oYQ);_ac(oUQ,oXQ);var oZQ=_setAttrs(z,"navigator",["hoverClass",10,"openType",1],e,s,gg);var oaQ=_setAttrs(z,"button",["class",12,"type",1],e,s,gg);var obQ=_o(z,14,e,s,gg);_ac(oaQ,obQ);_ac(oZQ,oaQ);_ac(oUQ,oZQ);_ac(oTQ,oUQ);_ac(oOQ,oTQ);_ac(r,oOQ);oLQ.pop();oLQ.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/navigator/navigate.maml"]={f:m28,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/navigator/navigator.maml"]={};
  var m29=function(e,s,r,gg){
    var z=gz$gma_30()
    var ocQ=e_["./macle_demo_EN/page/API/pages/navigator/navigator.maml"].i;_ai(ocQ,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/navigator/navigator.maml',0,0);_ai(ocQ,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/navigator/navigator.maml',0,0);var ofQ=_ctn("view");_setAttr(z,ofQ,'class',0,e,s,gg);var ogQ=_cvn();
    var ohQ=_o(z,1,e,s,gg);
    var oiQ=_gd('./macle_demo_EN/page/API/pages/navigator/navigator.maml',ohQ,e_,d_);
    if(oiQ){
      var ojQ=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oiQ(ojQ,ojQ,ogQ,gg);
      gg.f=tgf;
    }else{
      _w(ohQ,'./macle_demo_EN/page/API/pages/navigator/navigator.maml',0,0);
    }
    _ac(ofQ,ogQ);var okQ=_ctn("view");_setAttr(z,okQ,'class',3,e,s,gg);var olQ=_ctn("view");_setAttr(z,olQ,'class',4,e,s,gg);var omQ=_ctn("view");_setAttr(z,omQ,'class',5,e,s,gg);var onQ=_ctn("view");var ooQ=_o(z,6,e,s,gg);_ac(onQ,ooQ);_ac(omQ,onQ);var opQ=_setAttrs(z,"button",["bindtap",7,"class",0,"type",1],e,s,gg);var oqQ=_o(z,7,e,s,gg);_ac(opQ,oqQ);_ac(omQ,opQ);_ac(olQ,omQ);var orQ=_ctn("view");_setAttr(z,orQ,'class',5,e,s,gg);var osQ=_ctn("view");var otQ=_o(z,9,e,s,gg);_ac(osQ,otQ);_ac(orQ,osQ);var ouQ=_setAttrs(z,"button",["type",8,"bindtap",2,"class",2],e,s,gg);var ovQ=_o(z,10,e,s,gg);_ac(ouQ,ovQ);_ac(orQ,ouQ);_ac(olQ,orQ);var owQ=_ctn("view");_setAttr(z,owQ,'class',5,e,s,gg);var oxQ=_ctn("view");var oyQ=_o(z,11,e,s,gg);_ac(oxQ,oyQ);_ac(owQ,oxQ);var ozQ=_setAttrs(z,"button",["type",8,"bindtap",4,"class",4],e,s,gg);var o_Q=_o(z,12,e,s,gg);_ac(ozQ,o_Q);_ac(owQ,ozQ);_ac(olQ,owQ);var oAR=_ctn("view");_setAttr(z,oAR,'class',5,e,s,gg);var oBR=_ctn("view");var oCR=_o(z,13,e,s,gg);_ac(oBR,oCR);_ac(oAR,oBR);var oDR=_setAttrs(z,"button",["type",8,"bindtap",6,"class",6],e,s,gg);var oER=_o(z,14,e,s,gg);_ac(oDR,oER);_ac(oAR,oDR);_ac(olQ,oAR);var oFR=_ctn("view");_setAttr(z,oFR,'class',5,e,s,gg);var oGR=_ctn("view");var oHR=_o(z,15,e,s,gg);_ac(oGR,oHR);_ac(oFR,oGR);var oIR=_setAttrs(z,"button",["type",8,"bindtap",8,"class",8],e,s,gg);var oJR=_o(z,16,e,s,gg);_ac(oIR,oJR);_ac(oFR,oIR);_ac(olQ,oFR);_ac(okQ,olQ);_ac(ofQ,okQ);var oKR=_cvn();
    var oLR=_o(z,17,e,s,gg);
    var oMR=_gd('./macle_demo_EN/page/API/pages/navigator/navigator.maml',oLR,e_,d_);
    if(oMR){
      var oNR={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oMR(oNR,oNR,oKR,gg);
      gg.f=tgf;
    }else{
      _w(oLR,'./macle_demo_EN/page/API/pages/navigator/navigator.maml',0,0);
    }
    _ac(ofQ,oKR);_ac(r,ofQ);ocQ.pop();ocQ.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/navigator/navigator.maml"]={f:m29,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/navigator/redirect.maml"]={};
  var m30=function(e,s,r,gg){
    var z=gz$gma_31()
    var oOR=e_["./macle_demo_EN/page/API/pages/navigator/redirect.maml"].i;_ai(oOR,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/navigator/redirect.maml',0,0);_ai(oOR,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/navigator/redirect.maml',0,0);var oRR=_ctn("view");_setAttr(z,oRR,'class',0,e,s,gg);var oSR=_cvn();
    var oTR=_o(z,1,e,s,gg);
    var oUR=_gd('./macle_demo_EN/page/API/pages/navigator/redirect.maml',oTR,e_,d_);
    if(oUR){
      var oVR=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oUR(oVR,oVR,oSR,gg);
      gg.f=tgf;
    }else{
      _w(oTR,'./macle_demo_EN/page/API/pages/navigator/redirect.maml',0,0);
    }
    _ac(oRR,oSR);var oWR=_ctn("view");_setAttr(z,oWR,'class',3,e,s,gg);var oXR=_o(z,4,e,s,gg);_ac(oWR,oXR);_ac(oRR,oWR);var oYR=_cvn();
    var oZR=_o(z,5,e,s,gg);
    var oaR=_gd('./macle_demo_EN/page/API/pages/navigator/redirect.maml',oZR,e_,d_);
    if(oaR){
      var obR={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oaR(obR,obR,oYR,gg);
      gg.f=tgf;
    }else{
      _w(oZR,'./macle_demo_EN/page/API/pages/navigator/redirect.maml',0,0);
    }
    _ac(oRR,oYR);_ac(r,oRR);oOR.pop();oOR.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/navigator/redirect.maml"]={f:m30,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/network/network.maml"]={};
  var m31=function(e,s,r,gg){
    var z=gz$gma_32()
    var ocR=e_["./macle_demo_EN/page/API/pages/network/network.maml"].i;_ai(ocR,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/network/network.maml',0,0);_ai(ocR,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/network/network.maml',0,0);var ofR=_ctn("view");_setAttr(z,ofR,'class',0,e,s,gg);var ogR=_cvn();
    var ohR=_o(z,1,e,s,gg);
    var oiR=_gd('./macle_demo_EN/page/API/pages/network/network.maml',ohR,e_,d_);
    if(oiR){
      var ojR=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oiR(ojR,ojR,ogR,gg);
      gg.f=tgf;
    }else{
      _w(ohR,'./macle_demo_EN/page/API/pages/network/network.maml',0,0);
    }
    _ac(ofR,ogR);var okR=_ctn("view");_setAttr(z,okR,'class',3,e,s,gg);var olR=_setAttrs(z,"button",["bindtap",4,"type",1],e,s,gg);var omR=_o(z,6,e,s,gg);_ac(olR,omR);_ac(okR,olR);var onR=_setAttrs(z,"button",["type",5,"bindtap",2],e,s,gg);var ooR=_o(z,8,e,s,gg);_ac(onR,ooR);_ac(okR,onR);_ac(ofR,okR);var opR=_ctn("view");_setAttr(z,opR,'class',9,e,s,gg);var oqR=_ctn("text");var orR=_o(z,10,e,s,gg);_ac(oqR,orR);_ac(opR,oqR);_ac(ofR,opR);var osR=_cvn();
    var otR=_o(z,11,e,s,gg);
    var ouR=_gd('./macle_demo_EN/page/API/pages/network/network.maml',otR,e_,d_);
    if(ouR){
      var ovR={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ouR(ovR,ovR,osR,gg);
      gg.f=tgf;
    }else{
      _w(otR,'./macle_demo_EN/page/API/pages/network/network.maml',0,0);
    }
    _ac(ofR,osR);_ac(r,ofR);ocR.pop();ocR.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/network/network.maml"]={f:m31,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/open-document/open-document.maml"]={};
  var m32=function(e,s,r,gg){
    var z=gz$gma_33()
    var owR=e_["./macle_demo_EN/page/API/pages/open-document/open-document.maml"].i;_ai(owR,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/open-document/open-document.maml',0,0);_ai(owR,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/open-document/open-document.maml',0,0);var ozR=_ctn("view");_setAttr(z,ozR,'class',0,e,s,gg);var o_R=_cvn();
    var oAS=_o(z,1,e,s,gg);
    var oBS=_gd('./macle_demo_EN/page/API/pages/open-document/open-document.maml',oAS,e_,d_);
    if(oBS){
      var oCS=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oBS(oCS,oCS,o_R,gg);
      gg.f=tgf;
    }else{
      _w(oAS,'./macle_demo_EN/page/API/pages/open-document/open-document.maml',0,0);
    }
    _ac(ozR,o_R);var oDS=_ctn("view");_setAttr(z,oDS,'class',3,e,s,gg);var oES=_ctn("view");_setAttr(z,oES,'class',4,e,s,gg);var oFS=_setAttrs(z,"button",["bindtap",5,"type",1],e,s,gg);var oGS=_o(z,7,e,s,gg);_ac(oFS,oGS);_ac(oES,oFS);_ac(oDS,oES);var oHS=_ctn("view");_setAttr(z,oHS,'class',8,e,s,gg);var oIS=_ctn("text");var oJS=_o(z,9,e,s,gg);_ac(oIS,oJS);_ac(oHS,oIS);var oKS=_setAttrs(z,"switch",["bindchange",10,"checked",1],e,s,gg);_ac(oHS,oKS);_ac(oDS,oHS);_ac(ozR,oDS);var oLS=_cvn();
    var oMS=_o(z,12,e,s,gg);
    var oNS=_gd('./macle_demo_EN/page/API/pages/open-document/open-document.maml',oMS,e_,d_);
    if(oNS){
      var oOS={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oNS(oOS,oOS,oLS,gg);
      gg.f=tgf;
    }else{
      _w(oMS,'./macle_demo_EN/page/API/pages/open-document/open-document.maml',0,0);
    }
    _ac(ozR,oLS);_ac(r,ozR);owR.pop();owR.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/open-document/open-document.maml"]={f:m32,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml"]={};
  var m33=function(e,s,r,gg){
    var z=gz$gma_34()
    var oPS=e_["./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml"].i;_ai(oPS,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml',0,0);_ai(oPS,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml',0,0);var oSS=_ctn("view");_setAttr(z,oSS,'class',0,e,s,gg);var oTS=_cvn();
    var oUS=_o(z,1,e,s,gg);
    var oVS=_gd('./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml',oUS,e_,d_);
    if(oVS){
      var oWS=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oVS(oWS,oWS,oTS,gg);
      gg.f=tgf;
    }else{
      _w(oUS,'./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml',0,0);
    }
    _ac(oSS,oTS);var oXS=_ctn("view");_setAttr(z,oXS,'class',3,e,s,gg);var oYS=_ctn("view");_setAttr(z,oYS,'class',4,e,s,gg);var oZS=_setAttrs(z,"button",["bindtap",5,"class",0],e,s,gg);var oaS=_o(z,6,e,s,gg);_ac(oZS,oaS);_ac(oYS,oZS);var obS=_setAttrs(z,"button",["bindtap",7,"class",0],e,s,gg);var ocS=_o(z,8,e,s,gg);_ac(obS,ocS);_ac(oYS,obS);_ac(oXS,oYS);_ac(oSS,oXS);var odS=_cvn();
    var oeS=_o(z,9,e,s,gg);
    var ofS=_gd('./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml',oeS,e_,d_);
    if(ofS){
      var ogS={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ofS(ogS,ogS,odS,gg);
      gg.f=tgf;
    }else{
      _w(oeS,'./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml',0,0);
    }
    _ac(oSS,odS);_ac(r,oSS);oPS.pop();oPS.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml"]={f:m33,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/request/request.maml"]={};
  var m34=function(e,s,r,gg){
    var z=gz$gma_35()
    var ohS=e_["./macle_demo_EN/page/API/pages/request/request.maml"].i;_ai(ohS,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/request/request.maml',0,0);_ai(ohS,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/request/request.maml',0,0);var okS=_ctn("view");_setAttr(z,okS,'class',0,e,s,gg);var olS=_cvn();
    var omS=_o(z,1,e,s,gg);
    var onS=_gd('./macle_demo_EN/page/API/pages/request/request.maml',omS,e_,d_);
    if(onS){
      var ooS=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      onS(ooS,ooS,olS,gg);
      gg.f=tgf;
    }else{
      _w(omS,'./macle_demo_EN/page/API/pages/request/request.maml',0,0);
    }
    _ac(okS,olS);var opS=_ctn("view");_setAttr(z,opS,'class',3,e,s,gg);var oqS=_ctn("view");_setAttr(z,oqS,'class',4,e,s,gg);var orS=_ctn("text");_setAttr(z,orS,'class',5,e,s,gg);var osS=_o(z,6,e,s,gg);_ac(orS,osS);_ac(oqS,orS);_ac(opS,oqS);var otS=_ctn("view");_setAttr(z,otS,'class',7,e,s,gg);var ouS=_setAttrs(z,"button",["bindtap",8,"class",1,"disabled",2,"loading",3,"type",4],e,s,gg);var ovS=_o(z,13,e,s,gg);_ac(ouS,ovS);_ac(otS,ouS);var owS=_setAttrs(z,"button",["type",12,"bindtap",2,"class",3,"disabled",4,"loading",5],e,s,gg);var oxS=_o(z,18,e,s,gg);_ac(owS,oxS);_ac(otS,owS);_ac(opS,otS);_ac(okS,opS);var oyS=_cvn();
    var ozS=_o(z,19,e,s,gg);
    var o_S=_gd('./macle_demo_EN/page/API/pages/request/request.maml',ozS,e_,d_);
    if(o_S){
      var oAT={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      o_S(oAT,oAT,oyS,gg);
      gg.f=tgf;
    }else{
      _w(ozS,'./macle_demo_EN/page/API/pages/request/request.maml',0,0);
    }
    _ac(okS,oyS);_ac(r,okS);ohS.pop();ohS.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/request/request.maml"]={f:m34,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/scanCode/scanCode.maml"]={};
  var m35=function(e,s,r,gg){
    var z=gz$gma_36()
    var oBT=e_["./macle_demo_EN/page/API/pages/scanCode/scanCode.maml"].i;_ai(oBT,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/scanCode/scanCode.maml',0,0);_ai(oBT,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/scanCode/scanCode.maml',0,0);var oET=_ctn("view");_setAttr(z,oET,'class',0,e,s,gg);var oFT=_cvn();
    var oGT=_o(z,1,e,s,gg);
    var oHT=_gd('./macle_demo_EN/page/API/pages/scanCode/scanCode.maml',oGT,e_,d_);
    if(oHT){
      var oIT=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oHT(oIT,oIT,oFT,gg);
      gg.f=tgf;
    }else{
      _w(oGT,'./macle_demo_EN/page/API/pages/scanCode/scanCode.maml',0,0);
    }
    _ac(oET,oFT);var oJT=_ctn("view");_setAttr(z,oJT,'class',3,e,s,gg);var oKT=_ctn("view");_setAttr(z,oKT,'class',4,e,s,gg);var oLT=_o(z,5,e,s,gg);_ac(oKT,oLT);_ac(oJT,oKT);var oMT=_ctn("view");_setAttr(z,oMT,'class',6,e,s,gg);var oNT=_ctn("view");_setAttr(z,oNT,'class',7,e,s,gg);var oOT=_ctn("view");_setAttr(z,oOT,'class',8,e,s,gg);var oPT=_o(z,9,e,s,gg);_ac(oOT,oPT);_ac(oNT,oOT);_ac(oMT,oNT);var oQT=_ctn("view");_setAttr(z,oQT,'class',7,e,s,gg);var oRT=_ctn("view");_setAttr(z,oRT,'class',10,e,s,gg);var oST=_o(z,11,e,s,gg);_ac(oRT,oST);_ac(oQT,oRT);_ac(oMT,oQT);_ac(oJT,oMT);var oTT=_ctn("view");_setAttr(z,oTT,'class',12,e,s,gg);var oUT=_setAttrs(z,"button",["bindtap",13,"type",1],e,s,gg);var oVT=_o(z,15,e,s,gg);_ac(oUT,oVT);_ac(oTT,oUT);_ac(oJT,oTT);_ac(oET,oJT);var oWT=_cvn();
    var oXT=_o(z,16,e,s,gg);
    var oYT=_gd('./macle_demo_EN/page/API/pages/scanCode/scanCode.maml',oXT,e_,d_);
    if(oYT){
      var oZT={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oYT(oZT,oZT,oWT,gg);
      gg.f=tgf;
    }else{
      _w(oXT,'./macle_demo_EN/page/API/pages/scanCode/scanCode.maml',0,0);
    }
    _ac(oET,oWT);_ac(r,oET);oBT.pop();oBT.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/scanCode/scanCode.maml"]={f:m35,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml"]={};
  var m36=function(e,s,r,gg){
    var z=gz$gma_37()
    var oaT=e_["./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml"].i;_ai(oaT,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml',0,0);_ai(oaT,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml',0,0);var odT=_ctn("view");_setAttr(z,odT,'class',0,e,s,gg);var oeT=_cvn();
    var ofT=_o(z,1,e,s,gg);
    var ogT=_gd('./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml',ofT,e_,d_);
    if(ogT){
      var ohT=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ogT(ohT,ohT,oeT,gg);
      gg.f=tgf;
    }else{
      _w(ofT,'./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml',0,0);
    }
    _ac(odT,oeT);var oiT=_ctn("view");_setAttr(z,oiT,'class',3,e,s,gg);var ojT=_ctn("view");_setAttr(z,ojT,'class',4,e,s,gg);var okT=_ctn("view");_setAttr(z,okT,'class',5,e,s,gg);var olT=_o(z,6,e,s,gg);_ac(okT,olT);_ac(ojT,okT);var omT=_ctn("text");_setAttr(z,omT,'class',7,e,s,gg);var onT=_o(z,8,e,s,gg);_ac(omT,onT);_ac(ojT,omT);_ac(oiT,ojT);var ooT=_ctn("view");_setAttr(z,ooT,'class',9,e,s,gg);var opT=_ctn("view");_setAttr(z,opT,'class',10,e,s,gg);var oqT=_o(z,11,e,s,gg);_ac(opT,oqT);_ac(ooT,opT);var orT=_ctn("view");_setAttr(z,orT,'class',12,e,s,gg);var osT=_setAttrs(z,"slider",["bindchange",13,"class",1,"max",2,"min",3,"step",4,"value",5],e,s,gg);_ac(orT,osT);_ac(ooT,orT);_ac(oiT,ooT);var otT=_setAttrs(z,"button",["bindtap",19,"class",1,"type",2],e,s,gg);var ouT=_o(z,22,e,s,gg);_ac(otT,ouT);_ac(oiT,otT);_ac(odT,oiT);var ovT=_cvn();
    var owT=_o(z,23,e,s,gg);
    var oxT=_gd('./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml',owT,e_,d_);
    if(oxT){
      var oyT={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oxT(oyT,oyT,ovT,gg);
      gg.f=tgf;
    }else{
      _w(owT,'./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml',0,0);
    }
    _ac(odT,ovT);_ac(r,odT);oaT.pop();oaT.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml"]={f:m36,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/set-background/set-background.maml"]={};
  var m37=function(e,s,r,gg){
    var z=gz$gma_38()
    var ozT=e_["./macle_demo_EN/page/API/pages/set-background/set-background.maml"].i;_ai(ozT,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/set-background/set-background.maml',0,0);_ai(ozT,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/set-background/set-background.maml',0,0);var oBU=_ctn("view");_setAttr(z,oBU,'class',0,e,s,gg);var oCU=_cvn();
    var oDU=_o(z,1,e,s,gg);
    var oEU=_gd('./macle_demo_EN/page/API/pages/set-background/set-background.maml',oDU,e_,d_);
    if(oEU){
      var oFU=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oEU(oFU,oFU,oCU,gg);
      gg.f=tgf;
    }else{
      _w(oDU,'./macle_demo_EN/page/API/pages/set-background/set-background.maml',0,0);
    }
    _ac(oBU,oCU);var oGU=_ctn("view");_setAttr(z,oGU,'class',3,e,s,gg);var oHU=_ctn("view");_setAttr(z,oHU,'class',4,e,s,gg);var oIU=_ctn("view");_setAttr(z,oIU,'class',5,e,s,gg);var oJU=_ctn("view");_setAttr(z,oJU,'class',6,e,s,gg);var oKU=_ctn("view");_setAttr(z,oKU,'class',7,e,s,gg);var oLU=_ctn("view");_setAttr(z,oLU,'class',8,e,s,gg);var oMU=_o(z,9,e,s,gg);_ac(oLU,oMU);_ac(oKU,oLU);_ac(oJU,oKU);var oNU=_ctn("view");_setAttr(z,oNU,'class',10,e,s,gg);var oOU=_setAttrs(z,"input",["bindinput",11,"class",1,"id",2,"name",2,"placeholder",3,"type",4,"value",5],e,s,gg);_ac(oNU,oOU);_ac(oJU,oNU);_ac(oIU,oJU);var oPU=_ctn("view");_setAttr(z,oPU,'class',6,e,s,gg);var oQU=_ctn("view");_setAttr(z,oQU,'class',7,e,s,gg);var oRU=_ctn("view");_setAttr(z,oRU,'class',8,e,s,gg);var oSU=_o(z,17,e,s,gg);_ac(oRU,oSU);_ac(oQU,oRU);_ac(oPU,oQU);var oTU=_ctn("view");_setAttr(z,oTU,'class',10,e,s,gg);var oUU=_setAttrs(z,"input",["class",12,"type",3,"bindinput",6,"id",7,"name",7,"placeholder",8,"value",9],e,s,gg);_ac(oTU,oUU);_ac(oPU,oTU);_ac(oIU,oPU);_ac(oHU,oIU);var oVU=_ctn("view");_setAttr(z,oVU,'class',22,e,s,gg);var oWU=_setAttrs(z,"button",["bindtap",23,"class",0],e,s,gg);var oXU=_o(z,24,e,s,gg);_ac(oWU,oXU);_ac(oVU,oWU);var oYU=_setAttrs(z,"button",["bindtap",25,"class",0],e,s,gg);var oZU=_o(z,26,e,s,gg);_ac(oYU,oZU);_ac(oVU,oYU);var oaU=_setAttrs(z,"button",["bindtap",27,"class",1,"type",2],e,s,gg);var obU=_o(z,30,e,s,gg);_ac(oaU,obU);_ac(oVU,oaU);_ac(oHU,oVU);var ocU=_ctn("view");_setAttr(z,ocU,'class',31,e,s,gg);var odU=_setAttrs(z,"view",["class",32,"style",1],e,s,gg);var oeU=_o(z,34,e,s,gg);_ac(odU,oeU);_ac(ocU,odU);_ac(oHU,ocU);_ac(oGU,oHU);_ac(oBU,oGU);var ofU=_cvn();
    var ogU=_o(z,35,e,s,gg);
    var ohU=_gd('./macle_demo_EN/page/API/pages/set-background/set-background.maml',ogU,e_,d_);
    if(ohU){
      var oiU={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ohU(oiU,oiU,ofU,gg);
      gg.f=tgf;
    }else{
      _w(ogU,'./macle_demo_EN/page/API/pages/set-background/set-background.maml',0,0);
    }
    _ac(oBU,ofU);_ac(r,oBU);ozT.pop();ozT.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/set-background/set-background.maml"]={f:m37,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml"]={};
  var m38=function(e,s,r,gg){
    var z=gz$gma_39()
    var ojU=e_["./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml"].i;_ai(ojU,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml',0,0);_ai(ojU,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml',0,0);var omU=_ctn("view");_setAttr(z,omU,'class',0,e,s,gg);var onU=_cvn();
    var ooU=_o(z,1,e,s,gg);
    var opU=_gd('./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml',ooU,e_,d_);
    if(opU){
      var oqU=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      opU(oqU,oqU,onU,gg);
      gg.f=tgf;
    }else{
      _w(ooU,'./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml',0,0);
    }
    _ac(omU,onU);var orU=_setAttrs(z,"form",["bindsubmit",3,"class",1],e,s,gg);var osU=_ctn("view");_setAttr(z,osU,'class',5,e,s,gg);var otU=_ctn("view");_setAttr(z,otU,'class',6,e,s,gg);var ouU=_ctn("view");_setAttr(z,ouU,'class',7,e,s,gg);var ovU=_ctn("view");_setAttr(z,ovU,'class',8,e,s,gg);var owU=_o(z,9,e,s,gg);_ac(ovU,owU);_ac(ouU,ovU);_ac(otU,ouU);var oxU=_ctn("view");_setAttr(z,oxU,'class',10,e,s,gg);var oyU=_setAttrs(z,"input",["bindinput",11,"class",1,"id",2,"name",2,"placeholder",3,"type",4,"value",5],e,s,gg);_ac(oxU,oyU);_ac(otU,oxU);_ac(osU,otU);var ozU=_ctn("view");_setAttr(z,ozU,'class',6,e,s,gg);var o_U=_ctn("view");_setAttr(z,o_U,'class',7,e,s,gg);var oAV=_ctn("view");_setAttr(z,oAV,'class',8,e,s,gg);var oBV=_o(z,17,e,s,gg);_ac(oAV,oBV);_ac(o_U,oAV);_ac(ozU,o_U);var oCV=_ctn("view");_setAttr(z,oCV,'class',10,e,s,gg);var oDV=_setAttrs(z,"input",["class",12,"placeholder",2,"type",3,"bindinput",6,"id",7,"name",7,"value",8],e,s,gg);_ac(oCV,oDV);_ac(ozU,oCV);_ac(osU,ozU);_ac(orU,osU);var oEV=_ctn("view");_setAttr(z,oEV,'class',21,e,s,gg);var oFV=_setAttrs(z,"button",["class",3,"formType",19,"type",20],e,s,gg);var oGV=_o(z,24,e,s,gg);_ac(oFV,oGV);_ac(oEV,oFV);_ac(orU,oEV);_ac(omU,orU);var oHV=_ctn("view");_setAttr(z,oHV,'class',25,e,s,gg);var oIV=_setAttrs(z,"view",["class",26,"style",1],e,s,gg);var oJV=_o(z,28,e,s,gg);_ac(oIV,oJV);_ac(oHV,oIV);_ac(omU,oHV);var oKV=_cvn();
    var oLV=_o(z,29,e,s,gg);
    var oMV=_gd('./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml',oLV,e_,d_);
    if(oMV){
      var oNV={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oMV(oNV,oNV,oKV,gg);
      gg.f=tgf;
    }else{
      _w(oLV,'./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml',0,0);
    }
    _ac(omU,oKV);_ac(r,omU);ojU.pop();ojU.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml"]={f:m38,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml"]={};
  var m39=function(e,s,r,gg){
    var z=gz$gma_40()
    var oOV=e_["./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml"].i;_ai(oOV,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml',0,0);_ai(oOV,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml',0,0);var oRV=_ctn("view");_setAttr(z,oRV,'class',0,e,s,gg);var oSV=_cvn();
    var oTV=_o(z,1,e,s,gg);
    var oUV=_gd('./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml',oTV,e_,d_);
    if(oUV){
      var oVV=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oUV(oVV,oVV,oSV,gg);
      gg.f=tgf;
    }else{
      _w(oTV,'./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml',0,0);
    }
    _ac(oRV,oSV);var oWV=_setAttrs(z,"form",["bindsubmit",3,"class",1],e,s,gg);var oXV=_ctn("view");_setAttr(z,oXV,'class',5,e,s,gg);var oYV=_ctn("view");_setAttr(z,oYV,'class',6,e,s,gg);var oZV=_ctn("view");_setAttr(z,oZV,'class',7,e,s,gg);var oaV=_ctn("view");_setAttr(z,oaV,'class',8,e,s,gg);var obV=_o(z,9,e,s,gg);_ac(oaV,obV);_ac(oZV,oaV);_ac(oYV,oZV);var ocV=_ctn("view");_setAttr(z,ocV,'class',10,e,s,gg);var odV=_setAttrs(z,"input",["id",3,"class",8,"name",9,"placeholder",10,"type",11],e,s,gg);_ac(ocV,odV);_ac(oYV,ocV);_ac(oXV,oYV);_ac(oWV,oXV);var oeV=_ctn("view");_setAttr(z,oeV,'class',15,e,s,gg);var ofV=_setAttrs(z,"button",["class",3,"formType",13,"type",14],e,s,gg);var ogV=_o(z,18,e,s,gg);_ac(ofV,ogV);_ac(oeV,ofV);var ohV=_setAttrs(z,"button",["type",17,"bindtap",2,"class",2],e,s,gg);var oiV=_o(z,20,e,s,gg);_ac(ohV,oiV);_ac(oeV,ohV);_ac(oWV,oeV);_ac(oRV,oWV);var ojV=_cvn();
    var okV=_o(z,21,e,s,gg);
    var olV=_gd('./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml',okV,e_,d_);
    if(olV){
      var omV={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      olV(omV,omV,ojV,gg);
      gg.f=tgf;
    }else{
      _w(okV,'./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml',0,0);
    }
    _ac(oRV,ojV);_ac(r,oRV);oOV.pop();oOV.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml"]={f:m39,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml"]={};
  var m40=function(e,s,r,gg){
    var z=gz$gma_41()
    var onV=e_["./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml"].i;_ai(onV,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml',0,0);_ai(onV,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml',0,0);var oqV=_ctn("view");_setAttr(z,oqV,'class',0,e,s,gg);var orV=_cvn();
    var osV=_o(z,1,e,s,gg);
    var otV=_gd('./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml',osV,e_,d_);
    if(otV){
      var ouV=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      otV(ouV,ouV,orV,gg);
      gg.f=tgf;
    }else{
      _w(osV,'./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml',0,0);
    }
    _ac(oqV,orV);var ovV=_ctn("view");_setAttr(z,ovV,'class',3,e,s,gg);var owV=_ctn("view");_setAttr(z,owV,'class',4,e,s,gg);var oxV=_setAttrs(z,"button",["bindtap",5,"class",1,"type",2],e,s,gg);var oyV=_o(z,8,e,s,gg);_ac(oxV,oyV);_ac(owV,oxV);var ozV=_setAttrs(z,"button",["type",7,"bindtap",2,"class",2],e,s,gg);var o_V=_o(z,10,e,s,gg);_ac(ozV,o_V);_ac(owV,ozV);_ac(ovV,owV);_ac(oqV,ovV);var oAW=_cvn();
    var oBW=_o(z,11,e,s,gg);
    var oCW=_gd('./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml',oBW,e_,d_);
    if(oCW){
      var oDW={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oCW(oDW,oDW,oAW,gg);
      gg.f=tgf;
    }else{
      _w(oBW,'./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml',0,0);
    }
    _ac(oqV,oAW);_ac(r,oqV);onV.pop();onV.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml"]={f:m40,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml"]={};
  var m41=function(e,s,r,gg){
    var z=gz$gma_42()
    var oEW=e_["./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml"].i;_ai(oEW,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml',0,0);_ai(oEW,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml',0,0);var oHW=_ctn("view");_setAttr(z,oHW,'class',0,e,s,gg);var oIW=_cvn();
    var oJW=_o(z,1,e,s,gg);
    var oKW=_gd('./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml',oJW,e_,d_);
    if(oKW){
      var oLW=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oKW(oLW,oLW,oIW,gg);
      gg.f=tgf;
    }else{
      _w(oJW,'./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml',0,0);
    }
    _ac(oHW,oIW);var oMW=_ctn("view");_setAttr(z,oMW,'class',3,e,s,gg);var oNW=_ctn("view");_setAttr(z,oNW,'class',4,e,s,gg);var oOW=_ctn("view");_setAttr(z,oOW,'class',5,e,s,gg);var oPW=_ctn("view");_setAttr(z,oPW,'class',6,e,s,gg);var oQW=_ctn("view");_setAttr(z,oQW,'class',7,e,s,gg);var oRW=_ctn("view");_setAttr(z,oRW,'class',8,e,s,gg);var oSW=_o(z,9,e,s,gg);_ac(oRW,oSW);_ac(oQW,oRW);_ac(oPW,oQW);var oTW=_ctn("view");_setAttr(z,oTW,'class',10,e,s,gg);var oUW=_setAttrs(z,"input",["id",9,"name",0,"bindinput",2,"class",3,"placeholder",4,"type",5,"value",6],e,s,gg);_ac(oTW,oUW);_ac(oPW,oTW);_ac(oOW,oPW);var oVW=_ctn("view");_setAttr(z,oVW,'class',6,e,s,gg);var oWW=_ctn("view");_setAttr(z,oWW,'class',7,e,s,gg);var oXW=_ctn("view");_setAttr(z,oXW,'class',8,e,s,gg);var oYW=_o(z,16,e,s,gg);_ac(oXW,oYW);_ac(oWW,oXW);_ac(oVW,oWW);var oZW=_ctn("view");_setAttr(z,oZW,'class',10,e,s,gg);var oaW=_setAttrs(z,"input",["class",12,"type",2,"id",4,"bindinput",5,"maxlength",6,"name",7,"placeholder",8,"value",9],e,s,gg);_ac(oZW,oaW);_ac(oVW,oZW);_ac(oOW,oVW);_ac(oNW,oOW);var obW=_ctn("view");_setAttr(z,obW,'class',22,e,s,gg);var ocW=_setAttrs(z,"button",["bindtap",23,"class",0,"type",1],e,s,gg);var odW=_o(z,25,e,s,gg);_ac(ocW,odW);_ac(obW,ocW);var oeW=_setAttrs(z,"button",["bindtap",26,"class",0],e,s,gg);var ofW=_o(z,27,e,s,gg);_ac(oeW,ofW);_ac(obW,oeW);var ogW=_setAttrs(z,"button",["bindtap",28,"class",0],e,s,gg);var ohW=_o(z,29,e,s,gg);_ac(ogW,ohW);_ac(obW,ogW);var oiW=_setAttrs(z,"button",["bindtap",30,"class",1],e,s,gg);var ojW=_o(z,32,e,s,gg);_ac(oiW,ojW);_ac(obW,oiW);var okW=_setAttrs(z,"button",["bindtap",33,"class",1],e,s,gg);var olW=_o(z,35,e,s,gg);_ac(okW,olW);_ac(obW,okW);var omW=_setAttrs(z,"button",["bindtap",36,"class",1],e,s,gg);var onW=_o(z,38,e,s,gg);_ac(omW,onW);_ac(obW,omW);var ooW=_setAttrs(z,"button",["bindtap",39,"class",1],e,s,gg);var opW=_o(z,41,e,s,gg);_ac(ooW,opW);_ac(obW,ooW);var oqW=_setAttrs(z,"button",["bindtap",42,"class",1],e,s,gg);var orW=_o(z,44,e,s,gg);_ac(oqW,orW);_ac(obW,oqW);var osW=_setAttrs(z,"button",["bindtap",45,"class",1],e,s,gg);var otW=_o(z,47,e,s,gg);_ac(osW,otW);_ac(obW,osW);var ouW=_setAttrs(z,"button",["bindtap",48,"class",1],e,s,gg);var ovW=_o(z,47,e,s,gg);_ac(ouW,ovW);_ac(obW,ouW);_ac(oNW,obW);_ac(oMW,oNW);_ac(oHW,oMW);var owW=_cvn();
    var oxW=_o(z,50,e,s,gg);
    var oyW=_gd('./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml',oxW,e_,d_);
    if(oyW){
      var ozW={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oyW(ozW,ozW,owW,gg);
      gg.f=tgf;
    }else{
      _w(oxW,'./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml',0,0);
    }
    _ac(oHW,owW);_ac(r,oHW);oEW.pop();oEW.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml"]={f:m41,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/storage/storage.maml"]={};
  var m42=function(e,s,r,gg){
    var z=gz$gma_43()
    var o_W=e_["./macle_demo_EN/page/API/pages/storage/storage.maml"].i;_ai(o_W,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/storage/storage.maml',0,0);_ai(o_W,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/storage/storage.maml',0,0);var oCX=_ctn("view");_setAttr(z,oCX,'class',0,e,s,gg);var oDX=_cvn();
    var oEX=_o(z,1,e,s,gg);
    var oFX=_gd('./macle_demo_EN/page/API/pages/storage/storage.maml',oEX,e_,d_);
    if(oFX){
      var oGX=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oFX(oGX,oGX,oDX,gg);
      gg.f=tgf;
    }else{
      _w(oEX,'./macle_demo_EN/page/API/pages/storage/storage.maml',0,0);
    }
    _ac(oCX,oDX);var oHX=_ctn("view");_setAttr(z,oHX,'class',3,e,s,gg);var oIX=_ctn("view");_setAttr(z,oIX,'class',4,e,s,gg);var oJX=_ctn("view");_setAttr(z,oJX,'class',5,e,s,gg);var oKX=_ctn("view");_setAttr(z,oKX,'class',6,e,s,gg);var oLX=_ctn("view");_setAttr(z,oLX,'class',7,e,s,gg);var oMX=_ctn("view");_setAttr(z,oMX,'class',8,e,s,gg);var oNX=_o(z,9,e,s,gg);_ac(oMX,oNX);_ac(oLX,oMX);_ac(oKX,oLX);var oOX=_ctn("view");_setAttr(z,oOX,'class',10,e,s,gg);var oPX=_setAttrs(z,"input",["id",9,"name",0,"bindinput",2,"class",3,"placeholder",4,"type",5,"value",6],e,s,gg);_ac(oOX,oPX);_ac(oKX,oOX);_ac(oJX,oKX);var oQX=_ctn("view");_setAttr(z,oQX,'class',6,e,s,gg);var oRX=_ctn("view");_setAttr(z,oRX,'class',7,e,s,gg);var oSX=_ctn("view");_setAttr(z,oSX,'class',8,e,s,gg);var oTX=_o(z,16,e,s,gg);_ac(oSX,oTX);_ac(oRX,oSX);_ac(oQX,oRX);var oUX=_ctn("view");_setAttr(z,oUX,'class',10,e,s,gg);var oVX=_setAttrs(z,"input",["class",12,"type",2,"id",4,"bindinput",5,"name",6,"placeholder",7,"value",8],e,s,gg);_ac(oUX,oVX);_ac(oQX,oUX);_ac(oJX,oQX);_ac(oIX,oJX);var oWX=_ctn("view");_setAttr(z,oWX,'class',21,e,s,gg);var oXX=_setAttrs(z,"button",["bindtap",22,"class",0,"type",1],e,s,gg);var oYX=_o(z,24,e,s,gg);_ac(oXX,oYX);_ac(oWX,oXX);var oZX=_setAttrs(z,"button",["bindtap",25,"class",0],e,s,gg);var oaX=_o(z,26,e,s,gg);_ac(oZX,oaX);_ac(oWX,oZX);var obX=_setAttrs(z,"button",["bindtap",27,"class",0],e,s,gg);var ocX=_o(z,28,e,s,gg);_ac(obX,ocX);_ac(oWX,obX);var odX=_setAttrs(z,"button",["bindtap",29,"class",0],e,s,gg);var oeX=_o(z,30,e,s,gg);_ac(odX,oeX);_ac(oWX,odX);var ofX=_setAttrs(z,"button",["bindtap",31,"class",0],e,s,gg);var ogX=_o(z,32,e,s,gg);_ac(ofX,ogX);_ac(oWX,ofX);var ohX=_setAttrs(z,"button",["class",22,"bindtap",11],e,s,gg);var oiX=_o(z,34,e,s,gg);_ac(ohX,oiX);_ac(oWX,ohX);var ojX=_setAttrs(z,"button",["class",25,"bindtap",10],e,s,gg);var okX=_o(z,36,e,s,gg);_ac(ojX,okX);_ac(oWX,ojX);_ac(oIX,oWX);_ac(oHX,oIX);_ac(oCX,oHX);var olX=_cvn();
    var omX=_o(z,37,e,s,gg);
    var onX=_gd('./macle_demo_EN/page/API/pages/storage/storage.maml',omX,e_,d_);
    if(onX){
      var ooX={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      onX(ooX,ooX,olX,gg);
      gg.f=tgf;
    }else{
      _w(omX,'./macle_demo_EN/page/API/pages/storage/storage.maml',0,0);
    }
    _ac(oCX,olX);_ac(r,oCX);o_W.pop();o_W.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/storage/storage.maml"]={f:m42,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/toast/toast.maml"]={};
  var m43=function(e,s,r,gg){
    var z=gz$gma_44()
    var opX=e_["./macle_demo_EN/page/API/pages/toast/toast.maml"].i;_ai(opX,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/toast/toast.maml',0,0);_ai(opX,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/toast/toast.maml',0,0);var osX=_ctn("view");_setAttr(z,osX,'class',0,e,s,gg);var otX=_cvn();
    var ouX=_o(z,1,e,s,gg);
    var ovX=_gd('./macle_demo_EN/page/API/pages/toast/toast.maml',ouX,e_,d_);
    if(ovX){
      var owX=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ovX(owX,owX,otX,gg);
      gg.f=tgf;
    }else{
      _w(ouX,'./macle_demo_EN/page/API/pages/toast/toast.maml',0,0);
    }
    _ac(osX,otX);var oxX=_ctn("view");_setAttr(z,oxX,'class',3,e,s,gg);var oyX=_ctn("view");_setAttr(z,oyX,'class',4,e,s,gg);var ozX=_setAttrs(z,"button",["bindtap",5,"id",1,"type",2],e,s,gg);var o_X=_o(z,8,e,s,gg);_ac(ozX,o_X);_ac(oyX,ozX);var oAY=_setAttrs(z,"button",["bindtap",9,"id",1,"type",2],e,s,gg);var oBY=_o(z,12,e,s,gg);_ac(oAY,oBY);_ac(oyX,oAY);var oCY=_setAttrs(z,"button",["bindtap",13,"id",1,"type",2],e,s,gg);var oDY=_o(z,16,e,s,gg);_ac(oCY,oDY);_ac(oyX,oCY);var oEY=_setAttrs(z,"button",["type",7,"bindtap",10,"id",11],e,s,gg);var oFY=_o(z,19,e,s,gg);_ac(oEY,oFY);_ac(oyX,oEY);var oGY=_setAttrs(z,"button",["type",15,"bindtap",5,"id",6],e,s,gg);var oHY=_o(z,22,e,s,gg);_ac(oGY,oHY);_ac(oyX,oGY);var oIY=_setAttrs(z,"button",["type",7,"bindtap",16,"id",17],e,s,gg);var oJY=_o(z,25,e,s,gg);_ac(oIY,oJY);_ac(oyX,oIY);var oKY=_setAttrs(z,"button",["bindtap",26,"id",1],e,s,gg);var oLY=_o(z,28,e,s,gg);_ac(oKY,oLY);_ac(oyX,oKY);var oMY=_setAttrs(z,"input",["placeholder",29,"style",1,"value",2],e,s,gg);oMY.rawAttr={"model:value":"{{toastTitle}}"};_ac(oyX,oMY);var oNY=_setAttrs(z,"button",["type",7,"bindtap",25,"id",26],e,s,gg);var oOY=_o(z,34,e,s,gg);_ac(oNY,oOY);_ac(oyX,oNY);_ac(oxX,oyX);_ac(osX,oxX);var oPY=_cvn();
    var oQY=_o(z,35,e,s,gg);
    var oRY=_gd('./macle_demo_EN/page/API/pages/toast/toast.maml',oQY,e_,d_);
    if(oRY){
      var oSY={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oRY(oSY,oSY,oPY,gg);
      gg.f=tgf;
    }else{
      _w(oQY,'./macle_demo_EN/page/API/pages/toast/toast.maml',0,0);
    }
    _ac(osX,oPY);_ac(r,osX);opX.pop();opX.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/toast/toast.maml"]={f:m43,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml"]={};
  var m44=function(e,s,r,gg){
    var z=gz$gma_45()
    var oTY=e_["./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml"].i;_ai(oTY,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml',0,0);_ai(oTY,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml',0,0);var oWY=_ctn("view");_setAttr(z,oWY,'class',0,e,s,gg);var oXY=_cvn();
    var oYY=_o(z,1,e,s,gg);
    var oZY=_gd('./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml',oYY,e_,d_);
    if(oZY){
      var oaY=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oZY(oaY,oaY,oXY,gg);
      gg.f=tgf;
    }else{
      _w(oYY,'./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml',0,0);
    }
    _ac(oWY,oXY);var obY=_ctn("view");_setAttr(z,obY,'class',3,e,s,gg);var ocY=_ctn("view");_setAttr(z,ocY,'class',4,e,s,gg);var odY=_setAttrs(z,"button",["bindtap",5,"class",1],e,s,gg);var oeY=_o(z,7,e,s,gg);_ac(odY,oeY);_ac(ocY,odY);var ofY=_setAttrs(z,"button",["bindtap",6,"class",0],e,s,gg);var ogY=_o(z,8,e,s,gg);_ac(ofY,ogY);_ac(ocY,ofY);var ohY=_setAttrs(z,"button",["bindtap",9,"class",0],e,s,gg);var oiY=_o(z,10,e,s,gg);_ac(ohY,oiY);_ac(ocY,ohY);var ojY=_setAttrs(z,"button",["bindtap",11,"class",0],e,s,gg);var okY=_o(z,12,e,s,gg);_ac(ojY,okY);_ac(ocY,ojY);_ac(obY,ocY);var olY=_cvn();if(_o(z,13,e,s,gg)){olY.maVkey=1;var omY=_ctn("view");_setAttr(z,omY,'class',14,e,s,gg);var ooY=_setAttrs(z,"textarea",["maxlength",15,"value",1],e,s,gg);_ac(omY,ooY);_ac(olY,omY);} _ac(obY,olY);_ac(oWY,obY);var opY=_cvn();
    var oqY=_o(z,17,e,s,gg);
    var orY=_gd('./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml',oqY,e_,d_);
    if(orY){
      var osY={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      orY(osY,osY,opY,gg);
      gg.f=tgf;
    }else{
      _w(oqY,'./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml',0,0);
    }
    _ac(oWY,opY);_ac(r,oWY);oTY.pop();oTY.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml"]={f:m44,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/vibrate/vibrate.maml"]={};
  var m45=function(e,s,r,gg){
    var z=gz$gma_46()
    var otY=e_["./macle_demo_EN/page/API/pages/vibrate/vibrate.maml"].i;_ai(otY,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/vibrate/vibrate.maml',0,0);_ai(otY,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/vibrate/vibrate.maml',0,0);var owY=_ctn("view");_setAttr(z,owY,'class',0,e,s,gg);var oxY=_cvn();
    var oyY=_o(z,1,e,s,gg);
    var ozY=_gd('./macle_demo_EN/page/API/pages/vibrate/vibrate.maml',oyY,e_,d_);
    if(ozY){
      var o_Y=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ozY(o_Y,o_Y,oxY,gg);
      gg.f=tgf;
    }else{
      _w(oyY,'./macle_demo_EN/page/API/pages/vibrate/vibrate.maml',0,0);
    }
    _ac(owY,oxY);var oAZ=_ctn("view");_setAttr(z,oAZ,'class',3,e,s,gg);var oBZ=_ctn("view");_setAttr(z,oBZ,'class',4,e,s,gg);var oCZ=_ctn("view");_setAttr(z,oCZ,'class',5,e,s,gg);var oDZ=_ctn("view");_setAttr(z,oDZ,'class',6,e,s,gg);var oEZ=_o(z,7,e,s,gg);_ac(oDZ,oEZ);_ac(oCZ,oDZ);_ac(oBZ,oCZ);var oFZ=_ctn("view");_setAttr(z,oFZ,'class',8,e,s,gg);var oGZ=_setAttrs(z,"picker",["bindchange",9,"mode",1,"range",2,"value",3],e,s,gg);var oHZ=_ctn("view");_setAttr(z,oHZ,'class',13,e,s,gg);var oIZ=_o(z,14,e,s,gg);_ac(oHZ,oIZ);_ac(oGZ,oHZ);_ac(oFZ,oGZ);_ac(oBZ,oFZ);_ac(oAZ,oBZ);var oJZ=_ctn("view");_setAttr(z,oJZ,'class',15,e,s,gg);var oKZ=_setAttrs(z,"button",["bindtap",16,"class",0,"type",1],e,s,gg);var oLZ=_o(z,18,e,s,gg);_ac(oKZ,oLZ);_ac(oJZ,oKZ);var oMZ=_setAttrs(z,"button",["bindtap",19,"class",0,"type",1],e,s,gg);var oNZ=_o(z,21,e,s,gg);_ac(oMZ,oNZ);_ac(oJZ,oMZ);_ac(oAZ,oJZ);var oOZ=_ctn("view");_setAttr(z,oOZ,'class',22,e,s,gg);var oPZ=_ctn("view");_setAttr(z,oPZ,'class',23,e,s,gg);var oQZ=_o(z,24,e,s,gg);_ac(oPZ,oQZ);_ac(oOZ,oPZ);_ac(oAZ,oOZ);_ac(owY,oAZ);var oRZ=_cvn();
    var oSZ=_o(z,25,e,s,gg);
    var oTZ=_gd('./macle_demo_EN/page/API/pages/vibrate/vibrate.maml',oSZ,e_,d_);
    if(oTZ){
      var oUZ={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oTZ(oUZ,oUZ,oRZ,gg);
      gg.f=tgf;
    }else{
      _w(oSZ,'./macle_demo_EN/page/API/pages/vibrate/vibrate.maml',0,0);
    }
    _ac(owY,oRZ);_ac(r,owY);otY.pop();otY.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/vibrate/vibrate.maml"]={f:m45,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/websocket/websocket.maml"]={};
  var m46=function(e,s,r,gg){
    var z=gz$gma_47()
    var oVZ=e_["./macle_demo_EN/page/API/pages/websocket/websocket.maml"].i;_ai(oVZ,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/websocket/websocket.maml',0,0);_ai(oVZ,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/websocket/websocket.maml',0,0);var oYZ=_ctn("view");_setAttr(z,oYZ,'class',0,e,s,gg);var oZZ=_cvn();
    var oaZ=_o(z,1,e,s,gg);
    var obZ=_gd('./macle_demo_EN/page/API/pages/websocket/websocket.maml',oaZ,e_,d_);
    if(obZ){
      var ocZ=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      obZ(ocZ,ocZ,oZZ,gg);
      gg.f=tgf;
    }else{
      _w(oaZ,'./macle_demo_EN/page/API/pages/websocket/websocket.maml',0,0);
    }
    _ac(oYZ,oZZ);var odZ=_ctn("view");_setAttr(z,odZ,'class',3,e,s,gg);var oeZ=_ctn("view");_setAttr(z,oeZ,'class',4,e,s,gg);var ofZ=_ctn("view");_setAttr(z,ofZ,'class',5,e,s,gg);var ogZ=_ctn("view");_setAttr(z,ogZ,'class',6,e,s,gg);var ohZ=_ctn("view");_setAttr(z,ohZ,'class',7,e,s,gg);var oiZ=_o(z,8,e,s,gg);_ac(ohZ,oiZ);_ac(ogZ,ohZ);var ojZ=_setAttrs(z,"input",["class",9,"id",1,"placeholder",2,"style",3,"value",4],e,s,gg);ojZ.rawAttr={"model:value":"{{wsUrl}}"};_ac(ogZ,ojZ);_ac(ofZ,ogZ);var okZ=_ctn("view");_setAttr(z,okZ,'class',6,e,s,gg);var olZ=_ctn("view");_setAttr(z,olZ,'class',7,e,s,gg);var omZ=_o(z,14,e,s,gg);_ac(olZ,omZ);_ac(okZ,olZ);var onZ=_setAttrs(z,"input",["class",9,"id",6,"placeholder",7,"style",8,"type",9,"value",10],e,s,gg);onZ.rawAttr={"model:value":"{{closeCode}}"};_ac(okZ,onZ);_ac(ofZ,okZ);var ooZ=_ctn("view");_setAttr(z,ooZ,'class',6,e,s,gg);var opZ=_ctn("view");_setAttr(z,opZ,'class',7,e,s,gg);var oqZ=_o(z,20,e,s,gg);_ac(opZ,oqZ);_ac(ooZ,opZ);var orZ=_setAttrs(z,"input",["class",9,"style",8,"id",12,"placeholder",13,"value",14],e,s,gg);orZ.rawAttr={"model:value":"{{closeReason}}"};_ac(ooZ,orZ);_ac(ofZ,ooZ);var osZ=_ctn("view");_setAttr(z,osZ,'class',24,e,s,gg);var otZ=_ctn("view");_setAttr(z,otZ,'class',7,e,s,gg);var ouZ=_o(z,25,e,s,gg);_ac(otZ,ouZ);_ac(osZ,otZ);var ovZ=_ctn("view");_setAttr(z,ovZ,'class',9,e,s,gg);var owZ=_setAttrs(z,"switch",["bindchange",26,"disabled",1],e,s,gg);_ac(ovZ,owZ);_ac(osZ,ovZ);_ac(ofZ,osZ);var oxZ=_ctn("view");_setAttr(z,oxZ,'class',6,e,s,gg);var oyZ=_ctn("view");_setAttr(z,oyZ,'class',7,e,s,gg);var ozZ=_o(z,28,e,s,gg);_ac(oyZ,ozZ);_ac(oxZ,oyZ);var o_Z=_setAttrs(z,"input",["class",9,"style",3,"id",20,"placeholder",21,"value",22],e,s,gg);o_Z.rawAttr={"model:value":"{{messageToSend}}"};_ac(oxZ,o_Z);_ac(ofZ,oxZ);_ac(oeZ,ofZ);_ac(odZ,oeZ);var oAa=_ctn("view");_setAttr(z,oAa,'class',32,e,s,gg);var oBa=_setAttrs(z,"button",["bindtap",33,"id",1,"loading",2,"size",3,"type",4],e,s,gg);var oCa=_o(z,38,e,s,gg);_ac(oBa,oCa);_ac(oAa,oBa);_ac(odZ,oAa);var oDa=_ctn("view");_setAttr(z,oDa,'class',39,e,s,gg);var oEa=_ctn("view");_setAttr(z,oEa,'class',7,e,s,gg);var oFa=_o(z,40,e,s,gg);_ac(oEa,oFa);_ac(oDa,oEa);var oGa=_setAttrs(z,"view",["class",41,"id",1],e,s,gg);var oHa=_o(z,43,e,s,gg);_ac(oGa,oHa);_ac(oDa,oGa);_ac(odZ,oDa);var oIa=_ctn("view");_setAttr(z,oIa,'class',39,e,s,gg);var oJa=_ctn("view");_setAttr(z,oJa,'class',7,e,s,gg);var oKa=_o(z,44,e,s,gg);_ac(oJa,oKa);_ac(oIa,oJa);var oLa=_setAttrs(z,"view",["class",41,"id",4],e,s,gg);var oMa=_o(z,46,e,s,gg);_ac(oLa,oMa);_ac(oIa,oLa);_ac(odZ,oIa);var oNa=_ctn("view");_setAttr(z,oNa,'class',47,e,s,gg);var oOa=_ctn("view");_setAttr(z,oOa,'class',48,e,s,gg);var oPa=_o(z,49,e,s,gg);_ac(oOa,oPa);_ac(oNa,oOa);var oQa=_setAttrs(z,"view",["class",41,"id",9],e,s,gg);var oRa=_o(z,51,e,s,gg);_ac(oQa,oRa);_ac(oNa,oQa);_ac(odZ,oNa);var oSa=_ctn("view");_setAttr(z,oSa,'class',47,e,s,gg);var oTa=_ctn("view");_setAttr(z,oTa,'class',7,e,s,gg);var oUa=_o(z,52,e,s,gg);_ac(oTa,oUa);_ac(oSa,oTa);var oVa=_setAttrs(z,"view",["class",41,"id",12],e,s,gg);var oWa=_o(z,54,e,s,gg);_ac(oVa,oWa);_ac(oSa,oVa);_ac(odZ,oSa);var oXa=_ctn("view");_setAttr(z,oXa,'class',47,e,s,gg);var oYa=_ctn("view");_setAttr(z,oYa,'class',7,e,s,gg);var oZa=_o(z,55,e,s,gg);_ac(oYa,oZa);_ac(oXa,oYa);var oaa=_setAttrs(z,"view",["class",41,"id",15],e,s,gg);var oba=_o(z,57,e,s,gg);_ac(oaa,oba);_ac(oXa,oaa);_ac(odZ,oXa);_ac(oYZ,odZ);var oca=_cvn();
    var oda=_o(z,58,e,s,gg);
    var oea=_gd('./macle_demo_EN/page/API/pages/websocket/websocket.maml',oda,e_,d_);
    if(oea){
      var ofa={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oea(ofa,ofa,oca,gg);
      gg.f=tgf;
    }else{
      _w(oda,'./macle_demo_EN/page/API/pages/websocket/websocket.maml',0,0);
    }
    _ac(oYZ,oca);_ac(r,oYZ);oVZ.pop();oVZ.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/websocket/websocket.maml"]={f:m46,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/common/foot.maml"]={};
  d_["./macle_demo_EN/page/common/foot.maml"]["foot"]=function(e,s,r,gg){
    var z=gz$gma_48(),b='./macle_demo_EN/page/common/foot.maml:foot'
    r.maVkey=b
    gg.f=$gdc(f_["./macle_demo_EN/page/common/foot.maml"],"",1)
    if(p_[b]){_wl(b,'./macle_demo_EN/page/common/foot.maml');return}
    p_[b]=true
    try{
      var oha=_setAttrs(z,"navigator",["class",0,"hoverClass",1,"openType",1,"url",2],e,s,gg);var oia=_setAttrs(z,"image",["class",4,"src",1],e,s,gg);_ac(oha,oia);_ac(r,oha);
    }catch(e){
      p_[b]=false
      throw e
    }
    p_[b]=false
    return r
  };
  var m47=function(e,s,r,gg){
    var z=gz$gma_48()
    
    return r;
  };
  e_["./macle_demo_EN/page/common/foot.maml"]={f:m47,j:[],i:[],ti:[],ic:[]};

  d_["./macle_demo_EN/page/common/head.maml"]={};
  d_["./macle_demo_EN/page/common/head.maml"]["head"]=function(e,s,r,gg){
    var z=gz$gma_49(),b='./macle_demo_EN/page/common/head.maml:head'
    r.maVkey=b
    gg.f=$gdc(f_["./macle_demo_EN/page/common/head.maml"],"",1)
    if(p_[b]){_wl(b,'./macle_demo_EN/page/common/head.maml');return}
    p_[b]=true
    try{
      var oma=_ctn("view");_setAttr(z,oma,'class',0,e,s,gg);var ona=_ctn("view");_setAttr(z,ona,'class',1,e,s,gg);var ooa=_o(z,2,e,s,gg);_ac(ona,ooa);_ac(oma,ona);var opa=_ctn("view");_setAttr(z,opa,'class',3,e,s,gg);_ac(oma,opa);var oqa=_cvn();if(_o(z,4,e,s,gg)){oqa.maVkey=1;var ora=_ctn("view");_setAttr(z,ora,'class',5,e,s,gg);var ota=_o(z,6,e,s,gg);_ac(ora,ota);_ac(oqa,ora);} _ac(oma,oqa);_ac(r,oma);
    }catch(e){
      p_[b]=false
      throw e
    }
    p_[b]=false
    return r
  };
  var m48=function(e,s,r,gg){
    var z=gz$gma_49()
    
    return r;
  };
  e_["./macle_demo_EN/page/common/head.maml"]={f:m48,j:[],i:[],ti:[],ic:[]};

  d_["./macle_demo_EN/page/component/pages/audio/audio.maml"]={};
  var m49=function(e,s,r,gg){
    var z=gz$gma_50()
    var owa=e_["./macle_demo_EN/page/component/pages/audio/audio.maml"].i;_ai(owa,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/audio/audio.maml',0,0);_ai(owa,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/audio/audio.maml',0,0);var oza=_ctn("view");_setAttr(z,oza,'class',0,e,s,gg);var o_a=_cvn();
    var oAb=_o(z,1,e,s,gg);
    var oBb=_gd('./macle_demo_EN/page/component/pages/audio/audio.maml',oAb,e_,d_);
    if(oBb){
      var oCb=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oBb(oCb,oCb,o_a,gg);
      gg.f=tgf;
    }else{
      _w(oAb,'./macle_demo_EN/page/component/pages/audio/audio.maml',0,0);
    }
    _ac(oza,o_a);var oDb=_ctn("view");_setAttr(z,oDb,'class',3,e,s,gg);var oEb=_setAttrs(z,"view",["class",4,"style",1],e,s,gg);var oFb=_setAttrs(z,"audio",["author",6,"bindended",1,"binderror",2,"bindpause",3,"bindplay",4,"bindtimeupdate",5,"controls",6,"id",7,"loop",8,"name",9,"poster",10,"src",11,"style",12],e,s,gg);_ac(oEb,oFb);_ac(oDb,oEb);_ac(oza,oDb);var oGb=_ctn("view");_setAttr(z,oGb,'class',19,e,s,gg);var oHb=_ctn("text");_setAttr(z,oHb,'class',20,e,s,gg);var oIb=_o(z,21,e,s,gg);_ac(oHb,oIb);_ac(oGb,oHb);var oJb=_ctn("view");_setAttr(z,oJb,'class',22,e,s,gg);var oKb=_ctn("button");_setAttr(z,oKb,'bindtap',23,e,s,gg);var oLb=_o(z,21,e,s,gg);_ac(oKb,oLb);_ac(oJb,oKb);_ac(oGb,oJb);_ac(oza,oGb);var oMb=_ctn("view");_setAttr(z,oMb,'class',19,e,s,gg);var oNb=_ctn("text");_setAttr(z,oNb,'class',20,e,s,gg);var oOb=_o(z,24,e,s,gg);_ac(oNb,oOb);_ac(oMb,oNb);var oPb=_ctn("view");_setAttr(z,oPb,'class',25,e,s,gg);var oQb=_ctn("button");_setAttr(z,oQb,'bindtap',26,e,s,gg);var oRb=_o(z,24,e,s,gg);_ac(oQb,oRb);_ac(oPb,oQb);_ac(oMb,oPb);_ac(oza,oMb);var oSb=_ctn("view");_setAttr(z,oSb,'class',19,e,s,gg);var oTb=_ctn("text");_setAttr(z,oTb,'class',20,e,s,gg);var oUb=_o(z,27,e,s,gg);_ac(oTb,oUb);_ac(oSb,oTb);var oVb=_ctn("view");_setAttr(z,oVb,'class',28,e,s,gg);var oWb=_ctn("button");_setAttr(z,oWb,'bindtap',29,e,s,gg);var oXb=_o(z,30,e,s,gg);_ac(oWb,oXb);_ac(oVb,oWb);_ac(oSb,oVb);_ac(oza,oSb);var oYb=_cvn();
    var oZb=_o(z,31,e,s,gg);
    var oab=_gd('./macle_demo_EN/page/component/pages/audio/audio.maml',oZb,e_,d_);
    if(oab){
      var obb={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oab(obb,obb,oYb,gg);
      gg.f=tgf;
    }else{
      _w(oZb,'./macle_demo_EN/page/component/pages/audio/audio.maml',0,0);
    }
    _ac(oza,oYb);_ac(r,oza);owa.pop();owa.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/audio/audio.maml"]={f:m49,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/button/button.maml"]={};
  var m50=function(e,s,r,gg){
    var z=gz$gma_51()
    var ocb=e_["./macle_demo_EN/page/component/pages/button/button.maml"].i;_ai(ocb,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/button/button.maml',0,0);_ai(ocb,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/button/button.maml',0,0);var ofb=_ctn("view");_setAttr(z,ofb,'class',0,e,s,gg);var ogb=_cvn();
    var ohb=_o(z,1,e,s,gg);
    var oib=_gd('./macle_demo_EN/page/component/pages/button/button.maml',ohb,e_,d_);
    if(oib){
      var ojb=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oib(ojb,ojb,ogb,gg);
      gg.f=tgf;
    }else{
      _w(ohb,'./macle_demo_EN/page/component/pages/button/button.maml',0,0);
    }
    _ac(ofb,ogb);var okb=_ctn("view");_setAttr(z,okb,'class',3,e,s,gg);var olb=_setAttrs(z,"view",["class",4,"id",1],e,s,gg);var omb=_setAttrs(z,"view",["hoverClass",6,"hoverStartTime",1,"hoverStayTime",2],e,s,gg);var onb=_setAttrs(z,"button",["class",9,"size",1,"type",2],e,s,gg);var oob=_o(z,12,e,s,gg);_ac(onb,oob);_ac(omb,onb);var opb=_setAttrs(z,"button",["type",11,"class",2,"hoverStopPropagation",3,"loading",3],e,s,gg);var oqb=_o(z,15,e,s,gg);_ac(opb,oqb);_ac(omb,opb);var orb=_setAttrs(z,"button",["type",11,"disabled",3,"hoverStopPropagation",3,"class",5],e,s,gg);var osb=_o(z,17,e,s,gg);_ac(orb,osb);_ac(omb,orb);_ac(olb,omb);var otb=_setAttrs(z,"button",["type",10,"class",8,"hoverClass",9,"hoverStartTime",10,"hoverStayTime",11],e,s,gg);var oub=_o(z,22,e,s,gg);_ac(otb,oub);_ac(olb,otb);var ovb=_setAttrs(z,"button",["type",10,"disabled",4,"class",13],e,s,gg);var owb=_o(z,24,e,s,gg);_ac(ovb,owb);_ac(olb,ovb);var oxb=_setAttrs(z,"button",["class",25,"disabled",1,"hoverClass",2,"type",3],e,s,gg);var oyb=_o(z,29,e,s,gg);_ac(oxb,oyb);_ac(olb,oxb);var ozb=_setAttrs(z,"button",["disabled",14,"type",14,"class",16],e,s,gg);var o_b=_o(z,31,e,s,gg);_ac(ozb,o_b);_ac(olb,ozb);var oAc=_setAttrs(z,"button",["type",10,"hoverStartTime",11,"hoverStayTime",11,"class",22,"hoverClass",23],e,s,gg);var oBc=_o(z,34,e,s,gg);_ac(oAc,oBc);_ac(olb,oAc);var oCc=_ctn("view");_setAttr(z,oCc,'class',35,e,s,gg);var oDc=_setAttrs(z,"button",["type",11,"plain",3,"class",25],e,s,gg);var oEc=_o(z,37,e,s,gg);_ac(oDc,oEc);_ac(oCc,oDc);var oFc=_setAttrs(z,"button",["type",11,"disabled",3,"plain",3,"class",27],e,s,gg);var oGc=_o(z,39,e,s,gg);_ac(oFc,oGc);_ac(oCc,oFc);var oHc=_setAttrs(z,"button",["type",10,"plain",4,"class",30],e,s,gg);var oIc=_o(z,37,e,s,gg);_ac(oHc,oIc);_ac(oCc,oHc);var oJc=_setAttrs(z,"button",["type",10,"disabled",4,"plain",4,"class",31],e,s,gg);var oKc=_o(z,37,e,s,gg);_ac(oJc,oKc);_ac(oCc,oJc);var oLc=_setAttrs(z,"button",["type",11,"class",31,"size",32],e,s,gg);var oMc=_o(z,37,e,s,gg);_ac(oLc,oMc);_ac(oCc,oLc);var oNc=_setAttrs(z,"button",["type",10,"size",33,"class",34],e,s,gg);var oOc=_o(z,37,e,s,gg);_ac(oNc,oOc);_ac(oCc,oNc);var oPc=_setAttrs(z,"button",["type",28,"size",15,"class",17],e,s,gg);var oQc=_o(z,37,e,s,gg);_ac(oPc,oQc);_ac(oCc,oPc);_ac(olb,oCc);var oRc=_setAttrs(z,"view",["hoverClass",6,"hoverStartTime",1,"class",40,"hoverStayTime",41],e,s,gg);var oSc=_setAttrs(z,"button",["type",11,"class",37,"plain",38,"size",38],e,s,gg);var oTc=_o(z,50,e,s,gg);_ac(oSc,oTc);_ac(oRc,oSc);var oUc=_setAttrs(z,"button",["loading",49,"size",0,"class",2,"type",3],e,s,gg);var oVc=_o(z,53,e,s,gg);_ac(oUc,oVc);_ac(oRc,oUc);var oWc=_setAttrs(z,"button",["disabled",49,"class",5],e,s,gg);var oXc=_o(z,55,e,s,gg);_ac(oWc,oXc);_ac(oRc,oWc);var oYc=_setAttrs(z,"button",["hoverClass",49,"class",7],e,s,gg);var oZc=_o(z,57,e,s,gg);_ac(oYc,oZc);_ac(oRc,oYc);var oac=_setAttrs(z,"button",["type",11,"hoverStopPropagation",38,"class",47],e,s,gg);var obc=_o(z,59,e,s,gg);_ac(oac,obc);_ac(oRc,oac);var occ=_setAttrs(z,"button",["type",10,"hoverClass",9,"hoverStartTime",39,"hoverStayTime",39,"class",50],e,s,gg);var odc=_o(z,61,e,s,gg);_ac(occ,odc);_ac(oRc,occ);_ac(olb,oRc);_ac(okb,olb);_ac(ofb,okb);var oec=_cvn();
    var ofc=_o(z,62,e,s,gg);
    var ogc=_gd('./macle_demo_EN/page/component/pages/button/button.maml',ofc,e_,d_);
    if(ogc){
      var ohc={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ogc(ohc,ohc,oec,gg);
      gg.f=tgf;
    }else{
      _w(ofc,'./macle_demo_EN/page/component/pages/button/button.maml',0,0);
    }
    _ac(ofb,oec);_ac(r,ofb);ocb.pop();ocb.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/button/button.maml"]={f:m50,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/camera/camera.maml"]={};
  var m51=function(e,s,r,gg){
    var z=gz$gma_52()
    var oic=e_["./macle_demo_EN/page/component/pages/camera/camera.maml"].i;_ai(oic,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/camera/camera.maml',0,0);_ai(oic,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/camera/camera.maml',0,0);var olc=_ctn("view");_setAttr(z,olc,'class',0,e,s,gg);var omc=_cvn();
    var onc=_o(z,1,e,s,gg);
    var ooc=_gd('./macle_demo_EN/page/component/pages/camera/camera.maml',onc,e_,d_);
    if(ooc){
      var opc=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ooc(opc,opc,omc,gg);
      gg.f=tgf;
    }else{
      _w(onc,'./macle_demo_EN/page/component/pages/camera/camera.maml',0,0);
    }
    _ac(olc,omc);var oqc=_setAttrs(z,"camera",["binderror",3,"bindstop",1,"devicePosition",2,"flash",3,"style",4],e,s,gg);_ac(olc,oqc);var orc=_setAttrs(z,"button",["bindtap",8,"class",1,"type",2],e,s,gg);var osc=_o(z,11,e,s,gg);_ac(orc,osc);_ac(olc,orc);var otc=_setAttrs(z,"button",["class",9,"type",1,"bindtap",3],e,s,gg);var ouc=_o(z,13,e,s,gg);_ac(otc,ouc);_ac(olc,otc);var ovc=_setAttrs(z,"button",["class",9,"type",1,"bindtap",5],e,s,gg);var owc=_o(z,15,e,s,gg);_ac(ovc,owc);_ac(olc,ovc);var oxc=_ctn("view");var oyc=_o(z,16,e,s,gg);_ac(oxc,oyc);_ac(olc,oxc);var ozc=_setAttrs(z,"image",["style",7,"src",10],e,s,gg);_ac(olc,ozc);var o_c=_cvn();
    var oAd=_o(z,18,e,s,gg);
    var oBd=_gd('./macle_demo_EN/page/component/pages/camera/camera.maml',oAd,e_,d_);
    if(oBd){
      var oCd={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oBd(oCd,oCd,o_c,gg);
      gg.f=tgf;
    }else{
      _w(oAd,'./macle_demo_EN/page/component/pages/camera/camera.maml',0,0);
    }
    _ac(olc,o_c);_ac(r,olc);oic.pop();oic.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/camera/camera.maml"]={f:m51,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/checkbox/checkbox.maml"]={};
  var m52=function(e,s,r,gg){
    var z=gz$gma_53()
    var oDd=e_["./macle_demo_EN/page/component/pages/checkbox/checkbox.maml"].i;_ai(oDd,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/checkbox/checkbox.maml',0,0);_ai(oDd,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/checkbox/checkbox.maml',0,0);var oGd=_ctn("view");_setAttr(z,oGd,'class',0,e,s,gg);var oHd=_cvn();
    var oId=_o(z,1,e,s,gg);
    var oJd=_gd('./macle_demo_EN/page/component/pages/checkbox/checkbox.maml',oId,e_,d_);
    if(oJd){
      var oKd=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oJd(oKd,oKd,oHd,gg);
      gg.f=tgf;
    }else{
      _w(oId,'./macle_demo_EN/page/component/pages/checkbox/checkbox.maml',0,0);
    }
    _ac(oGd,oHd);var oLd=_ctn("view");_setAttr(z,oLd,'class',3,e,s,gg);var oMd=_ctn("view");_setAttr(z,oMd,'class',4,e,s,gg);var oNd=_ctn("view");_setAttr(z,oNd,'class',5,e,s,gg);var oOd=_o(z,6,e,s,gg);_ac(oNd,oOd);_ac(oMd,oNd);var oPd=_ctn("label");_setAttr(z,oPd,'class',7,e,s,gg);var oQd=_setAttrs(z,"checkbox",["checked",8,"disabled",0,"class",1,"color",2,"value",3],e,s,gg);_ac(oPd,oQd);var oRd=_o(z,12,e,s,gg);_ac(oPd,oRd);_ac(oMd,oPd);var oSd=_ctn("label");_setAttr(z,oSd,'class',7,e,s,gg);var oTd=_setAttrs(z,"checkbox",["color",10,"value",1,"class",3],e,s,gg);_ac(oSd,oTd);var oUd=_o(z,14,e,s,gg);_ac(oSd,oUd);_ac(oMd,oSd);_ac(oLd,oMd);var oVd=_ctn("view");_setAttr(z,oVd,'class',15,e,s,gg);var oWd=_ctn("view");_setAttr(z,oWd,'class',5,e,s,gg);var oXd=_o(z,16,e,s,gg);_ac(oWd,oXd);_ac(oVd,oWd);var oYd=_ctn("view");_setAttr(z,oYd,'class',17,e,s,gg);var oZd=_ctn("checkbox-group");_setAttr(z,oZd,'bindchange',18,e,s,gg);var oad=_cvn();var obd=function(ofd,oed,odd,gg){var ocd=_ctn("label");_setAttr(z,ocd,'class',21,ofd,oed,gg);var ohd=_ctn("view");_setAttr(z,ohd,'class',22,ofd,oed,gg);var oid=_setAttrs(z,"checkbox",["value",20,"checked",3,"class",4,"color",5],ofd,oed,gg);_ac(ohd,oid);_ac(ocd,ohd);var ojd=_ctn("view");_setAttr(z,ojd,'class',26,ofd,oed,gg);var okd=_o(z,27,ofd,oed,gg);_ac(ojd,okd);_ac(ocd,ojd);_ac(odd,ocd);return odd;};_2(z,19,obd,e,s,gg,oad,"item","index",'{{item.value}}');_ac(oZd,oad);_ac(oYd,oZd);_ac(oVd,oYd);_ac(oLd,oVd);_ac(oGd,oLd);var old=_cvn();
    var omd=_o(z,28,e,s,gg);
    var ond=_gd('./macle_demo_EN/page/component/pages/checkbox/checkbox.maml',omd,e_,d_);
    if(ond){
      var ood={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ond(ood,ood,old,gg);
      gg.f=tgf;
    }else{
      _w(omd,'./macle_demo_EN/page/component/pages/checkbox/checkbox.maml',0,0);
    }
    _ac(oGd,old);_ac(r,oGd);oDd.pop();oDd.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/checkbox/checkbox.maml"]={f:m52,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/cover-image/cover-image.maml"]={};
  var m53=function(e,s,r,gg){
    var z=gz$gma_54()
    var opd=e_["./macle_demo_EN/page/component/pages/cover-image/cover-image.maml"].i;_ai(opd,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/cover-image/cover-image.maml',0,0);_ai(opd,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/cover-image/cover-image.maml',0,0);var osd=_ctn("view");_setAttr(z,osd,'class',0,e,s,gg);var otd=_cvn();
    var oud=_o(z,1,e,s,gg);
    var ovd=_gd('./macle_demo_EN/page/component/pages/cover-image/cover-image.maml',oud,e_,d_);
    if(ovd){
      var owd=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ovd(owd,owd,otd,gg);
      gg.f=tgf;
    }else{
      _w(oud,'./macle_demo_EN/page/component/pages/cover-image/cover-image.maml',0,0);
    }
    _ac(osd,otd);var oxd=_setAttrs(z,"camera",["binderror",3,"devicePosition",1,"flash",2,"style",3],e,s,gg);var oyd=_setAttrs(z,"cover-image",["class",7,"src",1],e,s,gg);_ac(oxd,oyd);_ac(osd,oxd);var ozd=_cvn();
    var o_d=_o(z,9,e,s,gg);
    var oAe=_gd('./macle_demo_EN/page/component/pages/cover-image/cover-image.maml',o_d,e_,d_);
    if(oAe){
      var oBe={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oAe(oBe,oBe,ozd,gg);
      gg.f=tgf;
    }else{
      _w(o_d,'./macle_demo_EN/page/component/pages/cover-image/cover-image.maml',0,0);
    }
    _ac(osd,ozd);_ac(r,osd);opd.pop();opd.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/cover-image/cover-image.maml"]={f:m53,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/cover-view/cover-view.maml"]={};
  var m54=function(e,s,r,gg){
    var z=gz$gma_55()
    var oCe=e_["./macle_demo_EN/page/component/pages/cover-view/cover-view.maml"].i;_ai(oCe,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/cover-view/cover-view.maml',0,0);_ai(oCe,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/cover-view/cover-view.maml',0,0);var oFe=_ctn("view");_setAttr(z,oFe,'class',0,e,s,gg);var oGe=_cvn();
    var oHe=_o(z,1,e,s,gg);
    var oIe=_gd('./macle_demo_EN/page/component/pages/cover-view/cover-view.maml',oHe,e_,d_);
    if(oIe){
      var oJe=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oIe(oJe,oJe,oGe,gg);
      gg.f=tgf;
    }else{
      _w(oHe,'./macle_demo_EN/page/component/pages/cover-view/cover-view.maml',0,0);
    }
    _ac(oFe,oGe);var oKe=_ctn("button");_setAttr(z,oKe,'bindtap',3,e,s,gg);var oLe=_o(z,4,e,s,gg);_ac(oKe,oLe);_ac(oFe,oKe);var oMe=_setAttrs(z,"camera",["binderror",5,"devicePosition",1,"flash",2,"style",3],e,s,gg);var oNe=_ctn("cover-view");_setAttr(z,oNe,'class',9,e,s,gg);var oOe=_ctn("cover-view");_setAttr(z,oOe,'class',10,e,s,gg);var oPe=_o(z,11,e,s,gg);_ac(oOe,oPe);_ac(oNe,oOe);var oQe=_ctn("cover-view");_setAttr(z,oQe,'class',12,e,s,gg);var oRe=_o(z,13,e,s,gg);_ac(oQe,oRe);_ac(oNe,oQe);var oSe=_ctn("cover-view");_setAttr(z,oSe,'class',14,e,s,gg);var oTe=_o(z,15,e,s,gg);_ac(oSe,oTe);_ac(oNe,oSe);_ac(oMe,oNe);_ac(oFe,oMe);var oUe=_cvn();
    var oVe=_o(z,16,e,s,gg);
    var oWe=_gd('./macle_demo_EN/page/component/pages/cover-view/cover-view.maml',oVe,e_,d_);
    if(oWe){
      var oXe={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oWe(oXe,oXe,oUe,gg);
      gg.f=tgf;
    }else{
      _w(oVe,'./macle_demo_EN/page/component/pages/cover-view/cover-view.maml',0,0);
    }
    _ac(oFe,oUe);_ac(r,oFe);oCe.pop();oCe.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/cover-view/cover-view.maml"]={f:m54,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/form/form.maml"]={};
  var m55=function(e,s,r,gg){
    var z=gz$gma_56()
    var oYe=e_["./macle_demo_EN/page/component/pages/form/form.maml"].i;_ai(oYe,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/form/form.maml',0,0);_ai(oYe,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/form/form.maml',0,0);var obe=_ctn("view");_setAttr(z,obe,'class',0,e,s,gg);var oce=_cvn();
    var ode=_o(z,1,e,s,gg);
    var oee=_gd('./macle_demo_EN/page/component/pages/form/form.maml',ode,e_,d_);
    if(oee){
      var ofe=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oee(ofe,ofe,oce,gg);
      gg.f=tgf;
    }else{
      _w(ode,'./macle_demo_EN/page/component/pages/form/form.maml',0,0);
    }
    _ac(obe,oce);var oge=_ctn("view");_setAttr(z,oge,'class',3,e,s,gg);var ohe=_setAttrs(z,"form",["bindreset",4,"bindsubmit",1,"id",2],e,s,gg);var oie=_ctn("view");_setAttr(z,oie,'class',7,e,s,gg);var oje=_ctn("view");_setAttr(z,oje,'class',8,e,s,gg);var oke=_o(z,9,e,s,gg);_ac(oje,oke);_ac(oie,oje);var ole=_setAttrs(z,"switch",["id",9,"name",0],e,s,gg);_ac(oie,ole);_ac(ohe,oie);var ome=_ctn("view");_setAttr(z,ome,'class',7,e,s,gg);var one=_ctn("view");_setAttr(z,one,'class',8,e,s,gg);var ooe=_o(z,10,e,s,gg);_ac(one,ooe);_ac(ome,one);var ope=_setAttrs(z,"radio-group",["name",10,"id",1],e,s,gg);var oqe=_ctn("label");var ore=_setAttrs(z,"radio",["id",12,"value",0],e,s,gg);_ac(oqe,ore);var ose=_o(z,13,e,s,gg);_ac(oqe,ose);_ac(ope,oqe);var ote=_ctn("label");var oue=_setAttrs(z,"radio",["id",14,"value",0],e,s,gg);_ac(ote,oue);var ove=_o(z,15,e,s,gg);_ac(ote,ove);_ac(ope,ote);_ac(ome,ope);_ac(ohe,ome);var owe=_ctn("view");_setAttr(z,owe,'class',7,e,s,gg);var oxe=_ctn("view");_setAttr(z,oxe,'class',8,e,s,gg);var oye=_o(z,16,e,s,gg);_ac(oxe,oye);_ac(owe,oxe);var oze=_setAttrs(z,"checkbox-group",["name",16,"id",1],e,s,gg);var o_e=_ctn("label");var oAf=_setAttrs(z,"checkbox",["id",18,"value",0],e,s,gg);_ac(o_e,oAf);var oBf=_o(z,13,e,s,gg);_ac(o_e,oBf);_ac(oze,o_e);var oCf=_ctn("label");var oDf=_setAttrs(z,"checkbox",["id",19,"value",0],e,s,gg);_ac(oCf,oDf);var oEf=_o(z,15,e,s,gg);_ac(oCf,oEf);_ac(oze,oCf);_ac(owe,oze);_ac(ohe,owe);var oFf=_ctn("view");_setAttr(z,oFf,'class',7,e,s,gg);var oGf=_ctn("view");_setAttr(z,oGf,'class',8,e,s,gg);var oHf=_o(z,20,e,s,gg);_ac(oGf,oHf);_ac(oFf,oGf);var oIf=_setAttrs(z,"slider",["name",20,"id",1,"showValue",2,"value",3],e,s,gg);_ac(oFf,oIf);_ac(ohe,oFf);var oJf=_ctn("view");_setAttr(z,oJf,'class',24,e,s,gg);var oKf=_ctn("view");_setAttr(z,oKf,'class',8,e,s,gg);var oLf=_o(z,25,e,s,gg);_ac(oKf,oLf);_ac(oJf,oKf);var oMf=_ctn("view");_setAttr(z,oMf,'class',26,e,s,gg);var oNf=_ctn("view");_setAttr(z,oNf,'class',27,e,s,gg);var oOf=_ctn("view");_setAttr(z,oOf,'class',28,e,s,gg);var oPf=_setAttrs(z,"input",["name",25,"class",4,"id",5,"placeholder",6],e,s,gg);_ac(oOf,oPf);_ac(oNf,oOf);_ac(oMf,oNf);_ac(oJf,oMf);_ac(ohe,oJf);var oQf=_ctn("view");_setAttr(z,oQf,'class',32,e,s,gg);var oRf=_setAttrs(z,"button",["formType",5,"id",0,"type",28],e,s,gg);var oSf=_o(z,34,e,s,gg);_ac(oRf,oSf);_ac(oQf,oRf);var oTf=_setAttrs(z,"button",["formType",4,"id",0],e,s,gg);var oUf=_o(z,35,e,s,gg);_ac(oTf,oUf);_ac(oQf,oTf);_ac(ohe,oQf);_ac(oge,ohe);_ac(obe,oge);var oVf=_cvn();
    var oWf=_o(z,36,e,s,gg);
    var oXf=_gd('./macle_demo_EN/page/component/pages/form/form.maml',oWf,e_,d_);
    if(oXf){
      var oYf={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oXf(oYf,oYf,oVf,gg);
      gg.f=tgf;
    }else{
      _w(oWf,'./macle_demo_EN/page/component/pages/form/form.maml',0,0);
    }
    _ac(obe,oVf);_ac(r,obe);oYe.pop();oYe.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/form/form.maml"]={f:m55,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/icon/icon.maml"]={};
  var m56=function(e,s,r,gg){
    var z=gz$gma_57()
    var oZf=e_["./macle_demo_EN/page/component/pages/icon/icon.maml"].i;_ai(oZf,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/icon/icon.maml',0,0);_ai(oZf,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/icon/icon.maml',0,0);var ocf=_ctn("view");_setAttr(z,ocf,'class',0,e,s,gg);var odf=_cvn();
    var oef=_o(z,1,e,s,gg);
    var off=_gd('./macle_demo_EN/page/component/pages/icon/icon.maml',oef,e_,d_);
    if(off){
      var ogf=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      off(ogf,ogf,odf,gg);
      gg.f=tgf;
    }else{
      _w(oef,'./macle_demo_EN/page/component/pages/icon/icon.maml',0,0);
    }
    _ac(ocf,odf);var ohf=_ctn("view");_setAttr(z,ohf,'class',3,e,s,gg);var oif=_setAttrs(z,"icon",["class",4,"size",1,"type",2],e,s,gg);_ac(ohf,oif);var ojf=_ctn("view");_setAttr(z,ojf,'class',7,e,s,gg);var okf=_ctn("view");_setAttr(z,okf,'class',8,e,s,gg);var olf=_o(z,6,e,s,gg);_ac(okf,olf);_ac(ojf,okf);var omf=_ctn("view");_setAttr(z,omf,'class',9,e,s,gg);var onf=_o(z,10,e,s,gg);_ac(omf,onf);_ac(ojf,omf);_ac(ohf,ojf);_ac(ocf,ohf);var oof=_ctn("view");_setAttr(z,oof,'class',3,e,s,gg);var opf=_setAttrs(z,"icon",["size",5,"class",6,"type",7],e,s,gg);_ac(oof,opf);var oqf=_ctn("view");_setAttr(z,oqf,'class',7,e,s,gg);var orf=_ctn("view");_setAttr(z,orf,'class',8,e,s,gg);var osf=_o(z,12,e,s,gg);_ac(orf,osf);_ac(oqf,orf);var otf=_ctn("view");_setAttr(z,otf,'class',9,e,s,gg);var ouf=_o(z,13,e,s,gg);_ac(otf,ouf);_ac(oqf,otf);_ac(oof,oqf);_ac(ocf,oof);var ovf=_ctn("view");_setAttr(z,ovf,'class',3,e,s,gg);var owf=_setAttrs(z,"icon",["size",5,"class",9,"color",10,"type",11],e,s,gg);_ac(ovf,owf);var oxf=_ctn("view");_setAttr(z,oxf,'class',7,e,s,gg);var oyf=_ctn("view");_setAttr(z,oyf,'class',8,e,s,gg);var ozf=_o(z,16,e,s,gg);_ac(oyf,ozf);_ac(oxf,oyf);var o_f=_ctn("view");_setAttr(z,o_f,'class',9,e,s,gg);var oAg=_o(z,17,e,s,gg);_ac(o_f,oAg);_ac(oxf,o_f);_ac(ovf,oxf);_ac(ocf,ovf);var oBg=_ctn("view");_setAttr(z,oBg,'class',3,e,s,gg);var oCg=_setAttrs(z,"icon",["size",5,"type",11,"class",13],e,s,gg);_ac(oBg,oCg);var oDg=_ctn("view");_setAttr(z,oDg,'class',7,e,s,gg);var oEg=_ctn("view");_setAttr(z,oEg,'class',8,e,s,gg);var oFg=_o(z,19,e,s,gg);_ac(oEg,oFg);_ac(oDg,oEg);var oGg=_ctn("view");_setAttr(z,oGg,'class',9,e,s,gg);var oHg=_o(z,20,e,s,gg);_ac(oGg,oHg);_ac(oDg,oGg);_ac(oBg,oDg);_ac(ocf,oBg);var oIg=_ctn("view");_setAttr(z,oIg,'class',3,e,s,gg);var oJg=_setAttrs(z,"icon",["size",5,"class",16,"type",17],e,s,gg);_ac(oIg,oJg);var oKg=_ctn("view");_setAttr(z,oKg,'class',7,e,s,gg);var oLg=_ctn("view");_setAttr(z,oLg,'class',8,e,s,gg);var oMg=_o(z,22,e,s,gg);_ac(oLg,oMg);_ac(oKg,oLg);var oNg=_ctn("view");_setAttr(z,oNg,'class',9,e,s,gg);var oOg=_o(z,23,e,s,gg);_ac(oNg,oOg);_ac(oKg,oNg);_ac(oIg,oKg);_ac(ocf,oIg);var oPg=_ctn("view");_setAttr(z,oPg,'class',3,e,s,gg);var oQg=_ctn("view");_setAttr(z,oQg,'class',24,e,s,gg);var oRg=_setAttrs(z,"icon",["type",6,"class",19,"size",20],e,s,gg);_ac(oQg,oRg);_ac(oPg,oQg);var oSg=_ctn("view");_setAttr(z,oSg,'class',7,e,s,gg);var oTg=_ctn("view");_setAttr(z,oTg,'class',8,e,s,gg);var oUg=_o(z,27,e,s,gg);_ac(oTg,oUg);_ac(oSg,oTg);var oVg=_ctn("view");_setAttr(z,oVg,'class',9,e,s,gg);var oWg=_o(z,28,e,s,gg);_ac(oVg,oWg);_ac(oSg,oVg);_ac(oPg,oSg);_ac(ocf,oPg);var oXg=_ctn("view");_setAttr(z,oXg,'class',3,e,s,gg);var oYg=_ctn("view");_setAttr(z,oYg,'class',24,e,s,gg);var oZg=_setAttrs(z,"icon",["size",26,"class",3,"type",4],e,s,gg);_ac(oYg,oZg);_ac(oXg,oYg);var oag=_ctn("view");_setAttr(z,oag,'class',7,e,s,gg);var obg=_ctn("view");_setAttr(z,obg,'class',8,e,s,gg);var ocg=_o(z,31,e,s,gg);_ac(obg,ocg);_ac(oag,obg);var odg=_ctn("view");_setAttr(z,odg,'class',9,e,s,gg);var oeg=_o(z,32,e,s,gg);_ac(odg,oeg);_ac(oag,odg);_ac(oXg,oag);_ac(ocf,oXg);var ofg=_ctn("view");_setAttr(z,ofg,'class',3,e,s,gg);var ogg=_ctn("view");_setAttr(z,ogg,'class',24,e,s,gg);var ohg=_setAttrs(z,"icon",["type",16,"class",9,"size",10],e,s,gg);_ac(ogg,ohg);_ac(ofg,ogg);var oig=_ctn("view");_setAttr(z,oig,'class',7,e,s,gg);var ojg=_ctn("view");_setAttr(z,ojg,'class',8,e,s,gg);var okg=_o(z,33,e,s,gg);_ac(ojg,okg);_ac(oig,ojg);var olg=_ctn("view");_setAttr(z,olg,'class',9,e,s,gg);var omg=_o(z,34,e,s,gg);_ac(olg,omg);_ac(oig,olg);_ac(ofg,oig);_ac(ocf,ofg);var ong=_ctn("view");_setAttr(z,ong,'class',3,e,s,gg);var oog=_ctn("view");_setAttr(z,oog,'class',24,e,s,gg);var opg=_setAttrs(z,"icon",["size",26,"class",9,"type",10],e,s,gg);_ac(oog,opg);_ac(ong,oog);var oqg=_ctn("view");_setAttr(z,oqg,'class',7,e,s,gg);var org=_ctn("view");_setAttr(z,org,'class',8,e,s,gg);var osg=_o(z,37,e,s,gg);_ac(org,osg);_ac(oqg,org);var otg=_ctn("view");_setAttr(z,otg,'class',9,e,s,gg);var oug=_o(z,38,e,s,gg);_ac(otg,oug);_ac(oqg,otg);_ac(ong,oqg);_ac(ocf,ong);var ovg=_ctn("view");_setAttr(z,ovg,'class',3,e,s,gg);var owg=_ctn("view");_setAttr(z,owg,'class',24,e,s,gg);var oxg=_setAttrs(z,"icon",["size",26,"class",13,"type",14],e,s,gg);_ac(owg,oxg);_ac(ovg,owg);var oyg=_ctn("view");_setAttr(z,oyg,'class',7,e,s,gg);var ozg=_ctn("view");_setAttr(z,ozg,'class',8,e,s,gg);var o_g=_o(z,40,e,s,gg);_ac(ozg,o_g);_ac(oyg,ozg);var oAh=_ctn("view");_setAttr(z,oAh,'class',9,e,s,gg);var oBh=_o(z,41,e,s,gg);_ac(oAh,oBh);_ac(oyg,oAh);_ac(ovg,oyg);_ac(ocf,ovg);var oCh=_ctn("view");_setAttr(z,oCh,'class',3,e,s,gg);var oDh=_ctn("view");_setAttr(z,oDh,'class',24,e,s,gg);var oEh=_setAttrs(z,"icon",["size",26,"class",16,"type",17],e,s,gg);_ac(oDh,oEh);_ac(oCh,oDh);var oFh=_ctn("view");_setAttr(z,oFh,'class',7,e,s,gg);var oGh=_ctn("view");_setAttr(z,oGh,'class',8,e,s,gg);var oHh=_o(z,43,e,s,gg);_ac(oGh,oHh);_ac(oFh,oGh);var oIh=_ctn("view");_setAttr(z,oIh,'class',9,e,s,gg);var oJh=_o(z,44,e,s,gg);_ac(oIh,oJh);_ac(oFh,oIh);_ac(oCh,oFh);_ac(ocf,oCh);var oKh=_ctn("view");_setAttr(z,oKh,'class',3,e,s,gg);var oLh=_ctn("view");_setAttr(z,oLh,'class',24,e,s,gg);var oMh=_setAttrs(z,"icon",["size",26,"class",19,"type",20],e,s,gg);_ac(oLh,oMh);_ac(oKh,oLh);var oNh=_ctn("view");_setAttr(z,oNh,'class',7,e,s,gg);var oOh=_ctn("view");_setAttr(z,oOh,'class',8,e,s,gg);var oPh=_o(z,47,e,s,gg);_ac(oOh,oPh);_ac(oNh,oOh);var oQh=_ctn("view");_setAttr(z,oQh,'class',9,e,s,gg);var oRh=_o(z,48,e,s,gg);_ac(oQh,oRh);_ac(oNh,oQh);_ac(oKh,oNh);_ac(ocf,oKh);var oSh=_ctn("view");_setAttr(z,oSh,'class',3,e,s,gg);var oTh=_ctn("view");_setAttr(z,oTh,'class',24,e,s,gg);var oUh=_setAttrs(z,"icon",["class",49,"size",1,"type",2],e,s,gg);_ac(oTh,oUh);_ac(oSh,oTh);var oVh=_ctn("view");_setAttr(z,oVh,'class',7,e,s,gg);var oWh=_ctn("view");_setAttr(z,oWh,'class',8,e,s,gg);var oXh=_o(z,51,e,s,gg);_ac(oWh,oXh);_ac(oVh,oWh);var oYh=_ctn("view");_setAttr(z,oYh,'class',9,e,s,gg);var oZh=_o(z,52,e,s,gg);_ac(oYh,oZh);_ac(oVh,oYh);_ac(oSh,oVh);_ac(ocf,oSh);var oah=_cvn();
    var obh=_o(z,53,e,s,gg);
    var och=_gd('./macle_demo_EN/page/component/pages/icon/icon.maml',obh,e_,d_);
    if(och){
      var odh={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      och(odh,odh,oah,gg);
      gg.f=tgf;
    }else{
      _w(obh,'./macle_demo_EN/page/component/pages/icon/icon.maml',0,0);
    }
    _ac(ocf,oah);_ac(r,ocf);oZf.pop();oZf.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/icon/icon.maml"]={f:m56,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/image/image.maml"]={};
  var m57=function(e,s,r,gg){
    var z=gz$gma_58()
    var oeh=e_["./macle_demo_EN/page/component/pages/image/image.maml"].i;_ai(oeh,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/image/image.maml',0,0);_ai(oeh,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/image/image.maml',0,0);var ohh=_ctn("view");_setAttr(z,ohh,'class',0,e,s,gg);var oih=_cvn();
    var ojh=_o(z,1,e,s,gg);
    var okh=_gd('./macle_demo_EN/page/component/pages/image/image.maml',ojh,e_,d_);
    if(okh){
      var olh=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      okh(olh,olh,oih,gg);
      gg.f=tgf;
    }else{
      _w(ojh,'./macle_demo_EN/page/component/pages/image/image.maml',0,0);
    }
    _ac(ohh,oih);var omh=_ctn("view");_setAttr(z,omh,'class',3,e,s,gg);var onh=_cvn();var ooh=function(osh,orh,oqh,gg){var oph=_ctn("view");_setAttr(z,oph,'class',6,osh,orh,gg);var ouh=_ctn("view");_setAttr(z,ouh,'class',7,osh,orh,gg);var ovh=_o(z,8,osh,orh,gg);_ac(ouh,ovh);_ac(oph,ouh);var owh=_ctn("view");_setAttr(z,owh,'class',9,osh,orh,gg);var oxh=_setAttrs(z,"image",["binderror",10,"bindload",1,"class",2,"mode",3,"src",4],osh,orh,gg);_ac(owh,oxh);_ac(oph,owh);_ac(oqh,oph);return oqh;};_2(z,4,ooh,e,s,gg,onh,"item","index",'');_ac(omh,onh);var oyh=_ctn("view");_setAttr(z,oyh,'class',6,e,s,gg);var ozh=_ctn("view");_setAttr(z,ozh,'class',7,e,s,gg);var o_h=_o(z,15,e,s,gg);_ac(ozh,o_h);_ac(oyh,ozh);var oAi=_ctn("view");_setAttr(z,oAi,'class',9,e,s,gg);var oBi=_setAttrs(z,"image",["binderror",10,"bindload",1,"src",4,"class",6,"mode",7],e,s,gg);_ac(oAi,oBi);_ac(oyh,oAi);_ac(omh,oyh);var oCi=_ctn("view");_setAttr(z,oCi,'class',6,e,s,gg);var oDi=_ctn("view");_setAttr(z,oDi,'class',7,e,s,gg);var oEi=_o(z,18,e,s,gg);_ac(oDi,oEi);_ac(oCi,oDi);var oFi=_ctn("view");_setAttr(z,oFi,'class',9,e,s,gg);var oGi=_setAttrs(z,"image",["src",14,"class",5,"mode",6],e,s,gg);_ac(oFi,oGi);_ac(oCi,oFi);_ac(omh,oCi);_ac(ohh,omh);var oHi=_cvn();
    var oIi=_o(z,21,e,s,gg);
    var oJi=_gd('./macle_demo_EN/page/component/pages/image/image.maml',oIi,e_,d_);
    if(oJi){
      var oKi={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oJi(oKi,oKi,oHi,gg);
      gg.f=tgf;
    }else{
      _w(oIi,'./macle_demo_EN/page/component/pages/image/image.maml',0,0);
    }
    _ac(ohh,oHi);_ac(r,ohh);oeh.pop();oeh.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/image/image.maml"]={f:m57,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/input/input.maml"]={};
  var m58=function(e,s,r,gg){
    var z=gz$gma_59()
    var oLi=e_["./macle_demo_EN/page/component/pages/input/input.maml"].i;_ai(oLi,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/input/input.maml',0,0);_ai(oLi,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/input/input.maml',0,0);var oOi=_ctn("view");_setAttr(z,oOi,'class',0,e,s,gg);var oPi=_cvn();
    var oQi=_o(z,1,e,s,gg);
    var oRi=_gd('./macle_demo_EN/page/component/pages/input/input.maml',oQi,e_,d_);
    if(oRi){
      var oSi=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oRi(oSi,oSi,oPi,gg);
      gg.f=tgf;
    }else{
      _w(oQi,'./macle_demo_EN/page/component/pages/input/input.maml',0,0);
    }
    _ac(oOi,oPi);var oTi=_ctn("view");_setAttr(z,oTi,'class',3,e,s,gg);var oUi=_ctn("view");_setAttr(z,oUi,'class',4,e,s,gg);var oVi=_ctn("view");_setAttr(z,oVi,'class',5,e,s,gg);var oWi=_o(z,6,e,s,gg);_ac(oVi,oWi);_ac(oUi,oVi);var oXi=_ctn("view");_setAttr(z,oXi,'class',7,e,s,gg);var oYi=_ctn("view");_setAttr(z,oYi,'class',8,e,s,gg);var oZi=_setAttrs(z,"input",["class",9,"disabled",1,"value",2],e,s,gg);_ac(oYi,oZi);_ac(oXi,oYi);_ac(oUi,oXi);_ac(oTi,oUi);var oai=_ctn("view");_setAttr(z,oai,'class',4,e,s,gg);var obi=_ctn("view");_setAttr(z,obi,'class',5,e,s,gg);var oci=_o(z,12,e,s,gg);_ac(obi,oci);_ac(oai,obi);var odi=_ctn("view");_setAttr(z,odi,'class',7,e,s,gg);var oei=_ctn("view");_setAttr(z,oei,'class',8,e,s,gg);var ofi=_setAttrs(z,"input",["adjustPosition",10,"confirmHold",0,"focus",0,"bindblur",3,"bindconfirm",4,"bindfocus",5,"class",6,"confirmType",7,"placeholder",8,"selectionEnd",9,"selectionStart",10,"value",11],e,s,gg);_ac(oei,ofi);_ac(odi,oei);_ac(oai,odi);_ac(oTi,oai);var ogi=_ctn("view");_setAttr(z,ogi,'class',4,e,s,gg);var ohi=_ctn("view");_setAttr(z,ohi,'class',5,e,s,gg);var oii=_o(z,22,e,s,gg);_ac(ohi,oii);_ac(ogi,ohi);var oji=_ctn("view");_setAttr(z,oji,'class',7,e,s,gg);var oki=_ctn("view");_setAttr(z,oki,'class',8,e,s,gg);var oli=_setAttrs(z,"input",["bindblur",13,"bindconfirm",1,"bindfocus",2,"class",10,"maxlength",11,"placeholder",12,"value",13],e,s,gg);_ac(oki,oli);_ac(oji,oki);_ac(ogi,oji);_ac(oTi,ogi);var omi=_ctn("view");_setAttr(z,omi,'class',4,e,s,gg);var oni=_ctn("view");_setAttr(z,oni,'class',27,e,s,gg);var ooi=_o(z,28,e,s,gg);_ac(oni,ooi);_ac(omi,oni);var opi=_ctn("view");_setAttr(z,opi,'class',7,e,s,gg);var oqi=_ctn("view");_setAttr(z,oqi,'class',8,e,s,gg);var ori=_setAttrs(z,"input",["bindinput",29,"class",1,"placeholder",2],e,s,gg);_ac(oqi,ori);_ac(opi,oqi);_ac(omi,opi);_ac(oTi,omi);var osi=_ctn("view");_setAttr(z,osi,'class',4,e,s,gg);var oti=_ctn("view");_setAttr(z,oti,'class',5,e,s,gg);var oui=_o(z,32,e,s,gg);_ac(oti,oui);_ac(osi,oti);var ovi=_ctn("view");_setAttr(z,ovi,'class',7,e,s,gg);var owi=_ctn("view");_setAttr(z,owi,'class',8,e,s,gg);var oxi=_setAttrs(z,"input",["bindinput",33,"class",1,"placeholder",2],e,s,gg);_ac(owi,oxi);_ac(ovi,owi);_ac(osi,ovi);_ac(oTi,osi);var oyi=_ctn("view");_setAttr(z,oyi,'class',4,e,s,gg);var ozi=_ctn("view");_setAttr(z,ozi,'class',5,e,s,gg);var o_i=_o(z,36,e,s,gg);_ac(ozi,o_i);_ac(oyi,ozi);var oAj=_ctn("view");_setAttr(z,oAj,'class',7,e,s,gg);var oBj=_ctn("view");_setAttr(z,oBj,'class',8,e,s,gg);var oCj=_setAttrs(z,"input",["bindinput",37,"class",1,"placeholder",2,"type",3],e,s,gg);_ac(oBj,oCj);_ac(oAj,oBj);_ac(oyi,oAj);_ac(oTi,oyi);var oDj=_ctn("view");_setAttr(z,oDj,'class',4,e,s,gg);var oEj=_ctn("view");_setAttr(z,oEj,'class',5,e,s,gg);var oFj=_o(z,41,e,s,gg);_ac(oEj,oFj);_ac(oDj,oEj);var oGj=_ctn("view");_setAttr(z,oGj,'class',7,e,s,gg);var oHj=_ctn("view");_setAttr(z,oHj,'class',8,e,s,gg);var oIj=_setAttrs(z,"input",["class",42,"placeholder",1,"type",2],e,s,gg);_ac(oHj,oIj);_ac(oGj,oHj);_ac(oDj,oGj);_ac(oTi,oDj);var oJj=_ctn("view");_setAttr(z,oJj,'class',4,e,s,gg);var oKj=_ctn("view");_setAttr(z,oKj,'class',5,e,s,gg);var oLj=_o(z,45,e,s,gg);_ac(oKj,oLj);_ac(oJj,oKj);var oMj=_ctn("view");_setAttr(z,oMj,'class',7,e,s,gg);var oNj=_ctn("view");_setAttr(z,oNj,'class',8,e,s,gg);var oOj=_setAttrs(z,"input",["password",10,"class",36,"placeholder",37,"type",38],e,s,gg);_ac(oNj,oOj);_ac(oMj,oNj);_ac(oJj,oMj);_ac(oTi,oJj);var oPj=_ctn("view");_setAttr(z,oPj,'class',4,e,s,gg);var oQj=_ctn("view");_setAttr(z,oQj,'class',5,e,s,gg);var oRj=_o(z,49,e,s,gg);_ac(oQj,oRj);_ac(oPj,oQj);var oSj=_ctn("view");_setAttr(z,oSj,'class',7,e,s,gg);var oTj=_ctn("view");_setAttr(z,oTj,'class',8,e,s,gg);var oUj=_setAttrs(z,"input",["bindblur",13,"bindfocus",2,"class",37,"placeholder",38,"placeholderClass",39,"placeholderStyle",40],e,s,gg);_ac(oTj,oUj);_ac(oSj,oTj);_ac(oPj,oSj);_ac(oTi,oPj);var oVj=_ctn("view");_setAttr(z,oVj,'class',4,e,s,gg);var oWj=_ctn("view");_setAttr(z,oWj,'class',5,e,s,gg);var oXj=_o(z,54,e,s,gg);_ac(oWj,oXj);_ac(oVj,oWj);var oYj=_ctn("view");_setAttr(z,oYj,'class',7,e,s,gg);var oZj=_ctn("view");_setAttr(z,oZj,'class',8,e,s,gg);var oaj=_setAttrs(z,"input",["confirmHold",10,"type",38,"class",45,"placeholder",46],e,s,gg);_ac(oZj,oaj);_ac(oYj,oZj);_ac(oVj,oYj);_ac(oTi,oVj);var obj=_ctn("view");_setAttr(z,obj,'class',4,e,s,gg);var ocj=_ctn("view");_setAttr(z,ocj,'class',57,e,s,gg);var odj=_o(z,58,e,s,gg);_ac(ocj,odj);_ac(obj,ocj);var oej=_ctn("view");_setAttr(z,oej,'class',7,e,s,gg);var ofj=_ctn("view");_setAttr(z,ofj,'class',8,e,s,gg);var ogj=_setAttrs(z,"input",["class",59,"value",1],e,s,gg);ogj.rawAttr={"model:value":"{{modelValue}}"};_ac(ofj,ogj);_ac(oej,ofj);_ac(obj,oej);_ac(oTi,obj);_ac(oOi,oTi);var ohj=_ctn("view");_setAttr(z,ohj,'class',4,e,s,gg);var oij=_ctn("view");_setAttr(z,oij,'class',57,e,s,gg);var ojj=_o(z,61,e,s,gg);_ac(oij,ojj);_ac(ohj,oij);var okj=_ctn("view");_setAttr(z,okj,'class',7,e,s,gg);var olj=_ctn("view");_setAttr(z,olj,'class',8,e,s,gg);var omj=_setAttrs(z,"input",["placeholder",61,"class",1,"type",2],e,s,gg);_ac(olj,omj);_ac(okj,olj);_ac(ohj,okj);_ac(oOi,ohj);var onj=_ctn("view");_setAttr(z,onj,'class',4,e,s,gg);var ooj=_ctn("view");_setAttr(z,ooj,'class',57,e,s,gg);var opj=_o(z,64,e,s,gg);_ac(ooj,opj);_ac(onj,ooj);var oqj=_ctn("view");_setAttr(z,oqj,'class',7,e,s,gg);var orj=_ctn("view");_setAttr(z,orj,'class',8,e,s,gg);var osj=_setAttrs(z,"input",["placeholder",64,"class",1,"type",2],e,s,gg);_ac(orj,osj);_ac(oqj,orj);_ac(onj,oqj);_ac(oOi,onj);var otj=_ctn("view");_setAttr(z,otj,'class',4,e,s,gg);var ouj=_ctn("view");_setAttr(z,ouj,'class',57,e,s,gg);var ovj=_o(z,67,e,s,gg);_ac(ouj,ovj);_ac(otj,ouj);var owj=_ctn("view");_setAttr(z,owj,'class',7,e,s,gg);var oxj=_ctn("view");_setAttr(z,oxj,'class',8,e,s,gg);var oyj=_setAttrs(z,"input",["placeholder",67,"class",1,"type",2],e,s,gg);_ac(oxj,oyj);_ac(owj,oxj);_ac(otj,owj);_ac(oOi,otj);var ozj=_ctn("view");_setAttr(z,ozj,'class',4,e,s,gg);var o_j=_ctn("view");_setAttr(z,o_j,'class',57,e,s,gg);var oAk=_o(z,70,e,s,gg);_ac(o_j,oAk);_ac(ozj,o_j);var oBk=_ctn("view");_setAttr(z,oBk,'class',7,e,s,gg);var oCk=_ctn("view");_setAttr(z,oCk,'class',8,e,s,gg);var oDk=_setAttrs(z,"input",["type",48,"class",23,"confirmType",24,"placeholder",25,"placeholderStyle",26],e,s,gg);_ac(oCk,oDk);_ac(oBk,oCk);_ac(ozj,oBk);_ac(oOi,ozj);var oEk=_ctn("view");_setAttr(z,oEk,'class',4,e,s,gg);var oFk=_ctn("view");_setAttr(z,oFk,'class',57,e,s,gg);var oGk=_o(z,75,e,s,gg);_ac(oFk,oGk);_ac(oEk,oFk);var oHk=_ctn("view");_setAttr(z,oHk,'class',7,e,s,gg);var oIk=_ctn("view");_setAttr(z,oIk,'class',8,e,s,gg);var oJk=_setAttrs(z,"input",["type",48,"class",28,"confirmType",29,"placeholder",30],e,s,gg);_ac(oIk,oJk);_ac(oHk,oIk);_ac(oEk,oHk);_ac(oOi,oEk);var oKk=_ctn("view");_setAttr(z,oKk,'class',4,e,s,gg);var oLk=_ctn("view");_setAttr(z,oLk,'class',57,e,s,gg);var oMk=_o(z,79,e,s,gg);_ac(oLk,oMk);_ac(oKk,oLk);var oNk=_ctn("view");_setAttr(z,oNk,'class',7,e,s,gg);var oOk=_ctn("view");_setAttr(z,oOk,'class',8,e,s,gg);var oPk=_setAttrs(z,"input",["type",48,"placeholderClass",4,"class",32,"confirmType",33,"placeholder",34],e,s,gg);_ac(oOk,oPk);_ac(oNk,oOk);_ac(oKk,oNk);_ac(oOi,oKk);var oQk=_ctn("view");_setAttr(z,oQk,'class',4,e,s,gg);var oRk=_ctn("view");_setAttr(z,oRk,'class',57,e,s,gg);var oSk=_o(z,83,e,s,gg);_ac(oRk,oSk);_ac(oQk,oRk);var oTk=_ctn("view");_setAttr(z,oTk,'class',7,e,s,gg);var oUk=_ctn("view");_setAttr(z,oUk,'class',8,e,s,gg);var oVk=_setAttrs(z,"input",["class",16,"type",32,"placeholderClass",36,"confirmType",68,"placeholder",69],e,s,gg);_ac(oUk,oVk);_ac(oTk,oUk);_ac(oQk,oTk);_ac(oOi,oQk);var oWk=_ctn("view");_setAttr(z,oWk,'class',4,e,s,gg);var oXk=_ctn("view");_setAttr(z,oXk,'class',57,e,s,gg);var oYk=_o(z,86,e,s,gg);_ac(oXk,oYk);_ac(oWk,oXk);var oZk=_ctn("view");_setAttr(z,oZk,'class',7,e,s,gg);var oak=_ctn("view");_setAttr(z,oak,'class',8,e,s,gg);var obk=_setAttrs(z,"input",["confirmType",17,"type",31,"placeholderClass",35,"adjustPosition",70,"class",71,"cursor",72,"placeholder",73],e,s,gg);_ac(oak,obk);_ac(oZk,oak);_ac(oWk,oZk);_ac(oOi,oWk);var ock=_cvn();
    var odk=_o(z,91,e,s,gg);
    var oek=_gd('./macle_demo_EN/page/component/pages/input/input.maml',odk,e_,d_);
    if(oek){
      var ofk={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oek(ofk,ofk,ock,gg);
      gg.f=tgf;
    }else{
      _w(odk,'./macle_demo_EN/page/component/pages/input/input.maml',0,0);
    }
    _ac(oOi,ock);_ac(r,oOi);oLi.pop();oLi.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/input/input.maml"]={f:m58,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/label/label.maml"]={};
  var m59=function(e,s,r,gg){
    var z=gz$gma_60()
    var ogk=e_["./macle_demo_EN/page/component/pages/label/label.maml"].i;_ai(ogk,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/label/label.maml',0,0);_ai(ogk,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/label/label.maml',0,0);var ojk=_ctn("view");_setAttr(z,ojk,'class',0,e,s,gg);var okk=_cvn();
    var olk=_o(z,1,e,s,gg);
    var omk=_gd('./macle_demo_EN/page/component/pages/label/label.maml',olk,e_,d_);
    if(omk){
      var onk=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      omk(onk,onk,okk,gg);
      gg.f=tgf;
    }else{
      _w(olk,'./macle_demo_EN/page/component/pages/label/label.maml',0,0);
    }
    _ac(ojk,okk);var ook=_ctn("view");_setAttr(z,ook,'class',3,e,s,gg);var opk=_ctn("view");_setAttr(z,opk,'class',4,e,s,gg);var oqk=_ctn("view");_setAttr(z,oqk,'class',5,e,s,gg);var ork=_o(z,6,e,s,gg);_ac(oqk,ork);_ac(opk,oqk);var osk=_setAttrs(z,"checkbox-group",["bindchange",7,"class",1,"id",2],e,s,gg);var otk=_cvn();var ouk=function(oyk,oxk,owk,gg){var ovk=_ctn("view");_setAttr(z,ovk,'class',11,oyk,oxk,gg);var o_k=_ctn("label");_setAttr(z,o_k,'id',12,oyk,oxk,gg);var oAl=_setAttrs(z,"checkbox",["checked",13,"id",1,"value",2],oyk,oxk,gg);_ac(o_k,oAl);var oBl=_ctn("text");_setAttr(z,oBl,'class',16,oyk,oxk,gg);var oCl=_o(z,17,oyk,oxk,gg);_ac(oBl,oCl);_ac(o_k,oBl);_ac(ovk,o_k);_ac(owk,ovk);return owk;};_2(z,10,ouk,e,s,gg,otk,"item","index",'');_ac(osk,otk);_ac(opk,osk);_ac(ook,opk);var oDl=_ctn("view");_setAttr(z,oDl,'class',4,e,s,gg);var oEl=_ctn("view");_setAttr(z,oEl,'class',5,e,s,gg);var oFl=_o(z,18,e,s,gg);_ac(oEl,oFl);_ac(oDl,oEl);var oGl=_setAttrs(z,"radio-group",["class",8,"bindchange",11,"id",12],e,s,gg);var oHl=_cvn();var oIl=function(oMl,oLl,oKl,gg){var oJl=_ctn("view");_setAttr(z,oJl,'class',22,oMl,oLl,gg);var oOl=_setAttrs(z,"radio",["checked",13,"id",2,"value",2,"color",10],oMl,oLl,gg);_ac(oJl,oOl);var oPl=_setAttrs(z,"label",["for",15,"class",9],oMl,oLl,gg);var oQl=_ctn("text");_setAttr(z,oQl,'id',25,oMl,oLl,gg);var oRl=_o(z,26,oMl,oLl,gg);_ac(oQl,oRl);_ac(oPl,oQl);_ac(oJl,oPl);_ac(oKl,oJl);return oKl;};_2(z,21,oIl,e,s,gg,oHl,"item","index",'');_ac(oGl,oHl);_ac(oDl,oGl);_ac(ook,oDl);var oSl=_ctn("view");_setAttr(z,oSl,'class',4,e,s,gg);var oTl=_ctn("view");_setAttr(z,oTl,'class',5,e,s,gg);var oUl=_o(z,27,e,s,gg);_ac(oTl,oUl);_ac(oSl,oTl);var oVl=_ctn("label");_setAttr(z,oVl,'class',28,e,s,gg);var oWl=_setAttrs(z,"checkbox",["class",29,"id",1],e,s,gg);var oXl=_o(z,31,e,s,gg);_ac(oWl,oXl);_ac(oVl,oWl);var oYl=_setAttrs(z,"checkbox",["class",29,"id",3],e,s,gg);var oZl=_o(z,31,e,s,gg);_ac(oYl,oZl);_ac(oVl,oYl);var oal=_ctn("view");_setAttr(z,oal,'class',33,e,s,gg);var obl=_o(z,34,e,s,gg);_ac(oal,obl);_ac(oVl,oal);_ac(oSl,oVl);_ac(ook,oSl);_ac(ojk,ook);var ocl=_cvn();
    var odl=_o(z,35,e,s,gg);
    var oel=_gd('./macle_demo_EN/page/component/pages/label/label.maml',odl,e_,d_);
    if(oel){
      var ofl={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oel(ofl,ofl,ocl,gg);
      gg.f=tgf;
    }else{
      _w(odl,'./macle_demo_EN/page/component/pages/label/label.maml',0,0);
    }
    _ac(ojk,ocl);_ac(r,ojk);ogk.pop();ogk.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/label/label.maml"]={f:m59,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/navigator/navigate.maml"]={};
  var m60=function(e,s,r,gg){
    var z=gz$gma_61()
    var ogl=e_["./macle_demo_EN/page/component/pages/navigator/navigate.maml"].i;_ai(ogl,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/navigator/navigate.maml',0,0);_ai(ogl,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/navigator/navigate.maml',0,0);var ojl=_ctn("view");_setAttr(z,ojl,'class',0,e,s,gg);var okl=_cvn();
    var oll=_o(z,1,e,s,gg);
    var oml=_gd('./macle_demo_EN/page/component/pages/navigator/navigate.maml',oll,e_,d_);
    if(oml){
      var onl=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oml(onl,onl,okl,gg);
      gg.f=tgf;
    }else{
      _w(oll,'./macle_demo_EN/page/component/pages/navigator/navigate.maml',0,0);
    }
    _ac(ojl,okl);var ool=_ctn("view");_setAttr(z,ool,'class',3,e,s,gg);var opl=_setAttrs(z,"text",["class",4,"decode",1,"selectable",1,"space",1],e,s,gg);var oql=_o(z,6,e,s,gg);_ac(opl,oql);_ac(ool,opl);var orl=_ctn("view");_setAttr(z,orl,'class',7,e,s,gg);var osl=_setAttrs(z,"navigator",["delta",8,"hoverClass",1,"openType",2],e,s,gg);var otl=_ctn("button");_setAttr(z,otl,'type',11,e,s,gg);var oul=_o(z,12,e,s,gg);_ac(otl,oul);_ac(osl,otl);_ac(orl,osl);_ac(ool,orl);_ac(ojl,ool);var ovl=_cvn();
    var owl=_o(z,13,e,s,gg);
    var oxl=_gd('./macle_demo_EN/page/component/pages/navigator/navigate.maml',owl,e_,d_);
    if(oxl){
      var oyl={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oxl(oyl,oyl,ovl,gg);
      gg.f=tgf;
    }else{
      _w(owl,'./macle_demo_EN/page/component/pages/navigator/navigate.maml',0,0);
    }
    _ac(ojl,ovl);_ac(r,ojl);ogl.pop();ogl.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/navigator/navigate.maml"]={f:m60,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/navigator/navigator.maml"]={};
  var m61=function(e,s,r,gg){
    var z=gz$gma_62()
    var ozl=e_["./macle_demo_EN/page/component/pages/navigator/navigator.maml"].i;_ai(ozl,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/navigator/navigator.maml',0,0);_ai(ozl,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/navigator/navigator.maml',0,0);var oBm=_ctn("view");_setAttr(z,oBm,'class',0,e,s,gg);var oCm=_cvn();
    var oDm=_o(z,1,e,s,gg);
    var oEm=_gd('./macle_demo_EN/page/component/pages/navigator/navigator.maml',oDm,e_,d_);
    if(oEm){
      var oFm=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oEm(oFm,oFm,oCm,gg);
      gg.f=tgf;
    }else{
      _w(oDm,'./macle_demo_EN/page/component/pages/navigator/navigator.maml',0,0);
    }
    _ac(oBm,oCm);var oGm=_ctn("view");_setAttr(z,oGm,'class',3,e,s,gg);var oHm=_ctn("view");_setAttr(z,oHm,'class',4,e,s,gg);var oIm=_setAttrs(z,"navigator",["class",5,"url",1],e,s,gg);var oJm=_ctn("button");_setAttr(z,oJm,'type',7,e,s,gg);var oKm=_o(z,8,e,s,gg);_ac(oJm,oKm);_ac(oIm,oJm);_ac(oHm,oIm);var oLm=_setAttrs(z,"navigator",["class",5,"hoverClass",4,"openType",5,"url",5],e,s,gg);var oMm=_ctn("button");_setAttr(z,oMm,'type',7,e,s,gg);var oNm=_o(z,11,e,s,gg);_ac(oMm,oNm);_ac(oLm,oMm);_ac(oHm,oLm);var oOm=_setAttrs(z,"navigator",["class",5,"hoverClass",7,"openType",8,"url",9],e,s,gg);var oPm=_ctn("button");_setAttr(z,oPm,'type',7,e,s,gg);var oQm=_o(z,13,e,s,gg);_ac(oPm,oQm);_ac(oOm,oPm);_ac(oHm,oOm);var oRm=_setAttrs(z,"navigator",["class",5,"openType",10,"url",10],e,s,gg);var oSm=_ctn("button");_setAttr(z,oSm,'type',7,e,s,gg);var oTm=_o(z,16,e,s,gg);_ac(oSm,oTm);_ac(oRm,oSm);_ac(oHm,oRm);var oUm=_setAttrs(z,"navigator",["class",5,"delta",12,"openType",13],e,s,gg);var oVm=_ctn("button");_setAttr(z,oVm,'type',7,e,s,gg);var oWm=_o(z,19,e,s,gg);_ac(oVm,oWm);_ac(oUm,oVm);_ac(oHm,oUm);_ac(oGm,oHm);_ac(oBm,oGm);var oXm=_cvn();
    var oYm=_o(z,20,e,s,gg);
    var oZm=_gd('./macle_demo_EN/page/component/pages/navigator/navigator.maml',oYm,e_,d_);
    if(oZm){
      var oam={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oZm(oam,oam,oXm,gg);
      gg.f=tgf;
    }else{
      _w(oYm,'./macle_demo_EN/page/component/pages/navigator/navigator.maml',0,0);
    }
    _ac(oBm,oXm);_ac(r,oBm);ozl.pop();ozl.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/navigator/navigator.maml"]={f:m61,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/navigator/redirect.maml"]={};
  var m62=function(e,s,r,gg){
    var z=gz$gma_63()
    var obm=e_["./macle_demo_EN/page/component/pages/navigator/redirect.maml"].i;_ai(obm,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/navigator/redirect.maml',0,0);_ai(obm,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/navigator/redirect.maml',0,0);var oem=_ctn("view");_setAttr(z,oem,'class',0,e,s,gg);var ofm=_cvn();
    var ogm=_o(z,1,e,s,gg);
    var ohm=_gd('./macle_demo_EN/page/component/pages/navigator/redirect.maml',ogm,e_,d_);
    if(ohm){
      var oim=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ohm(oim,oim,ofm,gg);
      gg.f=tgf;
    }else{
      _w(ogm,'./macle_demo_EN/page/component/pages/navigator/redirect.maml',0,0);
    }
    _ac(oem,ofm);var ojm=_ctn("view");_setAttr(z,ojm,'class',3,e,s,gg);var okm=_ctn("view");var olm=_o(z,4,e,s,gg);_ac(okm,olm);_ac(ojm,okm);var omm=_ctn("view");_setAttr(z,omm,'class',5,e,s,gg);var onm=_ctn("navigator");_setAttr(z,onm,'openType',6,e,s,gg);var oom=_ctn("button");_setAttr(z,oom,'type',7,e,s,gg);var opm=_o(z,8,e,s,gg);_ac(oom,opm);_ac(onm,oom);_ac(omm,onm);_ac(ojm,omm);_ac(oem,ojm);var oqm=_cvn();
    var orm=_o(z,9,e,s,gg);
    var osm=_gd('./macle_demo_EN/page/component/pages/navigator/redirect.maml',orm,e_,d_);
    if(osm){
      var otm={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      osm(otm,otm,oqm,gg);
      gg.f=tgf;
    }else{
      _w(orm,'./macle_demo_EN/page/component/pages/navigator/redirect.maml',0,0);
    }
    _ac(oem,oqm);_ac(r,oem);obm.pop();obm.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/navigator/redirect.maml"]={f:m62,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/navigator/reLaunch.maml"]={};
  var m63=function(e,s,r,gg){
    var z=gz$gma_64()
    var oum=e_["./macle_demo_EN/page/component/pages/navigator/reLaunch.maml"].i;_ai(oum,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/navigator/reLaunch.maml',0,0);_ai(oum,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/navigator/reLaunch.maml',0,0);var oxm=_ctn("view");_setAttr(z,oxm,'class',0,e,s,gg);var oym=_cvn();
    var ozm=_o(z,1,e,s,gg);
    var o_m=_gd('./macle_demo_EN/page/component/pages/navigator/reLaunch.maml',ozm,e_,d_);
    if(o_m){
      var oAn=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      o_m(oAn,oAn,oym,gg);
      gg.f=tgf;
    }else{
      _w(ozm,'./macle_demo_EN/page/component/pages/navigator/reLaunch.maml',0,0);
    }
    _ac(oxm,oym);var oBn=_ctn("view");_setAttr(z,oBn,'class',3,e,s,gg);var oCn=_ctn("view");var oDn=_o(z,4,e,s,gg);_ac(oCn,oDn);_ac(oBn,oCn);_ac(oxm,oBn);var oEn=_cvn();
    var oFn=_o(z,5,e,s,gg);
    var oGn=_gd('./macle_demo_EN/page/component/pages/navigator/reLaunch.maml',oFn,e_,d_);
    if(oGn){
      var oHn={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oGn(oHn,oHn,oEn,gg);
      gg.f=tgf;
    }else{
      _w(oFn,'./macle_demo_EN/page/component/pages/navigator/reLaunch.maml',0,0);
    }
    _ac(oxm,oEn);_ac(r,oxm);oum.pop();oum.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/navigator/reLaunch.maml"]={f:m63,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/picker-view/picker-view.maml"]={};
  var m64=function(e,s,r,gg){
    var z=gz$gma_65()
    var oIn=e_["./macle_demo_EN/page/component/pages/picker-view/picker-view.maml"].i;_ai(oIn,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/picker-view/picker-view.maml',0,0);_ai(oIn,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/picker-view/picker-view.maml',0,0);var oLn=_ctn("view");_setAttr(z,oLn,'class',0,e,s,gg);var oMn=_cvn();
    var oNn=_o(z,1,e,s,gg);
    var oOn=_gd('./macle_demo_EN/page/component/pages/picker-view/picker-view.maml',oNn,e_,d_);
    if(oOn){
      var oPn=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oOn(oPn,oPn,oMn,gg);
      gg.f=tgf;
    }else{
      _w(oNn,'./macle_demo_EN/page/component/pages/picker-view/picker-view.maml',0,0);
    }
    _ac(oLn,oMn);var oQn=_ctn("view");_setAttr(z,oQn,'class',3,e,s,gg);var oRn=_ctn("view");_setAttr(z,oRn,'id',4,e,s,gg);var oSn=_o(z,5,e,s,gg);_ac(oRn,oSn);_ac(oQn,oRn);var oTn=_setAttrs(z,"picker-view",["bindchange",6,"bindpickend",1,"bindpickstart",2,"class",3,"indicatorClass",4,"indicatorStyle",5,"maskClass",6,"maskStyle",7,"value",8],e,s,gg);var oUn=_ctn("picker-view-column");var oVn=_cvn();var oWn=function(oan,oZn,oYn,gg){var oXn=_ctn("view");_setAttr(z,oXn,'style',16,oan,oZn,gg);var ocn=_o(z,17,oan,oZn,gg);_ac(oXn,ocn);_ac(oYn,oXn);return oYn;};_2(z,15,oWn,e,s,gg,oVn,"item","index",'');_ac(oUn,oVn);_ac(oTn,oUn);var odn=_ctn("picker-view-column");var oen=_cvn();var ofn=function(ojn,oin,ohn,gg){var ogn=_ctn("view");_setAttr(z,ogn,'style',16,ojn,oin,gg);var oln=_o(z,19,ojn,oin,gg);_ac(ogn,oln);_ac(ohn,ogn);return ohn;};_2(z,18,ofn,e,s,gg,oen,"item","index",'');_ac(odn,oen);_ac(oTn,odn);var omn=_ctn("picker-view-column");var onn=_cvn();var oon=function(osn,orn,oqn,gg){var opn=_ctn("view");_setAttr(z,opn,'style',16,osn,orn,gg);var oun=_o(z,21,osn,orn,gg);_ac(opn,oun);_ac(oqn,opn);return oqn;};_2(z,20,oon,e,s,gg,onn,"item","index",'');_ac(omn,onn);_ac(oTn,omn);_ac(oQn,oTn);var ovn=_ctn("view");_setAttr(z,ovn,'id',8,e,s,gg);var own=_o(z,22,e,s,gg);_ac(ovn,own);_ac(oQn,ovn);var oxn=_ctn("view");_setAttr(z,oxn,'id',7,e,s,gg);var oyn=_o(z,23,e,s,gg);_ac(oxn,oyn);_ac(oQn,oxn);_ac(oLn,oQn);var ozn=_cvn();
    var o_n=_o(z,24,e,s,gg);
    var oAo=_gd('./macle_demo_EN/page/component/pages/picker-view/picker-view.maml',o_n,e_,d_);
    if(oAo){
      var oBo={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oAo(oBo,oBo,ozn,gg);
      gg.f=tgf;
    }else{
      _w(o_n,'./macle_demo_EN/page/component/pages/picker-view/picker-view.maml',0,0);
    }
    _ac(oLn,ozn);_ac(r,oLn);oIn.pop();oIn.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/picker-view/picker-view.maml"]={f:m64,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/picker/picker.maml"]={};
  var m65=function(e,s,r,gg){
    var z=gz$gma_66()
    var oCo=e_["./macle_demo_EN/page/component/pages/picker/picker.maml"].i;_ai(oCo,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/picker/picker.maml',0,0);_ai(oCo,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/picker/picker.maml',0,0);var oFo=_ctn("view");_setAttr(z,oFo,'class',0,e,s,gg);var oGo=_cvn();
    var oHo=_o(z,1,e,s,gg);
    var oIo=_gd('./macle_demo_EN/page/component/pages/picker/picker.maml',oHo,e_,d_);
    if(oIo){
      var oJo=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oIo(oJo,oJo,oGo,gg);
      gg.f=tgf;
    }else{
      _w(oHo,'./macle_demo_EN/page/component/pages/picker/picker.maml',0,0);
    }
    _ac(oFo,oGo);var oKo=_ctn("view");_setAttr(z,oKo,'class',3,e,s,gg);var oLo=_ctn("view");_setAttr(z,oLo,'class',4,e,s,gg);var oMo=_setAttrs(z,"form",["catchreset",5,"catchsubmit",1],e,s,gg);var oNo=_ctn("view");_setAttr(z,oNo,'class',7,e,s,gg);var oOo=_o(z,8,e,s,gg);_ac(oNo,oOo);_ac(oMo,oNo);var oPo=_ctn("view");_setAttr(z,oPo,'class',9,e,s,gg);var oQo=_ctn("view");_setAttr(z,oQo,'class',10,e,s,gg);var oRo=_ctn("view");_setAttr(z,oRo,'class',11,e,s,gg);var oSo=_ctn("view");_setAttr(z,oSo,'class',12,e,s,gg);var oTo=_o(z,13,e,s,gg);_ac(oSo,oTo);_ac(oRo,oSo);_ac(oQo,oRo);var oUo=_ctn("view");_setAttr(z,oUo,'class',14,e,s,gg);var oVo=_setAttrs(z,"picker",["bindcancel",15,"bindchange",1,"headerText",2,"name",3,"range",4,"value",5],e,s,gg);var oWo=_ctn("view");_setAttr(z,oWo,'class',21,e,s,gg);var oXo=_o(z,22,e,s,gg);_ac(oWo,oXo);_ac(oVo,oWo);_ac(oUo,oVo);_ac(oQo,oUo);_ac(oPo,oQo);_ac(oMo,oPo);var oYo=_ctn("view");_setAttr(z,oYo,'class',7,e,s,gg);var oZo=_o(z,23,e,s,gg);_ac(oYo,oZo);_ac(oMo,oYo);var oao=_ctn("view");_setAttr(z,oao,'class',9,e,s,gg);var obo=_ctn("view");_setAttr(z,obo,'class',10,e,s,gg);var oco=_ctn("view");_setAttr(z,oco,'class',11,e,s,gg);var odo=_ctn("view");_setAttr(z,odo,'class',12,e,s,gg);var oeo=_o(z,13,e,s,gg);_ac(odo,oeo);_ac(oco,odo);_ac(obo,oco);var ofo=_ctn("view");_setAttr(z,ofo,'class',14,e,s,gg);var ogo=_setAttrs(z,"picker",["bindchange",16,"range",3,"value",4,"disabled",8,"name",9],e,s,gg);var oho=_ctn("view");_setAttr(z,oho,'class',21,e,s,gg);var oio=_o(z,26,e,s,gg);_ac(oho,oio);_ac(ogo,oho);_ac(ofo,ogo);_ac(obo,ofo);_ac(oao,obo);_ac(oMo,oao);var ojo=_ctn("view");_setAttr(z,ojo,'class',7,e,s,gg);var oko=_o(z,27,e,s,gg);_ac(ojo,oko);_ac(oMo,ojo);var olo=_ctn("view");_setAttr(z,olo,'class',9,e,s,gg);var omo=_ctn("view");_setAttr(z,omo,'class',10,e,s,gg);var ono=_ctn("view");_setAttr(z,ono,'class',11,e,s,gg);var ooo=_ctn("view");_setAttr(z,ooo,'class',12,e,s,gg);var opo=_o(z,13,e,s,gg);_ac(ooo,opo);_ac(ono,ooo);_ac(omo,ono);var oqo=_ctn("view");_setAttr(z,oqo,'class',14,e,s,gg);var oro=_setAttrs(z,"picker",["bindcancel",15,"bindchange",13,"name",14,"range",15,"rangeKey",16,"value",17],e,s,gg);var oso=_ctn("view");_setAttr(z,oso,'class',21,e,s,gg);var oto=_o(z,33,e,s,gg);_ac(oso,oto);_ac(oro,oso);_ac(oqo,oro);_ac(omo,oqo);_ac(olo,omo);_ac(oMo,olo);var ouo=_ctn("view");_setAttr(z,ouo,'class',7,e,s,gg);var ovo=_o(z,34,e,s,gg);_ac(ouo,ovo);_ac(oMo,ouo);var owo=_ctn("view");_setAttr(z,owo,'class',9,e,s,gg);var oxo=_ctn("view");_setAttr(z,oxo,'class',10,e,s,gg);var oyo=_ctn("view");_setAttr(z,oyo,'class',11,e,s,gg);var ozo=_ctn("view");_setAttr(z,ozo,'class',12,e,s,gg);var o_o=_o(z,13,e,s,gg);_ac(ozo,o_o);_ac(oyo,ozo);_ac(oxo,oyo);var oAp=_ctn("view");_setAttr(z,oAp,'class',14,e,s,gg);var oBp=_setAttrs(z,"picker",["bindchange",35,"bindcolumnchange",1,"mode",2,"name",3,"range",4,"value",5],e,s,gg);var oCp=_ctn("view");_setAttr(z,oCp,'class',21,e,s,gg);var oDp=_o(z,41,e,s,gg);_ac(oCp,oDp);_ac(oBp,oCp);_ac(oAp,oBp);_ac(oxo,oAp);_ac(owo,oxo);_ac(oMo,owo);var oEp=_ctn("view");_setAttr(z,oEp,'class',7,e,s,gg);var oFp=_o(z,42,e,s,gg);_ac(oEp,oFp);_ac(oMo,oEp);var oGp=_ctn("view");_setAttr(z,oGp,'class',9,e,s,gg);var oHp=_ctn("view");_setAttr(z,oHp,'class',10,e,s,gg);var oIp=_ctn("view");_setAttr(z,oIp,'class',11,e,s,gg);var oJp=_ctn("view");_setAttr(z,oJp,'class',12,e,s,gg);var oKp=_o(z,13,e,s,gg);_ac(oJp,oKp);_ac(oIp,oJp);_ac(oHp,oIp);var oLp=_ctn("view");_setAttr(z,oLp,'class',14,e,s,gg);var oMp=_setAttrs(z,"picker",["bindcancel",15,"bindchange",28,"end",29,"mode",30,"name",31,"start",32,"value",33],e,s,gg);var oNp=_ctn("view");_setAttr(z,oNp,'class',21,e,s,gg);var oOp=_o(z,49,e,s,gg);_ac(oNp,oOp);_ac(oMp,oNp);_ac(oLp,oMp);_ac(oHp,oLp);_ac(oGp,oHp);_ac(oMo,oGp);var oPp=_ctn("view");_setAttr(z,oPp,'class',7,e,s,gg);var oQp=_o(z,50,e,s,gg);_ac(oPp,oQp);_ac(oMo,oPp);var oRp=_ctn("view");_setAttr(z,oRp,'class',9,e,s,gg);var oSp=_ctn("view");_setAttr(z,oSp,'class',10,e,s,gg);var oTp=_ctn("view");_setAttr(z,oTp,'class',11,e,s,gg);var oUp=_ctn("view");_setAttr(z,oUp,'class',12,e,s,gg);var oVp=_o(z,13,e,s,gg);_ac(oUp,oVp);_ac(oTp,oUp);_ac(oSp,oTp);var oWp=_ctn("view");_setAttr(z,oWp,'class',14,e,s,gg);var oXp=_setAttrs(z,"picker",["bindcancel",15,"bindchange",36,"end",37,"mode",38,"name",39,"start",40,"value",41],e,s,gg);var oYp=_ctn("view");_setAttr(z,oYp,'class',21,e,s,gg);var oZp=_o(z,57,e,s,gg);_ac(oYp,oZp);_ac(oXp,oYp);_ac(oWp,oXp);_ac(oSp,oWp);_ac(oRp,oSp);_ac(oMo,oRp);var oap=_ctn("view");_setAttr(z,oap,'class',7,e,s,gg);var obp=_o(z,58,e,s,gg);_ac(oap,obp);_ac(oMo,oap);var ocp=_ctn("view");_setAttr(z,ocp,'class',9,e,s,gg);var odp=_ctn("view");_setAttr(z,odp,'class',10,e,s,gg);var oep=_ctn("view");_setAttr(z,oep,'class',11,e,s,gg);var ofp=_ctn("view");_setAttr(z,ofp,'class',12,e,s,gg);var ogp=_o(z,13,e,s,gg);_ac(ofp,ogp);_ac(oep,ofp);_ac(odp,oep);var ohp=_ctn("view");_setAttr(z,ohp,'class',14,e,s,gg);var oip=_setAttrs(z,"picker",["bindcancel",15,"mode",38,"bindchange",44,"end",45,"fields",46,"name",47,"start",48,"value",49],e,s,gg);var ojp=_ctn("view");_setAttr(z,ojp,'class',21,e,s,gg);var okp=_o(z,65,e,s,gg);_ac(ojp,okp);_ac(oip,ojp);_ac(ohp,oip);_ac(odp,ohp);_ac(ocp,odp);_ac(oMo,ocp);var olp=_ctn("view");_setAttr(z,olp,'class',7,e,s,gg);var omp=_o(z,66,e,s,gg);_ac(olp,omp);_ac(oMo,olp);var onp=_ctn("view");_setAttr(z,onp,'class',9,e,s,gg);var oop=_ctn("view");_setAttr(z,oop,'class',10,e,s,gg);var opp=_ctn("view");_setAttr(z,opp,'class',11,e,s,gg);var oqp=_ctn("view");_setAttr(z,oqp,'class',12,e,s,gg);var orp=_o(z,13,e,s,gg);_ac(oqp,orp);_ac(opp,oqp);_ac(oop,opp);var osp=_ctn("view");_setAttr(z,osp,'class',14,e,s,gg);var otp=_setAttrs(z,"picker",["bindcancel",15,"bindchange",52,"customItem",53,"mode",54,"name",55,"value",56],e,s,gg);var oup=_ctn("view");_setAttr(z,oup,'class',21,e,s,gg);var ovp=_o(z,72,e,s,gg);_ac(oup,ovp);_ac(otp,oup);_ac(osp,otp);_ac(oop,osp);_ac(onp,oop);_ac(oMo,onp);var owp=_ctn("view");_setAttr(z,owp,'class',73,e,s,gg);var oxp=_setAttrs(z,"button",["formType",6,"type",68],e,s,gg);var oyp=_o(z,75,e,s,gg);_ac(oxp,oyp);_ac(owp,oxp);var ozp=_ctn("button");_setAttr(z,ozp,'formType',5,e,s,gg);var o_p=_o(z,76,e,s,gg);_ac(ozp,o_p);_ac(owp,ozp);_ac(oMo,owp);_ac(oLo,oMo);_ac(oKo,oLo);_ac(oFo,oKo);var oAq=_cvn();
    var oBq=_o(z,77,e,s,gg);
    var oCq=_gd('./macle_demo_EN/page/component/pages/picker/picker.maml',oBq,e_,d_);
    if(oCq){
      var oDq={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oCq(oDq,oDq,oAq,gg);
      gg.f=tgf;
    }else{
      _w(oBq,'./macle_demo_EN/page/component/pages/picker/picker.maml',0,0);
    }
    _ac(oFo,oAq);_ac(r,oFo);oCo.pop();oCo.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/picker/picker.maml"]={f:m65,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/progress/progress.maml"]={};
  var m66=function(e,s,r,gg){
    var z=gz$gma_67()
    var oEq=e_["./macle_demo_EN/page/component/pages/progress/progress.maml"].i;_ai(oEq,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/progress/progress.maml',0,0);_ai(oEq,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/progress/progress.maml',0,0);var oHq=_ctn("view");_setAttr(z,oHq,'class',0,e,s,gg);var oIq=_cvn();
    var oJq=_o(z,1,e,s,gg);
    var oKq=_gd('./macle_demo_EN/page/component/pages/progress/progress.maml',oJq,e_,d_);
    if(oKq){
      var oLq=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oKq(oLq,oLq,oIq,gg);
      gg.f=tgf;
    }else{
      _w(oJq,'./macle_demo_EN/page/component/pages/progress/progress.maml',0,0);
    }
    _ac(oHq,oIq);var oMq=_ctn("view");_setAttr(z,oMq,'class',3,e,s,gg);var oNq=_ctn("view");var oOq=_o(z,4,e,s,gg);_ac(oNq,oOq);_ac(oMq,oNq);var oPq=_ctn("view");_setAttr(z,oPq,'class',5,e,s,gg);var oQq=_setAttrs(z,"progress",["class",6,"fontSize",1,"percent",1,"showInfo",2,"strokeWidth",3],e,s,gg);_ac(oPq,oQq);_ac(oMq,oPq);var oRq=_ctn("view");var oSq=_o(z,10,e,s,gg);_ac(oRq,oSq);_ac(oMq,oRq);var oTq=_ctn("view");_setAttr(z,oTq,'class',11,e,s,gg);var oUq=_setAttrs(z,"progress",["active",8,"showInfo",0,"bindactiveend",4,"class",5,"percent",6,"strokeWidth",7],e,s,gg);_ac(oTq,oUq);_ac(oMq,oTq);var oVq=_ctn("view");var oWq=_o(z,16,e,s,gg);_ac(oVq,oWq);_ac(oMq,oVq);var oXq=_ctn("view");_setAttr(z,oXq,'class',17,e,s,gg);var oYq=_setAttrs(z,"progress",["strokeWidth",7,"active",1,"showInfo",1,"activeColor",11,"backgroundColor",12,"borderRadius",13,"class",14,"percent",15],e,s,gg);_ac(oXq,oYq);_ac(oMq,oXq);var oZq=_ctn("view");var oaq=_o(z,23,e,s,gg);_ac(oZq,oaq);_ac(oMq,oZq);var obq=_ctn("view");_setAttr(z,obq,'class',24,e,s,gg);var ocq=_setAttrs(z,"progress",["active",8,"showInfo",0,"percent",6,"activeMode",17,"class",18,"duration",19],e,s,gg);_ac(obq,ocq);_ac(oMq,obq);var odq=_ctn("view");var oeq=_o(z,28,e,s,gg);_ac(odq,oeq);_ac(oMq,odq);var ofq=_ctn("view");_setAttr(z,ofq,'class',29,e,s,gg);var ogq=_setAttrs(z,"progress",["active",8,"showInfo",0,"percent",6,"duration",19,"activeMode",22,"class",23],e,s,gg);_ac(ofq,ogq);_ac(oMq,ofq);var ohq=_setAttrs(z,"button",["bindtap",32,"class",1],e,s,gg);var oiq=_o(z,34,e,s,gg);_ac(ohq,oiq);_ac(oMq,ohq);var ojq=_ctn("view");var okq=_o(z,35,e,s,gg);_ac(ojq,okq);_ac(oMq,ojq);var olq=_ctn("view");_setAttr(z,olq,'class',36,e,s,gg);var omq=_setAttrs(z,"progress",["fontSize",7,"percent",0,"strokeWidth",2,"active",30,"showInfo",30,"class",31],e,s,gg);_ac(olq,omq);_ac(oMq,olq);var onq=_ctn("view");var ooq=_o(z,39,e,s,gg);_ac(onq,ooq);_ac(oMq,onq);var opq=_ctn("view");_setAttr(z,opq,'class',40,e,s,gg);var oqq=_setAttrs(z,"progress",["percent",7,"strokeWidth",2,"class",34,"fontSize",35,"showInfo",36],e,s,gg);_ac(opq,oqq);_ac(oMq,opq);var orq=_ctn("view");var osq=_o(z,44,e,s,gg);_ac(orq,osq);_ac(oMq,orq);var otq=_ctn("view");_setAttr(z,otq,'class',45,e,s,gg);var ouq=_setAttrs(z,"progress",["fontSize",7,"percent",0,"strokeWidth",2,"class",39],e,s,gg);_ac(otq,ouq);_ac(oMq,otq);var ovq=_ctn("view");var owq=_o(z,47,e,s,gg);_ac(ovq,owq);_ac(oMq,ovq);var oxq=_ctn("view");_setAttr(z,oxq,'class',48,e,s,gg);var oyq=_setAttrs(z,"progress",["percent",7,"showInfo",1,"strokeWidth",2,"fontSize",35,"borderRadius",42,"class",43],e,s,gg);_ac(oxq,oyq);_ac(oMq,oxq);_ac(oHq,oMq);var ozq=_cvn();
    var o_q=_o(z,51,e,s,gg);
    var oAr=_gd('./macle_demo_EN/page/component/pages/progress/progress.maml',o_q,e_,d_);
    if(oAr){
      var oBr={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oAr(oBr,oBr,ozq,gg);
      gg.f=tgf;
    }else{
      _w(o_q,'./macle_demo_EN/page/component/pages/progress/progress.maml',0,0);
    }
    _ac(oHq,ozq);_ac(r,oHq);oEq.pop();oEq.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/progress/progress.maml"]={f:m66,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/radio/radio.maml"]={};
  var m67=function(e,s,r,gg){
    var z=gz$gma_68()
    var oCr=e_["./macle_demo_EN/page/component/pages/radio/radio.maml"].i;_ai(oCr,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/radio/radio.maml',0,0);_ai(oCr,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/radio/radio.maml',0,0);var oFr=_ctn("view");_setAttr(z,oFr,'class',0,e,s,gg);var oGr=_cvn();
    var oHr=_o(z,1,e,s,gg);
    var oIr=_gd('./macle_demo_EN/page/component/pages/radio/radio.maml',oHr,e_,d_);
    if(oIr){
      var oJr=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oIr(oJr,oJr,oGr,gg);
      gg.f=tgf;
    }else{
      _w(oHr,'./macle_demo_EN/page/component/pages/radio/radio.maml',0,0);
    }
    _ac(oFr,oGr);var oKr=_ctn("view");_setAttr(z,oKr,'class',3,e,s,gg);var oLr=_ctn("view");_setAttr(z,oLr,'class',4,e,s,gg);var oMr=_ctn("view");_setAttr(z,oMr,'class',5,e,s,gg);var oNr=_o(z,6,e,s,gg);_ac(oMr,oNr);_ac(oLr,oMr);var oOr=_ctn("label");_setAttr(z,oOr,'class',7,e,s,gg);var oPr=_setAttrs(z,"radio",["checked",8,"class",1,"value",2],e,s,gg);_ac(oOr,oPr);var oQr=_o(z,11,e,s,gg);_ac(oOr,oQr);_ac(oLr,oOr);var oRr=_ctn("label");_setAttr(z,oRr,'class',7,e,s,gg);var oSr=_setAttrs(z,"radio",["class",12,"value",1],e,s,gg);_ac(oRr,oSr);var oTr=_o(z,14,e,s,gg);_ac(oRr,oTr);_ac(oLr,oRr);var oUr=_ctn("label");_setAttr(z,oUr,'class',7,e,s,gg);var oVr=_setAttrs(z,"radio",["disabled",8,"class",7,"value",8],e,s,gg);_ac(oUr,oVr);var oWr=_o(z,17,e,s,gg);_ac(oUr,oWr);_ac(oLr,oUr);var oXr=_ctn("label");_setAttr(z,oXr,'class',7,e,s,gg);var oYr=_setAttrs(z,"radio",["checked",18,"class",1,"color",2,"disabled",3,"value",4],e,s,gg);_ac(oXr,oYr);var oZr=_o(z,23,e,s,gg);_ac(oXr,oZr);_ac(oLr,oXr);_ac(oKr,oLr);var oar=_ctn("view");_setAttr(z,oar,'class',24,e,s,gg);var obr=_ctn("view");_setAttr(z,obr,'class',5,e,s,gg);var ocr=_o(z,25,e,s,gg);_ac(obr,ocr);_ac(oar,obr);var odr=_ctn("view");_setAttr(z,odr,'class',26,e,s,gg);var oer=_ctn("radio-group");_setAttr(z,oer,'bindchange',27,e,s,gg);var ofr=_cvn();var ogr=function(okr,ojr,oir,gg){var ohr=_ctn("label");_setAttr(z,ohr,'class',30,okr,ojr,gg);var omr=_ctn("view");_setAttr(z,omr,'class',31,okr,ojr,gg);var onr=_setAttrs(z,"radio",["value",29,"checked",3,"class",4,"color",5],okr,ojr,gg);_ac(omr,onr);_ac(ohr,omr);var oor=_ctn("view");_setAttr(z,oor,'class',35,okr,ojr,gg);var opr=_o(z,36,okr,ojr,gg);_ac(oor,opr);_ac(ohr,oor);_ac(oir,ohr);return oir;};_2(z,28,ogr,e,s,gg,ofr,"item","index",'{{item.value}}');_ac(oer,ofr);_ac(odr,oer);_ac(oar,odr);_ac(oKr,oar);_ac(oFr,oKr);var oqr=_cvn();
    var orr=_o(z,37,e,s,gg);
    var osr=_gd('./macle_demo_EN/page/component/pages/radio/radio.maml',orr,e_,d_);
    if(osr){
      var otr={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      osr(otr,otr,oqr,gg);
      gg.f=tgf;
    }else{
      _w(orr,'./macle_demo_EN/page/component/pages/radio/radio.maml',0,0);
    }
    _ac(oFr,oqr);_ac(r,oFr);oCr.pop();oCr.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/radio/radio.maml"]={f:m67,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/rich-text/rich-text.maml"]={};
  var m68=function(e,s,r,gg){
    var z=gz$gma_69()
    var our=e_["./macle_demo_EN/page/component/pages/rich-text/rich-text.maml"].i;_ai(our,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/rich-text/rich-text.maml',0,0);_ai(our,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/rich-text/rich-text.maml',0,0);var oxr=_ctn("view");_setAttr(z,oxr,'class',0,e,s,gg);var oyr=_cvn();
    var ozr=_o(z,1,e,s,gg);
    var o_r=_gd('./macle_demo_EN/page/component/pages/rich-text/rich-text.maml',ozr,e_,d_);
    if(o_r){
      var oAs=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      o_r(oAs,oAs,oyr,gg);
      gg.f=tgf;
    }else{
      _w(ozr,'./macle_demo_EN/page/component/pages/rich-text/rich-text.maml',0,0);
    }
    _ac(oxr,oyr);var oBs=_ctn("view");_setAttr(z,oBs,'class',3,e,s,gg);var oCs=_ctn("view");_setAttr(z,oCs,'class',4,e,s,gg);var oDs=_ctn("view");_setAttr(z,oDs,'class',5,e,s,gg);var oEs=_o(z,6,e,s,gg);_ac(oDs,oEs);_ac(oCs,oDs);var oFs=_ctn("view");_setAttr(z,oFs,'class',7,e,s,gg);var oGs=_setAttrs(z,"rich-text",["class",8,"nodes",1,"space",2],e,s,gg);_ac(oFs,oGs);_ac(oCs,oFs);_ac(oBs,oCs);var oHs=_ctn("view");_setAttr(z,oHs,'class',4,e,s,gg);var oIs=_ctn("view");_setAttr(z,oIs,'class',5,e,s,gg);var oJs=_o(z,11,e,s,gg);_ac(oIs,oJs);_ac(oHs,oIs);var oKs=_ctn("view");_setAttr(z,oKs,'class',7,e,s,gg);var oLs=_setAttrs(z,"rich-text",["space",10,"nodes",2],e,s,gg);_ac(oKs,oLs);_ac(oHs,oKs);_ac(oBs,oHs);var oMs=_ctn("view");_setAttr(z,oMs,'class',4,e,s,gg);var oNs=_ctn("view");_setAttr(z,oNs,'class',5,e,s,gg);var oOs=_o(z,13,e,s,gg);_ac(oNs,oOs);_ac(oMs,oNs);var oPs=_ctn("view");_setAttr(z,oPs,'class',7,e,s,gg);var oQs=_ctn("rich-text");_setAttr(z,oQs,'nodes',14,e,s,gg);_ac(oPs,oQs);_ac(oMs,oPs);_ac(oBs,oMs);var oRs=_ctn("view");_setAttr(z,oRs,'class',4,e,s,gg);var oSs=_ctn("view");_setAttr(z,oSs,'class',5,e,s,gg);var oTs=_o(z,15,e,s,gg);_ac(oSs,oTs);_ac(oRs,oSs);var oUs=_ctn("view");_setAttr(z,oUs,'class',7,e,s,gg);var oVs=_ctn("rich-text");_setAttr(z,oVs,'nodes',16,e,s,gg);_ac(oUs,oVs);_ac(oRs,oUs);_ac(oBs,oRs);_ac(oxr,oBs);var oWs=_cvn();
    var oXs=_o(z,17,e,s,gg);
    var oYs=_gd('./macle_demo_EN/page/component/pages/rich-text/rich-text.maml',oXs,e_,d_);
    if(oYs){
      var oZs={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oYs(oZs,oZs,oWs,gg);
      gg.f=tgf;
    }else{
      _w(oXs,'./macle_demo_EN/page/component/pages/rich-text/rich-text.maml',0,0);
    }
    _ac(oxr,oWs);_ac(r,oxr);our.pop();our.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/rich-text/rich-text.maml"]={f:m68,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml"]={};
  var m69=function(e,s,r,gg){
    var z=gz$gma_70()
    var oas=e_["./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml"].i;_ai(oas,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml',0,0);_ai(oas,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml',0,0);var ods=_ctn("view");_setAttr(z,ods,'class',0,e,s,gg);var oes=_cvn();
    var ofs=_o(z,1,e,s,gg);
    var ogs=_gd('./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml',ofs,e_,d_);
    if(ogs){
      var ohs=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ogs(ohs,ohs,oes,gg);
      gg.f=tgf;
    }else{
      _w(ofs,'./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml',0,0);
    }
    _ac(ods,oes);var ois=_ctn("view");_setAttr(z,ois,'class',3,e,s,gg);var ojs=_ctn("view");_setAttr(z,ojs,'class',4,e,s,gg);var oks=_ctn("view");_setAttr(z,oks,'class',5,e,s,gg);var ols=_ctn("text");var oms=_o(z,6,e,s,gg);_ac(ols,oms);_ac(oks,ols);_ac(ojs,oks);var ons=_ctn("view");_setAttr(z,ons,'class',7,e,s,gg);var oos=_setAttrs(z,"scroll-view",["binddragend",8,"binddragging",1,"binddragstart",2,"bindscroll",3,"bindscrolltolower",4,"bindscrolltoupper",5,"class",6,"enhanced",7,"scrollY",7,"scrollWithAnimation",7,"showScrollbar",7,"lowerThreshold",8,"upperThreshold",8,"scrollIntoView",9,"scrollTop",10,"style",11],e,s,gg);var ops=_cvn();var oqs=function(ous,ots,oss,gg){var ows=_setAttrs(z,"view",["style",19,"class",5,"id",6],ous,ots,gg);_ac(oss,ows);return oss;};_2(z,20,oqs,e,s,gg,ops,"item","index",'{{item}}');_ac(oos,ops);_ac(ons,oos);_ac(ojs,ons);var oxs=_ctn("view");_setAttr(z,oxs,'class',26,e,s,gg);var oys=_cvn();var ozs=function(oCt,oBt,oAt,gg){var oEt=_setAttrs(z,"button",["bindtap",27,"data-index",1,"size",2,"type",3],oCt,oBt,gg);var oFt=_o(z,31,oCt,oBt,gg);_ac(oEt,oFt);_ac(oAt,oEt);return oAt;};_2(z,20,ozs,e,s,gg,oys,"item","index",'{{item}}');_ac(oxs,oys);var oGt=_setAttrs(z,"button",["data-scroll-top",16,"size",13,"type",14,"bindtap",16,"id",17],e,s,gg);var oHt=_o(z,34,e,s,gg);_ac(oGt,oHt);_ac(oxs,oGt);_ac(ojs,oxs);var oIt=_ctn("view");_setAttr(z,oIt,'class',26,e,s,gg);var oJt=_setAttrs(z,"button",["size",29,"type",1,"bindtap",3,"data-scroll-top",6,"id",7],e,s,gg);var oKt=_o(z,37,e,s,gg);_ac(oJt,oKt);_ac(oIt,oJt);var oLt=_setAttrs(z,"button",["size",29,"type",1,"bindtap",3,"data-scroll-top",9,"id",10],e,s,gg);var oMt=_o(z,40,e,s,gg);_ac(oLt,oMt);_ac(oIt,oLt);var oNt=_setAttrs(z,"button",["data-reverse",15,"size",14,"type",15,"bindtap",17,"data-scroll-top",20,"id",26],e,s,gg);var oOt=_o(z,42,e,s,gg);_ac(oNt,oOt);_ac(oIt,oNt);var oPt=_setAttrs(z,"button",["data-reverse",15,"size",14,"type",15,"bindtap",17,"data-scroll-top",23,"id",28],e,s,gg);var oQt=_o(z,44,e,s,gg);_ac(oPt,oQt);_ac(oIt,oPt);_ac(ojs,oIt);_ac(ois,ojs);var oRt=_ctn("view");_setAttr(z,oRt,'id',45,e,s,gg);var oSt=_o(z,46,e,s,gg);_ac(oRt,oSt);_ac(ois,oRt);var oTt=_ctn("view");_setAttr(z,oTt,'id',47,e,s,gg);var oUt=_o(z,48,e,s,gg);_ac(oTt,oUt);_ac(ois,oTt);var oVt=_ctn("view");_setAttr(z,oVt,'id',49,e,s,gg);var oWt=_o(z,50,e,s,gg);_ac(oVt,oWt);_ac(ois,oVt);var oXt=_ctn("view");_setAttr(z,oXt,'id',51,e,s,gg);var oYt=_o(z,52,e,s,gg);_ac(oXt,oYt);_ac(ois,oXt);var oZt=_ctn("view");_setAttr(z,oZt,'id',53,e,s,gg);var oat=_o(z,54,e,s,gg);_ac(oZt,oat);_ac(ois,oZt);var obt=_ctn("view");_setAttr(z,obt,'id',55,e,s,gg);var oct=_o(z,56,e,s,gg);_ac(obt,oct);_ac(ois,obt);var odt=_ctn("view");_setAttr(z,odt,'class',4,e,s,gg);var oet=_ctn("view");_setAttr(z,oet,'class',5,e,s,gg);var oft=_ctn("text");var ogt=_o(z,57,e,s,gg);_ac(oft,ogt);_ac(oet,oft);_ac(odt,oet);var oht=_ctn("view");_setAttr(z,oht,'class',7,e,s,gg);var oit=_setAttrs(z,"scroll-view",["bindscroll",11,"bindscrolltolower",1,"bindscrolltoupper",2,"enhanced",4,"scrollX",4,"scrollWithAnimation",4,"showScrollbar",4,"class",47,"scrollLeft",48,"style",49],e,s,gg);var ojt=_cvn();var okt=function(oot,ont,omt,gg){var oqt=_setAttrs(z,"view",["class",61,"id",1],oot,ont,gg);_ac(omt,oqt);return omt;};_2(z,20,okt,e,s,gg,ojt,"item","index",'{{item}}');_ac(oit,ojt);_ac(oht,oit);_ac(odt,oht);var ort=_ctn("view");_setAttr(z,ort,'class',63,e,s,gg);var ost=_ctn("text");var ott=_o(z,64,e,s,gg);_ac(ost,ott);_ac(ort,ost);_ac(odt,ort);var out=_ctn("view");_setAttr(z,out,'class',26,e,s,gg);var ovt=_setAttrs(z,"button",["size",29,"type",1,"bindtap",36,"id",37],e,s,gg);var owt=_o(z,67,e,s,gg);_ac(ovt,owt);_ac(out,ovt);var oxt=_setAttrs(z,"button",["size",29,"type",1,"bindtap",39,"id",40],e,s,gg);var oyt=_o(z,34,e,s,gg);_ac(oxt,oyt);_ac(out,oxt);_ac(odt,out);_ac(ois,odt);_ac(ods,ois);var ozt=_cvn();
    var o_t=_o(z,70,e,s,gg);
    var oAu=_gd('./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml',o_t,e_,d_);
    if(oAu){
      var oBu={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oAu(oBu,oBu,ozt,gg);
      gg.f=tgf;
    }else{
      _w(o_t,'./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml',0,0);
    }
    _ac(ods,ozt);_ac(r,ods);oas.pop();oas.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml"]={f:m69,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/slider/slider.maml"]={};
  var m70=function(e,s,r,gg){
    var z=gz$gma_71()
    var oCu=e_["./macle_demo_EN/page/component/pages/slider/slider.maml"].i;_ai(oCu,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/slider/slider.maml',0,0);_ai(oCu,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/slider/slider.maml',0,0);var oFu=_ctn("view");_setAttr(z,oFu,'class',0,e,s,gg);var oGu=_cvn();
    var oHu=_o(z,1,e,s,gg);
    var oIu=_gd('./macle_demo_EN/page/component/pages/slider/slider.maml',oHu,e_,d_);
    if(oIu){
      var oJu=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oIu(oJu,oJu,oGu,gg);
      gg.f=tgf;
    }else{
      _w(oHu,'./macle_demo_EN/page/component/pages/slider/slider.maml',0,0);
    }
    _ac(oFu,oGu);var oKu=_ctn("view");_setAttr(z,oKu,'id',3,e,s,gg);var oLu=_o(z,4,e,s,gg);_ac(oKu,oLu);_ac(oFu,oKu);var oMu=_setAttrs(z,"view",["class",0,"id",5],e,s,gg);var oNu=_ctn("text");var oOu=_o(z,6,e,s,gg);_ac(oNu,oOu);_ac(oMu,oNu);_ac(oFu,oMu);var oPu=_setAttrs(z,"view",["class",0,"id",7],e,s,gg);var oQu=_ctn("text");var oRu=_o(z,8,e,s,gg);_ac(oQu,oRu);_ac(oPu,oQu);_ac(oFu,oPu);var oSu=_ctn("view");_setAttr(z,oSu,'class',9,e,s,gg);var oTu=_ctn("view");_setAttr(z,oTu,'class',10,e,s,gg);var oUu=_ctn("view");_setAttr(z,oUu,'class',11,e,s,gg);var oVu=_o(z,12,e,s,gg);_ac(oUu,oVu);_ac(oTu,oUu);var oWu=_ctn("view");_setAttr(z,oWu,'class',13,e,s,gg);var oXu=_setAttrs(z,"slider",["activeColor",14,"backgroundColor",1,"bindchange",2,"bindchanging",3,"blockColor",4,"blockSize",5,"id",6,"showValue",7],e,s,gg);_ac(oWu,oXu);_ac(oTu,oWu);var oYu=_cvn();if(_o(z,22,e,s,gg)){oYu.maVkey=1;var oZu=_ctn("view");_setAttr(z,oZu,'class',23,e,s,gg);var obu=_o(z,24,e,s,gg);_ac(oZu,obu);_ac(oYu,oZu);} _ac(oTu,oYu);var ocu=_cvn();if(_o(z,25,e,s,gg)){ocu.maVkey=1;var odu=_ctn("view");_setAttr(z,odu,'class',26,e,s,gg);var ofu=_o(z,27,e,s,gg);_ac(odu,ofu);_ac(ocu,odu);} _ac(oTu,ocu);_ac(oSu,oTu);var ogu=_ctn("view");_setAttr(z,ogu,'class',10,e,s,gg);var ohu=_ctn("view");_setAttr(z,ohu,'class',11,e,s,gg);var oiu=_o(z,28,e,s,gg);_ac(ohu,oiu);_ac(ogu,ohu);var oju=_ctn("view");_setAttr(z,oju,'class',13,e,s,gg);var oku=_setAttrs(z,"slider",["showValue",21,"bindchange",8,"bindchanging",9,"id",10,"step",11,"value",12],e,s,gg);_ac(oju,oku);_ac(ogu,oju);_ac(oSu,ogu);var olu=_ctn("view");_setAttr(z,olu,'class',10,e,s,gg);var omu=_ctn("view");_setAttr(z,omu,'class',11,e,s,gg);var onu=_o(z,34,e,s,gg);_ac(omu,onu);_ac(olu,omu);var oou=_ctn("view");_setAttr(z,oou,'class',13,e,s,gg);var opu=_setAttrs(z,"slider",["step",32,"min",1,"bindchange",3,"id",4,"max",5,"value",6],e,s,gg);_ac(oou,opu);_ac(olu,oou);_ac(oSu,olu);var oqu=_ctn("view");_setAttr(z,oqu,'class',10,e,s,gg);var oru=_ctn("view");_setAttr(z,oru,'class',11,e,s,gg);var osu=_o(z,39,e,s,gg);_ac(oru,osu);_ac(oqu,oru);var otu=_ctn("view");_setAttr(z,otu,'class',13,e,s,gg);var ouu=_setAttrs(z,"slider",["value",38,"bindchange",2,"blockSize",3,"id",4,"min",5,"showValue",5,"step",6],e,s,gg);_ac(otu,ouu);_ac(oqu,otu);_ac(oSu,oqu);var ovu=_ctn("view");_setAttr(z,ovu,'class',10,e,s,gg);var owu=_ctn("view");_setAttr(z,owu,'class',11,e,s,gg);var oxu=_o(z,45,e,s,gg);_ac(owu,oxu);_ac(ovu,owu);var oyu=_ctn("view");_setAttr(z,oyu,'class',13,e,s,gg);var ozu=_setAttrs(z,"slider",["showValue",21,"step",11,"value",17,"max",22,"bindchange",25,"blockSize",26,"id",27],e,s,gg);_ac(oyu,ozu);_ac(ovu,oyu);_ac(oSu,ovu);var o_u=_ctn("view");_setAttr(z,o_u,'class',10,e,s,gg);var oAv=_ctn("view");_setAttr(z,oAv,'class',11,e,s,gg);var oBv=_o(z,49,e,s,gg);_ac(oAv,oBv);_ac(o_u,oAv);var oCv=_ctn("view");_setAttr(z,oCv,'class',13,e,s,gg);var oDv=_setAttrs(z,"slider",["disabled",21,"showValue",0,"step",11,"value",17,"bindchange",29,"id",30],e,s,gg);_ac(oCv,oDv);_ac(o_u,oCv);_ac(oSu,o_u);_ac(oFu,oSu);var oEv=_cvn();
    var oFv=_o(z,52,e,s,gg);
    var oGv=_gd('./macle_demo_EN/page/component/pages/slider/slider.maml',oFv,e_,d_);
    if(oGv){
      var oHv={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oGv(oHv,oHv,oEv,gg);
      gg.f=tgf;
    }else{
      _w(oFv,'./macle_demo_EN/page/component/pages/slider/slider.maml',0,0);
    }
    _ac(oFu,oEv);_ac(r,oFu);oCu.pop();oCu.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/slider/slider.maml"]={f:m70,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/swiper/swiper.maml"]={};
  var m71=function(e,s,r,gg){
    var z=gz$gma_72()
    var oIv=e_["./macle_demo_EN/page/component/pages/swiper/swiper.maml"].i;_ai(oIv,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/swiper/swiper.maml',0,0);_ai(oIv,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/swiper/swiper.maml',0,0);var oLv=_ctn("view");_setAttr(z,oLv,'class',0,e,s,gg);var oMv=_cvn();
    var oNv=_o(z,1,e,s,gg);
    var oOv=_gd('./macle_demo_EN/page/component/pages/swiper/swiper.maml',oNv,e_,d_);
    if(oOv){
      var oPv=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oOv(oPv,oPv,oMv,gg);
      gg.f=tgf;
    }else{
      _w(oNv,'./macle_demo_EN/page/component/pages/swiper/swiper.maml',0,0);
    }
    _ac(oLv,oMv);var oQv=_ctn("view");_setAttr(z,oQv,'class',3,e,s,gg);var oRv=_ctn("view");_setAttr(z,oRv,'class',4,e,s,gg);var oSv=_setAttrs(z,"swiper",["autoplay",5,"circular",1,"duration",2,"easingFunction",3,"indicatorActiveColor",4,"indicatorColor",5,"indicatorDots",6,"interval",7,"vertical",8],e,s,gg);var oTv=_cvn();var oUv=function(oYv,oXv,oWv,gg){var oav=_ctn("swiper-item");var obv=_ctn("view");_setAttr(z,obv,'class',16,oYv,oXv,gg);_ac(oav,obv);_ac(oWv,oav);return oWv;};_2(z,14,oUv,e,s,gg,oTv,"item","index",'*this');_ac(oSv,oTv);_ac(oRv,oSv);_ac(oQv,oRv);var ocv=_setAttrs(z,"view",["class",17,"style",1],e,s,gg);var odv=_ctn("view");_setAttr(z,odv,'class',19,e,s,gg);var oev=_ctn("view");_setAttr(z,oev,'class',20,e,s,gg);var ofv=_ctn("view");_setAttr(z,ofv,'class',21,e,s,gg);var ogv=_o(z,22,e,s,gg);_ac(ofv,ogv);_ac(oev,ofv);var ohv=_ctn("view");_setAttr(z,ohv,'class',23,e,s,gg);var oiv=_setAttrs(z,"switch",["checked",11,"bindchange",13],e,s,gg);_ac(ohv,oiv);_ac(oev,ohv);_ac(odv,oev);var ojv=_ctn("view");_setAttr(z,ojv,'class',20,e,s,gg);var okv=_ctn("view");_setAttr(z,okv,'class',21,e,s,gg);var olv=_o(z,25,e,s,gg);_ac(okv,olv);_ac(ojv,okv);var omv=_ctn("view");_setAttr(z,omv,'class',26,e,s,gg);var onv=_setAttrs(z,"switch",["checked",5,"bindchange",22],e,s,gg);_ac(omv,onv);_ac(ojv,omv);_ac(odv,ojv);_ac(ocv,odv);_ac(oQv,ocv);var oov=_ctn("view");_setAttr(z,oov,'class',28,e,s,gg);var opv=_ctn("view");_setAttr(z,opv,'class',29,e,s,gg);var oqv=_ctn("text");var orv=_o(z,30,e,s,gg);_ac(oqv,orv);_ac(opv,oqv);var osv=_ctn("text");_setAttr(z,osv,'class',31,e,s,gg);var otv=_o(z,32,e,s,gg);_ac(osv,otv);_ac(opv,osv);_ac(oov,opv);var ouv=_setAttrs(z,"slider",["value",7,"bindchange",26,"class",27,"max",28,"min",29],e,s,gg);_ac(oov,ouv);var ovv=_ctn("view");_setAttr(z,ovv,'class',29,e,s,gg);var owv=_ctn("text");var oxv=_o(z,37,e,s,gg);_ac(owv,oxv);_ac(ovv,owv);var oyv=_ctn("text");_setAttr(z,oyv,'class',31,e,s,gg);var ozv=_o(z,38,e,s,gg);_ac(oyv,ozv);_ac(ovv,oyv);_ac(oov,ovv);var o_v=_setAttrs(z,"slider",["value",12,"min",23,"bindchange",27,"class",28,"max",29],e,s,gg);_ac(oov,o_v);_ac(oQv,oov);_ac(oLv,oQv);var oAw=_cvn();
    var oBw=_o(z,42,e,s,gg);
    var oCw=_gd('./macle_demo_EN/page/component/pages/swiper/swiper.maml',oBw,e_,d_);
    if(oCw){
      var oDw={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oCw(oDw,oDw,oAw,gg);
      gg.f=tgf;
    }else{
      _w(oBw,'./macle_demo_EN/page/component/pages/swiper/swiper.maml',0,0);
    }
    _ac(oLv,oAw);_ac(r,oLv);oIv.pop();oIv.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/swiper/swiper.maml"]={f:m71,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/switch/switch.maml"]={};
  var m72=function(e,s,r,gg){
    var z=gz$gma_73()
    var oEw=e_["./macle_demo_EN/page/component/pages/switch/switch.maml"].i;_ai(oEw,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/switch/switch.maml',0,0);_ai(oEw,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/switch/switch.maml',0,0);var oHw=_ctn("view");_setAttr(z,oHw,'class',0,e,s,gg);var oIw=_cvn();
    var oJw=_o(z,1,e,s,gg);
    var oKw=_gd('./macle_demo_EN/page/component/pages/switch/switch.maml',oJw,e_,d_);
    if(oKw){
      var oLw=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oKw(oLw,oLw,oIw,gg);
      gg.f=tgf;
    }else{
      _w(oJw,'./macle_demo_EN/page/component/pages/switch/switch.maml',0,0);
    }
    _ac(oHw,oIw);var oMw=_ctn("view");_setAttr(z,oMw,'class',3,e,s,gg);var oNw=_ctn("view");_setAttr(z,oNw,'class',4,e,s,gg);var oOw=_ctn("view");_setAttr(z,oOw,'class',5,e,s,gg);var oPw=_o(z,6,e,s,gg);_ac(oOw,oPw);_ac(oNw,oOw);var oQw=_ctn("view");_setAttr(z,oQw,'class',7,e,s,gg);var oRw=_setAttrs(z,"switch",["bindchange",8,"id",1],e,s,gg);_ac(oQw,oRw);_ac(oNw,oQw);var oSw=_cvn();if(_o(z,10,e,s,gg)){oSw.maVkey=1;var oTw=_ctn("view");_setAttr(z,oTw,'class',11,e,s,gg);var oVw=_o(z,12,e,s,gg);_ac(oTw,oVw);_ac(oSw,oTw);} _ac(oNw,oSw);_ac(oMw,oNw);var oWw=_ctn("view");_setAttr(z,oWw,'class',4,e,s,gg);var oXw=_ctn("view");_setAttr(z,oXw,'class',5,e,s,gg);var oYw=_o(z,13,e,s,gg);_ac(oXw,oYw);_ac(oWw,oXw);var oZw=_ctn("view");_setAttr(z,oZw,'class',7,e,s,gg);var oaw=_setAttrs(z,"switch",["bindchange",14,"checked",1,"id",2,"type",3],e,s,gg);_ac(oZw,oaw);_ac(oWw,oZw);_ac(oMw,oWw);var obw=_ctn("view");_setAttr(z,obw,'class',4,e,s,gg);var ocw=_ctn("view");_setAttr(z,ocw,'class',5,e,s,gg);var odw=_o(z,18,e,s,gg);_ac(ocw,odw);_ac(obw,ocw);var oew=_ctn("view");_setAttr(z,oew,'class',7,e,s,gg);var ofw=_setAttrs(z,"switch",["checked",15,"color",4,"id",5],e,s,gg);_ac(oew,ofw);var ogw=_setAttrs(z,"switch",["checked",15,"type",2,"color",4,"id",6],e,s,gg);_ac(oew,ogw);_ac(obw,oew);_ac(oMw,obw);var ohw=_ctn("view");_setAttr(z,ohw,'class',4,e,s,gg);var oiw=_ctn("view");_setAttr(z,oiw,'class',5,e,s,gg);var ojw=_o(z,22,e,s,gg);_ac(oiw,ojw);_ac(ohw,oiw);var okw=_ctn("view");_setAttr(z,okw,'class',7,e,s,gg);var olw=_setAttrs(z,"switch",["checked",15,"disabled",0,"id",8],e,s,gg);_ac(okw,olw);var omw=_setAttrs(z,"switch",["checked",15,"disabled",0,"type",2,"id",9],e,s,gg);_ac(okw,omw);_ac(ohw,okw);_ac(oMw,ohw);_ac(oHw,oMw);var onw=_cvn();
    var oow=_o(z,25,e,s,gg);
    var opw=_gd('./macle_demo_EN/page/component/pages/switch/switch.maml',oow,e_,d_);
    if(opw){
      var oqw={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      opw(oqw,oqw,onw,gg);
      gg.f=tgf;
    }else{
      _w(oow,'./macle_demo_EN/page/component/pages/switch/switch.maml',0,0);
    }
    _ac(oHw,onw);_ac(r,oHw);oEw.pop();oEw.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/switch/switch.maml"]={f:m72,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/text/text.maml"]={};
  var m73=function(e,s,r,gg){
    var z=gz$gma_74()
    var orw=e_["./macle_demo_EN/page/component/pages/text/text.maml"].i;_ai(orw,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/text/text.maml',0,0);_ai(orw,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/text/text.maml',0,0);var ouw=_ctn("view");_setAttr(z,ouw,'class',0,e,s,gg);var ovw=_cvn();
    var oww=_o(z,1,e,s,gg);
    var oxw=_gd('./macle_demo_EN/page/component/pages/text/text.maml',oww,e_,d_);
    if(oxw){
      var oyw=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oxw(oyw,oyw,ovw,gg);
      gg.f=tgf;
    }else{
      _w(oww,'./macle_demo_EN/page/component/pages/text/text.maml',0,0);
    }
    _ac(ouw,ovw);var ozw=_ctn("view");_setAttr(z,ozw,'class',3,e,s,gg);var o_w=_ctn("view");_setAttr(z,o_w,'class',4,e,s,gg);var oAx=_setAttrs(z,"view",["class",5,"scrollTop",1,"scrollY",2],e,s,gg);var oBx=_setAttrs(z,"text",["class",8,"decode",1,"space",2,"userSelect",3],e,s,gg);var oCx=_o(z,12,e,s,gg);_ac(oBx,oCx);_ac(oAx,oBx);_ac(o_w,oAx);var oDx=_ctn("view");var oEx=_setAttrs(z,"text",["userSelect",7,"class",6,"space",7],e,s,gg);var oFx=_o(z,15,e,s,gg);_ac(oEx,oFx);_ac(oDx,oEx);_ac(o_w,oDx);var oGx=_ctn("view");var oHx=_setAttrs(z,"text",["class",16,"space",1,"userSelect",2],e,s,gg);var oIx=_o(z,19,e,s,gg);_ac(oHx,oIx);_ac(oGx,oHx);_ac(o_w,oGx);var oJx=_ctn("view");var oKx=_setAttrs(z,"text",["space",10,"class",10],e,s,gg);var oLx=_o(z,21,e,s,gg);_ac(oKx,oLx);_ac(oJx,oKx);_ac(o_w,oJx);var oMx=_ctn("view");var oNx=_setAttrs(z,"text",["class",22,"space",1,"userSelect",2],e,s,gg);var oOx=_o(z,25,e,s,gg);_ac(oNx,oOx);_ac(oMx,oNx);_ac(o_w,oMx);var oPx=_setAttrs(z,"button",["bindtap",26,"class",1,"disabled",2],e,s,gg);var oQx=_o(z,29,e,s,gg);_ac(oPx,oQx);_ac(o_w,oPx);var oRx=_setAttrs(z,"button",["bindtap",30,"disabled",1],e,s,gg);var oSx=_o(z,32,e,s,gg);_ac(oRx,oSx);_ac(o_w,oRx);var oTx=_setAttrs(z,"button",["bindtap",33,"class",1],e,s,gg);var oUx=_o(z,35,e,s,gg);_ac(oTx,oUx);_ac(o_w,oTx);var oVx=_setAttrs(z,"button",["bindtap",36,"class",1],e,s,gg);var oWx=_o(z,38,e,s,gg);_ac(oVx,oWx);_ac(o_w,oVx);_ac(ozw,o_w);_ac(ouw,ozw);var oXx=_cvn();
    var oYx=_o(z,39,e,s,gg);
    var oZx=_gd('./macle_demo_EN/page/component/pages/text/text.maml',oYx,e_,d_);
    if(oZx){
      var oax={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oZx(oax,oax,oXx,gg);
      gg.f=tgf;
    }else{
      _w(oYx,'./macle_demo_EN/page/component/pages/text/text.maml',0,0);
    }
    _ac(ouw,oXx);_ac(r,ouw);orw.pop();orw.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/text/text.maml"]={f:m73,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/textarea/textarea.maml"]={};
  var m74=function(e,s,r,gg){
    var z=gz$gma_75()
    var obx=e_["./macle_demo_EN/page/component/pages/textarea/textarea.maml"].i;_ai(obx,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/textarea/textarea.maml',0,0);_ai(obx,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/textarea/textarea.maml',0,0);var oex=_ctn("view");_setAttr(z,oex,'class',0,e,s,gg);var ofx=_cvn();
    var ogx=_o(z,1,e,s,gg);
    var ohx=_gd('./macle_demo_EN/page/component/pages/textarea/textarea.maml',ogx,e_,d_);
    if(ohx){
      var oix=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ohx(oix,oix,ofx,gg);
      gg.f=tgf;
    }else{
      _w(ogx,'./macle_demo_EN/page/component/pages/textarea/textarea.maml',0,0);
    }
    _ac(oex,ofx);var ojx=_ctn("view");_setAttr(z,ojx,'class',3,e,s,gg);var okx=_ctn("view");_setAttr(z,okx,'class',4,e,s,gg);var olx=_ctn("view");_setAttr(z,olx,'class',5,e,s,gg);var omx=_o(z,6,e,s,gg);_ac(olx,omx);_ac(okx,olx);var onx=_ctn("view");_setAttr(z,onx,'class',7,e,s,gg);var oox=_setAttrs(z,"textarea",["placeholder",6,"autoHeight",2,"bindblur",3,"bindconfirm",4,"bindfocus",5,"bindinput",6,"bindlinechange",7,"id",8,"placeholderStyle",9,"style",10],e,s,gg);_ac(onx,oox);_ac(okx,onx);_ac(ojx,okx);var opx=_ctn("view");_setAttr(z,opx,'class',4,e,s,gg);var oqx=_ctn("view");_setAttr(z,oqx,'class',5,e,s,gg);var orx=_o(z,17,e,s,gg);_ac(oqx,orx);_ac(opx,oqx);var osx=_ctn("view");_setAttr(z,osx,'class',7,e,s,gg);var otx=_setAttrs(z,"textarea",["autoHeight",8,"focus",0,"id",10,"maxlength",11,"selectionEnd",12,"selectionStart",13,"style",14,"value",15],e,s,gg);_ac(osx,otx);_ac(opx,osx);_ac(ojx,opx);var oux=_ctn("view");_setAttr(z,oux,'class',24,e,s,gg);var ovx=_ctn("view");_setAttr(z,ovx,'class',25,e,s,gg);var owx=_o(z,26,e,s,gg);_ac(ovx,owx);_ac(oux,ovx);var oxx=_ctn("view");_setAttr(z,oxx,'class',7,e,s,gg);var oyx=_setAttrs(z,"textarea",["autoHeight",8,"disabled",0,"focus",0,"maxlength",11,"selectionEnd",12,"selectionStart",13,"style",14,"id",19,"value",20],e,s,gg);_ac(oxx,oyx);var ozx=_setAttrs(z,"textarea",["autoHeight",8,"maxlength",11,"style",14,"id",21,"value",22],e,s,gg);_ac(oxx,ozx);var o_x=_setAttrs(z,"textarea",["maxlength",19,"id",12,"placeholder",13,"placeholderClass",14],e,s,gg);_ac(oxx,o_x);_ac(oux,oxx);_ac(ojx,oux);_ac(oex,ojx);var oAy=_cvn();
    var oBy=_o(z,34,e,s,gg);
    var oCy=_gd('./macle_demo_EN/page/component/pages/textarea/textarea.maml',oBy,e_,d_);
    if(oCy){
      var oDy={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oCy(oDy,oDy,oAy,gg);
      gg.f=tgf;
    }else{
      _w(oBy,'./macle_demo_EN/page/component/pages/textarea/textarea.maml',0,0);
    }
    _ac(oex,oAy);_ac(r,oex);obx.pop();obx.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/textarea/textarea.maml"]={f:m74,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/video/video.maml"]={};
  var m75=function(e,s,r,gg){
    var z=gz$gma_76()
    var oEy=e_["./macle_demo_EN/page/component/pages/video/video.maml"].i;_ai(oEy,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/video/video.maml',0,0);_ai(oEy,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/video/video.maml',0,0);var oHy=_ctn("view");_setAttr(z,oHy,'class',0,e,s,gg);var oIy=_cvn();
    var oJy=_o(z,1,e,s,gg);
    var oKy=_gd('./macle_demo_EN/page/component/pages/video/video.maml',oJy,e_,d_);
    if(oKy){
      var oLy=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oKy(oLy,oLy,oIy,gg);
      gg.f=tgf;
    }else{
      _w(oJy,'./macle_demo_EN/page/component/pages/video/video.maml',0,0);
    }
    _ac(oHy,oIy);var oMy=_ctn("view");_setAttr(z,oMy,'class',3,e,s,gg);var oNy=_ctn("view");_setAttr(z,oNy,'class',4,e,s,gg);var oOy=_setAttrs(z,"video",["autoplay",5,"bindended",1,"binderror",2,"bindpause",3,"bindplay",4,"bindtimeupdate",5,"controls",6,"hidden",7,"id",8,"loop",9,"muted",10,"objectFit",11,"poster",12,"src",13],e,s,gg);_ac(oNy,oOy);var oPy=_ctn("view");_setAttr(z,oPy,'class',19,e,s,gg);var oQy=_ctn("view");_setAttr(z,oQy,'class',20,e,s,gg);var oRy=_ctn("view");_setAttr(z,oRy,'class',21,e,s,gg);var oSy=_ctn("view");_setAttr(z,oSy,'class',22,e,s,gg);var oTy=_o(z,23,e,s,gg);_ac(oSy,oTy);_ac(oRy,oSy);_ac(oQy,oRy);var oUy=_ctn("view");_setAttr(z,oUy,'class',24,e,s,gg);var oVy=_setAttrs(z,"input",["adjustPosition",25,"bindinput",1,"class",2,"placeholder",3,"type",4,"value",5],e,s,gg);_ac(oUy,oVy);_ac(oQy,oUy);_ac(oPy,oQy);_ac(oNy,oPy);var oWy=_ctn("view");_setAttr(z,oWy,'class',31,e,s,gg);var oXy=_setAttrs(z,"button",["bindtap",32,"class",1,"type",2],e,s,gg);var oYy=_o(z,35,e,s,gg);_ac(oXy,oYy);_ac(oWy,oXy);var oZy=_setAttrs(z,"button",["type",34,"bindtap",2,"class",3],e,s,gg);var oay=_o(z,36,e,s,gg);_ac(oZy,oay);_ac(oWy,oZy);var oby=_setAttrs(z,"button",["type",34,"bindtap",4,"class",5],e,s,gg);var ocy=_o(z,40,e,s,gg);_ac(oby,ocy);_ac(oWy,oby);_ac(oNy,oWy);_ac(oMy,oNy);_ac(oHy,oMy);var ody=_cvn();
    var oey=_o(z,41,e,s,gg);
    var ofy=_gd('./macle_demo_EN/page/component/pages/video/video.maml',oey,e_,d_);
    if(ofy){
      var ogy={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ofy(ogy,ogy,ody,gg);
      gg.f=tgf;
    }else{
      _w(oey,'./macle_demo_EN/page/component/pages/video/video.maml',0,0);
    }
    _ac(oHy,ody);_ac(r,oHy);oEy.pop();oEy.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/video/video.maml"]={f:m75,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/view/view.maml"]={};
  var m76=function(e,s,r,gg){
    var z=gz$gma_77()
    var ohy=e_["./macle_demo_EN/page/component/pages/view/view.maml"].i;_ai(ohy,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/view/view.maml',0,0);_ai(ohy,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/view/view.maml',0,0);var oky=_ctn("view");_setAttr(z,oky,'class',0,e,s,gg);var oly=_cvn();
    var omy=_o(z,1,e,s,gg);
    var ony=_gd('./macle_demo_EN/page/component/pages/view/view.maml',omy,e_,d_);
    if(ony){
      var ooy=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ony(ooy,ooy,oly,gg);
      gg.f=tgf;
    }else{
      _w(omy,'./macle_demo_EN/page/component/pages/view/view.maml',0,0);
    }
    _ac(oky,oly);var opy=_ctn("view");_setAttr(z,opy,'class',3,e,s,gg);var oqy=_ctn("view");_setAttr(z,oqy,'class',4,e,s,gg);var ory=_ctn("view");_setAttr(z,ory,'class',5,e,s,gg);var osy=_ctn("text");var oty=_o(z,6,e,s,gg);_ac(osy,oty);_ac(ory,osy);_ac(oqy,ory);var ouy=_setAttrs(z,"view",["class",7,"hoverClass",1,"hoverStartTime",2,"hoverStayTime",3],e,s,gg);var ovy=_setAttrs(z,"view",["class",11,"style",1],e,s,gg);var owy=_setAttrs(z,"view",["class",13,"hoverStopPropagation",1],e,s,gg);_ac(ovy,owy);var oxy=_ctn("view");_setAttr(z,oxy,'class',15,e,s,gg);_ac(ovy,oxy);var oyy=_ctn("view");_setAttr(z,oyy,'class',16,e,s,gg);_ac(ovy,oyy);_ac(ouy,ovy);_ac(oqy,ouy);_ac(opy,oqy);var ozy=_ctn("view");_setAttr(z,ozy,'class',4,e,s,gg);var o_y=_ctn("view");_setAttr(z,o_y,'class',5,e,s,gg);var oAz=_ctn("text");var oBz=_o(z,17,e,s,gg);_ac(oAz,oBz);_ac(o_y,oAz);_ac(ozy,o_y);var oCz=_setAttrs(z,"view",["class",11,"style",7],e,s,gg);var oDz=_ctn("view");_setAttr(z,oDz,'class',19,e,s,gg);_ac(oCz,oDz);var oEz=_ctn("view");_setAttr(z,oEz,'class',20,e,s,gg);_ac(oCz,oEz);var oFz=_ctn("view");_setAttr(z,oFz,'class',21,e,s,gg);_ac(oCz,oFz);_ac(ozy,oCz);_ac(opy,ozy);_ac(oky,opy);var oGz=_cvn();
    var oHz=_o(z,22,e,s,gg);
    var oIz=_gd('./macle_demo_EN/page/component/pages/view/view.maml',oHz,e_,d_);
    if(oIz){
      var oJz={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oIz(oJz,oJz,oGz,gg);
      gg.f=tgf;
    }else{
      _w(oHz,'./macle_demo_EN/page/component/pages/view/view.maml',0,0);
    }
    _ac(oky,oGz);_ac(r,oky);ohy.pop();ohy.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/view/view.maml"]={f:m76,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/web-view/web-view.maml"]={};
  var m77=function(e,s,r,gg){
    var z=gz$gma_78()
    var oLz=_ctn("web-view");_setAttr(z,oLz,'src',0,e,s,gg);_ac(r,oLz);
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/web-view/web-view.maml"]={f:m77,j:[],i:[],ti:[],ic:[]};

  d_["./macle_demo_EN/page/framework/pages/communication/communication.maml"]={};
  var m78=function(e,s,r,gg){
    var z=gz$gma_79()
    var oMz=e_["./macle_demo_EN/page/framework/pages/communication/communication.maml"].i;_ai(oMz,'../../../common/head.maml',e_,'./macle_demo_EN/page/framework/pages/communication/communication.maml',0,0);_ai(oMz,'../../../common/foot.maml',e_,'./macle_demo_EN/page/framework/pages/communication/communication.maml',0,0);var oPz=_ctn("view");_setAttr(z,oPz,'class',0,e,s,gg);var oQz=_setAttrs(z,"detail",["bindmyevent",1,"detail",1,"id",2,"propTest",3],e,s,gg);var oRz=_ctn("button");_setAttr(z,oRz,'bindtap',5,e,s,gg);var oSz=_o(z,6,e,s,gg);_ac(oRz,oSz);_ac(oQz,oRz);_ac(oPz,oQz);var oTz=_ctn("button");_setAttr(z,oTz,'bindtap',7,e,s,gg);var oUz=_o(z,8,e,s,gg);_ac(oTz,oUz);_ac(oPz,oTz);var oVz=_ctn("button");_setAttr(z,oVz,'bindtap',9,e,s,gg);var oWz=_o(z,10,e,s,gg);_ac(oVz,oWz);_ac(oPz,oVz);var oXz=_cvn();
    var oYz=_o(z,11,e,s,gg);
    var oZz=_gd('./macle_demo_EN/page/framework/pages/communication/communication.maml',oYz,e_,d_);
    if(oZz){
      var oaz={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oZz(oaz,oaz,oXz,gg);
      gg.f=tgf;
    }else{
      _w(oYz,'./macle_demo_EN/page/framework/pages/communication/communication.maml',0,0);
    }
    _ac(oPz,oXz);_ac(r,oPz);oMz.pop();oMz.pop();
    return r;
  };
  e_["./macle_demo_EN/page/framework/pages/communication/communication.maml"]={f:m78,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml"]={};
  var m79=function(e,s,r,gg){
    var z=gz$gma_80()
    var obz=e_["./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml"].i;_ai(obz,'../../../common/head.maml',e_,'./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml',0,0);_ai(obz,'../../../common/foot.maml',e_,'./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml',0,0);var oez=_setAttrs(z,"view",["class",0,"style",1],e,s,gg);var ofz=_cvn();
    var ogz=_o(z,2,e,s,gg);
    var ohz=_gd('./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml',ogz,e_,d_);
    if(ohz){
      var oiz=_1(z,3,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ohz(oiz,oiz,ofz,gg);
      gg.f=tgf;
    }else{
      _w(ogz,'./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml',0,0);
    }
    _ac(oez,ofz);var ojz=_ctn("view");_setAttr(z,ojz,'class',4,e,s,gg);var okz=_ctn("view");var olz=_o(z,5,e,s,gg);_ac(okz,olz);_ac(ojz,okz);var omz=_ctn("view");var onz=_o(z,6,e,s,gg);_ac(omz,onz);_ac(ojz,omz);var ooz=_ctn("view");var opz=_o(z,7,e,s,gg);_ac(ooz,opz);_ac(ojz,ooz);var oqz=_ctn("view");var orz=_o(z,8,e,s,gg);_ac(oqz,orz);_ac(ojz,oqz);var osz=_ctn("view");var otz=_o(z,9,e,s,gg);_ac(osz,otz);_ac(ojz,osz);var ouz=_ctn("view");var ovz=_o(z,10,e,s,gg);_ac(ouz,ovz);_ac(ojz,ouz);var owz=_ctn("view");_setAttr(z,owz,'class',11,e,s,gg);var oxz=_ctn("button");_setAttr(z,oxz,'bindtap',12,e,s,gg);var oyz=_o(z,13,e,s,gg);_ac(oxz,oyz);_ac(owz,oxz);var ozz=_ctn("button");_setAttr(z,ozz,'bindtap',14,e,s,gg);var o_z=_o(z,15,e,s,gg);_ac(ozz,o_z);_ac(owz,ozz);var oA_=_ctn("button");_setAttr(z,oA_,'bindtap',14,e,s,gg);var oB_=_o(z,16,e,s,gg);_ac(oA_,oB_);_ac(owz,oA_);var oC_=_ctn("button");_setAttr(z,oC_,'bindtap',17,e,s,gg);var oD_=_o(z,18,e,s,gg);_ac(oC_,oD_);_ac(owz,oC_);_ac(ojz,owz);var oE_=_ctn("view");_setAttr(z,oE_,'class',19,e,s,gg);var oF_=_ctn("view");_setAttr(z,oF_,'class',20,e,s,gg);var oG_=_setAttrs(z,"view",["class",21,"style",1],e,s,gg);var oH_=_ctn("view");_setAttr(z,oH_,'class',23,e,s,gg);var oI_=_ctn("view");_setAttr(z,oI_,'class',24,e,s,gg);var oJ_=_o(z,25,e,s,gg);_ac(oI_,oJ_);_ac(oH_,oI_);_ac(oG_,oH_);var oK_=_ctn("view");_setAttr(z,oK_,'class',26,e,s,gg);var oL_=_setAttrs(z,"picker",["bindchange",27,"headerText",1,"name",2,"range",3,"value",4],e,s,gg);var oM_=_ctn("view");var oN_=_o(z,32,e,s,gg);_ac(oM_,oN_);_ac(oL_,oM_);_ac(oK_,oL_);_ac(oG_,oK_);_ac(oF_,oG_);_ac(oE_,oF_);_ac(ojz,oE_);_ac(oez,ojz);var oO_=_cvn();
    var oP_=_o(z,33,e,s,gg);
    var oQ_=_gd('./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml',oP_,e_,d_);
    if(oQ_){
      var oR_={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oQ_(oR_,oR_,oO_,gg);
      gg.f=tgf;
    }else{
      _w(oP_,'./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml',0,0);
    }
    _ac(oez,oO_);_ac(r,oez);obz.pop();obz.pop();
    return r;
  };
  e_["./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml"]={f:m79,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml"]={};
  var m80=function(e,s,r,gg){
    var z=gz$gma_81()
    var oS_=e_["./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml"].i;_ai(oS_,'../../../common/head.maml',e_,'./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml',0,0);_ai(oS_,'../../../common/foot.maml',e_,'./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml',0,0);var oW_=_setAttrs(z,"view",["class",0,"style",1],e,s,gg);var oX_=_cvn();
    var oY_=_o(z,2,e,s,gg);
    var oZ_=_gd('./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml',oY_,e_,d_);
    if(oZ_){
      var oa_=_1(z,3,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oZ_(oa_,oa_,oX_,gg);
      gg.f=tgf;
    }else{
      _w(oY_,'./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml',0,0);
    }
    _ac(oW_,oX_);var ob_=_ctn("view");_setAttr(z,ob_,'class',4,e,s,gg);var oc_=_o(z,5,e,s,gg);_ac(ob_,oc_);var od_=_ctn("view");var oe_=_o(z,6,e,s,gg);_ac(od_,oe_);_ac(ob_,od_);_ac(oW_,ob_);var of_=_cvn();
    var og_=_o(z,7,e,s,gg);
    var oh_=_gd('./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml',og_,e_,d_);
    if(oh_){
      var oi_={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oh_(oi_,oi_,of_,gg);
      gg.f=tgf;
    }else{
      _w(og_,'./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml',0,0);
    }
    _ac(oW_,of_);_ac(r,oW_);oS_.pop();oS_.pop();
    return r;
  };
  e_["./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml"]={f:m80,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml"]={};
  var m81=function(e,s,r,gg){
    var z=gz$gma_82()
    var oj_=e_["./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml"].i;_ai(oj_,'../../../common/head.maml',e_,'./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml',0,0);_ai(oj_,'../../../common/foot.maml',e_,'./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml',0,0);var om_=_ctn("view");_setAttr(z,om_,'class',0,e,s,gg);var on_=_cvn();
    var oo_=_o(z,1,e,s,gg);
    var op_=_gd('./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml',oo_,e_,d_);
    if(op_){
      var oq_=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      op_(oq_,oq_,on_,gg);
      gg.f=tgf;
    }else{
      _w(oo_,'./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml',0,0);
    }
    _ac(om_,on_);var os_=_setAttrs(z,"view",["bind:touchend",3,"bind:touchmove",0,"bind:touchstart",0,"class",1,"style",2],e,s,gg);var ot_=_setAttrs(z,"view",["bind:tap",6,"class",1,"style",2],e,s,gg);var ou_=_setAttrs(z,"image",["class",9,"mode",1,"src",2],e,s,gg);_ac(ot_,ou_);_ac(os_,ot_);_ac(om_,os_);var ov_=_setAttrs(z,"view",["class",4,"bind:touchend",8,"bind:touchmove",8,"bind:touchstart",8,"data-maxHeight",9,"data-maxWidth",10,"style",11],e,s,gg);var ow_=_setAttrs(z,"view",["catch:tap",6,"class",1,"style",10],e,s,gg);var ox_=_setAttrs(z,"image",["class",9,"mode",1,"src",2],e,s,gg);_ac(ow_,ox_);_ac(ov_,ow_);_ac(om_,ov_);var oy_=_cvn();
    var oz_=_o(z,17,e,s,gg);
    var o__=_gd('./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml',oz_,e_,d_);
    if(o__){
      var oAAB={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      o__(oAAB,oAAB,oy_,gg);
      gg.f=tgf;
    }else{
      _w(oz_,'./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml',0,0);
    }
    _ac(om_,oy_);_ac(r,om_);oj_.pop();oj_.pop();
    return r;
  };
  e_["./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml"]={f:m81,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml"]={};
  var m82=function(e,s,r,gg){
    var z=gz$gma_83()
    var oBAB=e_["./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml"].i;_ai(oBAB,'../../../common/head.maml',e_,'./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml',0,0);_ai(oBAB,'../../../common/foot.maml',e_,'./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml',0,0);var oFAB=_ctn("view");_setAttr(z,oFAB,'class',0,e,s,gg);var oGAB=_cvn();
    var oHAB=_o(z,1,e,s,gg);
    var oIAB=_gd('./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml',oHAB,e_,d_);
    if(oIAB){
      var oJAB=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oIAB(oJAB,oJAB,oGAB,gg);
      gg.f=tgf;
    }else{
      _w(oHAB,'./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml',0,0);
    }
    _ac(oFAB,oGAB);var oKAB=_ctn("view");_setAttr(z,oKAB,'class',3,e,s,gg);var oLAB=_o(z,4,e,s,gg);_ac(oKAB,oLAB);_ac(oFAB,oKAB);var oMAB=_ctn("view");var oNAB=_o(z,5,e,s,gg);_ac(oMAB,oNAB);_ac(oFAB,oMAB);var oOAB=_ctn("view");_setAttr(z,oOAB,'class',3,e,s,gg);var oPAB=_o(z,6,e,s,gg);_ac(oOAB,oPAB);_ac(oFAB,oOAB);var oQAB=_ctn("view");var oRAB=_o(z,7,e,s,gg);_ac(oQAB,oRAB);_ac(oFAB,oQAB);var oSAB=_ctn("view");_setAttr(z,oSAB,'class',3,e,s,gg);var oTAB=_o(z,8,e,s,gg);_ac(oSAB,oTAB);_ac(oFAB,oSAB);var oUAB=_ctn("view");var oVAB=_o(z,9,e,s,gg);_ac(oUAB,oVAB);_ac(oFAB,oUAB);var oWAB=_ctn("view");_setAttr(z,oWAB,'class',10,e,s,gg);var oXAB=_setAttrs(z,"button",["bindtap",11,"type",1],e,s,gg);var oYAB=_o(z,13,e,s,gg);_ac(oXAB,oYAB);_ac(oWAB,oXAB);_ac(oFAB,oWAB);var oZAB=_cvn();
    var oaAB=_o(z,14,e,s,gg);
    var obAB=_gd('./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml',oaAB,e_,d_);
    if(obAB){
      var ocAB={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      obAB(ocAB,ocAB,oZAB,gg);
      gg.f=tgf;
    }else{
      _w(oaAB,'./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml',0,0);
    }
    _ac(oFAB,oZAB);_ac(r,oFAB);oBAB.pop();oBAB.pop();
    return r;
  };
  e_["./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml"]={f:m82,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml"]={};
  var m83=function(e,s,r,gg){
    var z=gz$gma_84()
    var odAB=e_["./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml"].i;_ai(odAB,'../../../../common/head.maml',e_,'./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);_ai(odAB,'../../../../common/foot.maml',e_,'./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);var ogAB=_ctn("view");_setAttr(z,ogAB,'class',0,e,s,gg);var ohAB=_cvn();
    var oiAB=_o(z,1,e,s,gg);
    var ojAB=_gd('./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',oiAB,e_,d_);
    if(ojAB){
      var okAB=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ojAB(okAB,okAB,ohAB,gg);
      gg.f=tgf;
    }else{
      _w(oiAB,'./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);
    }
    _ac(ogAB,ohAB);var olAB=_ctn("view");_setAttr(z,olAB,'class',3,e,s,gg);var omAB=_ctn("view");_setAttr(z,omAB,'class',4,e,s,gg);var onAB=_setAttrs(z,"button",["bindtap",5,"class",1],e,s,gg);var ooAB=_o(z,7,e,s,gg);_ac(onAB,ooAB);_ac(omAB,onAB);var opAB=_setAttrs(z,"button",["bindtap",8,"class",0],e,s,gg);var oqAB=_o(z,9,e,s,gg);_ac(opAB,oqAB);_ac(omAB,opAB);var orAB=_setAttrs(z,"button",["bindtap",10,"class",0],e,s,gg);var osAB=_o(z,11,e,s,gg);_ac(orAB,osAB);_ac(omAB,orAB);var otAB=_setAttrs(z,"button",["bindtap",12,"class",1],e,s,gg);var ouAB=_o(z,14,e,s,gg);_ac(otAB,ouAB);_ac(omAB,otAB);_ac(olAB,omAB);_ac(ogAB,olAB);var ovAB=_cvn();
    var owAB=_o(z,15,e,s,gg);
    var oxAB=_gd('./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',owAB,e_,d_);
    if(oxAB){
      var oyAB={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oxAB(oyAB,oyAB,ovAB,gg);
      gg.f=tgf;
    }else{
      _w(owAB,'./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);
    }
    _ac(ogAB,ovAB);_ac(r,ogAB);odAB.pop();odAB.pop();
    return r;
  };
  e_["./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml"]={f:m83,j:[],i:[],ti:["../../../../common/head.maml","../../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/tabbar/api/index.maml"]={};
  var m84=function(e,s,r,gg){
    var z=gz$gma_85()
    var o_AB=_cvn();if(_o(z,0,e,s,gg)){o_AB.maVkey=1;var oABB=_ctn("set-tab-bar");_setAttr(z,oABB,'bindunmount',1,e,s,gg);_ac(o_AB,oABB);}else{o_AB.maVkey=2;var oCBB=_ctn("view");_setAttr(z,oCBB,'class',2,e,s,gg);var oEBB=_ctn("view");_setAttr(z,oEBB,'class',3,e,s,gg);var oFBB=_ctn("view");_setAttr(z,oFBB,'class',4,e,s,gg);var oGBB=_o(z,5,e,s,gg);_ac(oFBB,oGBB);_ac(oEBB,oFBB);_ac(oCBB,oEBB);var oHBB=_ctn("view");_setAttr(z,oHBB,'class',6,e,s,gg);var oIBB=_ctn("view");_setAttr(z,oIBB,'class',7,e,s,gg);var oJBB=_cvn();var oKBB=function(oOBB,oNBB,oMBB,gg){var oQBB=_ctn("view");_setAttr(z,oQBB,'class',10,oOBB,oNBB,gg);var oRBB=_setAttrs(z,"view",["id",9,"bindtap",2,"class",3],oOBB,oNBB,gg);var oSBB=_ctn("view");_setAttr(z,oSBB,'class',13,oOBB,oNBB,gg);var oTBB=_o(z,14,oOBB,oNBB,gg);_ac(oSBB,oTBB);_ac(oRBB,oSBB);var oUBB=_setAttrs(z,"image",["class",15,"src",1],oOBB,oNBB,gg);_ac(oRBB,oUBB);_ac(oQBB,oRBB);var oVBB=_ctn("view");_setAttr(z,oVBB,'class',17,oOBB,oNBB,gg);var oWBB=_ctn("view");_setAttr(z,oWBB,'class',18,oOBB,oNBB,gg);var oXBB=_cvn();var oYBB=function(ocBB,obBB,oaBB,gg){var oeBB=_cvn();if(_o(z,22,ocBB,obBB,gg)){oeBB.maVkey=1;var ofBB=_setAttrs(z,"navigator",["class",23,"url",1],ocBB,obBB,gg);var ohBB=_setAttrs(z,"view",["class",25,"id",1],ocBB,obBB,gg);var oiBB=_o(z,27,ocBB,obBB,gg);_ac(ohBB,oiBB);_ac(ofBB,ohBB);var ojBB=_ctn("view");_setAttr(z,ojBB,'class',28,ocBB,obBB,gg);_ac(ofBB,ojBB);_ac(oeBB,ofBB);}else{oeBB.maVkey=2;var okBB=_setAttrs(z,"view",["class",23,"bindtap",6],e,s,gg);var omBB=_setAttrs(z,"view",["class",25,"id",1],e,s,gg);var onBB=_o(z,27,e,s,gg);_ac(omBB,onBB);_ac(okBB,omBB);var ooBB=_ctn("view");_setAttr(z,ooBB,'class',28,e,s,gg);_ac(okBB,ooBB);_ac(oeBB,okBB);}_ac(oaBB,oeBB);return oaBB;};_2(z,19,oYBB,oOBB,oNBB,gg,oXBB,"page","index",'*item');_ac(oWBB,oXBB);_ac(oVBB,oWBB);_ac(oQBB,oVBB);_ac(oMBB,oQBB);return oMBB;};_2(z,8,oKBB,e,s,gg,oJBB,"item","index",'{{item.id}}');_ac(oIBB,oJBB);_ac(oHBB,oIBB);_ac(oCBB,oHBB);_ac(o_AB,oCBB);}_ac(r,o_AB);
    return r;
  };
  e_["./macle_demo_EN/page/tabbar/api/index.maml"]={f:m84,j:[],i:[],ti:[],ic:[]};

  d_["./macle_demo_EN/page/tabbar/component/index.maml"]={};
  var m85=function(e,s,r,gg){
    var z=gz$gma_86()
    var oqBB=_ctn("view");_setAttr(z,oqBB,'class',0,e,s,gg);var orBB=_ctn("view");_setAttr(z,orBB,'class',1,e,s,gg);var osBB=_ctn("view");_setAttr(z,osBB,'class',2,e,s,gg);var otBB=_o(z,3,e,s,gg);_ac(osBB,otBB);_ac(orBB,osBB);_ac(oqBB,orBB);var ouBB=_ctn("view");_setAttr(z,ouBB,'class',4,e,s,gg);var ovBB=_ctn("view");_setAttr(z,ovBB,'class',5,e,s,gg);var owBB=_cvn();var oxBB=function(oACB,o_BB,ozBB,gg){var oCCB=_ctn("view");_setAttr(z,oCCB,'class',9,oACB,o_BB,gg);var oDCB=_setAttrs(z,"view",["id",8,"bindtap",2,"class",3],oACB,o_BB,gg);var oECB=_ctn("view");_setAttr(z,oECB,'class',12,oACB,o_BB,gg);var oFCB=_o(z,13,oACB,o_BB,gg);_ac(oECB,oFCB);_ac(oDCB,oECB);var oGCB=_cvn();if(_o(z,14,oACB,o_BB,gg)){oGCB.maVkey=1;var oHCB=_setAttrs(z,"image",["class",15,"src",1],oACB,o_BB,gg);_ac(oGCB,oHCB);} _ac(oDCB,oGCB);_ac(oCCB,oDCB);var oJCB=_ctn("view");_setAttr(z,oJCB,'class',17,oACB,o_BB,gg);var oKCB=_ctn("view");_setAttr(z,oKCB,'class',18,oACB,o_BB,gg);var oLCB=_cvn();var oMCB=function(oQCB,oPCB,oOCB,gg){var oSCB=_setAttrs(z,"navigator",["class",22,"id",1,"url",2],oQCB,oPCB,gg);var oTCB=_setAttrs(z,"view",["class",25,"id",1],oQCB,oPCB,gg);var oUCB=_o(z,27,oQCB,oPCB,gg);_ac(oTCB,oUCB);_ac(oSCB,oTCB);var oVCB=_ctn("view");_setAttr(z,oVCB,'class',28,oQCB,oPCB,gg);_ac(oSCB,oVCB);_ac(oOCB,oSCB);return oOCB;};_2(z,19,oMCB,oACB,o_BB,gg,oLCB,"page","index",'*item');_ac(oKCB,oLCB);_ac(oJCB,oKCB);_ac(oCCB,oJCB);_ac(ozBB,oCCB);return ozBB;};_2(z,6,oxBB,e,s,gg,owBB,"item","index",'{{item.id}}');_ac(ovBB,owBB);_ac(ouBB,ovBB);_ac(oqBB,ouBB);_ac(r,oqBB);
    return r;
  };
  e_["./macle_demo_EN/page/tabbar/component/index.maml"]={f:m85,j:[],i:[],ti:[],ic:[]};

  d_["./macle_demo_EN/page/tabbar/framework/index.maml"]={};
  var m86=function(e,s,r,gg){
    var z=gz$gma_87()
    var oXCB=_ctn("view");_setAttr(z,oXCB,'class',0,e,s,gg);var oYCB=_ctn("view");_setAttr(z,oYCB,'class',1,e,s,gg);var oZCB=_ctn("view");_setAttr(z,oZCB,'class',2,e,s,gg);var oaCB=_o(z,3,e,s,gg);_ac(oZCB,oaCB);_ac(oYCB,oZCB);_ac(oXCB,oYCB);var obCB=_ctn("view");_setAttr(z,obCB,'class',4,e,s,gg);var ocCB=_ctn("view");_setAttr(z,ocCB,'class',5,e,s,gg);var odCB=_cvn();var oeCB=function(oiCB,ohCB,ogCB,gg){var okCB=_ctn("view");_setAttr(z,okCB,'class',9,oiCB,ohCB,gg);var olCB=_setAttrs(z,"view",["id",8,"bindtap",2,"class",3],oiCB,ohCB,gg);var omCB=_ctn("view");_setAttr(z,omCB,'class',12,oiCB,ohCB,gg);var onCB=_o(z,13,oiCB,ohCB,gg);_ac(omCB,onCB);_ac(olCB,omCB);_ac(okCB,olCB);var ooCB=_ctn("view");_setAttr(z,ooCB,'class',14,oiCB,ohCB,gg);var opCB=_ctn("view");_setAttr(z,opCB,'class',15,oiCB,ohCB,gg);var oqCB=_cvn();var orCB=function(ovCB,ouCB,otCB,gg){var oxCB=_setAttrs(z,"navigator",["class",19,"url",1],ovCB,ouCB,gg);var oyCB=_ctn("view");_setAttr(z,oyCB,'class',21,ovCB,ouCB,gg);var ozCB=_o(z,22,ovCB,ouCB,gg);_ac(oyCB,ozCB);_ac(oxCB,oyCB);var o_CB=_ctn("view");_setAttr(z,o_CB,'class',23,ovCB,ouCB,gg);_ac(oxCB,o_CB);_ac(otCB,oxCB);return otCB;};_2(z,16,orCB,oiCB,ohCB,gg,oqCB,"page","index",'*item');_ac(opCB,oqCB);_ac(ooCB,opCB);_ac(okCB,ooCB);_ac(ogCB,okCB);return ogCB;};_2(z,6,oeCB,e,s,gg,odCB,"item","index",'{{item.id}}');_ac(ocCB,odCB);_ac(obCB,ocCB);_ac(oXCB,obCB);_ac(r,oXCB);
    return r;
  };
  e_["./macle_demo_EN/page/tabbar/framework/index.maml"]={f:m86,j:[],i:[],ti:[],ic:[]};

  d_["./page/common/foot.maml"]={};
  d_["./page/common/foot.maml"]["foot"]=function(e,s,r,gg){
    var z=gz$gma_88(),b='./page/common/foot.maml:foot'
    r.maVkey=b
    gg.f=$gdc(f_["./page/common/foot.maml"],"",1)
    if(p_[b]){_wl(b,'./page/common/foot.maml');return}
    p_[b]=true
    try{
      var oBDB=_setAttrs(z,"navigator",["class",0,"hoverClass",1,"openType",1,"url",2],e,s,gg);var oCDB=_setAttrs(z,"image",["class",4,"src",1],e,s,gg);_ac(oBDB,oCDB);_ac(r,oBDB);
    }catch(e){
      p_[b]=false
      throw e
    }
    p_[b]=false
    return r
  };
  var m87=function(e,s,r,gg){
    var z=gz$gma_88()
    
    return r;
  };
  e_["./page/common/foot.maml"]={f:m87,j:[],i:[],ti:[],ic:[]};

  d_["./page/common/head.maml"]={};
  d_["./page/common/head.maml"]["head"]=function(e,s,r,gg){
    var z=gz$gma_89(),b='./page/common/head.maml:head'
    r.maVkey=b
    gg.f=$gdc(f_["./page/common/head.maml"],"",1)
    if(p_[b]){_wl(b,'./page/common/head.maml');return}
    p_[b]=true
    try{
      var oGDB=_ctn("view");_setAttr(z,oGDB,'class',0,e,s,gg);var oHDB=_ctn("view");_setAttr(z,oHDB,'class',1,e,s,gg);var oIDB=_o(z,2,e,s,gg);_ac(oHDB,oIDB);_ac(oGDB,oHDB);var oJDB=_ctn("view");_setAttr(z,oJDB,'class',3,e,s,gg);_ac(oGDB,oJDB);var oKDB=_cvn();if(_o(z,4,e,s,gg)){oKDB.maVkey=1;var oLDB=_ctn("view");_setAttr(z,oLDB,'class',5,e,s,gg);var oNDB=_o(z,6,e,s,gg);_ac(oLDB,oNDB);_ac(oKDB,oLDB);} _ac(oGDB,oKDB);_ac(r,oGDB);
    }catch(e){
      p_[b]=false
      throw e
    }
    p_[b]=false
    return r
  };
  var m88=function(e,s,r,gg){
    var z=gz$gma_89()
    
    return r;
  };
  e_["./page/common/head.maml"]={f:m88,j:[],i:[],ti:[],ic:[]};

  d_["./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml"]={};
  var m89=function(e,s,r,gg){
    var z=gz$gma_90()
    var oQDB=e_["./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml"].i;_ai(oQDB,'../../../../common/head.maml',e_,'./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);_ai(oQDB,'../../../../common/foot.maml',e_,'./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);var oTDB=_ctn("view");_setAttr(z,oTDB,'class',0,e,s,gg);var oUDB=_cvn();
    var oVDB=_o(z,1,e,s,gg);
    var oWDB=_gd('./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',oVDB,e_,d_);
    if(oWDB){
      var oXDB=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oWDB(oXDB,oXDB,oUDB,gg);
      gg.f=tgf;
    }else{
      _w(oVDB,'./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);
    }
    _ac(oTDB,oUDB);var oYDB=_ctn("view");_setAttr(z,oYDB,'class',3,e,s,gg);var oZDB=_ctn("view");_setAttr(z,oZDB,'class',4,e,s,gg);var oaDB=_setAttrs(z,"button",["bindtap",5,"class",1],e,s,gg);var obDB=_o(z,7,e,s,gg);_ac(oaDB,obDB);_ac(oZDB,oaDB);var ocDB=_setAttrs(z,"button",["bindtap",8,"class",0],e,s,gg);var odDB=_o(z,9,e,s,gg);_ac(ocDB,odDB);_ac(oZDB,ocDB);var oeDB=_setAttrs(z,"button",["bindtap",10,"class",0],e,s,gg);var ofDB=_o(z,11,e,s,gg);_ac(oeDB,ofDB);_ac(oZDB,oeDB);var ogDB=_setAttrs(z,"button",["bindtap",12,"class",1],e,s,gg);var ohDB=_o(z,14,e,s,gg);_ac(ogDB,ohDB);_ac(oZDB,ogDB);_ac(oYDB,oZDB);_ac(oTDB,oYDB);var oiDB=_cvn();
    var ojDB=_o(z,15,e,s,gg);
    var okDB=_gd('./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',ojDB,e_,d_);
    if(okDB){
      var olDB={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      okDB(olDB,olDB,oiDB,gg);
      gg.f=tgf;
    }else{
      _w(ojDB,'./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);
    }
    _ac(oTDB,oiDB);_ac(r,oTDB);oQDB.pop();oQDB.pop();
    return r;
  };
  e_["./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml"]={f:m89,j:[],i:[],ti:["../../../../common/head.maml","../../../../common/foot.maml"],ic:[]};

  d_["./page/tabbar/api/index.maml"]={};
  var m90=function(e,s,r,gg){
    var z=gz$gma_91()
    var onDB=_cvn();if(_o(z,0,e,s,gg)){onDB.maVkey=1;var ooDB=_ctn("set-tab-bar");_setAttr(z,ooDB,'bindunmount',1,e,s,gg);_ac(onDB,ooDB);}else{onDB.maVkey=2;var oqDB=_ctn("view");_setAttr(z,oqDB,'class',2,e,s,gg);var osDB=_ctn("view");_setAttr(z,osDB,'class',3,e,s,gg);var otDB=_ctn("view");_setAttr(z,otDB,'class',4,e,s,gg);var ouDB=_o(z,5,e,s,gg);_ac(otDB,ouDB);_ac(osDB,otDB);_ac(oqDB,osDB);var ovDB=_ctn("view");_setAttr(z,ovDB,'class',6,e,s,gg);var owDB=_ctn("view");_setAttr(z,owDB,'class',7,e,s,gg);var oxDB=_cvn();var oyDB=function(oBEB,oAEB,o_DB,gg){var oDEB=_ctn("view");_setAttr(z,oDEB,'class',10,oBEB,oAEB,gg);var oEEB=_setAttrs(z,"view",["id",9,"bindtap",2,"class",3],oBEB,oAEB,gg);var oFEB=_ctn("view");_setAttr(z,oFEB,'class',13,oBEB,oAEB,gg);var oGEB=_o(z,14,oBEB,oAEB,gg);_ac(oFEB,oGEB);_ac(oEEB,oFEB);var oHEB=_setAttrs(z,"image",["class",15,"src",1],oBEB,oAEB,gg);_ac(oEEB,oHEB);_ac(oDEB,oEEB);var oIEB=_ctn("view");_setAttr(z,oIEB,'class',17,oBEB,oAEB,gg);var oJEB=_ctn("view");_setAttr(z,oJEB,'class',18,oBEB,oAEB,gg);var oKEB=_cvn();var oLEB=function(oPEB,oOEB,oNEB,gg){var oREB=_cvn();if(_o(z,22,oPEB,oOEB,gg)){oREB.maVkey=1;var oSEB=_setAttrs(z,"navigator",["class",23,"url",1],oPEB,oOEB,gg);var oUEB=_setAttrs(z,"view",["class",25,"id",1],oPEB,oOEB,gg);var oVEB=_o(z,27,oPEB,oOEB,gg);_ac(oUEB,oVEB);_ac(oSEB,oUEB);var oWEB=_ctn("view");_setAttr(z,oWEB,'class',28,oPEB,oOEB,gg);_ac(oSEB,oWEB);_ac(oREB,oSEB);}else{oREB.maVkey=2;var oXEB=_setAttrs(z,"view",["class",23,"bindtap",6],e,s,gg);var oZEB=_setAttrs(z,"view",["class",25,"id",1],e,s,gg);var oaEB=_o(z,27,e,s,gg);_ac(oZEB,oaEB);_ac(oXEB,oZEB);var obEB=_ctn("view");_setAttr(z,obEB,'class',28,e,s,gg);_ac(oXEB,obEB);_ac(oREB,oXEB);}_ac(oNEB,oREB);return oNEB;};_2(z,19,oLEB,oBEB,oAEB,gg,oKEB,"page","index",'*item');_ac(oJEB,oKEB);_ac(oIEB,oJEB);_ac(oDEB,oIEB);_ac(o_DB,oDEB);return o_DB;};_2(z,8,oyDB,e,s,gg,oxDB,"item","index",'{{item.id}}');_ac(owDB,oxDB);_ac(ovDB,owDB);_ac(oqDB,ovDB);_ac(onDB,oqDB);}_ac(r,onDB);
    return r;
  };
  e_["./page/tabbar/api/index.maml"]={f:m90,j:[],i:[],ti:[],ic:[]};

  d_["./page/tabbar/component/index.maml"]={};
  var m91=function(e,s,r,gg){
    var z=gz$gma_92()
    var odEB=_ctn("view");_setAttr(z,odEB,'class',0,e,s,gg);var oeEB=_ctn("view");_setAttr(z,oeEB,'class',1,e,s,gg);var ofEB=_ctn("view");_setAttr(z,ofEB,'class',2,e,s,gg);var ogEB=_o(z,3,e,s,gg);_ac(ofEB,ogEB);_ac(oeEB,ofEB);_ac(odEB,oeEB);var ohEB=_ctn("view");_setAttr(z,ohEB,'class',4,e,s,gg);var oiEB=_ctn("view");_setAttr(z,oiEB,'class',5,e,s,gg);var ojEB=_cvn();var okEB=function(ooEB,onEB,omEB,gg){var oqEB=_ctn("view");_setAttr(z,oqEB,'class',9,ooEB,onEB,gg);var orEB=_setAttrs(z,"view",["id",8,"bindtap",2,"class",3],ooEB,onEB,gg);var osEB=_ctn("view");_setAttr(z,osEB,'class',12,ooEB,onEB,gg);var otEB=_o(z,13,ooEB,onEB,gg);_ac(osEB,otEB);_ac(orEB,osEB);var ouEB=_cvn();if(_o(z,14,ooEB,onEB,gg)){ouEB.maVkey=1;var ovEB=_setAttrs(z,"image",["class",15,"src",1],ooEB,onEB,gg);_ac(ouEB,ovEB);} _ac(orEB,ouEB);_ac(oqEB,orEB);var oxEB=_ctn("view");_setAttr(z,oxEB,'class',17,ooEB,onEB,gg);var oyEB=_ctn("view");_setAttr(z,oyEB,'class',18,ooEB,onEB,gg);var ozEB=_cvn();var o_EB=function(oDFB,oCFB,oBFB,gg){var oFFB=_setAttrs(z,"navigator",["class",22,"id",1,"url",2],oDFB,oCFB,gg);var oGFB=_setAttrs(z,"view",["class",25,"id",1],oDFB,oCFB,gg);var oHFB=_o(z,27,oDFB,oCFB,gg);_ac(oGFB,oHFB);_ac(oFFB,oGFB);var oIFB=_ctn("view");_setAttr(z,oIFB,'class',28,oDFB,oCFB,gg);_ac(oFFB,oIFB);_ac(oBFB,oFFB);return oBFB;};_2(z,19,o_EB,ooEB,onEB,gg,ozEB,"page","index",'*item');_ac(oyEB,ozEB);_ac(oxEB,oyEB);_ac(oqEB,oxEB);_ac(omEB,oqEB);return omEB;};_2(z,6,okEB,e,s,gg,ojEB,"item","index",'{{item.id}}');_ac(oiEB,ojEB);_ac(ohEB,oiEB);_ac(odEB,ohEB);_ac(r,odEB);
    return r;
  };
  e_["./page/tabbar/component/index.maml"]={f:m91,j:[],i:[],ti:[],ic:[]};

  d_["./page/tabbar/framework/index.maml"]={};
  var m92=function(e,s,r,gg){
    var z=gz$gma_93()
    var oKFB=_ctn("view");_setAttr(z,oKFB,'class',0,e,s,gg);var oLFB=_ctn("view");_setAttr(z,oLFB,'class',1,e,s,gg);var oMFB=_ctn("view");_setAttr(z,oMFB,'class',2,e,s,gg);var oNFB=_o(z,3,e,s,gg);_ac(oMFB,oNFB);_ac(oLFB,oMFB);_ac(oKFB,oLFB);var oOFB=_ctn("view");_setAttr(z,oOFB,'class',4,e,s,gg);var oPFB=_ctn("view");_setAttr(z,oPFB,'class',5,e,s,gg);var oQFB=_cvn();var oRFB=function(oVFB,oUFB,oTFB,gg){var oXFB=_ctn("view");_setAttr(z,oXFB,'class',9,oVFB,oUFB,gg);var oYFB=_setAttrs(z,"view",["id",8,"bindtap",2,"class",3],oVFB,oUFB,gg);var oZFB=_ctn("view");_setAttr(z,oZFB,'class',12,oVFB,oUFB,gg);var oaFB=_o(z,13,oVFB,oUFB,gg);_ac(oZFB,oaFB);_ac(oYFB,oZFB);_ac(oXFB,oYFB);var obFB=_ctn("view");_setAttr(z,obFB,'class',14,oVFB,oUFB,gg);var ocFB=_ctn("view");_setAttr(z,ocFB,'class',15,oVFB,oUFB,gg);var odFB=_cvn();var oeFB=function(oiFB,ohFB,ogFB,gg){var okFB=_setAttrs(z,"navigator",["class",19,"url",1],oiFB,ohFB,gg);var olFB=_ctn("view");_setAttr(z,olFB,'class',21,oiFB,ohFB,gg);var omFB=_o(z,22,oiFB,ohFB,gg);_ac(olFB,omFB);_ac(okFB,olFB);var onFB=_ctn("view");_setAttr(z,onFB,'class',23,oiFB,ohFB,gg);_ac(okFB,onFB);_ac(ogFB,okFB);return ogFB;};_2(z,16,oeFB,oVFB,oUFB,gg,odFB,"page","index",'*item');_ac(ocFB,odFB);_ac(obFB,ocFB);_ac(oXFB,obFB);_ac(oTFB,oXFB);return oTFB;};_2(z,6,oRFB,e,s,gg,oQFB,"item","index",'{{item.id}}');_ac(oPFB,oQFB);_ac(oOFB,oPFB);_ac(oKFB,oOFB);_ac(r,oKFB);
    return r;
  };
  e_["./page/tabbar/framework/index.maml"]={f:m92,j:[],i:[],ti:[],ic:[]};

  d_["./page/tabbar/react/index.maml"]={};
  var m93=function(e,s,r,gg){
    var z=gz$gma_94()
    var opFB=_ctn("view");_setAttr(z,opFB,'class',0,e,s,gg);var oqFB=_setAttrs(z,"script",["async",1,"src",1],e,s,gg);_ac(opFB,oqFB);var orFB=_ctn("script");_setAttr(z,orFB,'src',3,e,s,gg);_ac(opFB,orFB);var osFB=_ctn("div");_setAttr(z,osFB,'id',4,e,s,gg);var otFB=_o(z,5,e,s,gg);_ac(osFB,otFB);_ac(opFB,osFB);var ouFB=_ctn("web-view");_setAttr(z,ouFB,'src',6,e,s,gg);_ac(opFB,ouFB);var ovFB=_ctn("view");_setAttr(z,ovFB,'class',7,e,s,gg);var owFB=_ctn("view");_setAttr(z,owFB,'class',8,e,s,gg);var oxFB=_cvn();var oyFB=function(oBGB,oAGB,o_FB,gg){var oDGB=_ctn("view");_setAttr(z,oDGB,'class',12,oBGB,oAGB,gg);var oEGB=_setAttrs(z,"view",["id",11,"bindtap",2,"class",3],oBGB,oAGB,gg);var oFGB=_ctn("view");_setAttr(z,oFGB,'class',15,oBGB,oAGB,gg);var oGGB=_o(z,16,oBGB,oAGB,gg);_ac(oFGB,oGGB);_ac(oEGB,oFGB);var oHGB=_cvn();if(_o(z,17,oBGB,oAGB,gg)){oHGB.maVkey=1;var oIGB=_setAttrs(z,"image",["class",18,"src",1],oBGB,oAGB,gg);_ac(oHGB,oIGB);} _ac(oEGB,oHGB);_ac(oDGB,oEGB);var oKGB=_ctn("view");_setAttr(z,oKGB,'class',20,oBGB,oAGB,gg);var oLGB=_ctn("view");_setAttr(z,oLGB,'class',21,oBGB,oAGB,gg);var oMGB=_cvn();var oNGB=function(oRGB,oQGB,oPGB,gg){var oTGB=_setAttrs(z,"navigator",["class",25,"id",1,"url",2],oRGB,oQGB,gg);var oUGB=_setAttrs(z,"view",["class",28,"id",1],oRGB,oQGB,gg);var oVGB=_o(z,30,oRGB,oQGB,gg);_ac(oUGB,oVGB);_ac(oTGB,oUGB);var oWGB=_ctn("view");_setAttr(z,oWGB,'class',31,oRGB,oQGB,gg);_ac(oTGB,oWGB);_ac(oPGB,oTGB);return oPGB;};_2(z,22,oNGB,oBGB,oAGB,gg,oMGB,"page","index",'*item');_ac(oLGB,oMGB);_ac(oKGB,oLGB);_ac(oDGB,oKGB);_ac(o_FB,oDGB);return o_FB;};_2(z,9,oyFB,e,s,gg,oxFB,"item","index",'{{item.id}}');_ac(owFB,oxFB);_ac(ovFB,owFB);_ac(opFB,ovFB);_ac(r,opFB);
    return r;
  };
  e_["./page/tabbar/react/index.maml"]={f:m93,j:[],i:[],ti:[],ic:[]};

  if(path&&e_[path]){
    return function(env,dd,global){
      $gmac=0;
      var root={"tag":"ma-page","children":[]};
      var main=e_[path].f;
      if(typeof global==="undefined")global={};
      global.f=$gdc(f_[path],"",1)||{};
      global.f.i18n=f_['i18n']
      if(window.__mergeData__)env=window.__mergeData__(env,dd);
      try{
        main(env,{},root,global);
      }catch(e){
        console.log(e)
      }
      return root;
    }
  }
}

var BASE_DEVICE_WIDTH=750;
var deviceWidth=window.screen.width||375;
var isIOS=navigator.userAgent.match("iPhone");
var deviceDPR=window.devicePixelRatio||2;
var checkDeviceWidth=window.__checkDeviceWidth__||function(){
  var newDeviceDPR=window.devicePixelRatio||2
  var newDeviceWidth=window.screen.width||375
  var newDeviceHeight=window.screen.height||375
  if(window.screen.orientation&&/^landscape/.test(window.screen.orientation.type||''))newDeviceWidth=newDeviceHeight
  if(newDeviceWidth!==deviceWidth||newDeviceDPR!==deviceDPR){
    deviceDPR=newDeviceDPR
    deviceWidth=newDeviceWidth
  }
}
checkDeviceWidth()
var eps=1e-4;
var transformRPX=window.__transformRpx__||function(number,newDeviceWidth){
  if(number===0)return 0;
  number=number/BASE_DEVICE_WIDTH*(newDeviceWidth||deviceWidth);
  number=Math.floor(number+eps);
  if(number===0){
    if(deviceDPR===1||!isIOS)return 1;
    else return 0.5;
  }
  return number;
}
var __COMMON_STYLESHEETS__=__COMMON_STYLESHEETS__||{}
if(!__COMMON_STYLESHEETS__.hasOwnProperty('page/common/index.mass'))__COMMON_STYLESHEETS__['page/common/index.mass']=[".",[1],"index-hd{padding:",[0,80],";text-align:center}\n.",[1],"index-bd{padding:0 ",[0,30]," ",[0,40],"}\n.",[1],"index-ft{padding-bottom:",[0,20],";text-align:center}\n.",[1],"index-logo{height:",[0,86],";width:",[0,86],"}\n.",[1],"index-desc{color:#888;font-size:",[0,28],";margin-top:",[0,20],"}\n.",[1],"navigator-box{background-color:#fff;font-size:",[0,34],";line-height:1.41176471;opacity:0;position:relative;-webkit-transform:translateY(-50%);transform:translateY(-50%);transition:.3s}\n.",[1],"navigator-box-show{opacity:1;-webkit-transform:translateY(0);transform:translateY(0)}\n.",[1],"navigator{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding:",[0,20]," ",[0,30],";position:relative}\n.",[1],"navigator:before{border-top:",[0,1]," solid #d8d8d8;color:#d8d8d8;content:' ';height:1px;left:",[0,30],";position:absolute;right:",[0,30],";top:0}\n.",[1],"navigator:first-child:before{display:none}\n.",[1],"navigator-content{-webkit-flex:1;flex:1}\n.",[1],"navigator-arrow{padding-right:",[0,26],";position:relative}\n.",[1],"navigator-arrow:after{border-color:#888;border-style:solid;border-width:",[0,2]," ",[0,2]," 0 0;content:' ';display:inline-block;height:",[0,18],";margin-top:",[0,-8],";position:absolute;right:",[0,28],";top:50%;-webkit-transform:matrix(.71,.71,-.71,.71,0,0);transform:matrix(.71,.71,-.71,.71,0,0);width:",[0,18],"}\n.",[1],"kind-list-item{background-color:#fff;border-radius:",[0,4],";margin:",[0,20]," 0;overflow:hidden}\n.",[1],"kind-list-item:first-child{margin-top:0}\n.",[1],"kind-list-text{-webkit-flex:1;flex:1}\n.",[1],"kind-list-img{height:",[0,60],";width:",[0,60],"}\n.",[1],"kind-list-item-hd{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding:",[0,30],";transition:opacity .3s}\n.",[1],"kind-list-item-hd-show{opacity:.2}\n.",[1],"kind-list-item-bd{height:0;overflow:hidden}\n.",[1],"kind-list-item-bd-show{height:auto}"];
if(!__COMMON_STYLESHEETS__.hasOwnProperty('macle_demo_EN/page/common/lib/weui.mass'))__COMMON_STYLESHEETS__['macle_demo_EN/page/common/lib/weui.mass']=["body{font-family:-apple-system-font,Helvetica Neue,sans-serif;line-height:1.6}\nma-icon{vertical-align:middle}\n.",[1],"weui-cells{background-color:#fff;font-size:17px;line-height:1.41176471;margin-top:1.17647059em;position:relative}\n.",[1],"weui-cells:before{border-top:",[0,1]," solid #d9d9d9;top:0}\n.",[1],"weui-cells:after,.",[1],"weui-cells:before{color:#d9d9d9;content:' ';height:1px;left:0;position:absolute;right:0}\n.",[1],"weui-cells:after{border-bottom:",[0,1]," solid #d9d9d9;bottom:0}\n.",[1],"weui-cells__title{color:#999;font-size:14px;margin-bottom:.3em;margin-top:.77em;padding-left:15px;padding-right:15px}\n.",[1],"weui-cells_after-title{margin-top:0}\n.",[1],"weui-cells__tips{color:#999;font-size:14px;margin-top:.3em;padding-left:15px;padding-right:15px}\n.",[1],"weui-cell{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding:10px 15px;position:relative}\n.",[1],"weui-cell:before{border-top:",[0,1]," solid #d9d9d9;color:#d9d9d9;content:' ';height:1px;left:0;left:15px;position:absolute;right:0;top:0}\n.",[1],"weui-cell:first-child:before{display:none}\n.",[1],"weui-cell_active{background-color:#ececec}\n.",[1],"weui-cell_primary{-webkit-align-items:flex-start;align-items:flex-start}\n.",[1],"weui-cell__bd{-webkit-flex:1;flex:1}\n.",[1],"weui-cell__ft{color:#999;text-align:right}\n.",[1],"weui-cell_access{color:inherit}\n.",[1],"weui-cell__ft_in-access{padding-right:13px;position:relative}\n.",[1],"weui-cell__ft_in-access:after{border-color:#c8c8cd;border-style:solid;border-width:2px 2px 0 0;content:' ';display:inline-block;height:6px;margin-top:-4px;position:relative;position:absolute;right:2px;top:-2px;top:50%;-webkit-transform:matrix(.71,.71,-.71,.71,0,0);transform:matrix(.71,.71,-.71,.71,0,0);width:6px}\n.",[1],"weui-cell_link{color:#586c94;font-size:14px}\n.",[1],"weui-cell_link:active{background-color:#ececec}\n.",[1],"weui-cell_link:first-child:before{display:block}\n.",[1],"weui-icon-radio{margin-left:3.2px;margin-right:3.2px}\n.",[1],"weui-icon-checkbox_circle,.",[1],"weui-icon-checkbox_success{margin-left:4.6px;margin-right:4.6px}\n.",[1],"weui-check__label:active{background-color:#ececec}\n.",[1],"weui-check{left:-9999px;position:absolute}\n.",[1],"weui-check__hd_in-checkbox{padding-right:.35em}\n.",[1],"weui-cell__ft_in-radio{padding-left:.35em}\n.",[1],"weui-cell_input{padding-bottom:0;padding-top:0}\n.",[1],"weui-label{word-wrap:break-word;width:105px;word-break:break-all}\n.",[1],"weui-input{height:2.58823529em;line-height:2.58823529em;min-height:2.58823529em}\n.",[1],"weui-toptips{word-wrap:break-word;color:#fff;font-size:14px;left:0;padding:5px;position:fixed;right:0;text-align:center;top:0;-webkit-transform:translateZ(0);transform:translateZ(0);word-break:break-all;z-index:5000}\n.",[1],"weui-toptips_warn{background-color:#e64340}\n.",[1],"weui-textarea{display:block;width:100%}\n.",[1],"weui-textarea-counter{color:#b2b2b2;text-align:right}\n.",[1],"weui-cell_warn,.",[1],"weui-textarea-counter_warn{color:#e64340}\n.",[1],"weui-form-preview{background-color:#fff;position:relative}\n.",[1],"weui-form-preview:before{border-top:",[0,1]," solid #d9d9d9;top:0}\n.",[1],"weui-form-preview:after,.",[1],"weui-form-preview:before{color:#d9d9d9;content:' ';height:1px;left:0;position:absolute;right:0}\n.",[1],"weui-form-preview:after{border-bottom:",[0,1]," solid #d9d9d9;bottom:0}\n.",[1],"weui-form-preview__value{font-size:14px}\n.",[1],"weui-form-preview__value_in-hd{font-size:26px}\n.",[1],"weui-form-preview__hd{line-height:2.5em;padding:10px 15px;position:relative;text-align:right}\n.",[1],"weui-form-preview__hd:after{border-bottom:",[0,1]," solid #d9d9d9;bottom:0;color:#d9d9d9;content:' ';height:1px;left:0;left:15px;position:absolute;right:0}\n.",[1],"weui-form-preview__bd{color:#999;font-size:.9em;line-height:2;padding:10px 15px;text-align:right}\n.",[1],"weui-form-preview__ft{display:-webkit-flex;display:flex;line-height:50px;position:relative}\n.",[1],"weui-form-preview__ft:after{border-top:",[0,1]," solid #d5d5d6;color:#d5d5d6;content:' ';height:1px;left:0;position:absolute;right:0;top:0}\n.",[1],"weui-form-preview__item{overflow:hidden}\n.",[1],"weui-form-preview__label{color:#999;float:left;margin-right:1em;min-width:4em;text-align:justify;text-align-last:justify}\n.",[1],"weui-form-preview__value{word-wrap:break-word;display:block;overflow:hidden;word-break:normal}\n.",[1],"weui-form-preview__btn{color:#3cc51f;display:block;-webkit-flex:1;flex:1;position:relative;text-align:center}\n.",[1],"weui-form-preview__btn:after{border-left:",[0,1]," solid #d5d5d6;bottom:0;color:#d5d5d6;content:' ';left:0;position:absolute;top:0;width:1px}\n.",[1],"weui-form-preview__btn:first-child:after{display:none}\n.",[1],"weui-form-preview__btn_active{background-color:#eee}\n.",[1],"weui-form-preview__btn_default{color:#999}\n.",[1],"weui-form-preview__btn_primary{color:#0bb20c}\n.",[1],"weui-cell_select{padding:0}\n.",[1],"weui-select{border-right:",[0,1]," solid #d9d9d9;height:2.58823529em;line-height:2.58823529em;min-height:2.58823529em;padding-left:15px;padding-right:30px;position:relative}\n.",[1],"weui-select:before{border-color:#c8c8cd;border-style:solid;border-width:2px 2px 0 0;content:' ';display:inline-block;height:6px;margin-top:-4px;position:relative;position:absolute;right:15px;top:-2px;top:50%;-webkit-transform:matrix(.71,.71,-.71,.71,0,0);transform:matrix(.71,.71,-.71,.71,0,0);width:6px}\n.",[1],"weui-select_in-select-after{padding-left:0}\n.",[1],"weui-cell__bd_in-select-before,.",[1],"weui-cell__hd_in-select-after{padding-left:15px}\n.",[1],"weui-cell_vcode{padding-right:0}\n.",[1],"weui-vcode-btn,.",[1],"weui-vcode-img{height:2.58823529em;margin-left:5px;vertical-align:middle}\n.",[1],"weui-vcode-btn{border-left:1px solid #e5e5e5;color:#3cc51f;display:inline-block;font-size:17px;line-height:2.58823529em;padding:0 .6em 0 .7em;white-space:nowrap}\n.",[1],"weui-vcode-btn:active{color:#52a341}\n.",[1],"weui-cell_switch{padding-bottom:6px;padding-top:6px}\n.",[1],"weui-uploader__hd{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding-bottom:10px}\n.",[1],"weui-uploader__title{-webkit-flex:1;flex:1}\n.",[1],"weui-uploader__info{color:#b2b2b2}\n.",[1],"weui-uploader__bd{margin-bottom:-4px;margin-right:-9px;overflow:hidden}\n.",[1],"weui-uploader__file{float:left;margin-bottom:9px;margin-right:9px}\n.",[1],"weui-uploader__img{display:block;height:79px;width:79px}\n.",[1],"weui-uploader__file_status{position:relative}\n.",[1],"weui-uploader__file_status:before{background-color:rgba(0,0,0,.5);bottom:0;content:' ';left:0;position:absolute;right:0;top:0}\n.",[1],"weui-uploader__file-content{color:#fff;left:50%;position:absolute;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}\n.",[1],"weui-uploader__input-box{border:1px solid #d9d9d9;float:left;height:77px;margin-bottom:9px;margin-right:9px;position:relative;width:77px}\n.",[1],"weui-uploader__input-box:after,.",[1],"weui-uploader__input-box:before{background-color:#d9d9d9;content:' ';left:50%;position:absolute;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}\n.",[1],"weui-uploader__input-box:before{height:39.5px;width:2px}\n.",[1],"weui-uploader__input-box:after{height:2px;width:39.5px}\n.",[1],"weui-uploader__input-box:active{border-color:#999}\n.",[1],"weui-uploader__input-box:active:after,.",[1],"weui-uploader__input-box:active:before{background-color:#999}\n.",[1],"weui-uploader__input{height:100%;left:0;opacity:0;position:absolute;top:0;width:100%;z-index:1}\n.",[1],"weui-article{font-size:15px;padding:20px 15px}\n.",[1],"weui-article__section{margin-bottom:1.5em}\n.",[1],"weui-article__h1{font-size:18px;font-weight:400;margin-bottom:.9em}\n.",[1],"weui-article__h2{font-size:16px;font-weight:400;margin-bottom:.34em}\n.",[1],"weui-article__h3{font-size:15px;font-weight:400;margin-bottom:.34em}\n.",[1],"weui-article__p{margin:0 0 .8em}\n.",[1],"weui-msg{padding-top:36px;text-align:center}\n.",[1],"weui-msg__link{color:#586c94;display:inline}\n.",[1],"weui-msg__icon-area{margin-bottom:30px}\n.",[1],"weui-msg__text-area{margin-bottom:25px;padding:0 20px}\n.",[1],"weui-msg__title{font-size:20px;font-weight:400;margin-bottom:5px}\n.",[1],"weui-msg__desc{color:#999;font-size:14px}\n.",[1],"weui-msg__opr-area{margin-bottom:25px}\n.",[1],"weui-msg__extra-area{color:#999;font-size:14px;margin-bottom:15px}@media screen and (min-height:438px){.",[1],"weui-msg__extra-area{bottom:0;left:0;position:fixed;text-align:center;width:100%}}\n.",[1],"weui-flex{display:-webkit-flex;display:flex}\n.",[1],"weui-flex__item{-webkit-flex:1;flex:1}\n.",[1],"weui-btn{margin-top:15px}\n.",[1],"weui-btn:first-child{margin-top:0}\n.",[1],"weui-btn-area{margin:1.17647059em 15px .3em}\n.",[1],"weui-agree{display:block;font-size:13px;padding:.5em 15px}\n.",[1],"weui-agree__text{color:#999}\n.",[1],"weui-agree__link{color:#586c94;display:inline}\n.",[1],"weui-agree__checkbox{left:-9999px;position:absolute}\n.",[1],"weui-agree__checkbox-icon{background-color:#fff;border:1px solid #d1d1d1;border-radius:3px;display:inline-block;height:11px;position:relative;top:2px;width:11px}\n.",[1],"weui-agree__checkbox-icon-check{left:1px;position:absolute;top:1px}\n.",[1],"weui-footer{color:#999;font-size:14px;text-align:center}\n.",[1],"weui-footer_fixed-bottom{bottom:.52em;left:0;position:fixed;right:0}\n.",[1],"weui-footer__links{font-size:0}\n.",[1],"weui-footer__link{color:#586c94;display:inline-block;font-size:14px;margin:0 .62em;position:relative;vertical-align:top}\n.",[1],"weui-footer__link:before{border-left:",[0,1]," solid #c7c7c7;bottom:0;bottom:.36em;color:#c7c7c7;content:' ';left:0;left:-.65em;position:absolute;top:0;top:.36em;width:1px}\n.",[1],"weui-footer__link:first-child:before{display:none}\n.",[1],"weui-footer__text{font-size:12px;padding:0 .34em}\n.",[1],"weui-grids{border-left:",[0,1]," solid #d9d9d9;border-top:",[0,1]," solid #d9d9d9;overflow:hidden}\n.",[1],"weui-grid{border-bottom:",[0,1]," solid #d9d9d9;border-right:",[0,1]," solid #d9d9d9;box-sizing:border-box;float:left;padding:20px 10px;position:relative;width:33.33333333%}\n.",[1],"weui-grid_active{background-color:#ececec}\n.",[1],"weui-grid__icon{display:block;height:28px;margin:0 auto;width:28px}\n.",[1],"weui-grid__label{color:#000;display:block;font-size:14px;margin-top:5px;overflow:hidden;text-align:center;text-overflow:ellipsis;white-space:nowrap}\n.",[1],"weui-loading{-webkit-animation:weuiLoading 1s steps(12) infinite;animation:weuiLoading 1s steps(12) infinite;background:transparent url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjAiIGhlaWdodD0iMTIwIiB2aWV3Qm94PSIwIDAgMTAwIDEwMCI+PHBhdGggZmlsbD0ibm9uZSIgZD0iTTAgMGgxMDB2MTAwSDB6Ii8+PHJlY3Qgd2lkdGg9IjciIGhlaWdodD0iMjAiIHg9IjQ2LjUiIHk9IjQwIiBmaWxsPSIjRTlFOUU5IiByeD0iNSIgcnk9IjUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgLTMwKSIvPjxyZWN0IHdpZHRoPSI3IiBoZWlnaHQ9IjIwIiB4PSI0Ni41IiB5PSI0MCIgZmlsbD0iIzk4OTY5NyIgcng9IjUiIHJ5PSI1IiB0cmFuc2Zvcm09InJvdGF0ZSgzMCAxMDUuOTggNjUpIi8+PHJlY3Qgd2lkdGg9IjciIGhlaWdodD0iMjAiIHg9IjQ2LjUiIHk9IjQwIiBmaWxsPSIjOUI5OTlBIiByeD0iNSIgcnk9IjUiIHRyYW5zZm9ybT0icm90YXRlKDYwIDc1Ljk4IDY1KSIvPjxyZWN0IHdpZHRoPSI3IiBoZWlnaHQ9IjIwIiB4PSI0Ni41IiB5PSI0MCIgZmlsbD0iI0EzQTFBMiIgcng9IjUiIHJ5PSI1IiB0cmFuc2Zvcm09InJvdGF0ZSg5MCA2NSA2NSkiLz48cmVjdCB3aWR0aD0iNyIgaGVpZ2h0PSIyMCIgeD0iNDYuNSIgeT0iNDAiIGZpbGw9IiNBQkE5QUEiIHJ4PSI1IiByeT0iNSIgdHJhbnNmb3JtPSJyb3RhdGUoMTIwIDU4LjY2IDY1KSIvPjxyZWN0IHdpZHRoPSI3IiBoZWlnaHQ9IjIwIiB4PSI0Ni41IiB5PSI0MCIgZmlsbD0iI0IyQjJCMiIgcng9IjUiIHJ5PSI1IiB0cmFuc2Zvcm09InJvdGF0ZSgxNTAgNTQuMDIgNjUpIi8+PHJlY3Qgd2lkdGg9IjciIGhlaWdodD0iMjAiIHg9IjQ2LjUiIHk9IjQwIiBmaWxsPSIjQkFCOEI5IiByeD0iNSIgcnk9IjUiIHRyYW5zZm9ybT0icm90YXRlKDE4MCA1MCA2NSkiLz48cmVjdCB3aWR0aD0iNyIgaGVpZ2h0PSIyMCIgeD0iNDYuNSIgeT0iNDAiIGZpbGw9IiNDMkMwQzEiIHJ4PSI1IiByeT0iNSIgdHJhbnNmb3JtPSJyb3RhdGUoLTE1MCA0NS45OCA2NSkiLz48cmVjdCB3aWR0aD0iNyIgaGVpZ2h0PSIyMCIgeD0iNDYuNSIgeT0iNDAiIGZpbGw9IiNDQkNCQ0IiIHJ4PSI1IiByeT0iNSIgdHJhbnNmb3JtPSJyb3RhdGUoLTEyMCA0MS4zNCA2NSkiLz48cmVjdCB3aWR0aD0iNyIgaGVpZ2h0PSIyMCIgeD0iNDYuNSIgeT0iNDAiIGZpbGw9IiNEMkQyRDIiIHJ4PSI1IiByeT0iNSIgdHJhbnNmb3JtPSJyb3RhdGUoLTkwIDM1IDY1KSIvPjxyZWN0IHdpZHRoPSI3IiBoZWlnaHQ9IjIwIiB4PSI0Ni41IiB5PSI0MCIgZmlsbD0iI0RBREFEQSIgcng9IjUiIHJ5PSI1IiB0cmFuc2Zvcm09InJvdGF0ZSgtNjAgMjQuMDIgNjUpIi8+PHJlY3Qgd2lkdGg9IjciIGhlaWdodD0iMjAiIHg9IjQ2LjUiIHk9IjQwIiBmaWxsPSIjRTJFMkUyIiByeD0iNSIgcnk9IjUiIHRyYW5zZm9ybT0icm90YXRlKC0zMCAtNS45OCA2NSkiLz48L3N2Zz4=) no-repeat;background-size:100%;display:inline-block;height:20px;margin:0 5px;vertical-align:middle;width:20px}@-webkit-keyframes weuiLoading{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}\nto{-webkit-transform:rotate(1turn);transform:rotate(1turn)}}@keyframes weuiLoading{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}\nto{-webkit-transform:rotate(1turn);transform:rotate(1turn)}}\n.",[1],"weui-badge{background-color:#f43530;border-radius:18px;color:#fff;display:inline-block;font-size:12px;line-height:1.2;min-width:8px;padding:.15em .4em;text-align:center;vertical-align:middle}\n.",[1],"weui-badge_dot{min-width:0;padding:.4em}\n.",[1],"weui-loadmore{font-size:14px;line-height:1.6em;margin:1.5em auto;text-align:center;width:65%}\n.",[1],"weui-loadmore__tips{display:inline-block;vertical-align:middle}\n.",[1],"weui-loadmore_line{border-top:1px solid #e5e5e5;margin-top:2.4em}\n.",[1],"weui-loadmore__tips_in-line{background-color:#fff;color:#999;padding:0 .55em;position:relative;top:-.9em}\n.",[1],"weui-loadmore__tips_in-dot{height:1.6em;padding:0 .16em;position:relative;width:4px}\n.",[1],"weui-loadmore__tips_in-dot:before{background-color:#e5e5e5;border-radius:50%;content:' ';height:4px;left:50%;margin-left:-2px;margin-top:-1px;position:absolute;top:50%;width:4px}\n.",[1],"weui-panel{background-color:#fff;margin-top:10px;overflow:hidden;position:relative}\n.",[1],"weui-panel:first-child{margin-top:0}\n.",[1],"weui-panel:before{border-top:",[0,1]," solid #e5e5e5;top:0}\n.",[1],"weui-panel:after,.",[1],"weui-panel:before{color:#e5e5e5;content:' ';height:1px;left:0;position:absolute;right:0}\n.",[1],"weui-panel:after{border-bottom:",[0,1]," solid #e5e5e5;bottom:0}\n.",[1],"weui-panel__hd{color:#999;font-size:13px;padding:14px 15px 10px;position:relative}\n.",[1],"weui-panel__hd:after{border-bottom:",[0,1]," solid #e5e5e5;bottom:0;color:#e5e5e5;content:' ';height:1px;left:0;left:15px;position:absolute;right:0}\n.",[1],"weui-media-box{padding:15px;position:relative}\n.",[1],"weui-media-box:before{border-top:",[0,1]," solid #e5e5e5;color:#e5e5e5;content:' ';height:1px;left:0;left:15px;position:absolute;right:0;top:0}\n.",[1],"weui-media-box:first-child:before{display:none}\n.",[1],"weui-media-box__title{word-wrap:normal;word-wrap:break-word;font-size:17px;font-weight:400;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width:auto;word-break:break-all}\n.",[1],"weui-media-box__desc{-webkit-box-orient:vertical;-webkit-line-clamp:2;color:#999;display:-webkit-box;font-size:13px;line-height:1.2;overflow:hidden;text-overflow:ellipsis}\n.",[1],"weui-media-box__info{color:#cecece;font-size:13px;line-height:1em;list-style:none;margin-top:15px;overflow:hidden;padding-bottom:5px}\n.",[1],"weui-media-box__info__meta{float:left;padding-right:1em}\n.",[1],"weui-media-box__info__meta_extra{border-left:1px solid #cecece;padding-left:1em}\n.",[1],"weui-media-box__title_in-text{margin-bottom:8px}\n.",[1],"weui-media-box_appmsg{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex}\n.",[1],"weui-media-box__thumb{height:100%;vertical-align:top;width:100%}\n.",[1],"weui-media-box__hd_in-appmsg{height:60px;line-height:60px;margin-right:.8em;text-align:center;width:60px}\n.",[1],"weui-media-box__bd_in-appmsg{-webkit-flex:1;flex:1;min-width:0}\n.",[1],"weui-media-box_small-appmsg{padding:0}\n.",[1],"weui-cells_in-small-appmsg{margin-top:0}\n.",[1],"weui-cells_in-small-appmsg:before{display:none}\n.",[1],"weui-progress{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex}\n.",[1],"weui-progress__bar{-webkit-flex:1;flex:1}\n.",[1],"weui-progress__opr{font-size:0;margin-left:15px}\n.",[1],"weui-navbar{border-bottom:",[0,1]," solid #ccc;display:-webkit-flex;display:flex;position:absolute;top:0;width:100%;z-index:500}\n.",[1],"weui-navbar__item{display:block;-webkit-flex:1;flex:1;font-size:0;padding:13px 0;position:relative;text-align:center}\n.",[1],"weui-navbar__item.",[1],"weui-bar__item_on{color:#1aad19}\n.",[1],"weui-navbar__slider{background-color:#1aad19;bottom:0;content:' ';height:3px;left:0;position:absolute;transition:-webkit-transform .3s;transition:transform .3s;transition:transform .3s,-webkit-transform .3s;width:6em}\n.",[1],"weui-navbar__title{word-wrap:normal;display:inline-block;font-size:15px;max-width:8em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width:auto}\n.",[1],"weui-tab{height:100%;position:relative}\n.",[1],"weui-tab__panel{-webkit-overflow-scrolling:touch;box-sizing:border-box;height:100%;overflow:auto;padding-top:50px}\n.",[1],"weui-search-bar{background-color:#efeff4;border-bottom:",[0,1]," solid #d7d6dc;border-top:",[0,1]," solid #d7d6dc;box-sizing:border-box;display:-webkit-flex;display:flex;padding:8px 10px;position:relative}\n.",[1],"weui-icon-search{font-size:inherit;margin-right:8px}\n.",[1],"weui-icon-search_in-box{left:10px;position:absolute;top:7px}\n.",[1],"weui-search-bar__text{display:inline-block;font-size:14px;vertical-align:middle}\n.",[1],"weui-search-bar__form{background:#fff;border:",[0,1]," solid #e6e6ea;border-radius:5px;-webkit-flex:auto;flex:auto;position:relative}\n.",[1],"weui-search-bar__box{box-sizing:border-box;padding-left:30px;padding-right:30px;position:relative;width:100%;z-index:1}\n.",[1],"weui-search-bar__input{font-size:14px;height:28px;line-height:28px}\n.",[1],"weui-icon-clear{font-size:0;padding:7px 8px;position:absolute;right:0;top:0}\n.",[1],"weui-search-bar__label{background:#fff;border-radius:3px;bottom:0;color:#9b9b9b;left:0;line-height:28px;position:absolute;right:0;text-align:center;top:0;z-index:2}\n.",[1],"weui-search-bar__cancel-btn{color:#09bb07;line-height:28px;margin-left:10px;white-space:nowrap}"];


var setCssToHead=function(file,info){
  var importedStyles={},info=info||{};
  function makeup(file,opt){
    var isPath=typeof(file)==="string";
    if(isPath&&importedStyles.hasOwnProperty(file))return "";
    if(isPath)importedStyles[file]=1;
    var contents=isPath?__COMMON_STYLESHEETS__[file]:file,res="";
    for(var i=contents.length-1;i>=0;i--){
      var content=contents[i];
      if(typeof(content)==="object"){
        var op=content[0];
        if(op===0)res=transformRPX(content[1],opt.deviceWidth)+"px"+res; // rpx
        else if(op===1)res=opt.suffix+res; // suffix
        else if(op===2)res=makeup(content[1],opt)+res; // import at the top
        else if(op===3)res=makeup(content[1],opt)+res; // import not at the top
      }else{
        res=content+res;
      }
    }
    return res;
  }
  var rewritor=function(suffix,opt,style,tFile,tInfo){
    opt=opt||{};
    suffix=suffix||"";
    opt.suffix=suffix;
    tFile=tFile||file;
    tInfo=tInfo||info;
    css=makeup(tFile,opt);
    if(!css)return;
    
    if(!style){
      var head=document.head||document.getElementsByTagName('head')[0];
      style=document.createElement('style');
      style.type='text/css';
      style.setAttribute("mass:path",tInfo.path);
      head.appendChild(style);
    }
    if(style.childNodes.length==0)style.appendChild(document.createTextNode(css));
    else style.childNodes[0].nodeValue=css;
  }
  return rewritor;
}
__maAppCode__['app.json']={"window":{"navigationBarTextStyle":"black","navigationBarTitleText":"Example display","navigationBarBackgroundColor":"#F8F8F8","backgroundColor":"#F8F8F8"}};

__maAppCode__['component/communication-detail/index.json']={"component":true,"usingComponents":{"detailItem":"component/communication-detailItem/index"}};
__maAppCode__['component/communication-detailItem/index.json']={"component":true};
__maAppCode__['component/detail/index.json']={"component":true,"usingComponents":{"detailItem":"component/detailItem/index"}};
__maAppCode__['component/detailItem/index.json']={"component":true};
__maAppCode__['macle_demo_EN/component/communication-detail/index.json']={"component":true,"usingComponents":{"detailItem":"component/communication-detailItem/index"}};
__maAppCode__['macle_demo_EN/component/communication-detailItem/index.json']={"component":true};
__maAppCode__['macle_demo_EN/component/detail/index.json']={"component":true,"usingComponents":{"detailItem":"component/detailItem/index"}};
__maAppCode__['macle_demo_EN/component/detailItem/index.json']={"component":true};
__maAppCode__['macle_demo_EN/page/API/pages/application-event/application-event.json']={"navigationBarTitleText":"Application-level events"};
__maAppCode__['macle_demo_EN/page/API/pages/canIUse/canIUse.json']={"navigationBarTitleText":"canIUse"};
__maAppCode__['macle_demo_EN/page/API/pages/chooseContact/chooseContact.json']={"navigationBarTitleText":"Select Contact"};
__maAppCode__['macle_demo_EN/page/API/pages/compressImage/compressImage.json']={"navigationBarTitleText":"Compressed Picture"};
__maAppCode__['macle_demo_EN/page/API/pages/downloadFile/downloadFile.json']={"navigationBarTitleText":"Downloading files"};
__maAppCode__['macle_demo_EN/page/API/pages/file/file.json']={"navigationBarTitleText":"document"};
__maAppCode__['macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.json']={"navigationBarTitleText":"Obtaining the Battery Level of a Mobile Phone"};
__maAppCode__['macle_demo_EN/page/API/pages/get-image-info/get-image-info.json']={"navigationBarTitleText":"Obtaining Image Information"};
__maAppCode__['macle_demo_EN/page/API/pages/get-location/get-location.json']={"navigationBarTitleText":"Get Geographic Location"};
__maAppCode__['macle_demo_EN/page/API/pages/get-network-type/get-network-type.json']={"navigationBarTitleText":"Obtain the network type"};
__maAppCode__['macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.json']={"navigationBarTitleText":"Synchronously obtaining mobile phone system information"};
__maAppCode__['macle_demo_EN/page/API/pages/get-system-info/get-system-info.json']={"navigationBarTitleText":"Obtaining Mobile Phone System Information"};
__maAppCode__['macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.json']={"navigationBarTitleText":"Obtains the layout position information of a menu button"};
__maAppCode__['macle_demo_EN/page/API/pages/gyroscope/gyroscope.json']={"navigationBarTitleText":"gyroscope"};
__maAppCode__['macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.json']={"navigationBarTitleText":"Hide Keyboard"};
__maAppCode__['macle_demo_EN/page/API/pages/loading/loading.json']={"navigationBarTitleText":"The Loading dialog box is displayed"};
__maAppCode__['macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.json']={"navigationBarTitleText":"Calling"};
__maAppCode__['macle_demo_EN/page/API/pages/mediaImage/mediaImage.json']={"navigationBarTitleText":"mediaImage"};
__maAppCode__['macle_demo_EN/page/API/pages/memory-warning/memory-warning.json']={"navigationBarTitleText":"performance"};
__maAppCode__['macle_demo_EN/page/API/pages/modal/modal.json']={"navigationBarTitleText":"Display modal pop-up window"};
__maAppCode__['macle_demo_EN/page/API/pages/navigator/navigate.json']={"navigationBarTitleText":"navigatePage"};
__maAppCode__['macle_demo_EN/page/API/pages/navigator/navigator.json']={"navigationBarTitleText":"interface switch"};
__maAppCode__['macle_demo_EN/page/API/pages/navigator/redirect.json']={"navigationBarTitleText":"redirectPage"};
__maAppCode__['macle_demo_EN/page/API/pages/network/network.json']={"navigationBarTitleText":"Network change monitor"};
__maAppCode__['macle_demo_EN/page/API/pages/open-document/open-document.json']={"navigationBarTitleText":"Document Open"};
__maAppCode__['macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.json']={"enablePullDownRefresh":true,"navigationBarTitleText":"pull to refres"};
__maAppCode__['macle_demo_EN/page/API/pages/request/request.json']={"navigationBarTitleText":"network request"};
__maAppCode__['macle_demo_EN/page/API/pages/scanCode/scanCode.json']={"navigationBarTitleText":"Scan the QR code"};
__maAppCode__['macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.json']={"navigationBarTitleText":"screen brightness"};
__maAppCode__['macle_demo_EN/page/API/pages/set-background/set-background.json']={"enablePullDownRefresh":true,"navigationBarTitleText":"Background settings"};
__maAppCode__['macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.json']={"navigationBarTitleText":"Set the color of the navigation bar."};
__maAppCode__['macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.json']={"navigationBarTitleText":"Setting the interface title"};
__maAppCode__['macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.json']={"navigationBarTitleText":"Show Action Menu"};
__maAppCode__['macle_demo_EN/page/API/pages/storage-sync/storage-sync.json']={"navigationBarTitleText":"data storage"};
__maAppCode__['macle_demo_EN/page/API/pages/storage/storage.json']={"navigationBarTitleText":"data storage"};
__maAppCode__['macle_demo_EN/page/API/pages/toast/toast.json']={"navigationBarTitleText":"Display message prompt box"};
__maAppCode__['macle_demo_EN/page/API/pages/uploadFile/uploadFile.json']={"navigationBarTitleText":"Upload a file"};
__maAppCode__['macle_demo_EN/page/API/pages/vibrate/vibrate.json']={"navigationBarTitleText":"vibrate"};
__maAppCode__['macle_demo_EN/page/API/pages/websocket/websocket.json']={"navigationBarTitleText":"network request"};
__maAppCode__['macle_demo_EN/page/component/pages/audio/audio.json']={"navigationBarTitleText":"audio"};
__maAppCode__['macle_demo_EN/page/component/pages/button/button.json']={"navigationBarTitleText":"button"};
__maAppCode__['macle_demo_EN/page/component/pages/camera/camera.json']={"navigationBarTitleText":"Camera"};
__maAppCode__['macle_demo_EN/page/component/pages/checkbox/checkbox.json']={"navigationBarTitleText":"checkbox"};
__maAppCode__['macle_demo_EN/page/component/pages/cover-image/cover-image.json']={"navigationBarTitleText":"Cover-Image"};
__maAppCode__['macle_demo_EN/page/component/pages/cover-view/cover-view.json']={"navigationBarTitleText":"Cover-View"};
__maAppCode__['macle_demo_EN/page/component/pages/form/form.json']={"navigationBarTitleText":"form"};
__maAppCode__['macle_demo_EN/page/component/pages/icon/icon.json']={"navigationBarTitleText":"icon"};
__maAppCode__['macle_demo_EN/page/component/pages/image/image.json']={"navigationBarTitleText":"image"};
__maAppCode__['macle_demo_EN/page/component/pages/input/input.json']={"navigationBarTitleText":"input"};
__maAppCode__['macle_demo_EN/page/component/pages/label/label.json']={"navigationBarTitleText":"label"};
__maAppCode__['macle_demo_EN/page/component/pages/navigator/navigate.json']={"navigationBarTitleText":"navigatePage"};
__maAppCode__['macle_demo_EN/page/component/pages/navigator/navigator.json']={"navigationBarTitleText":"navigator"};
__maAppCode__['macle_demo_EN/page/component/pages/navigator/redirect.json']={"navigationBarTitleText":"redirectPage"};
__maAppCode__['macle_demo_EN/page/component/pages/navigator/reLaunch.json']={"navigationBarTitleText":"relaunchPage"};
__maAppCode__['macle_demo_EN/page/component/pages/picker-view/picker-view.json']={"navigationBarTitleText":"picker-view"};
__maAppCode__['macle_demo_EN/page/component/pages/picker/picker.json']={"navigationBarTitleText":"picker"};
__maAppCode__['macle_demo_EN/page/component/pages/progress/progress.json']={"navigationBarTitleText":"progress"};
__maAppCode__['macle_demo_EN/page/component/pages/radio/radio.json']={"navigationBarTitleText":"radio"};
__maAppCode__['macle_demo_EN/page/component/pages/rich-text/rich-text.json']={"navigationBarTitleText":"rich-text"};
__maAppCode__['macle_demo_EN/page/component/pages/scroll-view/scroll-view.json']={"navigationBarTitleText":"scroll-view"};
__maAppCode__['macle_demo_EN/page/component/pages/slider/slider.json']={"navigationBarTitleText":"slider"};
__maAppCode__['macle_demo_EN/page/component/pages/swiper/swiper.json']={"navigationBarTitleText":"swiper"};
__maAppCode__['macle_demo_EN/page/component/pages/switch/switch.json']={"navigationBarTitleText":"switch"};
__maAppCode__['macle_demo_EN/page/component/pages/text/text.json']={"navigationBarTitleText":"text"};
__maAppCode__['macle_demo_EN/page/component/pages/video/video.json']={"navigationBarTitleText":"video"};
__maAppCode__['macle_demo_EN/page/component/pages/view/view.json']={"navigationBarTitleText":"view","enablePullDownRefresh":true};
__maAppCode__['macle_demo_EN/page/component/pages/web-view/web-view.json']={"navigationBarTitleText":"web-view","enablePullDownRefresh":true};
__maAppCode__['macle_demo_EN/page/framework/pages/communication/communication.json']={"navigationBarTitleText":"组件间通信","usingComponents":{"detail":"component/communication-detail/index"}};
__maAppCode__['macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.json']={"navigationBarTitleText":"macle-i18n"};
__maAppCode__['macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.json']={"navigationBarTitleText":"View Startup Logs"};
__maAppCode__['macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.json']={"navigationBarTitleText":"sjs-drag"};
__maAppCode__['macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.json']={"navigationBarTitleText":"sjs-filter"};
__maAppCode__['macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.json']={"component":true,"usingComponents":{}};
__maAppCode__['macle_demo_EN/page/tabbar/api/index.json']={"navigationBarTitleText":"Applet interface capability display","usingComponents":{"set-tab-bar":"macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar"}};
__maAppCode__['macle_demo_EN/page/tabbar/component/index.json']={"navigationBarTitleText":"Applet official component display"};
__maAppCode__['macle_demo_EN/page/tabbar/framework/index.json']={"navigationBarTitleText":"Applet framework capability display"};
__maAppCode__['page/tabbar/api/components/set-tab-bar/set-tab-bar.json']={"component":true,"usingComponents":{}};
__maAppCode__['page/tabbar/api/index.json']={"navigationBarTitleText":"Applet interface capability display","usingComponents":{"set-tab-bar":"page/tabbar/api/components/set-tab-bar/set-tab-bar"}};
__maAppCode__['page/tabbar/component/index.json']={"navigationBarTitleText":"Applet official component display"};
__maAppCode__['page/tabbar/framework/index.json']={"navigationBarTitleText":"Applet framework capability display"};
__maAppCode__['page/tabbar/react/index.json']={"navigationBarTitleText":"Applet official component display"};

setCssToHead(["body{background-color:#f8f8f8;font-size:",[0,32],";height:100%;line-height:1.6}\nma-checkbox,ma-radio{margin-right:",[0,10],"}\nma-button{margin-bottom:",[0,20],";margin-top:",[0,20],"}\nma-form{width:100%}\n.",[1],"strong{font-weight:700}\n.",[1],"tc{text-align:center}\n.",[1],"container{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;font-size:",[0,32],";-webkit-justify-content:space-between;justify-content:space-between;min-height:100%}\n.",[1],"page-head{padding:",[0,60]," ",[0,50],";text-align:center}\n.",[1],"page-head-title{color:#bebebe;display:inline-block;font-size:",[0,32],";padding:0 ",[0,40]," ",[0,20],"}\n.",[1],"page-head-line{background-color:#d8d8d8;height:",[0,2],";margin:0 auto;width:",[0,150],"}\n.",[1],"page-head-desc{color:#9b9b9b;font-size:",[0,32],";padding-top:",[0,20],"}\n.",[1],"page-body{-webkit-flex-grow:1;flex-grow:1;overflow-x:hidden;width:100%}\n.",[1],"page-body-wrapper{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;width:100%}\n.",[1],"page-body-wording{height:",[0,400],";overflow:scroll;text-align:center;width:100%}\n.",[1],"page-body-info{-webkit-align-items:center;align-items:center;background-color:#fff;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;padding:",[0,50]," 0 ",[0,150],";width:100%}\n.",[1],"page-body-title{font-size:",[0,32],";margin-bottom:",[0,100],"}\n.",[1],"page-body-text{font-size:",[0,30],";line-height:26px}\n.",[1],"page-body-text-small{color:#000;font-size:",[0,24],";margin-bottom:",[0,100],"}\n.",[1],"page-foot{color:#1aad19;font-size:0;margin:",[0,100]," 0 ",[0,30],";text-align:center}\n.",[1],"icon-foot{height:",[0,20],";width:",[0,200],"}\n.",[1],"page-section{margin-bottom:",[0,60],";width:100%}\n.",[1],"page-section_center{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column}\n.",[1],"page-section:last-child{margin-bottom:0}\n.",[1],"page-section-gap{box-sizing:border-box;padding:0 ",[0,30],"}\n.",[1],"page-section-spacing{box-sizing:border-box;padding:0 ",[0,80],"}\n.",[1],"page-section-title{color:#999;font-size:",[0,28],";margin-bottom:",[0,10],";padding-left:",[0,30],";padding-right:",[0,30],"}\n.",[1],"page-section-gap .",[1],"page-section-title{padding-left:0;padding-right:0}\n.",[1],"btn-area{box-sizing:border-box;margin-top:",[0,60],";padding:0 ",[0,30],";width:100%}\n.",[1],"image-plus{border:",[0,2]," solid #d9d9d9;height:",[0,150],";position:relative;width:",[0,150],"}\n.",[1],"image-plus-nb{border:0}\n.",[1],"image-plus-text{color:#888;font-size:",[0,28],"}\n.",[1],"image-plus-horizontal{height:",[0,80],";width:",[0,4],"}\n.",[1],"image-plus-horizontal,.",[1],"image-plus-vertical{background-color:#d9d9d9;left:50%;position:absolute;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}\n.",[1],"image-plus-vertical{height:",[0,4],";width:",[0,80],"}\n.",[1],"demo-text-1{-webkit-align-items:center;align-items:center;background-color:#1aad19;color:#fff;font-size:",[0,36],";-webkit-justify-content:center;justify-content:center;position:relative}\n.",[1],"demo-text-1:before{content:'A';left:50%;position:absolute;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}\n.",[1],"demo-text-2{-webkit-align-items:center;align-items:center;background-color:#2782d7;color:#fff;font-size:",[0,36],";-webkit-justify-content:center;justify-content:center;position:relative}\n.",[1],"demo-text-2:before{content:'B';left:50%;position:absolute;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}\n.",[1],"demo-text-3{-webkit-align-items:center;align-items:center;background-color:#f1f1f1;color:#353535;font-size:",[0,36],";-webkit-justify-content:center;justify-content:center;position:relative}\n.",[1],"demo-text-3:before{content:'C';left:50%;position:absolute;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}"],{path:"./app.mass"})();
__maAppCode__['component/communication-detail/index.mass']=setCssToHead([".",[1],"box{background-color:bisque;height:200px;width:100%}\n.",[1],"test_color{margin-bottom:10px;padding-bottom:5px;padding-top:5px}"],{path:"./component/communication-detail/index.mass"});
__maAppCode__['component/communication-detailItem/index.mass']=setCssToHead([".",[1],"box{height:200px;width:100%}"],{path:"./component/communication-detailItem/index.mass"});
__maAppCode__['component/detail/index.mass']=setCssToHead([".",[1],"box{background-color:bisque;height:200px;width:100%}"],{path:"./component/detail/index.mass"});
__maAppCode__['component/detailItem/index.mass']=setCssToHead([".",[1],"child-box{background-color:#b4ecaf;height:300px;width:100%}"],{path:"./component/detailItem/index.mass"});
__maAppCode__['macle_demo_EN/component/communication-detail/index.mass']=setCssToHead([".",[1],"box{background-color:bisque;height:200px;width:100%}\n.",[1],"test_color{margin-bottom:10px;padding-bottom:5px;padding-top:5px}"],{path:"./macle_demo_EN/component/communication-detail/index.mass"});
__maAppCode__['macle_demo_EN/component/communication-detailItem/index.mass']=setCssToHead([".",[1],"box{height:200px;width:100%}"],{path:"./macle_demo_EN/component/communication-detailItem/index.mass"});
__maAppCode__['macle_demo_EN/component/detail/index.mass']=setCssToHead([".",[1],"box{background-color:bisque;height:200px;width:100%}"],{path:"./macle_demo_EN/component/detail/index.mass"});
__maAppCode__['macle_demo_EN/component/detailItem/index.mass']=setCssToHead([".",[1],"child-box{background-color:#b4ecaf;height:300px;width:100%}"],{path:"./macle_demo_EN/component/detailItem/index.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/application-event/application-event.mass']=setCssToHead([""],{path:"./macle_demo_EN/page/API/pages/application-event/application-event.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/canIUse/canIUse.mass']=setCssToHead([""],{path:"./macle_demo_EN/page/API/pages/canIUse/canIUse.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/chooseContact/chooseContact.mass']=setCssToHead([""],{path:"./macle_demo_EN/page/API/pages/chooseContact/chooseContact.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/compressImage/compressImage.mass']=setCssToHead([""],{path:"./macle_demo_EN/page/API/pages/compressImage/compressImage.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/downloadFile/downloadFile.mass']=setCssToHead([""],{path:"./macle_demo_EN/page/API/pages/downloadFile/downloadFile.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/file/file.mass']=setCssToHead([".",[1],"image{height:330px;width:100%}\n.",[1],"page-body-info{-webkit-align-items:center;align-items:center;box-sizing:border-box;display:-webkit-flex;display:flex;height:410px;-webkit-justify-content:center;justify-content:center;padding:15px}"],{path:"./macle_demo_EN/page/API/pages/file/file.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.mass']=setCssToHead([".",[1],"page-section{font-size:14px;margin:15px;padding:42px 30px 30px;width:auto}\n.",[1],"desc{margin-bottom:10px}\n.",[1],"input{font-size:39px;height:60px;line-height:60px}\n.",[1],"btn-area{padding:0}\n.",[1],"ma-cells{font-size:17px;line-height:1.41176471;margin-top:8px;overflow:hidden;position:relative}\n.",[1],"ma-cell{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding:16px;position:relative}\n.",[1],"ma-cell_input{background-color:#fff}\n.",[1],"ma-cell__bd{-webkit-flex:1;flex:1}\n.",[1],"ma-label{word-wrap:break-word;display:block;width:105px;word-break:break-all}\n.",[1],"ma-input{-webkit-appearance:none;background-color:transparent;border:0;color:inherit;font-size:inherit;height:1.41176471em;line-height:1.41176471;outline:0;width:100%}"],{path:"./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/get-image-info/get-image-info.mass']=setCssToHead([""],{path:"./macle_demo_EN/page/API/pages/get-image-info/get-image-info.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/get-location/get-location.mass']=setCssToHead([".",[1],"page-body-info{height:",[0,250],"}\n.",[1],"page-body-text-small{color:#000;font-size:",[0,24],";margin-bottom:",[0,100],"}\n.",[1],"page-body-text-location{display:-webkit-flex;display:flex;font-size:",[0,50],"}\n.",[1],"page-body-text-location ma-text{margin:",[0,10],"}"],{path:"./macle_demo_EN/page/API/pages/get-location/get-location.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/get-network-type/get-network-type.mass']=setCssToHead([".",[1],"weui-cell{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding:16px;position:relative}\n.",[1],"weui-cells{background-color:#fff;font-size:17px;line-height:1.41176471;margin-top:8px;overflow:hidden;position:relative}\n.",[1],"weui-cell__bd{min-height:24px;word-break:break-all}"],{path:"./macle_demo_EN/page/API/pages/get-network-type/get-network-type.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.mass']=setCssToHead([[2,"macle_demo_EN/page/common/lib/weui.mass"],""],{path:"./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/get-system-info/get-system-info.mass']=setCssToHead([[2,"macle_demo_EN/page/common/lib/weui.mass"],""],{path:"./macle_demo_EN/page/API/pages/get-system-info/get-system-info.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.mass']=setCssToHead([[2,"macle_demo_EN/page/common/lib/weui.mass"],""],{path:"./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/gyroscope/gyroscope.mass']=setCssToHead([".",[1],"page-body-info{height:",[0,250],"}\n.",[1],"page-body-text-small{color:#000;font-size:",[0,24],";margin-bottom:",[0,100],"}\n.",[1],"page-body-text-location{display:-webkit-flex;display:flex;font-size:",[0,50],"}\n.",[1],"page-body-text-location ma-text{margin:",[0,10],"}"],{path:"./macle_demo_EN/page/API/pages/gyroscope/gyroscope.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.mass']=setCssToHead([[2,"macle_demo_EN/page/common/lib/weui.mass"],".",[1],"page-section{margin-bottom:",[0,20],"}\n.",[1],"placeholderclass{font-weight:600}"],{path:"./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/loading/loading.mass']=setCssToHead([".",[1],"weui-cell{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding:16px;position:relative}\n.",[1],"weui-cells{background-color:#fff;font-size:17px;line-height:1.41176471;margin-top:8px;overflow:hidden;position:relative}\n.",[1],"weui-cell__bd{min-height:24px;word-break:break-all}"],{path:"./macle_demo_EN/page/API/pages/loading/loading.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.mass']=setCssToHead([".",[1],"page-section{background-color:var(--weui-BG-2);font-size:14px;margin:15px;padding:42px 30px 30px;width:auto}\n.",[1],"desc{margin-bottom:10px}\n.",[1],"input{border-bottom:1px solid var(--weui-FG-3);font-size:39px;height:60px;line-height:60px}\n.",[1],"btn-area{padding:0}"],{path:"./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/mediaImage/mediaImage.mass']=setCssToHead([".",[1],"weui-cells{background-color:var(--weui-BG-2);font-size:17px;line-height:1.41176471;margin-top:8px;overflow:hidden;position:relative}\n.",[1],"weui-cells:after{border-bottom:1px solid var(--weui-FG-3);bottom:0;-webkit-transform:scaleY(.5);transform:scaleY(.5);-webkit-transform-origin:0 100%;transform-origin:0 100%}\n.",[1],"weui-cells__title{color:var(--weui-FG-1);font-size:14px;line-height:1.4;margin-bottom:3px;margin-top:16px;padding-left:16px;padding-right:16px}\n.",[1],"weui-cells__title+.",[1],"weui-cells{margin-top:0}\n.",[1],"weui-cell{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding:16px;position:relative}\n.",[1],"weui-cell:before{border-top:1px solid var(--weui-FG-3);color:var(--weui-FG-3);content:' ';height:1px;left:0;left:16px;position:absolute;right:0;top:0;-webkit-transform:scaleY(.5);transform:scaleY(.5);-webkit-transform-origin:0 0;transform-origin:0 0;z-index:2}\n.",[1],"weui-cell__bd{-webkit-flex:1;flex:1}\n.",[1],"weui-label{word-wrap:break-word;display:block;width:105px;word-break:break-all}\n.",[1],"weui-input{-webkit-appearance:none;background-color:transparent;border:0;color:inherit;font-size:inherit;height:1.41176471em;line-height:1.41176471;outline:0;width:100%}\n.",[1],"weui-uploader{-webkit-flex:1;flex:1}\n.",[1],"weui-uploader__hd{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding-bottom:16px}\n.",[1],"weui-uploader__title{-webkit-flex:1;flex:1}\n.",[1],"weui-uploader__info{color:var(--weui-FG-2)}\n.",[1],"weui-uploader__bd{margin-bottom:-8px;margin-right:-8px;overflow:hidden}\n.",[1],"weui-uploader__files{list-style:none}\n.",[1],"weui-uploader__file{background:no-repeat 50%;background-size:cover}\n.",[1],"weui-uploader__file,.",[1],"weui-uploader__input-box{float:left;height:96px;margin-bottom:8px;margin-right:8px;width:96px}\n.",[1],"weui-uploader__input-box{background-color:#ededed;box-sizing:border-box;position:relative}@media(prefers-color-scheme:dark){.",[1],"weui-uploader__input-box{background-color:#2e2e2e}}\n.",[1],"weui-uploader__input-box:after,.",[1],"weui-uploader__input-box:before{background-color:#a3a3a3;content:' ';left:50%;position:absolute;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}@media(prefers-color-scheme:dark){.",[1],"weui-uploader__input-box:after,.",[1],"weui-uploader__input-box:before{background-color:#6d6d6d}}\n.",[1],"weui-uploader__input-box:before{height:32px;width:2px}\n.",[1],"weui-uploader__input-box:after{height:2px;width:32px}\n.",[1],"weui-uploader__input-box:active:after,.",[1],"weui-uploader__input-box:active:before{opacity:.7}\n.",[1],"weui-uploader__input{-webkit-tap-highlight-color:rgba(0,0,0,0);height:100%;left:0;opacity:0;position:absolute;top:0;width:100%;z-index:1}\nbody{--height:44px;--right:95px}\n.",[1],"weui-uploader__hd{display:block}\n.",[1],"weui-uploader__img{display:block;height:100%;width:100%}"],{path:"./macle_demo_EN/page/API/pages/mediaImage/mediaImage.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/memory-warning/memory-warning.mass']=setCssToHead([".",[1],"page-body-info{height:",[0,250],"}\n.",[1],"page-body-text-small{color:#000;font-size:",[0,24],";margin-bottom:",[0,100],"}\n.",[1],"page-body-text-location{display:-webkit-flex;display:flex;font-size:",[0,50],"}\n.",[1],"page-body-text-location ma-text{margin:",[0,10],"}"],{path:"./macle_demo_EN/page/API/pages/memory-warning/memory-warning.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/modal/modal.mass']=setCssToHead([""],{path:"./macle_demo_EN/page/API/pages/modal/modal.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/navigator/navigate.mass']=setCssToHead([".",[1],"btn-area{text-align:center}"],{path:"./macle_demo_EN/page/API/pages/navigator/navigate.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/navigator/navigator.mass']=setCssToHead([".",[1],"wrapper{padding:5px}"],{path:"./macle_demo_EN/page/API/pages/navigator/navigator.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/navigator/redirect.mass']=setCssToHead([".",[1],"wrapper{text-align:center}"],{path:"./macle_demo_EN/page/API/pages/navigator/redirect.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/network/network.mass']=setCssToHead([".",[1],"page-body-info{height:",[0,250],"}\n.",[1],"page-body-text-small{color:#000;font-size:",[0,24],";margin-bottom:",[0,100],"}\n.",[1],"page-body-text-location{display:-webkit-flex;display:flex;font-size:",[0,50],"}\n.",[1],"page-body-text-location ma-text{margin:",[0,10],"}"],{path:"./macle_demo_EN/page/API/pages/network/network.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/open-document/open-document.mass']=setCssToHead([""],{path:"./macle_demo_EN/page/API/pages/open-document/open-document.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.mass']=setCssToHead([""],{path:"./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/request/request.mass']=setCssToHead([""],{path:"./macle_demo_EN/page/API/pages/request/request.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/scanCode/scanCode.mass']=setCssToHead([".",[1],"weui-cells__title{font-size:14px;line-height:1.4;margin-bottom:3px;margin-top:16px;padding-left:16px;padding-right:16px}\n.",[1],"weui-cell{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding:16px;position:relative}\n.",[1],"weui-cells{background-color:#fff;font-size:17px;line-height:1.41176471;margin-top:8px;overflow:hidden;position:relative}\n.",[1],"weui-cell__bd{min-height:24px;word-break:break-all}"],{path:"./macle_demo_EN/page/API/pages/scanCode/scanCode.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.mass']=setCssToHead([".",[1],"page-body-text-screen-brightness{font-size:40px}\n.",[1],"page-section-gap{padding:15px}"],{path:"./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/set-background/set-background.mass']=setCssToHead([".",[1],"weui-cells{background-color:var(--weui-BG-2);font-size:17px;line-height:1.41176471;margin-top:8px;overflow:hidden;position:relative}\n.",[1],"weui-cell{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding:16px;position:relative}\n.",[1],"weui-cell_input{background-color:#fff}\n.",[1],"weui-cell__bd{-webkit-flex:1;flex:1}\n.",[1],"weui-label{word-wrap:break-word;display:block;width:120px;word-break:break-all}\n.",[1],"weui-input{-webkit-appearance:none;background-color:transparent;border:0;color:inherit;font-size:inherit;height:1.41176471em;line-height:1.41176471;outline:0;width:100%}"],{path:"./macle_demo_EN/page/API/pages/set-background/set-background.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.mass']=setCssToHead([".",[1],"weui-cells{background-color:var(--weui-BG-2);font-size:17px;line-height:1.41176471;margin-top:8px;overflow:hidden;position:relative}\n.",[1],"weui-cell{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding:16px;position:relative}\n.",[1],"weui-cell_input{background-color:#fff}\n.",[1],"weui-cell__bd{-webkit-flex:1;flex:1}\n.",[1],"weui-label{word-wrap:break-word;display:block;width:120px;word-break:break-all}\n.",[1],"weui-input{-webkit-appearance:none;background-color:transparent;border:0;color:inherit;font-size:inherit;height:1.41176471em;line-height:1.41176471;outline:0;width:100%}"],{path:"./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.mass']=setCssToHead([".",[1],"weui-cells{background-color:var(--weui-BG-2);font-size:17px;line-height:1.41176471;margin-top:8px;overflow:hidden;position:relative}\n.",[1],"weui-cell{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding:16px;position:relative}\n.",[1],"weui-cell_input{background-color:#fff}\n.",[1],"weui-cell__bd{-webkit-flex:1;flex:1}\n.",[1],"weui-label{word-wrap:break-word;display:block;width:105px;word-break:break-all}\n.",[1],"weui-input{-webkit-appearance:none;background-color:transparent;border:0;color:inherit;font-size:inherit;height:1.41176471em;line-height:1.41176471;outline:0;width:100%}"],{path:"./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.mass']=setCssToHead([""],{path:"./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/storage-sync/storage-sync.mass']=setCssToHead([".",[1],"ma-cells{font-size:17px;line-height:1.41176471;margin-top:8px;overflow:hidden;position:relative}\n.",[1],"ma-cell{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding:16px;position:relative}\n.",[1],"ma-cell_input{background-color:#fff}\n.",[1],"ma-cell__bd{-webkit-flex:1;flex:1}\n.",[1],"ma-label{word-wrap:break-word;display:block;width:105px;word-break:break-all}\n.",[1],"ma-input{-webkit-appearance:none;background-color:transparent;border:0;color:inherit;font-size:inherit;height:1.41176471em;line-height:1.41176471;outline:0;width:100%}"],{path:"./macle_demo_EN/page/API/pages/storage-sync/storage-sync.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/storage/storage.mass']=setCssToHead([".",[1],"ma-cells{font-size:17px;line-height:1.41176471;margin-top:8px;overflow:hidden;position:relative}\n.",[1],"ma-cell{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding:16px;position:relative}\n.",[1],"ma-cell_input{background-color:#fff}\n.",[1],"ma-cell__bd{-webkit-flex:1;flex:1}\n.",[1],"ma-label{word-wrap:break-word;display:block;width:105px;word-break:break-all}\n.",[1],"ma-input{-webkit-appearance:none;background-color:transparent;border:0;color:inherit;font-size:inherit;height:1.41176471em;line-height:1.41176471;outline:0;width:100%}"],{path:"./macle_demo_EN/page/API/pages/storage/storage.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/toast/toast.mass']=setCssToHead([""],{path:"./macle_demo_EN/page/API/pages/toast/toast.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/uploadFile/uploadFile.mass']=setCssToHead([""],{path:"./macle_demo_EN/page/API/pages/uploadFile/uploadFile.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/vibrate/vibrate.mass']=setCssToHead([".",[1],"weui-cells{background-color:#fff;font-size:17px;line-height:1.41176471;margin-top:8px;overflow:hidden;position:relative}\n.",[1],"weui-cells:after{bottom:0;-webkit-transform:scaleY(.5);transform:scaleY(.5);-webkit-transform-origin:0 100%;transform-origin:0 100%}\n.",[1],"weui-cells__title{font-size:14px;line-height:1.4;margin-bottom:3px;margin-top:16px;padding-left:16px;padding-right:16px}\n.",[1],"weui-cells__title+.",[1],"weui-cells{margin-top:0}\n.",[1],"weui-cell{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding:16px;position:relative}\n.",[1],"weui-cell:before{content:' ';height:1px;left:0;left:16px;position:absolute;right:0;top:0;-webkit-transform:scaleY(.5);transform:scaleY(.5);-webkit-transform-origin:0 0;transform-origin:0 0;z-index:2}\n.",[1],"weui-cell__bd{-webkit-flex:1;flex:1;min-height:24px;word-break:break-all}\n.",[1],"weui-label{word-wrap:break-word;display:block;width:105px;word-break:break-all}\n.",[1],"weui-input{-webkit-appearance:none;background-color:transparent;border:0;color:inherit;font-size:inherit;height:1.41176471em;line-height:1.41176471;outline:0;width:100%}\nbody{--height:44px;--right:95px}"],{path:"./macle_demo_EN/page/API/pages/vibrate/vibrate.mass"});
__maAppCode__['macle_demo_EN/page/API/pages/websocket/websocket.mass']=setCssToHead([[2,"macle_demo_EN/page/common/lib/weui.mass"],".",[1],"my-cell{-webkit-align-items:baseline;align-items:baseline;-webkit-flex-direction:column;flex-direction:column}\n.",[1],"my-weui-cell__ft{text-align:left;word-break:break-all}"],{path:"./macle_demo_EN/page/API/pages/websocket/websocket.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/audio/audio.mass']=setCssToHead([[2,"macle_demo_EN/page/common/lib/weui.mass"],".",[1],"intro{margin:30px;text-align:center}\n.",[1],"green{color:#09bb07}\n.",[1],"red{color:#f76260}\n.",[1],"blue{color:#10aeff}\n.",[1],"yellow{color:#ffbe00}\n.",[1],"gray{color:#c9c9c9}\n.",[1],"strong{font-weight:700}\n.",[1],"bc_green{background-color:#09bb07}\n.",[1],"bc_red{background-color:#f76260}\n.",[1],"bc_blue{background-color:#10aeff}\n.",[1],"bc_yellow{background-color:#ffbe00}\n.",[1],"bc_gray{background-color:#c9c9c9}\n.",[1],"tc{text-align:center}\nma-input{background-color:#fff;padding:10px 15px}\nma-checkbox,ma-radio{margin-right:5px}\n.",[1],"btn-area{padding:0 15px}\n.",[1],"btn-area ma-button{margin-bottom:10px;margin-top:10px}\n.",[1],"page{background-color:#fbf9fe;-webkit-flex:1;flex:1;font-family:-apple-system-font,Helvetica Neue,Helvetica,sans-serif;font-size:16px;min-height:100%;overflow:hidden}\n.",[1],"page__hd{padding:40px}\n.",[1],"page__title{display:block;font-size:20px}\n.",[1],"page__desc{color:#888;font-size:14px;margin-top:5px}\n.",[1],"section{margin-bottom:40px}\n.",[1],"section_gap{padding:0 15px}\n.",[1],"section__title{margin-bottom:8px;padding-left:15px;padding-right:15px}\n.",[1],"section_gap .",[1],"section__title{padding-left:0;padding-right:0}\n.",[1],"timeslider{display:-webkit-flex;display:flex}\nma-slider{-webkit-flex:1;flex:1}\n.",[1],"showTime{margin-top:7px}"],{path:"./macle_demo_EN/page/component/pages/audio/audio.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/button/button.mass']=setCssToHead(["ma-button{margin-bottom:",[0,30],";margin-top:",[0,30],"}\n.",[1],"button-sp-area{margin:0 auto;width:60%}\n.",[1],"mini-btn{margin-right:",[0,10],"}\n.",[1],"hoverclass{background-color:#8dee9a}\n.",[1],"buttonHoverclass{font-weight:700}"],{path:"./macle_demo_EN/page/component/pages/button/button.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/camera/camera.mass']=setCssToHead(["ma-button{margin-bottom:",[0,30],";margin-top:",[0,30],"}\n.",[1],"button-sp-area{margin:0 auto;width:60%}\n.",[1],"mini-btn{margin-right:",[0,10],"}\n.",[1],"hoverclass{background-color:#8dee9a}"],{path:"./macle_demo_EN/page/component/pages/camera/camera.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/checkbox/checkbox.mass']=setCssToHead([[2,"macle_demo_EN/page/common/lib/weui.mass"],".",[1],"checkbox{margin-right:",[0,20],"}"],{path:"./macle_demo_EN/page/component/pages/checkbox/checkbox.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/cover-image/cover-image.mass']=setCssToHead([".",[1],"cover-image{height:100px;margin-top:20px;opacity:.8;width:100px}"],{path:"./macle_demo_EN/page/component/pages/cover-image/cover-image.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/cover-view/cover-view.mass']=setCssToHead([".",[1],"cover-view{font-size:",[0,36],";margin-top:",[0,80],"}\n.",[1],"c-cover-view{color:#fff;display:inline-block;height:",[0,200],";opacity:.8;width:",[0,200],"}\n.",[1],"red{background:red}\n.",[1],"green{background:green}\n.",[1],"yellow{background:#ff0;color:#000;font-family:Franklin Gothic Medium,Arial Narrow,Arial,sans-serif}"],{path:"./macle_demo_EN/page/component/pages/cover-view/cover-view.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/form/form.mass']=setCssToHead([[2,"macle_demo_EN/page/common/lib/weui.mass"],"ma-label{display:inline-block;margin-right:",[0,20],";min-width:",[0,270],"}\nma-form{width:100%}\n.",[1],"picker-text{margin-left:",[0,20],";position:relative}"],{path:"./macle_demo_EN/page/component/pages/form/form.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/icon/icon.mass']=setCssToHead([".",[1],"icon-box{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;margin-bottom:",[0,40],";padding:0 ",[0,75],"}\n.",[1],"icon-box-img{margin-right:",[0,46],"}\n.",[1],"icon-box-ctn{-webkit-flex-shrink:100;flex-shrink:100}\n.",[1],"icon-box-title{font-size:",[0,34],"}\n.",[1],"icon-box-desc{color:#888;font-size:",[0,26],";margin-top:",[0,12],"}\n.",[1],"icon-small-wrp{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;height:93px;-webkit-justify-content:center;justify-content:center;margin-right:",[0,46],";width:93px}"],{path:"./macle_demo_EN/page/component/pages/icon/icon.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/image/image.mass']=setCssToHead([".",[1],"page-section-ctn{text-align:center}\n.",[1],"image{background-color:#eee;height:200px;margin-top:",[0,30],";width:200px}"],{path:"./macle_demo_EN/page/component/pages/image/image.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/input/input.mass']=setCssToHead([[2,"macle_demo_EN/page/common/lib/weui.mass"],".",[1],"page-section{margin-bottom:",[0,20],"}\n.",[1],"placeholderclass{color:aqua;font-size:40;font-weight:600}"],{path:"./macle_demo_EN/page/component/pages/input/input.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/label/label.mass']=setCssToHead([".",[1],"label-1,.",[1],"label-2{margin:",[0,30]," 0}\n.",[1],"label-3-text{color:#576b95;font-size:",[0,28],"}\n.",[1],"checkbox-3{display:block;margin:",[0,30]," 0}"],{path:"./macle_demo_EN/page/component/pages/label/label.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/navigator/navigate.mass']=setCssToHead([],{path:"./macle_demo_EN/page/component/pages/navigator/navigate.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/navigator/navigator.mass']=setCssToHead([".",[1],"navigator-hover ma-button,.",[1],"other-navigator-hover ma-button{background-color:#dedede}\n.",[1],"navigator{padding:10px}\n.",[1],"custom-navigator-hover{background-color:pink}\n.",[1],"other-navigator-hover{background-color:#e4ce07}"],{path:"./macle_demo_EN/page/component/pages/navigator/navigator.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/navigator/redirect.mass']=setCssToHead([],{path:"./macle_demo_EN/page/component/pages/navigator/redirect.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/navigator/reLaunch.mass']=setCssToHead([],{path:"./macle_demo_EN/page/component/pages/navigator/reLaunch.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/picker-view/picker-view.mass']=setCssToHead([".",[1],"content{padding:20px}\n.",[1],"intro{margin:30px;text-align:center}\n.",[1],"indicatorClass{background-color:#00ff2b;opacity:.1}\n.",[1],"maskClass{background-size:100% 275px;opacity:.3}\n.",[1],"pickerView{height:600px;width:100%}"],{path:"./macle_demo_EN/page/component/pages/picker-view/picker-view.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/picker/picker.mass']=setCssToHead([[2,"macle_demo_EN/page/common/lib/weui.mass"],".",[1],"picker{background-color:#fff;padding:",[0,19]," ",[0,26],"}\n.",[1],"weui-label{width:90px}"],{path:"./macle_demo_EN/page/component/pages/picker/picker.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/progress/progress.mass']=setCssToHead([".",[1],"progress-box{margin-bottom:20px}\n.",[1],"container{padding:20px}"],{path:"./macle_demo_EN/page/component/pages/progress/progress.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/radio/radio.mass']=setCssToHead([[2,"macle_demo_EN/page/common/lib/weui.mass"],".",[1],"radio{margin-right:",[0,20],"}"],{path:"./macle_demo_EN/page/component/pages/radio/radio.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/rich-text/rich-text.mass']=setCssToHead([".",[1],"container{background-color:#f8f8f8;font-size:",[0,32],";line-height:1.6}\n.",[1],"page-body{padding:",[0,20]," 0}\nma-rich-text{padding:",[0,25]," 0;width:",[0,700],"}\n.",[1],"rich-text-wrp{background-color:#fff;padding:0 ",[0,25],"}\n.",[1],"page-section{margin-bottom:",[0,60],";width:100%}\n.",[1],"page-section:last-child{margin-bottom:0}\n.",[1],"page-section-title{color:#999;font-size:",[0,28],";margin-bottom:",[0,10],";padding-left:",[0,30],";padding-right:",[0,30],"}"],{path:"./macle_demo_EN/page/component/pages/rich-text/rich-text.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/scroll-view/scroll-view.mass']=setCssToHead([".",[1],"page-section-spacing{margin-top:30px}\n.",[1],"scroll-view_H{height:150px;white-space:nowrap}\n.",[1],"scroll-view-item_H{display:inline-block;height:150px;width:100%}\n.",[1],"button-area{display:-webkit-flex;display:flex;margin:0 40px}\n.",[1],"input,.",[1],"scrollTo{margin:auto;text-align:center}\n.",[1],"setPosition{padding:10px 40px 0}"],{path:"./macle_demo_EN/page/component/pages/scroll-view/scroll-view.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/slider/slider.mass']=setCssToHead([".",[1],"test-span{display:none}"],{path:"./macle_demo_EN/page/component/pages/slider/slider.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/swiper/swiper.mass']=setCssToHead([[2,"macle_demo_EN/page/common/lib/weui.mass"],"ma-button{margin-bottom:",[0,30],"}\nma-button:last-child{margin-bottom:0}\n.",[1],"page-section-title{padding:0}\n.",[1],"swiper-item{display:block;height:150px}\n.",[1],"page-section-title{margin-top:",[0,60],";position:relative}\n.",[1],"info{color:#353535;font-size:",[0,30],";position:absolute;right:0}\n.",[1],"page-foot{margin-top:",[0,50],"}"],{path:"./macle_demo_EN/page/component/pages/swiper/swiper.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/switch/switch.mass']=setCssToHead([[2,"macle_demo_EN/page/common/lib/weui.mass"],".",[1],"test-span{display:none}"],{path:"./macle_demo_EN/page/component/pages/switch/switch.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/text/text.mass']=setCssToHead(["ma-button{margin:",[0,40]," 0}\n.",[1],"text-box{-webkit-align-items:center;align-items:center;background-color:#fff;color:#353535;display:-webkit-flex;display:flex;font-size:",[0,30],";-webkit-justify-content:center;justify-content:center;line-height:2em;margin-bottom:",[0,70],";min-height:",[0,300],";padding:",[0,40]," 0;text-align:center}"],{path:"./macle_demo_EN/page/component/pages/text/text.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/video/video.mass']=setCssToHead([[2,"macle_demo_EN/page/common/lib/weui.mass"],"body{background-color:#f8f8f8;font-size:",[0,32],";height:100%;line-height:1.6}\n.",[1],"page-body{padding:",[0,20]," 0}\n.",[1],"btn-area{box-sizing:border-box;margin-top:",[0,60],";padding:0 ",[0,30],";width:100%}\n.",[1],"tc{text-align:center}\n.",[1],"weui-cells{margin-top:",[0,80],";text-align:left}\n.",[1],"weui-label{width:5em}\n.",[1],"page-body-button{margin-bottom:",[0,30],"}"],{path:"./macle_demo_EN/page/component/pages/video/video.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/view/view.mass']=setCssToHead([".",[1],"flex-wrp{display:-webkit-flex;display:flex;margin-top:",[0,60],"}\n.",[1],"flex-item{font-size:",[0,26],";height:",[0,300],";width:",[0,200],"}\n.",[1],"flex-item-V{height:",[0,200],";margin:0 auto;width:",[0,300],"}\n.",[1],"hoverclass{background-color:#8dee9a}"],{path:"./macle_demo_EN/page/component/pages/view/view.mass"});
__maAppCode__['macle_demo_EN/page/component/pages/web-view/web-view.mass']=setCssToHead([""],{path:"./macle_demo_EN/page/component/pages/web-view/web-view.mass"});
__maAppCode__['macle_demo_EN/page/framework/pages/communication/communication.mass']=setCssToHead(["ma-button{margin-bottom:",[0,30],";margin-top:",[0,30],"}\n.",[1],"button-sp-area{margin:0 auto;width:60%}\n.",[1],"mini-btn{margin-right:",[0,10],"}\n.",[1],"hoverclass{background-color:#8dee9a}\n.",[1],"container{background-color:#f0f8ff}\n.",[1],"van-button--active:before{opacity:.15}\n.",[1],"button-class{width:200px}\n.",[1],"background-class{color:red}"],{path:"./macle_demo_EN/page/framework/pages/communication/communication.mass"});
__maAppCode__['macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.mass']=setCssToHead([[2,"macle_demo_EN/page/common/lib/weui.mass"],".",[1],"buttonArea{margin-top:30px}"],{path:"./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.mass"});
__maAppCode__['macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.mass']=setCssToHead([".",[1],"log-list{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;padding:",[0,40],"}\n.",[1],"log-item{margin:",[0,10],"}"],{path:"./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.mass"});
__maAppCode__['macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.mass']=setCssToHead(["#icon-navigate{position:absolute;right:13vw;top:3vw}\n.",[1],"liveMove{left:0;position:absolute;top:0;z-index:100}\n.",[1],"liveEnter-img{height:100px;width:100px}"],{path:"./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.mass"});
__maAppCode__['macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.mass']=setCssToHead([".",[1],"container>ma-view{text-align:center}\n.",[1],"label{font-weight:700}"],{path:"./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.mass"});
__maAppCode__['macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.mass']=setCssToHead([""],{path:"./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.mass"});
__maAppCode__['macle_demo_EN/page/tabbar/api/index.mass']=setCssToHead([[2,"page/common/index.mass"],""],{path:"./macle_demo_EN/page/tabbar/api/index.mass"});
__maAppCode__['macle_demo_EN/page/tabbar/component/index.mass']=setCssToHead([[2,"page/common/index.mass"],""],{path:"./macle_demo_EN/page/tabbar/component/index.mass"});
__maAppCode__['macle_demo_EN/page/tabbar/framework/index.mass']=setCssToHead([[2,"page/common/index.mass"],""],{path:"./macle_demo_EN/page/tabbar/framework/index.mass"});
__maAppCode__['page/tabbar/api/components/set-tab-bar/set-tab-bar.mass']=setCssToHead([""],{path:"./page/tabbar/api/components/set-tab-bar/set-tab-bar.mass"});
__maAppCode__['page/tabbar/api/index.mass']=setCssToHead([[2,"page/common/index.mass"],""],{path:"./page/tabbar/api/index.mass"});
__maAppCode__['page/tabbar/component/index.mass']=setCssToHead([[2,"page/common/index.mass"],""],{path:"./page/tabbar/component/index.mass"});
__maAppCode__['page/tabbar/framework/index.mass']=setCssToHead([[2,"page/common/index.mass"],""],{path:"./page/tabbar/framework/index.mass"});
__maAppCode__['page/tabbar/react/index.mass']=setCssToHead([[2,"page/common/index.mass"],""],{path:"./page/tabbar/react/index.mass"});
__maAppCode__['component/communication-detail/index.maml']=$gma('./component/communication-detail/index.maml');
__maAppCode__['component/communication-detailItem/index.maml']=$gma('./component/communication-detailItem/index.maml');
__maAppCode__['component/detail/index.maml']=$gma('./component/detail/index.maml');
__maAppCode__['component/detailItem/index.maml']=$gma('./component/detailItem/index.maml');
__maAppCode__['macle_demo_EN/component/communication-detail/index.maml']=$gma('./macle_demo_EN/component/communication-detail/index.maml');
__maAppCode__['macle_demo_EN/component/communication-detailItem/index.maml']=$gma('./macle_demo_EN/component/communication-detailItem/index.maml');
__maAppCode__['macle_demo_EN/component/detail/index.maml']=$gma('./macle_demo_EN/component/detail/index.maml');
__maAppCode__['macle_demo_EN/component/detailItem/index.maml']=$gma('./macle_demo_EN/component/detailItem/index.maml');
__maAppCode__['macle_demo_EN/page/API/pages/application-event/application-event.maml']=$gma('./macle_demo_EN/page/API/pages/application-event/application-event.maml');
__maAppCode__['macle_demo_EN/page/API/pages/canIUse/canIUse.maml']=$gma('./macle_demo_EN/page/API/pages/canIUse/canIUse.maml');
__maAppCode__['macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml']=$gma('./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml');
__maAppCode__['macle_demo_EN/page/API/pages/compressImage/compressImage.maml']=$gma('./macle_demo_EN/page/API/pages/compressImage/compressImage.maml');
__maAppCode__['macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml']=$gma('./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml');
__maAppCode__['macle_demo_EN/page/API/pages/file/file.maml']=$gma('./macle_demo_EN/page/API/pages/file/file.maml');
__maAppCode__['macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml']=$gma('./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml');
__maAppCode__['macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml']=$gma('./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml');
__maAppCode__['macle_demo_EN/page/API/pages/get-location/get-location.maml']=$gma('./macle_demo_EN/page/API/pages/get-location/get-location.maml');
__maAppCode__['macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml']=$gma('./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml');
__maAppCode__['macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml']=$gma('./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml');
__maAppCode__['macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml']=$gma('./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml');
__maAppCode__['macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml']=$gma('./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml');
__maAppCode__['macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml']=$gma('./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml');
__maAppCode__['macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml']=$gma('./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml');
__maAppCode__['macle_demo_EN/page/API/pages/loading/loading.maml']=$gma('./macle_demo_EN/page/API/pages/loading/loading.maml');
__maAppCode__['macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml']=$gma('./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml');
__maAppCode__['macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml']=$gma('./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml');
__maAppCode__['macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml']=$gma('./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml');
__maAppCode__['macle_demo_EN/page/API/pages/modal/modal.maml']=$gma('./macle_demo_EN/page/API/pages/modal/modal.maml');
__maAppCode__['macle_demo_EN/page/API/pages/navigator/navigate.maml']=$gma('./macle_demo_EN/page/API/pages/navigator/navigate.maml');
__maAppCode__['macle_demo_EN/page/API/pages/navigator/navigator.maml']=$gma('./macle_demo_EN/page/API/pages/navigator/navigator.maml');
__maAppCode__['macle_demo_EN/page/API/pages/navigator/redirect.maml']=$gma('./macle_demo_EN/page/API/pages/navigator/redirect.maml');
__maAppCode__['macle_demo_EN/page/API/pages/network/network.maml']=$gma('./macle_demo_EN/page/API/pages/network/network.maml');
__maAppCode__['macle_demo_EN/page/API/pages/open-document/open-document.maml']=$gma('./macle_demo_EN/page/API/pages/open-document/open-document.maml');
__maAppCode__['macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml']=$gma('./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml');
__maAppCode__['macle_demo_EN/page/API/pages/request/request.maml']=$gma('./macle_demo_EN/page/API/pages/request/request.maml');
__maAppCode__['macle_demo_EN/page/API/pages/scanCode/scanCode.maml']=$gma('./macle_demo_EN/page/API/pages/scanCode/scanCode.maml');
__maAppCode__['macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml']=$gma('./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml');
__maAppCode__['macle_demo_EN/page/API/pages/set-background/set-background.maml']=$gma('./macle_demo_EN/page/API/pages/set-background/set-background.maml');
__maAppCode__['macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml']=$gma('./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml');
__maAppCode__['macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml']=$gma('./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml');
__maAppCode__['macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml']=$gma('./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml');
__maAppCode__['macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml']=$gma('./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml');
__maAppCode__['macle_demo_EN/page/API/pages/storage/storage.maml']=$gma('./macle_demo_EN/page/API/pages/storage/storage.maml');
__maAppCode__['macle_demo_EN/page/API/pages/toast/toast.maml']=$gma('./macle_demo_EN/page/API/pages/toast/toast.maml');
__maAppCode__['macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml']=$gma('./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml');
__maAppCode__['macle_demo_EN/page/API/pages/vibrate/vibrate.maml']=$gma('./macle_demo_EN/page/API/pages/vibrate/vibrate.maml');
__maAppCode__['macle_demo_EN/page/API/pages/websocket/websocket.maml']=$gma('./macle_demo_EN/page/API/pages/websocket/websocket.maml');
__maAppCode__['macle_demo_EN/page/component/pages/audio/audio.maml']=$gma('./macle_demo_EN/page/component/pages/audio/audio.maml');
__maAppCode__['macle_demo_EN/page/component/pages/button/button.maml']=$gma('./macle_demo_EN/page/component/pages/button/button.maml');
__maAppCode__['macle_demo_EN/page/component/pages/camera/camera.maml']=$gma('./macle_demo_EN/page/component/pages/camera/camera.maml');
__maAppCode__['macle_demo_EN/page/component/pages/checkbox/checkbox.maml']=$gma('./macle_demo_EN/page/component/pages/checkbox/checkbox.maml');
__maAppCode__['macle_demo_EN/page/component/pages/cover-image/cover-image.maml']=$gma('./macle_demo_EN/page/component/pages/cover-image/cover-image.maml');
__maAppCode__['macle_demo_EN/page/component/pages/cover-view/cover-view.maml']=$gma('./macle_demo_EN/page/component/pages/cover-view/cover-view.maml');
__maAppCode__['macle_demo_EN/page/component/pages/form/form.maml']=$gma('./macle_demo_EN/page/component/pages/form/form.maml');
__maAppCode__['macle_demo_EN/page/component/pages/icon/icon.maml']=$gma('./macle_demo_EN/page/component/pages/icon/icon.maml');
__maAppCode__['macle_demo_EN/page/component/pages/image/image.maml']=$gma('./macle_demo_EN/page/component/pages/image/image.maml');
__maAppCode__['macle_demo_EN/page/component/pages/input/input.maml']=$gma('./macle_demo_EN/page/component/pages/input/input.maml');
__maAppCode__['macle_demo_EN/page/component/pages/label/label.maml']=$gma('./macle_demo_EN/page/component/pages/label/label.maml');
__maAppCode__['macle_demo_EN/page/component/pages/navigator/navigate.maml']=$gma('./macle_demo_EN/page/component/pages/navigator/navigate.maml');
__maAppCode__['macle_demo_EN/page/component/pages/navigator/navigator.maml']=$gma('./macle_demo_EN/page/component/pages/navigator/navigator.maml');
__maAppCode__['macle_demo_EN/page/component/pages/navigator/redirect.maml']=$gma('./macle_demo_EN/page/component/pages/navigator/redirect.maml');
__maAppCode__['macle_demo_EN/page/component/pages/navigator/reLaunch.maml']=$gma('./macle_demo_EN/page/component/pages/navigator/reLaunch.maml');
__maAppCode__['macle_demo_EN/page/component/pages/picker-view/picker-view.maml']=$gma('./macle_demo_EN/page/component/pages/picker-view/picker-view.maml');
__maAppCode__['macle_demo_EN/page/component/pages/picker/picker.maml']=$gma('./macle_demo_EN/page/component/pages/picker/picker.maml');
__maAppCode__['macle_demo_EN/page/component/pages/progress/progress.maml']=$gma('./macle_demo_EN/page/component/pages/progress/progress.maml');
__maAppCode__['macle_demo_EN/page/component/pages/radio/radio.maml']=$gma('./macle_demo_EN/page/component/pages/radio/radio.maml');
__maAppCode__['macle_demo_EN/page/component/pages/rich-text/rich-text.maml']=$gma('./macle_demo_EN/page/component/pages/rich-text/rich-text.maml');
__maAppCode__['macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml']=$gma('./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml');
__maAppCode__['macle_demo_EN/page/component/pages/slider/slider.maml']=$gma('./macle_demo_EN/page/component/pages/slider/slider.maml');
__maAppCode__['macle_demo_EN/page/component/pages/swiper/swiper.maml']=$gma('./macle_demo_EN/page/component/pages/swiper/swiper.maml');
__maAppCode__['macle_demo_EN/page/component/pages/switch/switch.maml']=$gma('./macle_demo_EN/page/component/pages/switch/switch.maml');
__maAppCode__['macle_demo_EN/page/component/pages/text/text.maml']=$gma('./macle_demo_EN/page/component/pages/text/text.maml');
__maAppCode__['macle_demo_EN/page/component/pages/video/video.maml']=$gma('./macle_demo_EN/page/component/pages/video/video.maml');
__maAppCode__['macle_demo_EN/page/component/pages/view/view.maml']=$gma('./macle_demo_EN/page/component/pages/view/view.maml');
__maAppCode__['macle_demo_EN/page/component/pages/web-view/web-view.maml']=$gma('./macle_demo_EN/page/component/pages/web-view/web-view.maml');
__maAppCode__['macle_demo_EN/page/framework/pages/communication/communication.maml']=$gma('./macle_demo_EN/page/framework/pages/communication/communication.maml');
__maAppCode__['macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml']=$gma('./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml');
__maAppCode__['macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml']=$gma('./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml');
__maAppCode__['macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml']=$gma('./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml');
__maAppCode__['macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml']=$gma('./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml');
__maAppCode__['macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml']=$gma('./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml');
__maAppCode__['macle_demo_EN/page/tabbar/api/index.maml']=$gma('./macle_demo_EN/page/tabbar/api/index.maml');
__maAppCode__['macle_demo_EN/page/tabbar/component/index.maml']=$gma('./macle_demo_EN/page/tabbar/component/index.maml');
__maAppCode__['macle_demo_EN/page/tabbar/framework/index.maml']=$gma('./macle_demo_EN/page/tabbar/framework/index.maml');
__maAppCode__['page/tabbar/api/components/set-tab-bar/set-tab-bar.maml']=$gma('./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml');
__maAppCode__['page/tabbar/api/index.maml']=$gma('./page/tabbar/api/index.maml');
__maAppCode__['page/tabbar/component/index.maml']=$gma('./page/tabbar/component/index.maml');
__maAppCode__['page/tabbar/framework/index.maml']=$gma('./page/tabbar/framework/index.maml');
__maAppCode__['page/tabbar/react/index.maml']=$gma('./page/tabbar/react/index.maml');

__mainPageFrameReady__();
var __pageFrameEndTime__=Date.now();
