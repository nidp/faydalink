var __maAppData=__maAppData||{};
var __maRoute=__maRoute||"";
var __layer__='service';
var __maAppCode__=__maAppCode__||{};
var global=global||{};
var __MAML_GLOBAL__=__MAML_GLOBAL__||{entrys:{},defines:{},modules:{},sjs_init:false}; 
var Component=Component||function(){};
var __maI18nResource__=__maI18nResource__||{};
(function (i18nRes) {
  // Merge i18n resource in subpackage scenario
  var newI18nRes={"en-US":{"test":"test messages","test2":"test message 2, {label}, {label2}","nested":"nested message: {test}","nested2":"nested message2: {obj.nested.value}","toggle":"Toggle locale","navigate":"Navigate to Log","window.title":"I18n","log":"log","cancelEvent":"cancel localChange event","selectTest":"{gender, select, male {male} female {female} other {other}}","selectTestNest":"{mood, select, good {{how} day!} sad {{how} day.} other {Whatever!}}","component":"Component","ui":"UI","api":"API","framework":"Framework","index.test":"Test fallback","navigate2":"Navigation 2nd"},"zh-CN":{"test":"Test Messages","test2":"Test message 2, {label}, {label2}","nested":"Nested Messages: {test}","nested2":"Nested message 2: {obj.nested.value}","toggle":"Switch Language","navigate":"redirect ","window.title":"Internationalization","log":"log","cancelEvent":"Listening event for canceling language change","selectTest":"{gender, select, male  female  other }","selectTestNest":"{mood, select, good {{how}Weather!} sad {{how}Weather.} other {other!}}","component":"component","ui":"extension component","api":"interface","framework":"framework","index.test":"alternate","navigate2":"Navigation 2"}};
  for(var locale in newI18nRes){
    if(i18nRes[locale]){
      for(var key in newI18nRes[locale]){
        i18nRes[locale][key] = newI18nRes[locale][key];
      }
    }else{
      i18nRes[locale]=newI18nRes[locale];
    }
  }
})(__maI18nResource__)

/* maml-transpiler v23.3.0 2023-03-29 16:31:41 */
window.__maml_transpiler_version__='v23.3.0'
var $gmac,$gaic={}
$gma=function(path,global){
  if(typeof global==='undefined')global={};
  function _ac(parent,child){if(typeof(child)!='undefined')parent.children.push(child);} // appendChild
  function _cvn(key){ // createVirtualNode
    if(typeof(key)!='undefined')return {tag:'virtual','maKey':key,children:[]};
    return {tag:'virtual',children:[]};
  }
  function _ctn(tag){ // createTagNode
    $gmac++;
    if($gmac>=16000) throw 'Dom count exceeds maximum 16000.';
    return {tag:tag.substr(0,3)=='ma-'?tag:'ma-'+tag,attr:{},children:[],n:[]}
  }
  function _rtw(msg){console.warn("[MAML runtime warn][$gma] "+msg)} // runtimeWarn
  $gmal={warn:console.warn,info:console.log,error:console.error}
  function $gmah(){
    function fn(){}
    fn.prototype={
      hn:function(obj){ // object has new value
        if(typeof(obj)=='object'){
          var cnt=0,any=false;
          for(var x in obj){
            any|=x==='__value__';
            cnt++;
            if(cnt>2)break;
          }
          return cnt==2&&any&&obj.hasOwnProperty('__maspec__');
        }
        return false;
      },
      nh:function(obj,special){ // new has new value object
        return {__value__:obj,__maspec__:special?special:true}
      },
      rv:function(obj){ // readValue
        return this.hn(obj)?this.rv(obj.__value__):obj;
      }
    }
    return new fn;
  }
  mah=$gmah();
  function $gstack(s){
    var t=s.split('\n '+' '+' '+' ');
    for(var i=0;i<t.length;++i){
      if(0==i) continue;
      if(")"===t[i][t[i].length-1])
      t[i]=t[i].replace(/\s\(.*\)$/,"");
      else t[i]="at anonymous function";
    }
    return t.join('\n '+' '+' '+' ');
  }
  function $gdc(o,p,r){ // deep copy
    o=mah.rv(o);
    if(o===null||o===undefined) return o;
    if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
    if(o.constructor===Object){
      var copy={};
      for(var key in o){
        if(o.hasOwnProperty(key))copy[undefined===p?key.substring(4):p+key]=$gdc(o[key],p,r);
      }
      return copy;
    }
    if(o.constructor===Date){
      var copy=new Date();
      copy.setTime(o.getTime());
      return copy;
    }
    if(o.constructor===Array){
      var copy=[];
      for(var index=0;index<o.length;index++)copy.push($gdc(o[index],p,r));
      return copy;
    }
    if(r&&o.constructor===Function){
      if (r==1)return $gdc(o(),undefined,2);
      if (r==2)return o;
    }
    if(o.constructor===RegExp){
      var m="";
      if(o.global)m+="g";
      if(o.ignoreCase)m+="i";
      if(o.multiline)m+="m";
      return new RegExp(o.source,m);
    }
    return null;
  }
  function $gmart(should_pass_type_info){
    function arithmeticEval(ops,e,s,g,o){
      var rop=ops[0][1],_f=false;
      var _a,_b,_c,_d,_aa,_bb;
      switch(rop){
        case '?:':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):rev(ops[3],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '&&':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):mah.rv(_a);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '||':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?mah.rv(_a):rev(ops[2],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '+':case '*':case '/':case '%':case '|':case '^':case '&':case '===':case '==':case '!=':case '!==':case '>=':case '<=':case '>':case '<':case '<<':case '>>':
          _a=rev(ops[1],e,s,g,o,_f);
          _b=rev(ops[2],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          switch(rop){
            case '+':
              _d=mah.rv(_a)+mah.rv(_b);
              break;
            case '*':
              _d=mah.rv(_a)*mah.rv(_b);
              break;
            case '/':
              _d=mah.rv(_a)/mah.rv(_b);
              break;
            case '%':
              _d=mah.rv(_a)%mah.rv(_b);
              break;
            case '|':
              _d=mah.rv(_a)|mah.rv(_b);
              break;
            case '^':
              _d=mah.rv(_a)^mah.rv(_b);
              break;
            case '&':
              _d=mah.rv(_a)&mah.rv(_b);
              break;
            case '===':
              _d=mah.rv(_a)===mah.rv(_b);
              break;
            case '==':
              _d=mah.rv(_a)==mah.rv(_b);
              break;
            case '!=':
              _d=mah.rv(_a)!=mah.rv(_b);
              break;
            case '!==':
              _d=mah.rv(_a)!==mah.rv(_b);
              break;
            case '>=':
              _d=mah.rv(_a)>=mah.rv(_b);
              break;
            case '<=':
              _d=mah.rv(_a)<=mah.rv(_b);
              break;
            case '>':
              _d=mah.rv(_a)>mah.rv(_b);
              break;
            case '<':
              _d=mah.rv(_a)<mah.rv(_b);
              break;
            case '<<':
              _d=mah.rv(_a)<<mah.rv(_b);
              break;
            case '>>':
              _d=mah.rv(_a)>>mah.rv(_b);
              break;
            default:
              break;
          }
          return _c?mah.nh(_d,"c"):_d;
        case '-':
          _a=ops.length===3?rev(ops[1],e,s,g,o,_f):0;
          _b=ops.length===3?rev(ops[2],e,s,g,o,_f):rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          _d=_c?mah.rv(_a)-mah.rv(_b):_a-_b;
          return _c?mah.nh(_d,"c"):_d;
        case '!':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=!mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        case '~':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=~mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        default:
          $gmal.warn('unrecognized op'+rop);
      }
    }
    function rev(ops,e,s,g,o,newap){
      var op=ops[0],_f=false;
      if(typeof newap!=="undefined")o.ap=newap;
      if(typeof(op)==='object'){
        var vop=op[0];
        var _a,_aa,_b,_bb,_c,_d,_s,_e,_ta,_tb,_td;
        switch(vop){
          case 2: // LogicalExpression|ConditionalExpression|UnaryExpression|BinaryExpression
            return arithmeticEval(ops,e,s,g,o);
          case 4: // ArrayExpression
            return rev(ops[1],e,s,g,o,_f);
          case 5: // ArrayMember
            switch(ops.length){
              case 2: // one member
                return should_pass_type_info?[rev(ops[1],e,s,g,o,_f)]:[mah.rv(rev(ops[1],e,s,g,o,_f))];
              case 1: // empty
                return [];
              default: // more members
                _a=rev(ops[1],e,s,g,o,_f);
                _a.push(should_pass_type_info?rev(ops[2],e,s,g,o,_f):mah.rv(rev(ops[2],e,s,g,o,_f)));
                return _a;
            }
          case 6: // MemberExpression
            _a=rev(ops[1],e,s,g,o);
            var ap=o.ap;
            _ta=mah.hn(_a);
            _aa=_ta?mah.rv(_a):_a;
            o.is_affected|=_ta;
            if(should_pass_type_info){
              if(_aa===null||typeof(_aa)==='undefined'){
                return _ta?mah.nh(undefined,'e'):undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return (_ta||_tb)?mah.nh(undefined,'e'):undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return (_ta||_tb)?(_td?_d:mah.nh(_d,'e')):_d;
            }else{
              if(_aa===null||typeof(_aa)==='undefined'){
                return undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return _td?mah.rv(_d):_d;
            }
          case 7: // Identifier
            switch(ops[1][0]){
              case 11: // CompoundExpression
                o.is_affected|=mah.hn(g);
                return g;
              case 3: // StaticString
                _s=mah.rv(s);
                _e=mah.rv(e);
                _b=ops[1][1];
                if(g&&g.f&&g.f.hasOwnProperty(_b)){
                  _a=g.f;
                  o.ap=true;
                }else{
                  _a=_s&&_s.hasOwnProperty(_b)?s:_e&&(_e.hasOwnProperty(_b)?e:undefined);
                }
                if(should_pass_type_info){
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    _d=_ta&&!_td?mah.nh(_d,'e'):_d;
                    return _d;
                  }
                }else{
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    return mah.rv(_d);
                  }
                }
                return undefined;
            }
            break;
          case 8: // ObjectProperty
            _a={};
            _a[ops[1]]=rev(ops[2],e,s,g,o,_f);
            return _a;
          case 9: // ObjectExpression
            _a=rev(ops[1],e,s,g,o,_f);
            _b=rev(ops[2],e,s,g,o,_f);
            function merge(_a,_b,_ow){
              _ta=mah.hn(_a);
              _tb=mah.hn(_b);
              _aa=mah.rv(_a);
              _bb=mah.rv(_b);
              if(should_pass_type_info){
                if(_tb){
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=mah.nh(_bb[k],'e');
                  }
                }else{
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=_bb[k];
                  }
                }
              }else{
                for(var k in _bb){
                  if(_ow||_aa.hasOwnProperty(k))_aa[k]=mah.rv(_bb[k]);
                }
              }
              return _a;
            }
            var _c=_a,_ow=true
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10){
              _a=_b,_b=_c,_ow=false
            }
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10)return merge(merge({},_a,_ow),_b,_ow);
            else return merge(_a,_b,_ow);
          case 10: // SpreadProperty
            return should_pass_type_info?rev(ops[1],e,s,g,o,_f):mah.rv(rev(ops[1],e,s,g,o,_f));
          case 12: // CallExpression
            var _r;
            _a=rev(ops[1],e,s,g,o);
            if(!o.ap)return should_pass_type_info&&mah.hn(_a)?mah.nh(_r,'f'):_r;
            var ap=o.ap;
            _b=rev(ops[2],e,s,g,o,_f);
            o.ap=ap;
            _ta=mah.hn(_a);
            _tb=_ca(_b);
            _aa=mah.rv(_a);
            _bb=mah.rv(_b);
            snap_bb=$gdc(_bb,"sjs_");
            try{
              _r=typeof _aa==="function"?$gdc(_aa.apply(null,snap_bb)):undefined;
            }catch(e){
              e.message=e.message.replace(/sjs_/g,"");
              e.stack=e.stack.substring(0,e.stack.indexOf("\n",e.stack.lastIndexOf("at sjs_")));
              e.stack=e.stack.replace(/\ssjs_/g," ");
              e.stack=$gstack(e.stack);
              e.stack += "\n "+" "+" "+" at " + path;
              if(window.__layer__==='view')console.error(e);
              _r=undefined;
            }
            return should_pass_type_info&&(_tb||_ta)?mah.nh(_r,'f'):_r;
        }
      }else{
        if(op===3||op===1) // StaticConstant
          return ops[1];
        else if(op===11){ // CompoundExpression
          var _a='';
          for(var index=1;index<ops.length;index++){
            var xp=mah.rv(rev(ops[index],e,s,g,o,_f));
            _a+=typeof(xp)==='undefined'?'':xp;
          }
          return _a;
        }
      }
    }
    return rev;
  }
  gra=$gmart(true);
  grb=$gmart(false);
  function mfor(to_iter,func,env,_s,global,father,itemname,indexname,keyname){
    var _n=!mah.hn(to_iter);
    var scope=mah.rv(_s);
    var full=Object.prototype.toString.call(mah.rv(to_iter));
    var type=full[8];
    var old_index=scope[indexname];
    var old_item=scope[itemname];
    var has_old_index=scope.hasOwnProperty(indexname);
    var has_old_item=scope.hasOwnProperty(itemname);

    if(type==='N'&&full[10]==='l')type='X';
    var _y;
    if(_n){
      if(type==='A'){
        for(var index=0;index<to_iter.length;index++){
          scope[itemname]=to_iter[index];
          scope[indexname]=mah.nh(index,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[index])):_cvn(mah.rv(mah.rv(to_iter[index])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in to_iter){
          scope[itemname]=to_iter[k];
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[k])):_cvn(mah.rv(mah.rv(to_iter[k])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<to_iter.length;i++){
          scope[itemname]=to_iter[i];
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<to_iter;i++){
          scope[itemname]=i;
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }else{
      var r_to_iter=mah.rv(to_iter);
      var r_iter_item,iter_item;
      if(type==='A'){
        for(var i=0;i<r_to_iter.length;i++){
          iter_item=r_to_iter[i];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(i,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in r_to_iter){
          iter_item=r_to_iter[k];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<r_to_iter.length;i++){
          scope[itemname]=mah.nh(r_to_iter[i],'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<r_to_iter;i++){
          scope[itemname]=mah.nh(i,'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }
    if(has_old_index){
      scope[indexname]=old_index;
    }else{
      delete scope[indexname];
    }
    if(has_old_item){
      scope[itemname]=old_item;
    }else{
      delete scope[itemname];
    }
  }
  function _ca(obj){
    if(mah.hn(obj))return true;
    if(typeof obj!=="object")return false;
    for(var i in obj){
      if(obj.hasOwnProperty(i)){
        if(_ca(obj[i]))return true;
      }
    }
    return false;
  }
  function _setAttr(z,node,attrname,opindex,env,scope,global){
    var o={},raw=grb(z[opindex],env,scope,global,o),value=$gdc(raw,"",2);
    if(o.is_affected||_ca(raw))node.n.push(attrname); // new attr
    node.attr[attrname]=value;
  }
  function _o(z,opindex,env,scope,global){
    var nothing={};
    return grb(z[opindex],env,scope,global,nothing);
  }
  function _1(z,opindex,env,scope,global){
    var nothing={};
    return gra(z[opindex],env,scope,global,nothing);
  }
  function _2(z,opindex,func,env,scope,global,father,itemname,indexname,keyname){
    var to_iter=_1(z,opindex,env,scope,global,father,itemname,indexname,keyname);
    mfor(to_iter,func,env,scope,global,father,itemname,indexname,keyname);
  }
  function _setAttrs(z,tag,attrs,env,scope,global){
    var t=_ctn(tag),base=0;
    for(var i=0;i<attrs.length;i+=2){
      if(attrs[i+1]<0){
        t.attr[attrs[i]]=true;
      }else{
        _setAttr(z,t,attrs[i],base+attrs[i+1],env,scope,global);
        if(base===0)base=attrs[i+1];
      }
    }
    return t;
  }

  var sjs_init=function(){
    if(!__MAML_GLOBAL__.sjs_init){
      sjs_Object();sjs_Function();sjs_Array();sjs_String();sjs_Boolean();sjs_Number();sjs_Math();sjs_Date();sjs_RegExp();
    }
    __MAML_GLOBAL__.sjs_init=true;
  };
  var sjs_Object=function(){
    Object.defineProperty(Object.prototype,"sjs_constructor",{writable:true,value:"Object"})
    Object.defineProperty(Object.prototype,"sjs_toString",{writable:true,value:function(){return "[object Object]"}})
  }
  var sjs_Function=function(){
    Object.defineProperty(Function.prototype,"sjs_constructor",{writable:true,value:"Function"})
    Object.defineProperty(Function.prototype,"sjs_toString",{writable:true,value:function(){return "[function Function]"}})
    Object.defineProperty(Function.prototype,"sjs_length",{get:function(){return this.length;},set:function(){}});
  }
  var sjs_Array=function(){
    Object.defineProperty(Array.prototype,"sjs_constructor",{writable:true,value:"Array"})
    Object.defineProperty(Array.prototype,"sjs_toString",{writable:true,value:function(){return this.nv_join();}})
    Object.defineProperty(Array.prototype,"sjs_join",{writable:true,value:function(s){
      s=undefined==s?',':s;var r="";
      for(var i=0;i<this.length;++i){
        if(0!=i)r+=s;
        if(null==this[i]||undefined==this[i])r+='';
        else if(this[i].nv_constructor==="Array"&&typeof this[i]=='object')r+=this[i].nv_join();
        else if(typeof this[i]=='function')r+=this[i].nv_toString();
        else r+=this[i].toString();
      }
      return r;
    }})
    Object.defineProperty(Array.prototype,"sjs_concat",{writable:true,value:Array.prototype.concat})
    Object.defineProperty(Array.prototype,"sjs_pop",{writable:true,value:Array.prototype.pop})
    Object.defineProperty(Array.prototype,"sjs_push",{writable:true,value:Array.prototype.push})
    Object.defineProperty(Array.prototype,"sjs_reverse",{writable:true,value:Array.prototype.reverse})
    Object.defineProperty(Array.prototype,"sjs_shift",{writable:true,value:Array.prototype.shift})
    Object.defineProperty(Array.prototype,"sjs_slice",{writable:true,value:Array.prototype.slice})
    Object.defineProperty(Array.prototype,"sjs_sort",{writable:true,value:Array.prototype.sort})
    Object.defineProperty(Array.prototype,"sjs_splice",{writable:true,value:Array.prototype.splice})
    Object.defineProperty(Array.prototype,"sjs_unshift",{writable:true,value:Array.prototype.unshift})
    Object.defineProperty(Array.prototype,"sjs_indexOf",{writable:true,value:Array.prototype.indexOf})
    Object.defineProperty(Array.prototype,"sjs_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
    Object.defineProperty(Array.prototype,"sjs_every",{writable:true,value:Array.prototype.every})
    Object.defineProperty(Array.prototype,"sjs_some",{writable:true,value:Array.prototype.some})
    Object.defineProperty(Array.prototype,"sjs_forEach",{writable:true,value:Array.prototype.forEach})
    Object.defineProperty(Array.prototype,"sjs_map",{writable:true,value:Array.prototype.map})
    Object.defineProperty(Array.prototype,"sjs_filter",{writable:true,value:Array.prototype.filter})
    Object.defineProperty(Array.prototype,"sjs_reduce",{writable:true,value:Array.prototype.reduce})
    Object.defineProperty(Array.prototype,"sjs_reduceRight",{writable:true,value:Array.prototype.reduceRight})
    Object.defineProperty(Array.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_String=function(){
    Object.defineProperty(String.prototype,"sjs_constructor",{writable:true,value:"String"})
    Object.defineProperty(String.prototype,"sjs_toString",{writable:true,value:String.prototype.toString})
    Object.defineProperty(String.prototype,"sjs_valueOf",{writable:true,value:String.prototype.valueOf})
    Object.defineProperty(String.prototype,"sjs_charAt",{writable:true,value:String.prototype.charAt})
    Object.defineProperty(String.prototype,"sjs_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
    Object.defineProperty(String.prototype,"sjs_concat",{writable:true,value:String.prototype.concat})
    Object.defineProperty(String.prototype,"sjs_indexOf",{writable:true,value:String.prototype.indexOf})
    Object.defineProperty(String.prototype,"sjs_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
    Object.defineProperty(String.prototype,"sjs_localeCompare",{writable:true,value:String.prototype.localeCompare})
    Object.defineProperty(String.prototype,"sjs_match",{writable:true,value:String.prototype.match})
    Object.defineProperty(String.prototype,"sjs_replace",{writable:true,value:String.prototype.replace})
    Object.defineProperty(String.prototype,"sjs_search",{writable:true,value:String.prototype.search})
    Object.defineProperty(String.prototype,"sjs_slice",{writable:true,value:String.prototype.slice})
    Object.defineProperty(String.prototype,"sjs_split",{writable:true,value:String.prototype.split})
    Object.defineProperty(String.prototype,"sjs_substring",{writable:true,value:String.prototype.substring})
    Object.defineProperty(String.prototype,"sjs_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
    Object.defineProperty(String.prototype,"sjs_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
    Object.defineProperty(String.prototype,"sjs_trim",{writable:true,value:String.prototype.trim})
    Object.defineProperty(String.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_Boolean=function(){
    Object.defineProperty(Boolean.prototype,"sjs_constructor",{writable:true,value:"Boolean"})
    Object.defineProperty(Boolean.prototype,"sjs_toString",{writable:true,value:Boolean.prototype.toString})
    Object.defineProperty(Boolean.prototype,"sjs_valueOf",{writable:true,value:Boolean.prototype.valueOf})
  }
  var sjs_Number=function(){
    Object.defineProperty(Number,"sjs_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
    Object.defineProperty(Number,"sjs_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
    Object.defineProperty(Number,"sjs_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
    Object.defineProperty(Number,"sjs_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
    Object.defineProperty(Number.prototype,"sjs_constructor",{writable:true,value:"Number"})
    Object.defineProperty(Number.prototype,"sjs_toString",{writable:true,value:Number.prototype.toString})
    Object.defineProperty(Number.prototype,"sjs_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
    Object.defineProperty(Number.prototype,"sjs_valueOf",{writable:true,value:Number.prototype.valueOf})
    Object.defineProperty(Number.prototype,"sjs_toFixed",{writable:true,value:Number.prototype.toFixed})
    Object.defineProperty(Number.prototype,"sjs_toExponential",{writable:true,value:Number.prototype.toExponential})
    Object.defineProperty(Number.prototype,"sjs_toPrecision",{writable:true,value:Number.prototype.toPrecision})
  }
  var sjs_Math=function(){
    Object.defineProperty(Math,"sjs_E",{writable:false,value:Math.E})
    Object.defineProperty(Math,"sjs_LN10",{writable:false,value:Math.LN10})
    Object.defineProperty(Math,"sjs_LN2",{writable:false,value:Math.LN2})
    Object.defineProperty(Math,"sjs_LOG2E",{writable:false,value:Math.LOG2E})
    Object.defineProperty(Math,"sjs_LOG10E",{writable:false,value:Math.LOG10E})
    Object.defineProperty(Math,"sjs_PI",{writable:false,value:Math.PI})
    Object.defineProperty(Math,"sjs_SQRT1_2",{writable:false,value:Math.SQRT1_2})
    Object.defineProperty(Math,"sjs_SQRT2",{writable:false,value:Math.SQRT2})
    Object.defineProperty(Math,"sjs_abs",{writable:false,value:Math.abs})
    Object.defineProperty(Math,"sjs_acos",{writable:false,value:Math.acos})
    Object.defineProperty(Math,"sjs_asin",{writable:false,value:Math.asin})
    Object.defineProperty(Math,"sjs_atan",{writable:false,value:Math.atan})
    Object.defineProperty(Math,"sjs_atan2",{writable:false,value:Math.atan2})
    Object.defineProperty(Math,"sjs_ceil",{writable:false,value:Math.ceil})
    Object.defineProperty(Math,"sjs_cos",{writable:false,value:Math.cos})
    Object.defineProperty(Math,"sjs_exp",{writable:false,value:Math.exp})
    Object.defineProperty(Math,"sjs_floor",{writable:false,value:Math.floor})
    Object.defineProperty(Math,"sjs_log",{writable:false,value:Math.log})
    Object.defineProperty(Math,"sjs_max",{writable:false,value:Math.max})
    Object.defineProperty(Math,"sjs_min",{writable:false,value:Math.min})
    Object.defineProperty(Math,"sjs_pow",{writable:false,value:Math.pow})
    Object.defineProperty(Math,"sjs_random",{writable:false,value:Math.random})
    Object.defineProperty(Math,"sjs_round",{writable:false,value:Math.round})
    Object.defineProperty(Math,"sjs_sin",{writable:false,value:Math.sin})
    Object.defineProperty(Math,"sjs_sqrt",{writable:false,value:Math.sqrt})
    Object.defineProperty(Math,"sjs_tan",{writable:false,value:Math.tan})
  }
  var sjs_Date=function(){
    Object.defineProperty(Date.prototype,"sjs_constructor",{writable:true,value:"Date"})
    Object.defineProperty(Date,"sjs_parse",{writable:true,value:Date.parse})
    Object.defineProperty(Date,"sjs_UTC",{writable:true,value:Date.UTC})
    Object.defineProperty(Date,"sjs_now",{writable:true,value:Date.now})
    Object.defineProperty(Date.prototype,"sjs_toString",{writable:true,value:Date.prototype.toString})
    Object.defineProperty(Date.prototype,"sjs_toDateString",{writable:true,value:Date.prototype.toDateString})
    Object.defineProperty(Date.prototype,"sjs_toTimeString",{writable:true,value:Date.prototype.toTimeString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
    Object.defineProperty(Date.prototype,"sjs_valueOf",{writable:true,value:Date.prototype.valueOf})
    Object.defineProperty(Date.prototype,"sjs_getTime",{writable:true,value:Date.prototype.getTime})
    Object.defineProperty(Date.prototype,"sjs_getFullYear",{writable:true,value:Date.prototype.getFullYear})
    Object.defineProperty(Date.prototype,"sjs_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_getMonth",{writable:true,value:Date.prototype.getMonth})
    Object.defineProperty(Date.prototype,"sjs_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_getDate",{writable:true,value:Date.prototype.getDate})
    Object.defineProperty(Date.prototype,"sjs_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
    Object.defineProperty(Date.prototype,"sjs_getDay",{writable:true,value:Date.prototype.getDay})
    Object.defineProperty(Date.prototype,"sjs_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
    Object.defineProperty(Date.prototype,"sjs_getHours",{writable:true,value:Date.prototype.getHours})
    Object.defineProperty(Date.prototype,"sjs_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
    Object.defineProperty(Date.prototype,"sjs_getMinutes",{writable:true,value:Date.prototype.getMinutes})
    Object.defineProperty(Date.prototype,"sjs_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_getSeconds",{writable:true,value:Date.prototype.getSeconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
    Object.defineProperty(Date.prototype,"sjs_setTime",{writable:true,value:Date.prototype.setTime})
    Object.defineProperty(Date.prototype,"sjs_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setSeconds",{writable:true,value:Date.prototype.setSeconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_setMinutes",{writable:true,value:Date.prototype.setMinutes})
    Object.defineProperty(Date.prototype,"sjs_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_setHours",{writable:true,value:Date.prototype.setHours})
    Object.defineProperty(Date.prototype,"sjs_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
    Object.defineProperty(Date.prototype,"sjs_setDate",{writable:true,value:Date.prototype.setDate})
    Object.defineProperty(Date.prototype,"sjs_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
    Object.defineProperty(Date.prototype,"sjs_setMonth",{writable:true,value:Date.prototype.setMonth})
    Object.defineProperty(Date.prototype,"sjs_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_setFullYear",{writable:true,value:Date.prototype.setFullYear})
    Object.defineProperty(Date.prototype,"sjs_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_toUTCString",{writable:true,value:Date.prototype.toUTCString})
    Object.defineProperty(Date.prototype,"sjs_toISOString",{writable:true,value:Date.prototype.toISOString})
    Object.defineProperty(Date.prototype,"sjs_toJSON",{writable:true,value:Date.prototype.toJSON})
  }
  var sjs_RegExp=function(){
    Object.defineProperty(RegExp.prototype,"sjs_constructor",{writable:true,value:"RegExp"})
    Object.defineProperty(RegExp.prototype,"sjs_exec",{writable:true,value:RegExp.prototype.exec})
    Object.defineProperty(RegExp.prototype,"sjs_test",{writable:true,value:RegExp.prototype.test})
    Object.defineProperty(RegExp.prototype,"sjs_toString",{writable:true,value:RegExp.prototype.toString})
    Object.defineProperty(RegExp.prototype,"sjs_source",{get:function(){return this.source;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_global",{get:function(){return this.global;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_multiline",{get:function(){return this.multiline;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
  }
  sjs_init();
  // sjs global object or function
  var sjs_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date,args));}
  var sjs_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp,args));}
  var sjs_console={sjs_log:function(){if(window.__layer__==='view'){var res="[SJS runtime info] ";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}}}
  var sjs_parseInt=parseInt,sjs_parseFloat=parseFloat,sjs_isNaN=isNaN,sjs_isFinite=isFinite,sjs_decodeURI=decodeURI,sjs_decodeURIComponent=decodeURIComponent,sjs_encodeURI=encodeURI,sjs_encodeURIComponent=encodeURIComponent;
  var sjs_JSON={
    sjs_stringify:function(o){return JSON.stringify($gdc(o));},
    sjs_parse:function(s){
      if(s===undefined)return undefined;
      return $gdc(JSON.parse(s),'sjs_');
    }
  }
  function _ck(k){return null==k?undefined:'number'===typeof k?k:"sjs_"+k} // compute key for sjs a[key]

  function _grp(path,e,me){if(path[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=path.split('/');for(var index=0;index<ppart.length;index++){if(ppart[index]=='..')mepart.pop();else if(ppart[index]=='.'||!ppart[index])continue;else mepart.push(ppart[index]);}path=mepart.join('/');}if(me[0]=='.'&&path[0]=='/')path='.'+path;if(e[path])return path;if(e[path+'.maml'])return path+'.maml';} // getRelativePath

  function _ai(i,path,e,me,r,c){var rp=_grp(path,e,me);if(rp)i.push(rp);else{i.push('');_rtw(me+':import:'+r+':'+c+': Path `'+path+'` not found from `'+me+'`.')}} // import

  function _gapi(e, path) {
    if (!path) return [];
    if ($gaic[path]) {
      return $gaic[path];
    }
    var ret = [],
      qq = [],
      hh = 0,
      tt = 0,
      put = {},
      visited = {};
    qq.push(path);
    visited[path] = true;
    tt++;
    while (hh < tt) {
      var a = qq[hh++];
      for (var index = 0; index < e[a].ic.length; index++) {
        var nd = e[a].ic[index];
        var np = _grp(nd, e, a);
        if (np && !visited[np]) {
          visited[np] = true;
          qq.push(np);
          tt++;
        }
      }
      for (var index = 0; a != path && index < e[a].ti.length; index++) {
        var ni = e[a].ti[index];
        var nm = _grp(ni, e, a);
        if (nm && !put[nm]) {
        }
      }
    }
    $gaic[path] = ret;
    return ret;
  }

  function _gd(p, c, e, d) {
    if (!c) return;
    if (d[p][c]) return d[p][c];
    for (var index = e[p].i.length - 1; index >= 0; index--) {
      if (e[p].i[index] && d[e[p].i[index]][c]) return d[e[p].i[index]][c];
    }
    for (var index = e[p].ti.length - 1; index >= 0; index--) {
      var q = _grp(e[p].ti[index], e, p);
      if (q && d[q][c]) return d[q][c];
    }
    var api = _gapi(e, p);
    for (var index = 0; index < api.length; index++) {
      if (api[index] && d[api[index]][c]) return d[api[index]][c];
    }
    for (var key = e[p].j.length - 1; key >= 0; key--)
      if (e[p].j[key]) {
        for (var qlen = e[e[p].j[key]].ti.length - 1; qlen >= 0; qlen--) {
          var tt = _grp(e[e[p].j[key]].ti[qlen], e, p);
          if (tt && d[tt][c]) {
            return d[tt][c];
          }
        }
      }
  }
  
  var $ixc = {};
  function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_rtw('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_rtw(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}} // include
  function _w(tn,f,line,c){_rtw(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}

  var e_=__MAML_GLOBAL__.entrys||{},d_=__MAML_GLOBAL__.defines||{},f_=__MAML_GLOBAL__.modules||{},p_={};
  if(window.i18n&&!f_.i18n){ // init sjs i18n api, remove arguments property sjs prefix
    f_.i18n={}
    for(var k in i18n){
      (function(k){ // simulate for loop let
        var key=k
        i18n['sjs_'+k]=i18n[k]
        if(typeof i18n[k]==="function"){
          i18n['sjs_'+k]=function(){return i18n[key].apply(null,$gdc(Array.prototype.slice.call(arguments)))}
          f_.i18n[k]=i18n['sjs_'+k]
        }else{
          i18n['sjs_'+k]=i18n[k]
          f_.i18n[k]=i18n[k]
        }
      })(k)
    }
  }
  __MAML_GLOBAL__.ops_cached=__MAML_GLOBAL__.ops_cached||{};
  __MAML_GLOBAL__.ops_set=__MAML_GLOBAL__.ops_set||{};
  __MAML_GLOBAL__.ops_init=__MAML_GLOBAL__.ops_init||{};
  var z=__MAML_GLOBAL__.ops_set.$gma||[];
  
  function gz$gma_1(){
    if(__MAML_GLOBAL__.ops_cached.$gma_1)return __MAML_GLOBAL__.ops_cached.$gma_1
    __MAML_GLOBAL__.ops_cached.$gma_1=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'onChildMethod']);
      Z([3,'A subcomponent invokes its subcomponent method']);
      Z([3,'trigger']);
      Z([11,[[7],[3,"text"]],[3,'\r\n        Subcomponent page component. Click to invoke the parent component method to display the subcomponents of the subcomponent']]);
      Z([[7],[3,"isDispalyItem"]]);
      Z([[7],[3,"list"]]);
      Z([3,'item']);
      Z([3,'name']);
      Z([3,'onMyEvent']);
      Z([3,'test_color']);
      Z([[7],[3,"item"]])
    })(__MAML_GLOBAL__.ops_cached.$gma_1);
    return __MAML_GLOBAL__.ops_cached.$gma_1
  }
  function gz$gma_2(){
    if(__MAML_GLOBAL__.ops_cached.$gma_2)return __MAML_GLOBAL__.ops_cached.$gma_2
    __MAML_GLOBAL__.ops_cached.$gma_2=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'trigger']);
      Z([3,'Subassembly of Subassembly'])
    })(__MAML_GLOBAL__.ops_cached.$gma_2);
    return __MAML_GLOBAL__.ops_cached.$gma_2
  }
  function gz$gma_3(){
    if(__MAML_GLOBAL__.ops_cached.$gma_3)return __MAML_GLOBAL__.ops_cached.$gma_3
    __MAML_GLOBAL__.ops_cached.$gma_3=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'box']);
      Z([3,'head']);
      Z([[8],"title",[1,"I am a custom componentA，My presentation is light orange"]]);
      Z([3,'addCount']);
      Z([3,'Click me to add 2 each time']);
      Z([11,[[7],[3,"count"]]]);
      Z([[6],[[7],[3,"detail"]],[3,"list"]]);
      Z([3,'item']);
      Z([3,'name']);
      Z([3,'background: #7fffd4']);
      Z([[7],[3,"item"]])
    })(__MAML_GLOBAL__.ops_cached.$gma_3);
    return __MAML_GLOBAL__.ops_cached.$gma_3
  }
  function gz$gma_4(){
    if(__MAML_GLOBAL__.ops_cached.$gma_4)return __MAML_GLOBAL__.ops_cached.$gma_4
    __MAML_GLOBAL__.ops_cached.$gma_4=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'child-box']);
      Z([3,'head']);
      Z([[8],"title",[1,"I am a subcomponent of custom component A，My color is light green"]]);
      Z([3,'addCount']);
      Z([3,'Click me to add 3 each time']);
      Z([11,[[7],[3,"count"]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_4);
    return __MAML_GLOBAL__.ops_cached.$gma_4
  }
  function gz$gma_5(){
    if(__MAML_GLOBAL__.ops_cached.$gma_5)return __MAML_GLOBAL__.ops_cached.$gma_5
    __MAML_GLOBAL__.ops_cached.$gma_5=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'onChildMethod']);
      Z([3,'A subcomponent invokes its subcomponent method']);
      Z([3,'trigger']);
      Z([11,[[7],[3,"text"]],[3,'\r\n        Subcomponent page component. Click to invoke the parent component method to display the subcomponents of the subcomponent']]);
      Z([[7],[3,"isDispalyItem"]]);
      Z([[7],[3,"list"]]);
      Z([3,'item']);
      Z([3,'name']);
      Z([3,'onMyEvent']);
      Z([3,'test_color']);
      Z([[7],[3,"item"]])
    })(__MAML_GLOBAL__.ops_cached.$gma_5);
    return __MAML_GLOBAL__.ops_cached.$gma_5
  }
  function gz$gma_6(){
    if(__MAML_GLOBAL__.ops_cached.$gma_6)return __MAML_GLOBAL__.ops_cached.$gma_6
    __MAML_GLOBAL__.ops_cached.$gma_6=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'trigger']);
      Z([3,'Subassembly of Subassembly'])
    })(__MAML_GLOBAL__.ops_cached.$gma_6);
    return __MAML_GLOBAL__.ops_cached.$gma_6
  }
  function gz$gma_7(){
    if(__MAML_GLOBAL__.ops_cached.$gma_7)return __MAML_GLOBAL__.ops_cached.$gma_7
    __MAML_GLOBAL__.ops_cached.$gma_7=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'box']);
      Z([3,'head']);
      Z([[8],"title",[1,"I am a custom componentA，My presentation is light orange"]]);
      Z([3,'addCount']);
      Z([3,'Click me to add 2 each time']);
      Z([11,[[7],[3,"count"]]]);
      Z([[6],[[7],[3,"detail"]],[3,"list"]]);
      Z([3,'item']);
      Z([3,'name']);
      Z([3,'background: #7fffd4']);
      Z([[7],[3,"item"]])
    })(__MAML_GLOBAL__.ops_cached.$gma_7);
    return __MAML_GLOBAL__.ops_cached.$gma_7
  }
  function gz$gma_8(){
    if(__MAML_GLOBAL__.ops_cached.$gma_8)return __MAML_GLOBAL__.ops_cached.$gma_8
    __MAML_GLOBAL__.ops_cached.$gma_8=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'child-box']);
      Z([3,'head']);
      Z([[8],"title",[1,"I am a subcomponent of custom component A，My color is light green"]]);
      Z([3,'addCount']);
      Z([3,'Click me to add 3 each time']);
      Z([11,[[7],[3,"count"]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_8);
    return __MAML_GLOBAL__.ops_cached.$gma_8
  }
  function gz$gma_9(){
    if(__MAML_GLOBAL__.ops_cached.$gma_9)return __MAML_GLOBAL__.ops_cached.$gma_9
    __MAML_GLOBAL__.ops_cached.$gma_9=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[9],[[8],"title",[1,"application-event"]],[[8],"desc",[1,"Application-level events"]]]);
      Z([3,'page-body']);
      Z([3,'onAppShow']);
      Z([3,'onAppShow1']);
      Z([3,'primary']);
      Z([3,'offAppShow']);
      Z([3,'onAppHide']);
      Z([3,'offAppHide']);
      Z([3,'onError']);
      Z([3,'offError']);
      Z([3,'Error']);
      Z([3,'text-area']);
      Z([3,'message']);
      Z([3,'white-space: pre-line;']);
      Z([11,[[7],[3,"detail"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_9);
    return __MAML_GLOBAL__.ops_cached.$gma_9
  }
  function gz$gma_10(){
    if(__MAML_GLOBAL__.ops_cached.$gma_10)return __MAML_GLOBAL__.ops_cached.$gma_10
    __MAML_GLOBAL__.ops_cached.$gma_10=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"canIUse"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'body-center contentAPI']);
      Z([11,[3,'The API result is:'],[[7],[3,"success"]]]);
      Z([3,'popapi1']);
      Z([3,'primary']);
      Z([3,'request.object.method.GET']);
      Z([3,'popapi2']);
      Z([3,'request.object.method.OPTI']);
      Z([3,'popapi3']);
      Z([3,'request.object.method']);
      Z([3,'popapi4']);
      Z([3,'request.object.meth']);
      Z([3,'popapi5']);
      Z([3,'request.object']);
      Z([3,'popapi6']);
      Z([3,'request.obj']);
      Z([3,'popapi7']);
      Z([3,'request']);
      Z([3,'popapi8']);
      Z([3,'reque']);
      Z([3,'body-center contentBtn']);
      Z([11,[3,'Component results are:'],[[7],[3,"popcom"]]]);
      Z([3,'popcom1']);
      Z([3,'button.size.default']);
      Z([3,'popcom2']);
      Z([3,'button.size.defau']);
      Z([3,'popcom3']);
      Z([3,'button.size']);
      Z([3,'popcom4']);
      Z([3,'button.si']);
      Z([3,'popcom5']);
      Z([3,'button']);
      Z([3,'popcom6']);
      Z([3,'butt']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_10);
    return __MAML_GLOBAL__.ops_cached.$gma_10
  }
  function gz$gma_11(){
    if(__MAML_GLOBAL__.ops_cached.$gma_11)return __MAML_GLOBAL__.ops_cached.$gma_11
    __MAML_GLOBAL__.ops_cached.$gma_11=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"chooseContact"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'chooseContact']);
      Z([3,'default']);
      Z([3,'Select Contact']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_11);
    return __MAML_GLOBAL__.ops_cached.$gma_11
  }
  function gz$gma_12(){
    if(__MAML_GLOBAL__.ops_cached.$gma_12)return __MAML_GLOBAL__.ops_cached.$gma_12
    __MAML_GLOBAL__.ops_cached.$gma_12=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"compressImage"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'widthFix']);
      Z([[7],[3,"src"]]);
      Z([3,'width: 300px;']);
      Z([3,'compressImage']);
      Z([3,'compress']);
      Z([3,'Compressed Picture']);
      Z([3,'compressImageFail']);
      Z([3,'compressFail']);
      Z([3,'Compressed Picture:The src is empty']);
      Z([[2,"!"],[[2,"!"],[[7],[3,"info"]]]]);
      Z([3,'result']);
      Z([3,'info']);
      Z([11,[[7],[3,"info"]]]);
      Z([[2,"!"],[[2,"!"],[[7],[3,"filePath"]]]]);
      Z([3,'filePath']);
      Z([11,[[7],[3,"filePath"]]]);
      Z([[2,"!"],[[2,"!"],[[7],[3,"complete"]]]]);
      Z([3,'nbsp']);
      Z([11,[[7],[3,"complete"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_12);
    return __MAML_GLOBAL__.ops_cached.$gma_12
  }
  function gz$gma_13(){
    if(__MAML_GLOBAL__.ops_cached.$gma_13)return __MAML_GLOBAL__.ops_cached.$gma_13
    __MAML_GLOBAL__.ops_cached.$gma_13=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"downloadFile"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'popdownloadFile']);
      Z([3,'downloadFile']);
      Z([3,'primary']);
      Z([3,'Downloading files']);
      Z([3,'downloadFail']);
      Z([3,'The download address is empty']);
      Z([3,'body-view']);
      Z([3,'Switching to the Public Network']);
      Z([3,'isPublicNetChange']);
      Z([[7],[3,"isPublicNet"]]);
      Z([[2,"!"],[[2,"!"],[[7],[3,"info"]]]]);
      Z([3,'result']);
      Z([3,'Returned information']);
      Z([3,'info']);
      Z([11,[[7],[3,"info"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_13);
    return __MAML_GLOBAL__.ops_cached.$gma_13
  }
  function gz$gma_14(){
    if(__MAML_GLOBAL__.ops_cached.$gma_14)return __MAML_GLOBAL__.ops_cached.$gma_14
    __MAML_GLOBAL__.ops_cached.$gma_14=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"saveFile"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'page-body-info']);
      Z([[2,"!="], [[7],[3,"tempFilePath"]], [1,""]]);
      Z([3,'image']);
      Z([3,'aspectFit']);
      Z([[7],[3,"tempFilePath"]]);
      Z([[2,"&&"],[[2,"==="], [[7],[3,"tempFilePath"]], [1,""]],[[2,"!="], [[7],[3,"savedFilePath"]], [1,""]]]);
      Z([[7],[3,"savedFilePath"]]);
      Z([[2,"&&"],[[2,"==="], [[7],[3,"tempFilePath"]], [1,""]],[[2,"==="], [[7],[3,"savedFilePath"]], [1,""]]]);
      Z([3,'chooseImage']);
      Z([3,'image-plus image-plus-nb']);
      Z([3,'image-plus-horizontal']);
      Z([3,'image-plus-vertical']);
      Z([3,'image-plus-text']);
      Z([3,'Please select a file']);
      Z([3,'btn-area']);
      Z([3,'saveFile']);
      Z([3,'primary']);
      Z([3,'Save the file']);
      Z([3,'clear']);
      Z([3,'getFileInfo']);
      Z([3,'Obtaining File Information']);
      Z([3,'getSavedFileInfo']);
      Z([3,'Obtaining Local File Information']);
      Z([3,'getSavedFileList']);
      Z([3,'removeSavedFile']);
      Z([3,'Deleting Local Cache Files']);
      Z([3,'text-area']);
      Z([3,'detail']);
      Z([11,[[7],[3,"detail"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_14);
    return __MAML_GLOBAL__.ops_cached.$gma_14
  }
  function gz$gma_15(){
    if(__MAML_GLOBAL__.ops_cached.$gma_15)return __MAML_GLOBAL__.ops_cached.$gma_15
    __MAML_GLOBAL__.ops_cached.$gma_15=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"getBatteryInfo"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'ma-cells ma-cells_after-title']);
      Z([3,'ma-cell ma-cell_input']);
      Z([3,'ma-cell__hd']);
      Z([3,'ma-label']);
      Z([3,'Current battery level']);
      Z([3,'ma-cell__bd']);
      Z([3,'ma-input battery']);
      Z([1,true]);
      Z([3,'Not obtained']);
      Z([3,'text']);
      Z([[7],[3,"level"]]);
      Z([3,'Battery mode']);
      Z([3,'ma-input']);
      Z([[7],[3,"isCharging"]]);
      Z([3,'getBatteryInfo']);
      Z([3,'primary']);
      Z([3,'Obtaining Battery Level Information']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_15);
    return __MAML_GLOBAL__.ops_cached.$gma_15
  }
  function gz$gma_16(){
    if(__MAML_GLOBAL__.ops_cached.$gma_16)return __MAML_GLOBAL__.ops_cached.$gma_16
    __MAML_GLOBAL__.ops_cached.$gma_16=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"getImageInfo"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'widthFix']);
      Z([[7],[3,"src"]]);
      Z([3,'width: 300px;']);
      Z([[7],[3,"netSrc"]]);
      Z([3,'getImageInfo']);
      Z([3,'getImageInfo2']);
      Z([3,'getImageInfoNet']);
      Z([3,'Obtaining Network Image Information']);
      Z([3,'getImageInfoFail']);
      Z([3,'ImageInfoFail']);
      Z([3,'Obtaining Image Information:The src is empty']);
      Z([[2,"!"],[[2,"!"],[[7],[3,"info"]]]]);
      Z([3,'result']);
      Z([3,'info']);
      Z([11,[[7],[3,"info"]]]);
      Z([[2,"!"],[[2,"!"],[[7],[3,"complete"]]]]);
      Z([3,'nbsp']);
      Z([11,[[7],[3,"complete"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_16);
    return __MAML_GLOBAL__.ops_cached.$gma_16
  }
  function gz$gma_17(){
    if(__MAML_GLOBAL__.ops_cached.$gma_17)return __MAML_GLOBAL__.ops_cached.$gma_17
    __MAML_GLOBAL__.ops_cached.$gma_17=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[9],[[8],"title",[1,"ma.getLocation"]],[[8],"desc",[1,"Obtain the current geographical location and speed"]]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'page-body-info']);
      Z([3,'page-body-text-small']);
      Z([3,'Longitude and latitude of the current position']);
      Z([[2,"==="], [[7],[3,"hasLocation"]], [1,false]]);
      Z([3,'page-body-text']);
      Z([3,'Not obtained']);
      Z([[2,"==="], [[7],[3,"hasLocation"]], [1,true]]);
      Z([3,'page-body-text-location']);
      Z([3,'result']);
      Z([11,[3,'E: '],[[6],[[6],[[7],[3,"location"]],[3,"longitude"]],[1,0]],[3,'°'],[[6],[[6],[[7],[3,"location"]],[3,"longitude"]],[1,1]],[3,'′']]);
      Z([11,[3,'N: '],[[6],[[6],[[7],[3,"location"]],[3,"latitude"]],[1,0]],[3,'°'],[[6],[[6],[[7],[3,"location"]],[3,"latitude"]],[1,1]],[3,'′']]);
      Z([3,'btn-area']);
      Z([3,'getLocation']);
      Z([3,'primary']);
      Z([3,'Get Location']);
      Z([3,'clear']);
      Z([3,'left empty']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_17);
    return __MAML_GLOBAL__.ops_cached.$gma_17
  }
  function gz$gma_18(){
    if(__MAML_GLOBAL__.ops_cached.$gma_18)return __MAML_GLOBAL__.ops_cached.$gma_18
    __MAML_GLOBAL__.ops_cached.$gma_18=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"getNetworkType"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'The network type is：']);
      Z([3,'weui-cells']);
      Z([3,'weui-cell']);
      Z([3,'weui-cell__bd']);
      Z([11,[[7],[3,"network"]]]);
      Z([11,[[7],[3,"complete"]]]);
      Z([3,'getNetworkType']);
      Z([3,'default']);
      Z([3,'Obtain the network type']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_18);
    return __MAML_GLOBAL__.ops_cached.$gma_18
  }
  function gz$gma_19(){
    if(__MAML_GLOBAL__.ops_cached.$gma_19)return __MAML_GLOBAL__.ops_cached.$gma_19
    __MAML_GLOBAL__.ops_cached.$gma_19=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"getSystemInfo"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'mobile phone model']);
      Z([3,'weui-cell__bd']);
      Z([3,'weui-input phoneModel']);
      Z([1,true]);
      Z([3,'Not obtained']);
      Z([3,'text']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"model"]]);
      Z([3,'language']);
      Z([3,'weui-input phonelanguage']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"language"]]);
      Z([3,'Screen width']);
      Z([3,'weui-input phonescreenWidth']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"screenWidth"]]);
      Z([3,'screen height']);
      Z([3,'weui-input phonescreenHeight']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"screenHeight"]]);
      Z([3,'Available window width']);
      Z([3,'weui-input phonewindowWidth']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"windowWidth"]]);
      Z([3,'Available height of window']);
      Z([3,'weui-input phonewindowHeight']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"windowHeight"]]);
      Z([3,'DPI']);
      Z([3,'weui-input phonepixelRatio']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"pixelRatio"]]);
      Z([3,'Status bar height']);
      Z([3,'weui-input phonestatusBarHeight']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"statusBarHeight"]]);
      Z([3,'system information']);
      Z([3,'weui-input phonesystem']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"system"]]);
      Z([3,'device brand']);
      Z([3,'weui-input phonebrand']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"brand"]]);
      Z([3,'btn-area']);
      Z([3,'getSystemInfoSync']);
      Z([3,'getSystemInfo']);
      Z([3,'primary']);
      Z([3,'Synchronize the system information of the mobile phone and update the system information 3 seconds later']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_19);
    return __MAML_GLOBAL__.ops_cached.$gma_19
  }
  function gz$gma_20(){
    if(__MAML_GLOBAL__.ops_cached.$gma_20)return __MAML_GLOBAL__.ops_cached.$gma_20
    __MAML_GLOBAL__.ops_cached.$gma_20=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"getSystemInfo"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'mobile phone model']);
      Z([3,'weui-cell__bd']);
      Z([3,'weui-input phoneModel']);
      Z([1,true]);
      Z([3,'Not obtained']);
      Z([3,'text']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"model"]]);
      Z([3,'language']);
      Z([3,'weui-input phonelanguage']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"language"]]);
      Z([3,'Screen width']);
      Z([3,'weui-input phonescreenWidth']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"screenWidth"]]);
      Z([3,'screen height']);
      Z([3,'weui-input phonescreenHeight']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"screenHeight"]]);
      Z([3,'Available window width']);
      Z([3,'weui-input phonewindowWidth']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"windowWidth"]]);
      Z([3,'Available height of window']);
      Z([3,'weui-input phonewindowHeight']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"windowHeight"]]);
      Z([3,'DPI']);
      Z([3,'weui-input phonepixelRatio']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"pixelRatio"]]);
      Z([3,'Status bar height']);
      Z([3,'weui-input phonestatusBarHeight']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"statusBarHeight"]]);
      Z([3,'system info']);
      Z([3,'weui-input phonesystem']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"system"]]);
      Z([3,'device brand']);
      Z([3,'weui-input phonebrand']);
      Z([[6],[[7],[3,"systemInfo"]],[3,"brand"]]);
      Z([3,'btn-area']);
      Z([3,'getSystemInfo']);
      Z([3,'primary']);
      Z([3,'Obtaining Mobile Phone System Information']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_20);
    return __MAML_GLOBAL__.ops_cached.$gma_20
  }
  function gz$gma_21(){
    if(__MAML_GLOBAL__.ops_cached.$gma_21)return __MAML_GLOBAL__.ops_cached.$gma_21
    __MAML_GLOBAL__.ops_cached.$gma_21=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"getmenuButtonPosInfo"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'width']);
      Z([3,'weui-cell__bd']);
      Z([3,'weui-input']);
      Z([1,true]);
      Z([3,'Not obtained']);
      Z([3,'text']);
      Z([[6],[[7],[3,"menuButtonPosInfo"]],[3,"width"]]);
      Z([3,'height']);
      Z([[6],[[7],[3,"menuButtonPosInfo"]],[3,"height"]]);
      Z([3,'upper boundary coordinate']);
      Z([[6],[[7],[3,"menuButtonPosInfo"]],[3,"top"]]);
      Z([3,'Right boundary coordinate']);
      Z([[6],[[7],[3,"menuButtonPosInfo"]],[3,"right"]]);
      Z([3,'lower boundary coordinate']);
      Z([[6],[[7],[3,"menuButtonPosInfo"]],[3,"bottom"]]);
      Z([3,'Left boundary coordinate']);
      Z([[6],[[7],[3,"menuButtonPosInfo"]],[3,"left"]]);
      Z([3,'btn-area']);
      Z([3,'getMenuButtonPosInfo']);
      Z([3,'primary']);
      Z([3,'Obtains the layout position information of a menu button']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_21);
    return __MAML_GLOBAL__.ops_cached.$gma_21
  }
  function gz$gma_22(){
    if(__MAML_GLOBAL__.ops_cached.$gma_22)return __MAML_GLOBAL__.ops_cached.$gma_22
    __MAML_GLOBAL__.ops_cached.$gma_22=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[9],[[8],"title",[1,"gyroscope"]],[[8],"desc",[1,"Monitor gyroscope changes"]]]);
      Z([3,'page-body']);
      Z([3,'startGyroscope']);
      Z([3,'primary']);
      Z([3,'Start monitoring gyroscope data']);
      Z([3,'stopGyroscope']);
      Z([3,'Stop monitoring gyroscope data']);
      Z([3,'onGyroscopeChange']);
      Z([3,'Monitor gyroscope data change events']);
      Z([3,'offGyroscopeChange']);
      Z([3,'Cancel the monitoring of gyro data change events']);
      Z([3,'text-area']);
      Z([11,[[7],[3,"detail"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_22);
    return __MAML_GLOBAL__.ops_cached.$gma_22
  }
  function gz$gma_23(){
    if(__MAML_GLOBAL__.ops_cached.$gma_23)return __MAML_GLOBAL__.ops_cached.$gma_23
    __MAML_GLOBAL__.ops_cached.$gma_23=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"hideKeyboard"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'weui-cells__title']);
      Z([3,'Focus on the text box below to pop up the keyboard，The keyboard is automatically hidden after 5 seconds']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'unsetAutoHide']);
      Z([3,'setAutoHide']);
      Z([3,'weui-input']);
      Z([3,'After the keyboard is ejected，Auto hide after 5 seconds']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_23);
    return __MAML_GLOBAL__.ops_cached.$gma_23
  }
  function gz$gma_24(){
    if(__MAML_GLOBAL__.ops_cached.$gma_24)return __MAML_GLOBAL__.ops_cached.$gma_24
    __MAML_GLOBAL__.ops_cached.$gma_24=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"toast"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'popLoading']);
      Z([3,'loadingToast']);
      Z([3,'primary']);
      Z([3,'The Loading dialog box is displayed']);
      Z([3,'weui-cells']);
      Z([3,'weui-cell']);
      Z([3,'weui-cell__bd']);
      Z([11,[[7],[3,"result"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_24);
    return __MAML_GLOBAL__.ops_cached.$gma_24
  }
  function gz$gma_25(){
    if(__MAML_GLOBAL__.ops_cached.$gma_25)return __MAML_GLOBAL__.ops_cached.$gma_25
    __MAML_GLOBAL__.ops_cached.$gma_25=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"makePhoneCall"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'desc']);
      Z([3,'Please enter your phone number below']);
      Z([3,'bindInput']);
      Z([3,'phoneNum']);
      Z([3,'input']);
      Z([3,'number']);
      Z([3,'btn-area']);
      Z([3,'makePhoneCall']);
      Z([[7],[3,"disabled"]]);
      Z([3,'primary']);
      Z([3,'call']);
      Z([3,'makePhoneCallFail']);
      Z([3,'nophoneNumber']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_25);
    return __MAML_GLOBAL__.ops_cached.$gma_25
  }
  function gz$gma_26(){
    if(__MAML_GLOBAL__.ops_cached.$gma_26)return __MAML_GLOBAL__.ops_cached.$gma_26
    __MAML_GLOBAL__.ops_cached.$gma_26=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"choose/previewImage"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'image credit']);
      Z([3,'weui-cell__bd']);
      Z([3,'sourceTypeChange']);
      Z([3,'selector']);
      Z([[7],[3,"sourceType"]]);
      Z([[7],[3,"sourceTypeIndex"]]);
      Z([3,'weui-input']);
      Z([11,[[6],[[7],[3,"sourceType"]],[[7],[3,"sourceTypeIndex"]]]]);
      Z([3,'image quality']);
      Z([3,'sizeTypeChange']);
      Z([[7],[3,"sizeType"]]);
      Z([[7],[3,"sizeTypeIndex"]]);
      Z([11,[[6],[[7],[3,"sizeType"]],[[7],[3,"sizeTypeIndex"]]]]);
      Z([3,'quantitative restriction']);
      Z([3,'countChange']);
      Z([[7],[3,"count"]]);
      Z([[7],[3,"countIndex"]]);
      Z([11,[[6],[[7],[3,"count"]],[[7],[3,"countIndex"]]]]);
      Z([3,'weui-cells']);
      Z([3,'weui-cell']);
      Z([3,'weui-uploader']);
      Z([3,'weui-uploader__hd']);
      Z([3,'weui-uploader__title']);
      Z([3,'Touch to preview the selected picture']);
      Z([3,'weui-uploader__info']);
      Z([11,[[6],[[7],[3,"imageList"]],[3,"length"]],[3,'/'],[[6],[[7],[3,"count"]],[[7],[3,"countIndex"]]]]);
      Z([3,'weui-uploader__bd']);
      Z([3,'weui-uploader__files']);
      Z([[7],[3,"imageList"]]);
      Z([3,'image']);
      Z([3,'weui-uploader__file']);
      Z([3,'previewImage']);
      Z([3,'weui-uploader__img']);
      Z([[7],[3,"image"]]);
      Z([3,'weui-uploader__input-box']);
      Z([3,'chooseImage']);
      Z([3,'weui-uploader__input']);
      Z([3,'saveImage']);
      Z([3,'saveImg']);
      Z([3,'Save Picture']);
      Z([3,'previewImage2']);
      Z([3,'previewImageNet']);
      Z([3,'Previewing Network Pictures']);
      Z([3,'previewImageFail']);
      Z([3,'previewFail']);
      Z([3,'Preview Picture:The urls is empty']);
      Z([[2,"!"],[[2,"!"],[[7],[3,"info"]]]]);
      Z([3,'result']);
      Z([3,'info']);
      Z([11,[[7],[3,"info"]]]);
      Z([[2,"!"],[[2,"!"],[[7],[3,"complete"]]]]);
      Z([3,'nbsp']);
      Z([11,[[7],[3,"complete"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_26);
    return __MAML_GLOBAL__.ops_cached.$gma_26
  }
  function gz$gma_27(){
    if(__MAML_GLOBAL__.ops_cached.$gma_27)return __MAML_GLOBAL__.ops_cached.$gma_27
    __MAML_GLOBAL__.ops_cached.$gma_27=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[9],[[8],"title",[1,"onMemoryWarning"]],[[8],"desc",[1,"Interception Performance Changes"]]]);
      Z([3,'page-body']);
      Z([3,'onMemoryWarning']);
      Z([3,'primary']);
      Z([3,'Registering a Listener']);
      Z([3,'offMemoryWarning']);
      Z([3,'Delete a listener']);
      Z([3,'offAll']);
      Z([3,'simulateMemoryWarning']);
      Z([3,'Simulating the Memory Alarm IOS']);
      Z([3,'text-area']);
      Z([11,[[7],[3,"detail"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_27);
    return __MAML_GLOBAL__.ops_cached.$gma_27
  }
  function gz$gma_28(){
    if(__MAML_GLOBAL__.ops_cached.$gma_28)return __MAML_GLOBAL__.ops_cached.$gma_28
    __MAML_GLOBAL__.ops_cached.$gma_28=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"showModal"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'modalSuccess']);
      Z([3,'showModal']);
      Z([3,'primary']);
      Z([3,'modal dialog box']);
      Z([3,'showModal2']);
      Z([3,'confirmText More than four words']);
      Z([3,'showModalEditable']);
      Z([3,'editableIstrue']);
      Z([[2,"!"],[[2,"!"],[[7],[3,"info"]]]]);
      Z([3,'result']);
      Z([11,[[7],[3,"info"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_28);
    return __MAML_GLOBAL__.ops_cached.$gma_28
  }
  function gz$gma_29(){
    if(__MAML_GLOBAL__.ops_cached.$gma_29)return __MAML_GLOBAL__.ops_cached.$gma_29
    __MAML_GLOBAL__.ops_cached.$gma_29=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"navigateTo"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'newPage']);
      Z([3,'new Page']);
      Z([3,'eventChannel']);
      Z([3,'navigateTo']);
      Z([3,'primary']);
      Z([3,'other-navigator-hover']);
      Z([3,'navigateBack']);
      Z([3,'returnPage']);
      Z([3,'default']);
      Z([3,'Return'])
    })(__MAML_GLOBAL__.ops_cached.$gma_29);
    return __MAML_GLOBAL__.ops_cached.$gma_29
  }
  function gz$gma_30(){
    if(__MAML_GLOBAL__.ops_cached.$gma_30)return __MAML_GLOBAL__.ops_cached.$gma_30
    __MAML_GLOBAL__.ops_cached.$gma_30=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"navigate"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'wrapper']);
      Z([3,'Retain the current page and switch to a page in the application. However, the tabbar page cannot be displayed.']);
      Z([3,'navigateTo']);
      Z([3,'primary']);
      Z([3,'Closes the current page and returns to the previous page or multi-level pages.']);
      Z([3,'navigateBack']);
      Z([3,'Close the current page and go to a page in the application. However, the tabbar page cannot be redirected.']);
      Z([3,'redirectTo']);
      Z([3,'The TabBar page is displayed and all non-tabBar pages are closed.']);
      Z([3,'switchTab']);
      Z([3,'Close all pages and open a page in the app.']);
      Z([3,'reLaunch']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_30);
    return __MAML_GLOBAL__.ops_cached.$gma_30
  }
  function gz$gma_31(){
    if(__MAML_GLOBAL__.ops_cached.$gma_31)return __MAML_GLOBAL__.ops_cached.$gma_31
    __MAML_GLOBAL__.ops_cached.$gma_31=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"redirect"]]);
      Z([3,'wrapper navigatorPage']);
      Z([3,'A page']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_31);
    return __MAML_GLOBAL__.ops_cached.$gma_31
  }
  function gz$gma_32(){
    if(__MAML_GLOBAL__.ops_cached.$gma_32)return __MAML_GLOBAL__.ops_cached.$gma_32
    __MAML_GLOBAL__.ops_cached.$gma_32=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[9],[[8],"title",[1,"onNetworkStatusChange"]],[[8],"desc",[1,"Monitors network signal changes"]]]);
      Z([3,'page-body']);
      Z([3,'onNetworkStatusChange']);
      Z([3,'primary']);
      Z([3,'Registering a Listener']);
      Z([3,'offNetworkStatusChange']);
      Z([3,'Deleting a Listener']);
      Z([3,'text-area']);
      Z([11,[[7],[3,"detail"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_32);
    return __MAML_GLOBAL__.ops_cached.$gma_32
  }
  function gz$gma_33(){
    if(__MAML_GLOBAL__.ops_cached.$gma_33)return __MAML_GLOBAL__.ops_cached.$gma_33
    __MAML_GLOBAL__.ops_cached.$gma_33=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"openDocument"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'openDocument']);
      Z([3,'primary']);
      Z([3,'Open a file']);
      Z([3,'body-view']);
      Z([3,'Switching to the Public Network']);
      Z([3,'isPublicNetChange']);
      Z([[7],[3,"isPublicNet"]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_33);
    return __MAML_GLOBAL__.ops_cached.$gma_33
  }
  function gz$gma_34(){
    if(__MAML_GLOBAL__.ops_cached.$gma_34)return __MAML_GLOBAL__.ops_cached.$gma_34
    __MAML_GLOBAL__.ops_cached.$gma_34=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"pullDownRefresh"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'startPullDownRefresh']);
      Z([3,'PullDownRefresh']);
      Z([3,'stopPullDownRefresh']);
      Z([3,'StopPullDownRefresh']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_34);
    return __MAML_GLOBAL__.ops_cached.$gma_34
  }
  function gz$gma_35(){
    if(__MAML_GLOBAL__.ops_cached.$gma_35)return __MAML_GLOBAL__.ops_cached.$gma_35
    __MAML_GLOBAL__.ops_cached.$gma_35=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"request"]]);
      Z([3,'page-body']);
      Z([3,'page-body-wording']);
      Z([3,'page-body-text']);
      Z([11,[[7],[3,"text"]]]);
      Z([3,'btn-area']);
      Z([3,'makeRequest']);
      Z([3,'getRequest']);
      Z([[7],[3,"buttonDisabled"]]);
      Z([[7],[3,"loading"]]);
      Z([3,'primary']);
      Z([3,'request(GET) - get location']);
      Z([3,'makePostRequest']);
      Z([3,'postRequest']);
      Z([[7],[3,"buttonPostDisabled"]]);
      Z([[7],[3,"PostLoading"]]);
      Z([3,'request(POST)- get token']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_35);
    return __MAML_GLOBAL__.ops_cached.$gma_35
  }
  function gz$gma_36(){
    if(__MAML_GLOBAL__.ops_cached.$gma_36)return __MAML_GLOBAL__.ops_cached.$gma_36
    __MAML_GLOBAL__.ops_cached.$gma_36=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"scanCode"]]);
      Z([3,'page-body']);
      Z([3,'weui-cells__title']);
      Z([3,'QR code scanning result']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell']);
      Z([3,'weui-cell__bd result']);
      Z([11,[[7],[3,"result"]]]);
      Z([3,'weui-cell__bd']);
      Z([11,[[7],[3,"complete"]]]);
      Z([3,'btn-area']);
      Z([3,'scanCode']);
      Z([3,'primary']);
      Z([3,'Sweep']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_36);
    return __MAML_GLOBAL__.ops_cached.$gma_36
  }
  function gz$gma_37(){
    if(__MAML_GLOBAL__.ops_cached.$gma_37)return __MAML_GLOBAL__.ops_cached.$gma_37
    __MAML_GLOBAL__.ops_cached.$gma_37=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"get/set/ScreenBrightness"]]);
      Z([3,'page-body']);
      Z([3,'page-body-info']);
      Z([3,'page-body-title']);
      Z([3,'Current screen brightness']);
      Z([3,'page-body-text-screen-brightness']);
      Z([11,[[7],[3,"screenBrightness"]]]);
      Z([3,'page-section page-section-gap']);
      Z([3,'page-section-title']);
      Z([3,'Set screen brightness']);
      Z([3,'body-view']);
      Z([3,'changeBrightness']);
      Z([3,'brightness']);
      Z([3,'1']);
      Z([3,'0']);
      Z([3,'0.1']);
      Z([[7],[3,"screenBrightness"]]);
      Z([3,'setKeepScreenOn']);
      Z([3,'screenBrightness']);
      Z([3,'primary']);
      Z([3,'Set the screen to be steady on']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_37);
    return __MAML_GLOBAL__.ops_cached.$gma_37
  }
  function gz$gma_38(){
    if(__MAML_GLOBAL__.ops_cached.$gma_38)return __MAML_GLOBAL__.ops_cached.$gma_38
    __MAML_GLOBAL__.ops_cached.$gma_38=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"setBackground"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'style']);
      Z([3,'weui-cell__bd']);
      Z([3,'textStyleChange']);
      Z([3,'weui-input']);
      Z([3,'textStyle']);
      Z([3,'PleaseEnter textStyle']);
      Z([3,'text']);
      Z([[7],[3,"textStyle"]]);
      Z([3,'background colo']);
      Z([3,'backgroundColorChange']);
      Z([3,'backgroundColor']);
      Z([3,'PleaseEnter backgroundColor']);
      Z([[7],[3,"backgroundColor"]]);
      Z([3,'btn-area']);
      Z([3,'setBackgroundTextStyle']);
      Z([3,'Setting the Loading Style']);
      Z([3,'setBackgroundColor']);
      Z([3,'Sets the window background color']);
      Z([3,'dropDown']);
      Z([3,'onPullDownRefresh']);
      Z([3,'primary']);
      Z([3,'pull to refresh']);
      Z([3,'text-area']);
      Z([3,'message']);
      Z([3,'white-space: pre-line;']);
      Z([11,[[7],[3,"detail"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_38);
    return __MAML_GLOBAL__.ops_cached.$gma_38
  }
  function gz$gma_39(){
    if(__MAML_GLOBAL__.ops_cached.$gma_39)return __MAML_GLOBAL__.ops_cached.$gma_39
    __MAML_GLOBAL__.ops_cached.$gma_39=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"setNavigationBarColor"]]);
      Z([3,'setNavigationBarColor']);
      Z([3,'page-body']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'Foreground color value']);
      Z([3,'weui-cell__bd']);
      Z([3,'frontColorChange']);
      Z([3,'weui-input']);
      Z([3,'frontColor']);
      Z([3,'Please enter a hexadecimal color']);
      Z([3,'text']);
      Z([[7],[3,"frontColor"]]);
      Z([3,'Background color value']);
      Z([3,'backgroundColorChange']);
      Z([3,'backgroundColor']);
      Z([[7],[3,"backgroundColor"]]);
      Z([3,'btn-area']);
      Z([3,'submit']);
      Z([3,'primary']);
      Z([3,'set']);
      Z([3,'text-area']);
      Z([3,'message']);
      Z([3,'white-space: pre-line;']);
      Z([11,[[7],[3,"detail"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_39);
    return __MAML_GLOBAL__.ops_cached.$gma_39
  }
  function gz$gma_40(){
    if(__MAML_GLOBAL__.ops_cached.$gma_40)return __MAML_GLOBAL__.ops_cached.$gma_40
    __MAML_GLOBAL__.ops_cached.$gma_40=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"setNavigationBarTitle"]]);
      Z([3,'setNavigationBarTitle']);
      Z([3,'page-body']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'Page Title']);
      Z([3,'weui-cell__bd']);
      Z([3,'weui-input']);
      Z([3,'title']);
      Z([3,'Enter the page title and click Settings']);
      Z([3,'text']);
      Z([3,'btn-area']);
      Z([3,'submit']);
      Z([3,'primary']);
      Z([3,'set']);
      Z([3,'setNavigationBarTitleFail']);
      Z([3,'No title setting']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_40);
    return __MAML_GLOBAL__.ops_cached.$gma_40
  }
  function gz$gma_41(){
    if(__MAML_GLOBAL__.ops_cached.$gma_41)return __MAML_GLOBAL__.ops_cached.$gma_41
    __MAML_GLOBAL__.ops_cached.$gma_41=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"action-sheet"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'actionSheetTap']);
      Z([3,'showActionSheet']);
      Z([3,'primary']);
      Z([3,'The action sheet is displayed']);
      Z([3,'showActionSheetFail']);
      Z([3,'The value of itemList is greater than 6']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_41);
    return __MAML_GLOBAL__.ops_cached.$gma_41
  }
  function gz$gma_42(){
    if(__MAML_GLOBAL__.ops_cached.$gma_42)return __MAML_GLOBAL__.ops_cached.$gma_42
    __MAML_GLOBAL__.ops_cached.$gma_42=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"get/set/clearStorage"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'ma-cells ma-cells_after-title']);
      Z([3,'ma-cell ma-cell_input']);
      Z([3,'ma-cell__hd']);
      Z([3,'ma-label']);
      Z([3,'key']);
      Z([3,'ma-cell__bd']);
      Z([3,'keyChange']);
      Z([3,'ma-input']);
      Z([3,'Enter a key']);
      Z([3,'text']);
      Z([[7],[3,"key"]]);
      Z([3,'value']);
      Z([3,'dataChange']);
      Z([3,'-1']);
      Z([3,'data']);
      Z([3,'Enter a value']);
      Z([[7],[3,"data"]]);
      Z([3,'btn-area']);
      Z([3,'setStorage']);
      Z([3,'primary']);
      Z([3,'Synchronizing Storage Data']);
      Z([3,'getStorage']);
      Z([3,'Read data synchronously']);
      Z([3,'clearStorage']);
      Z([3,'Clearing Data']);
      Z([3,'setStorageWithObj']);
      Z([3,'setStorageJson']);
      Z([3,'Synchronize storage objects {a:1,b:2}']);
      Z([3,'setStorageWithObjArray']);
      Z([3,'setStorageJsonArray']);
      Z([3,'Synchronous storage with array JSON']);
      Z([3,'getStorageWithObj']);
      Z([3,'']);
      Z([3,'Synchronous Read Object {a:1,b:2}']);
      Z([3,'setStorageWithDate']);
      Z([3,'setStorageDate']);
      Z([3,'Synchronize Storage Date Object']);
      Z([3,'getStorageWithDate']);
      Z([3,'getStorageDate']);
      Z([3,'Synchronous Read Date Object']);
      Z([3,'setStorageWithAarryBuffer']);
      Z([3,'setStoragefun']);
      Z([3,'Synchronous Storage Unsupported Type']);
      Z([3,'getStorageWithAarryBuffer']);
      Z([3,'getStoragefun']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_42);
    return __MAML_GLOBAL__.ops_cached.$gma_42
  }
  function gz$gma_43(){
    if(__MAML_GLOBAL__.ops_cached.$gma_43)return __MAML_GLOBAL__.ops_cached.$gma_43
    __MAML_GLOBAL__.ops_cached.$gma_43=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"get/set/clearStorage"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'ma-cells ma-cells_after-title']);
      Z([3,'ma-cell ma-cell_input']);
      Z([3,'ma-cell__hd']);
      Z([3,'ma-label']);
      Z([3,'key']);
      Z([3,'ma-cell__bd']);
      Z([3,'keyChange']);
      Z([3,'ma-input']);
      Z([3,'Enter a key']);
      Z([3,'text']);
      Z([[7],[3,"key"]]);
      Z([3,'value']);
      Z([3,'dataChange']);
      Z([3,'data']);
      Z([3,'Enter a value']);
      Z([[7],[3,"data"]]);
      Z([3,'btn-area']);
      Z([3,'setStorage']);
      Z([3,'primary']);
      Z([3,'stored data']);
      Z([3,'getStorage']);
      Z([3,'Read Data']);
      Z([3,'getStorageInfo']);
      Z([3,'Obtains the current storage']);
      Z([3,'removeStorage']);
      Z([3,'Remove Data']);
      Z([3,'clearStorage']);
      Z([3,'Clearing Data']);
      Z([3,'setStorageWithObj']);
      Z([3,'Storage objects {a:1,b:2}']);
      Z([3,'getStorageWithObj']);
      Z([3,'Read object {a:1,b:2}']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_43);
    return __MAML_GLOBAL__.ops_cached.$gma_43
  }
  function gz$gma_44(){
    if(__MAML_GLOBAL__.ops_cached.$gma_44)return __MAML_GLOBAL__.ops_cached.$gma_44
    __MAML_GLOBAL__.ops_cached.$gma_44=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"toast"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'popSuccess']);
      Z([3,'successToast']);
      Z([3,'primary']);
      Z([3,'Success']);
      Z([3,'popError']);
      Z([3,'errorToast']);
      Z([3,'warn']);
      Z([3,'failed']);
      Z([3,'popLoading']);
      Z([3,'loadingToast']);
      Z([3,'default']);
      Z([3,'wait']);
      Z([3,'popimage']);
      Z([3,'imgToast']);
      Z([3,'Image']);
      Z([3,'popOther']);
      Z([3,'otherToast']);
      Z([3,'Other']);
      Z([3,'mask']);
      Z([3,'maskToast']);
      Z([3,'Show Mask']);
      Z([3,'close']);
      Z([3,'closeToast']);
      Z([3,'Close the dialog box']);
      Z([3,'Enter text to display']);
      Z([3,'margin-top: 20px; border: 1px solid #1aad19;']);
      Z([[7],[3,"toastTitle"]]);
      Z([3,'popInput']);
      Z([3,'inputToast']);
      Z([3,'Show entered text']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_44);
    return __MAML_GLOBAL__.ops_cached.$gma_44
  }
  function gz$gma_45(){
    if(__MAML_GLOBAL__.ops_cached.$gma_45)return __MAML_GLOBAL__.ops_cached.$gma_45
    __MAML_GLOBAL__.ops_cached.$gma_45=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"uploadFile"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'popuploadFile']);
      Z([3,'uploadFile']);
      Z([3,'UploadAFile']);
      Z([3,'UploadAFile：nameNull']);
      Z([3,'uploadFile2']);
      Z([3,'UploadAFile：urlNull']);
      Z([3,'uploadFile3']);
      Z([3,'UploadAFile：filePathNull']);
      Z([[2,"!"],[[2,"!"],[[7],[3,"info"]]]]);
      Z([3,'result']);
      Z([3,'-1']);
      Z([[7],[3,"info"]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_45);
    return __MAML_GLOBAL__.ops_cached.$gma_45
  }
  function gz$gma_46(){
    if(__MAML_GLOBAL__.ops_cached.$gma_46)return __MAML_GLOBAL__.ops_cached.$gma_46
    __MAML_GLOBAL__.ops_cached.$gma_46=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"vibrate"]]);
      Z([3,'page-body']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'Vibration intensity']);
      Z([3,'weui-cell__bd']);
      Z([3,'typeChange']);
      Z([3,'selector']);
      Z([[7],[3,"type"]]);
      Z([[7],[3,"typeIndex"]]);
      Z([3,'weui-input']);
      Z([11,[[6],[[7],[3,"type"]],[[7],[3,"typeIndex"]]]]);
      Z([3,'btn-area']);
      Z([3,'vibrateLong']);
      Z([3,'primary']);
      Z([3,'long vibration']);
      Z([3,'vibrateShort']);
      Z([3,'default']);
      Z([3,'short vibration']);
      Z([3,'weui-cell']);
      Z([3,'weui-cell__bd result']);
      Z([11,[[7],[3,"result"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_46);
    return __MAML_GLOBAL__.ops_cached.$gma_46
  }
  function gz$gma_47(){
    if(__MAML_GLOBAL__.ops_cached.$gma_47)return __MAML_GLOBAL__.ops_cached.$gma_47
    __MAML_GLOBAL__.ops_cached.$gma_47=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"WebSocket"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell']);
      Z([3,'weui-cell__bd']);
      Z([3,'ws url']);
      Z([3,'weui-cell__ft']);
      Z([3,'wsurl']);
      Z([3,'Enter the WS service address']);
      Z([3,'width: 80%; text-align: left']);
      Z([[7],[3,"wsUrl"]]);
      Z([3,'code (when disabled)']);
      Z([3,'closecode']);
      Z([3,'Enter the close status code']);
      Z([3,'width: 62%; text-align: left']);
      Z([3,'number']);
      Z([[7],[3,"closeCode"]]);
      Z([3,'reason (when disabled)']);
      Z([3,'closereason']);
      Z([3,'Enter the close reaso']);
      Z([[7],[3,"closeReason"]]);
      Z([3,'weui-cell weui-cell_switch']);
      Z([3,'SocketStatus']);
      Z([3,'toggleSocket']);
      Z([[2,"!"],[[7],[3,"hasLogin"]]]);
      Z([3,'message']);
      Z([3,'websockermsg']);
      Z([3,'Enter a message to send']);
      Z([[7],[3,"messageToSend"]]);
      Z([3,'btn-area']);
      Z([3,'sendMessage']);
      Z([3,'send']);
      Z([[7],[3,"loading"]]);
      Z([3,'40']);
      Z([3,'primary']);
      Z([3,'Click me to send']);
      Z([3,' weui-cell my-cell']);
      Z([3,'API fail callback error information:']);
      Z([3,'weui-cell__ft my-weui-cell__ft']);
      Z([3,'apifail']);
      Z([11,[[7],[3,"errMsg"]]]);
      Z([3,'Intercepted Data OnOpen：']);
      Z([3,'openmsg']);
      Z([11,[[7],[3,"onOpenData"]]]);
      Z([3,'weui-cell my-cell']);
      Z([3,'weui-cell__bd ']);
      Z([3,'Intercepted Data OnClose：']);
      Z([3,'closemsg']);
      Z([11,[[7],[3,"onCloseData"]]]);
      Z([3,'Intercepted Data OnMessage: (communication message)']);
      Z([3,'onmsg']);
      Z([11,[[7],[3,"onMessageData"]]]);
      Z([3,'Intercepted Data OnError: (error information)']);
      Z([3,'OnError']);
      Z([11,[[7],[3,"onErrorData"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_47);
    return __MAML_GLOBAL__.ops_cached.$gma_47
  }
  function gz$gma_48(){
    if(__MAML_GLOBAL__.ops_cached.$gma_48)return __MAML_GLOBAL__.ops_cached.$gma_48
    __MAML_GLOBAL__.ops_cached.$gma_48=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'page-foot']);
      Z([3,'none']);
      Z([3,'switchTab']);
      Z([3,'/page/tabbar/component/index']);
      Z([3,'icon-foot']);
      Z([3,'../../../../image/icon_foot.png'])
    })(__MAML_GLOBAL__.ops_cached.$gma_48);
    return __MAML_GLOBAL__.ops_cached.$gma_48
  }
  function gz$gma_49(){
    if(__MAML_GLOBAL__.ops_cached.$gma_49)return __MAML_GLOBAL__.ops_cached.$gma_49
    __MAML_GLOBAL__.ops_cached.$gma_49=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'page-head']);
      Z([3,'page-head-title']);
      Z([11,[[7],[3,"title"]]]);
      Z([3,'page-head-line']);
      Z([[7],[3,"desc"]]);
      Z([3,'page-head-desc']);
      Z([11,[[7],[3,"desc"]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_49);
    return __MAML_GLOBAL__.ops_cached.$gma_49
  }
  function gz$gma_50(){
    if(__MAML_GLOBAL__.ops_cached.$gma_50)return __MAML_GLOBAL__.ops_cached.$gma_50
    __MAML_GLOBAL__.ops_cached.$gma_50=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"audio"]]);
      Z([3,'page-body']);
      Z([3,'page-section page-section-gap']);
      Z([3,'text-align: center;']);
      Z([[7],[3,"author"]]);
      Z([3,'bindended']);
      Z([3,'binderror']);
      Z([3,'bindpause']);
      Z([3,'bindplay']);
      Z([3,'bindtimeupdate']);
      Z([[7],[3,"controls"]]);
      Z([3,'myAudio']);
      Z([[7],[3,"loop"]]);
      Z([[7],[3,"name"]]);
      Z([[7],[3,"poster"]]);
      Z([[7],[3,"src"]]);
      Z([3,'text-align: left']);
      Z([3,'section section_gap']);
      Z([3,'section__title']);
      Z([3,'playout']);
      Z([3,'body-view playbutton']);
      Z([3,'playAudio']);
      Z([3,'pause']);
      Z([3,'body-view pausebutton']);
      Z([3,'pauseAudio']);
      Z([3,'Progress jump']);
      Z([3,'body-view seekbutton']);
      Z([3,'seekAudio']);
      Z([3,'Jump to 30 seconds']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_50);
    return __MAML_GLOBAL__.ops_cached.$gma_50
  }
  function gz$gma_51(){
    if(__MAML_GLOBAL__.ops_cached.$gma_51)return __MAML_GLOBAL__.ops_cached.$gma_51
    __MAML_GLOBAL__.ops_cached.$gma_51=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"button"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'buttonContainer']);
      Z([3,'hoverclass']);
      Z([3,'200']);
      Z([3,'5000']);
      Z([3,'btn-area1']);
      Z([3,'default']);
      Z([3,'primary']);
      Z([3,'Main operations on the page Normal']);
      Z([3,'btn-area2']);
      Z([3,'true']);
      Z([3,'Main operations on the page Loading']);
      Z([3,'btn-area3']);
      Z([3,'Main operations on the page Disabled']);
      Z([3,'btn-area4']);
      Z([3,'buttonHoverclass']);
      Z([3,'2000']);
      Z([3,'1000']);
      Z([3,'Page Minor Operations Normal']);
      Z([3,'btn-area5']);
      Z([3,'Page Minor Operations Disabled']);
      Z([3,'btn-area6']);
      Z([3,'false']);
      Z([3,'none']);
      Z([3,'warn']);
      Z([3,'Warning operations Normal']);
      Z([3,'btn-area7']);
      Z([3,'Warning operations Disabled']);
      Z([3,'btn-area8']);
      Z([3,'button-hover']);
      Z([3,'Page Minor Operations hover']);
      Z([3,'button-sp-area']);
      Z([3,'button-sp-area1']);
      Z([3,'button']);
      Z([3,'button-sp-area2']);
      Z([3,'Non-Clickable Buttons']);
      Z([3,'button-sp-area3']);
      Z([3,'button-sp-area4']);
      Z([3,'mini-btn mini-btn1']);
      Z([3,'mini']);
      Z([3,'mini-btn mini-btn2']);
      Z([3,'mini-btn mini-btn3']);
      Z([3,'button-area-abnormal']);
      Z([3,'3000']);
      Z([3,'button-area-abnormal1']);
      Z([3,'abc']);
      Z([3,'Invalid value test button 1']);
      Z([3,'button-area-abnormal2']);
      Z([3,'123']);
      Z([3,'Invalid value test button 2']);
      Z([3,'button-area-abnormal3']);
      Z([3,'Invalid value test button 3']);
      Z([3,'button-area-abnormal4']);
      Z([3,'Invalid value test button 4']);
      Z([3,'button-area-abnormal5']);
      Z([3,'Invalid value test button 5']);
      Z([3,'button-area-abnormal6']);
      Z([3,'Invalid value test button 6']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_51);
    return __MAML_GLOBAL__.ops_cached.$gma_51
  }
  function gz$gma_52(){
    if(__MAML_GLOBAL__.ops_cached.$gma_52)return __MAML_GLOBAL__.ops_cached.$gma_52
    __MAML_GLOBAL__.ops_cached.$gma_52=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"Camera"]]);
      Z([3,'error']);
      Z([3,'stop']);
      Z([[7],[3,"position"]]);
      Z([[7],[3,"flash"]]);
      Z([3,'width: 100%; height: 300px;']);
      Z([3,'takePhoto']);
      Z([3,'takephoto']);
      Z([3,'primary']);
      Z([3,'TakeAphoto']);
      Z([3,'takePosition']);
      Z([3,'SwitchCameras']);
      Z([3,'takeFlash']);
      Z([3,'TurnOnTheFlash']);
      Z([3,'preview']);
      Z([[7],[3,"src"]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_52);
    return __MAML_GLOBAL__.ops_cached.$gma_52
  }
  function gz$gma_53(){
    if(__MAML_GLOBAL__.ops_cached.$gma_53)return __MAML_GLOBAL__.ops_cached.$gma_53
    __MAML_GLOBAL__.ops_cached.$gma_53=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"checkbox"]]);
      Z([3,'page-body']);
      Z([3,'page-section page-section-gap']);
      Z([3,'page-section-title']);
      Z([3,'default styl']);
      Z([3,'checkbox']);
      Z([3,'true']);
      Z([3,'checkbox1']);
      Z([3,'#09BB07']);
      Z([3,'cb']);
      Z([3,'checked']);
      Z([3,'checkbox2']);
      Z([3,'Unchecked']);
      Z([3,'page-section']);
      Z([3,'Recommended display style']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'checkboxChange']);
      Z([[7],[3,"items"]]);
      Z([[6],[[7],[3,"item"]],[3,"value"]]);
      Z([3,'weui-cell weui-check__label']);
      Z([3,'weui-cell__hd']);
      Z([[6],[[7],[3,"item"]],[3,"checked"]]);
      Z([11,[3,'checkbox-'],[[6],[[7],[3,"item"]],[3,"value"]]]);
      Z([3,'pink']);
      Z([3,'weui-cell__bd']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_53);
    return __MAML_GLOBAL__.ops_cached.$gma_53
  }
  function gz$gma_54(){
    if(__MAML_GLOBAL__.ops_cached.$gma_54)return __MAML_GLOBAL__.ops_cached.$gma_54
    __MAML_GLOBAL__.ops_cached.$gma_54=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"cover-image"]]);
      Z([3,'error']);
      Z([3,'back']);
      Z([3,'off']);
      Z([3,'width: 100%; height: 300px;']);
      Z([3,'cover-image']);
      Z([3,'https://img.jianbihua.com/sites/default/files/styles/photo640x425logofull/public/images/2020-08/20200824151352_903065.jpg']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_54);
    return __MAML_GLOBAL__.ops_cached.$gma_54
  }
  function gz$gma_55(){
    if(__MAML_GLOBAL__.ops_cached.$gma_55)return __MAML_GLOBAL__.ops_cached.$gma_55
    __MAML_GLOBAL__.ops_cached.$gma_55=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"cover-view"]]);
      Z([3,'changeColor']);
      Z([3,'12345']);
      Z([3,'error']);
      Z([3,'back']);
      Z([3,'off']);
      Z([3,'width: 100%; height: 720rpx;']);
      Z([3,'cover-view']);
      Z([11,[3,'c-cover-view '],[[7],[3,"red"]]]);
      Z([3,'This is red']);
      Z([3,'c-cover-view green']);
      Z([3,'This is green']);
      Z([3,'c-cover-view yellow']);
      Z([3,'This is yellow']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_55);
    return __MAML_GLOBAL__.ops_cached.$gma_55
  }
  function gz$gma_56(){
    if(__MAML_GLOBAL__.ops_cached.$gma_56)return __MAML_GLOBAL__.ops_cached.$gma_56
    __MAML_GLOBAL__.ops_cached.$gma_56=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"form"]]);
      Z([3,'page-body']);
      Z([3,'reset']);
      Z([3,'submit']);
      Z([3,'form']);
      Z([3,'page-section page-section-gap']);
      Z([3,'page-section-title']);
      Z([3,'switch']);
      Z([3,'radio']);
      Z([3,'radioGroup']);
      Z([3,'radio1']);
      Z([3,'Option1']);
      Z([3,'radio2']);
      Z([3,'Option2']);
      Z([3,'checkbox']);
      Z([3,'checkboxGroup']);
      Z([3,'checkbox1']);
      Z([3,'checkbox2']);
      Z([3,'slider']);
      Z([3,'slider1']);
      Z([3,'true']);
      Z([3,'50']);
      Z([3,'page-section']);
      Z([3,'input']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__bd']);
      Z([3,'weui-input']);
      Z([3,'input1']);
      Z([3,'This is an input box']);
      Z([3,'btn-area']);
      Z([3,'primary']);
      Z([3,'Submit']);
      Z([3,'Reset']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_56);
    return __MAML_GLOBAL__.ops_cached.$gma_56
  }
  function gz$gma_57(){
    if(__MAML_GLOBAL__.ops_cached.$gma_57)return __MAML_GLOBAL__.ops_cached.$gma_57
    __MAML_GLOBAL__.ops_cached.$gma_57=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"icon"]]);
      Z([3,'icon-box']);
      Z([3,'icon-box-img icon1']);
      Z([3,'93']);
      Z([3,'success']);
      Z([3,'icon-box-ctn']);
      Z([3,'icon-box-title']);
      Z([3,'icon-box-desc']);
      Z([3,'Used to indicate that the operation completed successfully.']);
      Z([3,'icon-box-img icon2']);
      Z([3,'info']);
      Z([3,'Indicates the information prompt. It is also used to intercept operations without conditions, prompting users of required information.']);
      Z([3,'icon-box-img icon3']);
      Z([3,'#C9C9C9']);
      Z([3,'warn']);
      Z([3,'Indicates the situation that will result in certain consequences after the operation. Also used to indicate negative results due to system reasons']);
      Z([3,'icon-box-img icon4']);
      Z([3,'Strong warning']);
      Z([3,'Indicates the negative result caused by the user. Also used to indicate that the operation will result in irreparable consequences.']);
      Z([3,'icon-box-img icon5']);
      Z([3,'waiting']);
      Z([3,'This parameter indicates that the user needs to wait for the result.']);
      Z([3,'icon-small-wrp']);
      Z([3,'icon-small']);
      Z([3,'23']);
      Z([3,'Multi-Selection Control Icon_Selected']);
      Z([3,'Used in a multi-selection control to indicate that the item has been selected.']);
      Z([3,'icon-small icon6']);
      Z([3,'circle']);
      Z([3,'Multi-Selection Control Icon_Not Selected']);
      Z([3,'Used in the multi-selection control to indicate that the item can be selected but has not been selected.']);
      Z([3,'Error message']);
      Z([3,'Used to indicate an error in a form']);
      Z([3,'icon-small icon7']);
      Z([3,'success_no_circle']);
      Z([3,'Radio Control Icon_Selected']);
      Z([3,'Used in a radio control to indicate that the item has been selected.']);
      Z([3,'icon-small icon8']);
      Z([3,'download']);
      Z([3,'Used to indicate downloadable']);
      Z([3,'icon-small icon9']);
      Z([3,'info_circle']);
      Z([3,'Used to indicate an information prompt in a form']);
      Z([3,'icon-small icon10']);
      Z([3,'cancel']);
      Z([3,'Stop or Shut Down']);
      Z([3,'Used in a form to indicate shutdown or stop']);
      Z([3,'icon-small icon11']);
      Z([3,'14']);
      Z([3,'search']);
      Z([3,'Used in search controls, indicating that searchable']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_57);
    return __MAML_GLOBAL__.ops_cached.$gma_57
  }
  function gz$gma_58(){
    if(__MAML_GLOBAL__.ops_cached.$gma_58)return __MAML_GLOBAL__.ops_cached.$gma_58
    __MAML_GLOBAL__.ops_cached.$gma_58=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"image"]]);
      Z([3,'page-body']);
      Z([[7],[3,"array"]]);
      Z([3,'item']);
      Z([3,'page-section page-section-gap']);
      Z([3,'page-section-title']);
      Z([11,[[6],[[7],[3,"item"]],[3,"text"]]]);
      Z([3,'page-section-ctn']);
      Z([3,'binderror']);
      Z([3,'bindload']);
      Z([11,[3,'image'],[[7],[3,"index"]]]);
      Z([[6],[[7],[3,"item"]],[3,"mode"]]);
      Z([[7],[3,"src"]]);
      Z([3,'widthFix：width200px，The width-to-height ratio remains unchanged.']);
      Z([3,'image-widthFix']);
      Z([3,'widthFix']);
      Z([3,'heightFix：height200px，The width-to-height ratio remains unchanged.']);
      Z([3,'image-heightFix']);
      Z([3,'heightFix']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_58);
    return __MAML_GLOBAL__.ops_cached.$gma_58
  }
  function gz$gma_59(){
    if(__MAML_GLOBAL__.ops_cached.$gma_59)return __MAML_GLOBAL__.ops_cached.$gma_59
    __MAML_GLOBAL__.ops_cached.$gma_59=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"input"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'weui-cells__title']);
      Z([3,'disabled input']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-input input0']);
      Z([3,'true']);
      Z([3,'This is an inoperable input.']);
      Z([3,'Input that can be auto-focused']);
      Z([3,'bindblur']);
      Z([3,'bindconfirm']);
      Z([3,'bindfocus']);
      Z([3,'weui-input input16']);
      Z([3,'done']);
      Z([3,'Will get focus']);
      Z([3,'3']);
      Z([3,'1']);
      Z([3,'Display focus range']);
      Z([3,'Input that controls the maximum input length.']);
      Z([3,'weui-input input1']);
      Z([3,'12']);
      Z([3,'The value contains a maximum of 10 characters.']);
      Z([3,'1234567890111']);
      Z([3,'weui-cells__title inputvalue']);
      Z([11,[3,'Obtain input values in real time:'],[[7],[3,"inputValue"]]]);
      Z([3,'bindKeyInput']);
      Z([3,'weui-input input2']);
      Z([3,'Synchronize input to view']);
      Z([3,'Controls the input.']);
      Z([3,'bindReplaceInput']);
      Z([3,'weui-input input3']);
      Z([3,'Two consecutive ones become two.']);
      Z([3,'Directly return the input of the character string.']);
      Z([3,'bindinput']);
      Z([3,'weui-input input4']);
      Z([3,'Directly return a character string.']);
      Z([3,'digit']);
      Z([3,'Digital input']);
      Z([3,'weui-input input5']);
      Z([3,'This is a number entry box.']);
      Z([3,'number']);
      Z([3,'Password input']);
      Z([3,'weui-input input6']);
      Z([3,'This is a password entry box.']);
      Z([3,'text']);
      Z([3,'Input that controls the color of the placeholder']);
      Z([3,'weui-input input8']);
      Z([3,'Placeholder font is red']);
      Z([3,'placeholderclass']);
      Z([3,'color:#F76260']);
      Z([3,'Input that does not collapse when you click the lower right corner of the keyboard']);
      Z([3,'weui-input']);
      Z([3,'Keep the keyboard unstuck']);
      Z([3,'weui-cells__title inputmode']);
      Z([11,[3,'The input value of bidirectional binding is '],[[7],[3,"modelValue"]]]);
      Z([3,'weui-input input9']);
      Z([[7],[3,"modelValue"]]);
      Z([3,'ID Card Input Keyboard']);
      Z([3,'weui-input input10']);
      Z([3,'idcard']);
      Z([3,'Password Security Keyboard']);
      Z([3,'weui-input input11']);
      Z([3,'safe-password']);
      Z([3,'Nickname Entry Keyboard']);
      Z([3,'weui-input input12']);
      Z([3,'nickname']);
      Z([3,'Automatic test input 1']);
      Z([3,'weui-input input13']);
      Z([3,'search']);
      Z([3,'Auto input 1_placeholder style']);
      Z([3,'font-size:20px;font-weight:800']);
      Z([3,'Automatic test input 2']);
      Z([3,'weui-input input14']);
      Z([3,'send']);
      Z([3,'Automatic input 2_confirmType']);
      Z([3,'Automatic test input 3']);
      Z([3,'weui-input input15']);
      Z([3,'next']);
      Z([3,'AutoInput 3_placeholder Style Class']);
      Z([3,'Automatic test input 4']);
      Z([3,'go']);
      Z([3,'Automated Input 4']);
      Z([3,'Automatic test input 5']);
      Z([3,'false']);
      Z([3,'weui-input input17']);
      Z([3,'2']);
      Z([3,'Automated Input 5']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_59);
    return __MAML_GLOBAL__.ops_cached.$gma_59
  }
  function gz$gma_60(){
    if(__MAML_GLOBAL__.ops_cached.$gma_60)return __MAML_GLOBAL__.ops_cached.$gma_60
    __MAML_GLOBAL__.ops_cached.$gma_60=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"label"]]);
      Z([3,'page-body']);
      Z([3,'page-section page-section-gap']);
      Z([3,'page-section-title']);
      Z([3,'The form component is in the label.']);
      Z([3,'checkboxChange']);
      Z([3,'group']);
      Z([3,'checkboxGroup']);
      Z([[7],[3,"checkboxItems"]]);
      Z([3,'label-1']);
      Z([3,'label1']);
      Z([[6],[[7],[3,"item"]],[3,"checked"]]);
      Z([3,'checkbox1']);
      Z([[6],[[7],[3,"item"]],[3,"name"]]);
      Z([3,'label-1-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"value"]]]);
      Z([3,'label Use for to identify form components']);
      Z([3,'radioChange']);
      Z([3,'radioGroup']);
      Z([[7],[3,"radioItems"]]);
      Z([3,'label-2']);
      Z([3,'pink']);
      Z([3,'label-2-text']);
      Z([[6],[[7],[3,"item"]],[3,"value"]]);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([3,'Select the first label if there are multiple labels.']);
      Z([3,'label-3']);
      Z([3,'checkbox-3']);
      Z([3,'checkbox2']);
      Z([3,'Option 1']);
      Z([3,'checkbox3']);
      Z([3,'label-3-text']);
      Z([3,'Click the text under the label and select the first check box by default.']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_60);
    return __MAML_GLOBAL__.ops_cached.$gma_60
  }
  function gz$gma_61(){
    if(__MAML_GLOBAL__.ops_cached.$gma_61)return __MAML_GLOBAL__.ops_cached.$gma_61
    __MAML_GLOBAL__.ops_cached.$gma_61=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"navigate"]]);
      Z([3,'page-body']);
      Z([3,'']);
      Z([3,'false']);
      Z([3,'Page 1']);
      Z([3,'btn-area']);
      Z([3,'2']);
      Z([3,'other-navigator-hover']);
      Z([3,'navigateBack']);
      Z([3,'default']);
      Z([3,'Return to Home Page']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_61);
    return __MAML_GLOBAL__.ops_cached.$gma_61
  }
  function gz$gma_62(){
    if(__MAML_GLOBAL__.ops_cached.$gma_62)return __MAML_GLOBAL__.ops_cached.$gma_62
    __MAML_GLOBAL__.ops_cached.$gma_62=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"navigator"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'navigator']);
      Z([3,'navigate']);
      Z([3,'default']);
      Z([3,'navigateTopage1']);
      Z([3,'other-navigator-hover']);
      Z([3,'redirect']);
      Z([3,'redirectTopage2']);
      Z([3,'custom-navigator-hover']);
      Z([3,'switchTab']);
      Z([3,'/page/tabbar/component/index']);
      Z([3,'reLaunch']);
      Z([3,'reLaunchTopage3']);
      Z([3,'1']);
      Z([3,'navigateBack']);
      Z([3,'Return']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_62);
    return __MAML_GLOBAL__.ops_cached.$gma_62
  }
  function gz$gma_63(){
    if(__MAML_GLOBAL__.ops_cached.$gma_63)return __MAML_GLOBAL__.ops_cached.$gma_63
    __MAML_GLOBAL__.ops_cached.$gma_63=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"redirect"]]);
      Z([3,'page-body']);
      Z([3,'page 2']);
      Z([3,'btn-area']);
      Z([3,'navigateBack']);
      Z([3,'default']);
      Z([3,'return']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_63);
    return __MAML_GLOBAL__.ops_cached.$gma_63
  }
  function gz$gma_64(){
    if(__MAML_GLOBAL__.ops_cached.$gma_64)return __MAML_GLOBAL__.ops_cached.$gma_64
    __MAML_GLOBAL__.ops_cached.$gma_64=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"reLaunch"]]);
      Z([3,'page-body']);
      Z([3,'page 3']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_64);
    return __MAML_GLOBAL__.ops_cached.$gma_64
  }
  function gz$gma_65(){
    if(__MAML_GLOBAL__.ops_cached.$gma_65)return __MAML_GLOBAL__.ops_cached.$gma_65
    __MAML_GLOBAL__.ops_cached.$gma_65=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"picker-view"]]);
      Z([3,'content']);
      Z([3,'date']);
      Z([11,[[7],[3,"year"]],[3,'year'],[[7],[3,"month"]],[3,'month'],[[7],[3,"day"]],[3,'day']]);
      Z([3,'bindChange']);
      Z([3,'bindpickend']);
      Z([3,'bindpickstart']);
      Z([3,'pickerView']);
      Z([3,'indicatorClass']);
      Z([3,'height: 50px;']);
      Z([3,'maskClass']);
      Z([3,'background-color: #cd2b2b']);
      Z([[7],[3,"value"]]);
      Z([[7],[3,"years"]]);
      Z([3,'line-height: 50px']);
      Z([11,[[7],[3,"item"]],[3,'year']]);
      Z([[7],[3,"months"]]);
      Z([11,[[7],[3,"item"]],[3,'month']]);
      Z([[7],[3,"days"]]);
      Z([11,[[7],[3,"item"]],[3,'day']]);
      Z([11,[3,'bindpickstart count: '],[[7],[3,"bindpickstartCount"]]]);
      Z([11,[3,'bindpickend count: '],[[7],[3,"bindpickendCount"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_65);
    return __MAML_GLOBAL__.ops_cached.$gma_65
  }
  function gz$gma_66(){
    if(__MAML_GLOBAL__.ops_cached.$gma_66)return __MAML_GLOBAL__.ops_cached.$gma_66
    __MAML_GLOBAL__.ops_cached.$gma_66=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"picker"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'reset']);
      Z([3,'submit']);
      Z([3,'weui-cells__title']);
      Z([3,'General Selector']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'current selection']);
      Z([3,'weui-cell__bd']);
      Z([3,'bindcancel']);
      Z([3,'bindPickerChange']);
      Z([3,'title']);
      Z([3,'picker1']);
      Z([[7],[3,"array"]]);
      Z([[7],[3,"index"]]);
      Z([3,'weui-input']);
      Z([11,[[6],[[7],[3,"array"]],[[7],[3,"index"]]]]);
      Z([3,'Selector disabled']);
      Z([3,'true']);
      Z([3,'picker1_disabled']);
      Z([11,[[6],[[7],[3,"array"]],[1,0]]]);
      Z([3,'Common selector with range-key set']);
      Z([3,'bindPickerChangeForRangeKey']);
      Z([3,'picker1_rangekey']);
      Z([[7],[3,"objectArray"]]);
      Z([3,'name']);
      Z([[7],[3,"rangeKeyIndex"]]);
      Z([11,[[6],[[6],[[7],[3,"objectArray"]],[[7],[3,"rangeKeyIndex"]]],[1,"name"]]]);
      Z([3,'multi-column selector']);
      Z([3,'bindMultiPickerChange']);
      Z([3,'bindMultiPickerColumnChange']);
      Z([3,'multiSelector']);
      Z([3,'picker2']);
      Z([[7],[3,"multiArray"]]);
      Z([[7],[3,"multiIndex"]]);
      Z([11,[[7],[3,"multiSelectRes"]]]);
      Z([3,'Time Selector']);
      Z([3,'bindTimeChange']);
      Z([3,'21:01']);
      Z([3,'time']);
      Z([3,'picker3']);
      Z([3,'09:01']);
      Z([[7],[3,"time"]]);
      Z([11,[[7],[3,"time"]]]);
      Z([3,'Date Picker']);
      Z([3,'bindDateChange']);
      Z([3,'2017-09-01']);
      Z([3,'date']);
      Z([3,'picker4']);
      Z([3,'2015-09-01']);
      Z([[7],[3,"date"]]);
      Z([11,[[7],[3,"date"]]]);
      Z([3,'Select only the date picker for the year and month']);
      Z([3,'bindDateMonthChange']);
      Z([3,'2017-09']);
      Z([3,'month']);
      Z([3,'picker4_month']);
      Z([3,'2015-09']);
      Z([[7],[3,"date_month"]]);
      Z([11,[[7],[3,"date_month"]]]);
      Z([3,'Province/city selector']);
      Z([3,'bindRegionChange']);
      Z([[7],[3,"customItem"]]);
      Z([3,'region']);
      Z([3,'picker5']);
      Z([[7],[3,"region"]]);
      Z([11,[[6],[[7],[3,"region"]],[1,0]],[3,'，'],[[6],[[7],[3,"region"]],[1,1]],[3,'，'],[[6],[[7],[3,"region"]],[1,2]]]);
      Z([3,'btn-area']);
      Z([3,'primary']);
      Z([3,'Submit']);
      Z([3,'Reset']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_66);
    return __MAML_GLOBAL__.ops_cached.$gma_66
  }
  function gz$gma_67(){
    if(__MAML_GLOBAL__.ops_cached.$gma_67)return __MAML_GLOBAL__.ops_cached.$gma_67
    __MAML_GLOBAL__.ops_cached.$gma_67=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"progress"]]);
      Z([3,'page-body']);
      Z([3,'default style']);
      Z([3,'progress-box1']);
      Z([3,'ma-progress1']);
      Z([3,'20']);
      Z([3,'true']);
      Z([3,'2']);
      Z([3,'Bind the activeend event, which is invoked after the animation is complete.']);
      Z([3,'progress-box2']);
      Z([3,'activeend']);
      Z([3,'ma-progress2']);
      Z([[7],[3,"percent"]]);
      Z([3,'4']);
      Z([3,'Changeable style']);
      Z([3,'progress-box3']);
      Z([3,'pink']);
      Z([3,'yellow']);
      Z([3,'80']);
      Z([3,'ma-progress3']);
      Z([3,'60']);
      Z([3,'Animation from the beginning']);
      Z([3,'progress-box4']);
      Z([3,'backwards']);
      Z([3,'ma-progress4']);
      Z([3,'30']);
      Z([3,'The animation continues from the last end point.']);
      Z([3,'progress-box5']);
      Z([3,'forwards']);
      Z([3,'ma-progress5']);
      Z([3,'bindtap']);
      Z([3,'progress-box6']);
      Z([3,'Change the progress.']);
      Z([3,'Automated test 1']);
      Z([3,'progress-box7']);
      Z([3,'false']);
      Z([3,'ma-progress7']);
      Z([3,'Automated test 2']);
      Z([3,'progress-box8']);
      Z([3,'ma-progress8']);
      Z([3,'40']);
      Z([3,'abc']);
      Z([3,'Automated test 3']);
      Z([3,'progress-box9']);
      Z([3,'ma-progress9']);
      Z([3,'Automatic test show-info temporary']);
      Z([3,'progress-box10']);
      Z([3,'10px']);
      Z([3,'ma-progress10']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_67);
    return __MAML_GLOBAL__.ops_cached.$gma_67
  }
  function gz$gma_68(){
    if(__MAML_GLOBAL__.ops_cached.$gma_68)return __MAML_GLOBAL__.ops_cached.$gma_68
    __MAML_GLOBAL__.ops_cached.$gma_68=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"radio"]]);
      Z([3,'page-body']);
      Z([3,'page-section page-section-gap']);
      Z([3,'page-section-title']);
      Z([3,'default style']);
      Z([3,'radio']);
      Z([3,'true']);
      Z([3,'radio1']);
      Z([3,'r1']);
      Z([3,'checked']);
      Z([3,'radio2']);
      Z([3,'r2']);
      Z([3,'Unchecked']);
      Z([3,'radio3']);
      Z([3,'r3']);
      Z([3,'disabled']);
      Z([3,'456']);
      Z([3,'radio4']);
      Z([3,'red123']);
      Z([3,'123']);
      Z([3,'r4']);
      Z([3,'Invalid attribute.']);
      Z([3,'page-section']);
      Z([3,'Recommended display style']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'radioChange']);
      Z([[7],[3,"items"]]);
      Z([[6],[[7],[3,"item"]],[3,"value"]]);
      Z([3,'weui-cell weui-check__label']);
      Z([3,'weui-cell__hd']);
      Z([[6],[[7],[3,"item"]],[3,"checked"]]);
      Z([11,[3,'radio-'],[[6],[[7],[3,"item"]],[3,"value"]]]);
      Z([3,'pink']);
      Z([3,'weui-cell__bd']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_68);
    return __MAML_GLOBAL__.ops_cached.$gma_68
  }
  function gz$gma_69(){
    if(__MAML_GLOBAL__.ops_cached.$gma_69)return __MAML_GLOBAL__.ops_cached.$gma_69
    __MAML_GLOBAL__.ops_cached.$gma_69=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"rich-text"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'page-section-title']);
      Z([3,'Simple HTML String Rendering']);
      Z([3,'rich-text-wrp']);
      Z([3,'rich-text1']);
      Z([[7],[3,"html"]]);
      Z([3,'nbsp']);
      Z([3,'Simple Node List Rendering']);
      Z([[7],[3,"nodes"]]);
      Z([3,'Complex HTML String Rendering']);
      Z([[7],[3,"html2"]]);
      Z([3,'Complex Node List Rendering']);
      Z([[7],[3,"nodes2"]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_69);
    return __MAML_GLOBAL__.ops_cached.$gma_69
  }
  function gz$gma_70(){
    if(__MAML_GLOBAL__.ops_cached.$gma_70)return __MAML_GLOBAL__.ops_cached.$gma_70
    __MAML_GLOBAL__.ops_cached.$gma_70=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"scroll-view"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'page-section-title']);
      Z([3,'Vertical Scroll\nVertical scrolling']);
      Z([3,'page-section-spacing']);
      Z([3,'binddragend']);
      Z([3,'binddragging']);
      Z([3,'binddragstart']);
      Z([3,'scroll']);
      Z([3,'lower']);
      Z([3,'upper']);
      Z([3,'scroll-view']);
      Z([3,'true']);
      Z([3,'100']);
      Z([[7],[3,"toView"]]);
      Z([[7],[3,"scrollTop"]]);
      Z([11,[3,'height:'],[[7],[3,"scrollItemHeight"]],[3,'px']]);
      Z([[7],[3,"order"]]);
      Z([3,'item']);
      Z([3,'index']);
      Z([[7],[3,"item"]]);
      Z([11,[3,'scroll-view-item '],[[6],[[7],[3,"item"]],[3,"class"]]]);
      Z([11,[3,'v-'],[[6],[[7],[3,"item"]],[3,"index"]]]);
      Z([3,'button-area']);
      Z([3,'moveTo']);
      Z([[6],[[7],[3,"item"]],[3,"index"]]);
      Z([3,'mini']);
      Z([3,'primary']);
      Z([11,[3,'Scroll to '],[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([3,'scrollToTop']);
      Z([3,'setVposBtn']);
      Z([3,'100px']);
      Z([3,'101']);
      Z([3,'preScrollToUpperBtn']);
      Z([3,'upperThreshold + 1px']);
      Z([3,'99']);
      Z([3,'postScrollToUpperBtn']);
      Z([3,'upperThreshold - 1px']);
      Z([3,'preScrollToLowerBtn']);
      Z([3,'lowerThreshold + 1px']);
      Z([3,'postScrollToLowerBtn']);
      Z([3,'lowerThreshold - 1px']);
      Z([3,'bindscrolltoupperCount']);
      Z([11,[3,'bindscrolltoupper count (V\x26H): '],[[7],[3,"bindscrolltoupperCount"]]]);
      Z([3,'bindscrolltolowerCount']);
      Z([11,[3,'bindscrolltolower count (V\x26H): '],[[7],[3,"bindscrolltolowerCount"]]]);
      Z([3,'bindscrollCount']);
      Z([11,[3,'bindscroll count (V\x26H): '],[[7],[3,"bindscrollCount"]]]);
      Z([3,'binddragstartCount']);
      Z([11,[3,'binddragstart count (H): '],[[7],[3,"binddragstartCount"]]]);
      Z([3,'binddraggingCount']);
      Z([11,[3,'binddragging count (H): '],[[7],[3,"binddraggingCount"]]]);
      Z([3,'binddragendCount']);
      Z([11,[3,'binddragend count (H): '],[[7],[3,"binddragendCount"]]]);
      Z([3,'Horizontal Scroll\nHorizontal scrolling']);
      Z([3,'scroll-view_H']);
      Z([[7],[3,"scrollLeft"]]);
      Z([3,'width: 100%']);
      Z([11,[3,'scroll-view-item_H '],[[6],[[7],[3,"item"]],[3,"class"]]]);
      Z([11,[3,'h-'],[[6],[[7],[3,"item"]],[3,"index"]]]);
      Z([3,'page-section-title setPosition']);
      Z([3,'Set the position of the scroll bar\n']);
      Z([3,'scrollToLeft']);
      Z([3,'setHposBtn1']);
      Z([3,'far left']);
      Z([3,'scrollToLeft2']);
      Z([3,'setHposBtn2']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_70);
    return __MAML_GLOBAL__.ops_cached.$gma_70
  }
  function gz$gma_71(){
    if(__MAML_GLOBAL__.ops_cached.$gma_71)return __MAML_GLOBAL__.ops_cached.$gma_71
    __MAML_GLOBAL__.ops_cached.$gma_71=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"slider"]]);
      Z([3,'date']);
      Z([11,[3,'Slider oblongation'],[[6],[[6],[[7],[3,"e"]],[3,"detail"]],[3,"value"]]]);
      Z([3,'changeslide']);
      Z([11,[3,'Trigger the change event:'],[[7],[3,"isChange"]]]);
      Z([3,'changeslideing']);
      Z([11,[3,'Trigger the change event:'],[[7],[3,"isChanging"]]]);
      Z([3,'page-body']);
      Z([3,'page-section page-section-gap']);
      Z([3,'page-section-title']);
      Z([3,'Set the step']);
      Z([3,'body-view']);
      Z([3,'green']);
      Z([3,'yellow']);
      Z([3,'slider1change']);
      Z([3,'slider1changing']);
      Z([3,'pink']);
      Z([3,'12']);
      Z([3,'slider1']);
      Z([3,'true']);
      Z([[7],[3,"isChange"]]);
      Z([3,'change-slider1 test-span']);
      Z([3,'change slider1']);
      Z([[7],[3,"isChanging"]]);
      Z([3,'changing-slider1 test-span']);
      Z([3,'changing slider1']);
      Z([3,'Displays the current value']);
      Z([3,'slider2change']);
      Z([3,'slider2changing']);
      Z([3,'slider2']);
      Z([3,'5']);
      Z([3,'50']);
      Z([3,'Set Min/Max']);
      Z([3,'slider3change']);
      Z([3,'slider3']);
      Z([3,'200']);
      Z([3,'100']);
      Z([3,'Automatic test of attributes such as min']);
      Z([3,'slider4change']);
      Z([3,'11']);
      Z([3,'slider4']);
      Z([3,'abc']);
      Z([3,'3']);
      Z([3,'The max attribute of the automatic test is not moved. Do not use this attribute for other attributes']);
      Z([3,'slider5change']);
      Z([3,'29']);
      Z([3,'slider5']);
      Z([3,'Auto Test Disable Attribute 1']);
      Z([3,'slider6change']);
      Z([3,'slider6']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_71);
    return __MAML_GLOBAL__.ops_cached.$gma_71
  }
  function gz$gma_72(){
    if(__MAML_GLOBAL__.ops_cached.$gma_72)return __MAML_GLOBAL__.ops_cached.$gma_72
    __MAML_GLOBAL__.ops_cached.$gma_72=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"swiper"]]);
      Z([3,'page-body']);
      Z([3,'page-section page-section-spacing swiper page-swiper']);
      Z([[7],[3,"autoplay"]]);
      Z([[7],[3,"circular"]]);
      Z([[7],[3,"duration"]]);
      Z([[7],[3,"easingFunction"]]);
      Z([[7],[3,"indicatorActiveColor"]]);
      Z([[7],[3,"indicatorColor"]]);
      Z([[7],[3,"indicatorDots"]]);
      Z([[7],[3,"interval"]]);
      Z([[7],[3,"vertical"]]);
      Z([[7],[3,"background"]]);
      Z([3,'*this']);
      Z([11,[3,'swiper-item '],[[7],[3,"item"]]]);
      Z([3,'page-section']);
      Z([3,'margin-top: 40rpx;margin-bottom: 0;']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_switch']);
      Z([3,'weui-cell__bd']);
      Z([3,'Indicating Point']);
      Z([3,'weui-cell__ft swiper-dot']);
      Z([3,'changeIndicatorDots']);
      Z([3,'Autoplay']);
      Z([3,'weui-cell__ft swiper-autoplay']);
      Z([3,'changeAutoplay']);
      Z([3,'page-section page-section-spacing']);
      Z([3,'page-section-title']);
      Z([3,'Slide Switching Duration(ms)']);
      Z([3,'info']);
      Z([11,[[7],[3,"duration"]]]);
      Z([3,'durationChange']);
      Z([3,'swiper-duration']);
      Z([3,'2000']);
      Z([3,'500']);
      Z([3,'Auto-play interval(ms)']);
      Z([11,[[7],[3,"interval"]]]);
      Z([3,'intervalChange']);
      Z([3,'swiper-interval']);
      Z([3,'10000']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_72);
    return __MAML_GLOBAL__.ops_cached.$gma_72
  }
  function gz$gma_73(){
    if(__MAML_GLOBAL__.ops_cached.$gma_73)return __MAML_GLOBAL__.ops_cached.$gma_73
    __MAML_GLOBAL__.ops_cached.$gma_73=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"switch"]]);
      Z([3,'page-body']);
      Z([3,'page-section page-section-gap']);
      Z([3,'page-section-title']);
      Z([3,'Default switch style']);
      Z([3,'body-view']);
      Z([3,'switch1Change']);
      Z([3,'switch1']);
      Z([[7],[3,"isClicked"]]);
      Z([3,'test-span']);
      Z([3,'switch bind change']);
      Z([3,'Checkbox Style']);
      Z([3,'switch2Change']);
      Z([3,'true']);
      Z([3,'switch2']);
      Z([3,'checkbox']);
      Z([3,'Customizing the Switch Color']);
      Z([3,'#000000']);
      Z([3,'switch3']);
      Z([3,'switch4']);
      Z([3,'Disable the switch']);
      Z([3,'switch5']);
      Z([3,'switch6']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_73);
    return __MAML_GLOBAL__.ops_cached.$gma_73
  }
  function gz$gma_74(){
    if(__MAML_GLOBAL__.ops_cached.$gma_74)return __MAML_GLOBAL__.ops_cached.$gma_74
    __MAML_GLOBAL__.ops_cached.$gma_74=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"text"]]);
      Z([3,'page-body']);
      Z([3,'page-section page-section-spacing']);
      Z([3,'text-box']);
      Z([[7],[3,"scrollTop"]]);
      Z([3,'true']);
      Z([3,'text1']);
      Z([[7],[3,"decode"]]);
      Z([3,'emsp']);
      Z([[7],[3,"userSelect"]]);
      Z([11,[[7],[3,"text"]]]);
      Z([3,'text2']);
      Z([3,'ensp']);
      Z([3,'ChineseCharacters spaceensp']);
      Z([3,'text3']);
      Z([3,'nbsp']);
      Z([3,'false']);
      Z([3,'ChineseCharacters spacenbsp']);
      Z([3,'text4']);
      Z([3,'ChineseCharacters spaceemsp']);
      Z([3,'text5']);
      Z([3,'abc']);
      Z([3,'123']);
      Z([3,'ChineseCharacters InvalidSpace']);
      Z([3,'add']);
      Z([3,'addline']);
      Z([[2,"!"],[[7],[3,"canAdd"]]]);
      Z([3,'add line']);
      Z([3,'remove']);
      Z([[2,"!"],[[7],[3,"canRemove"]]]);
      Z([3,'remove line']);
      Z([3,'setDecode']);
      Z([3,'btn-decode']);
      Z([3,'set decode']);
      Z([3,'setUserSelect']);
      Z([3,'btn-user-select']);
      Z([3,'set user select']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_74);
    return __MAML_GLOBAL__.ops_cached.$gma_74
  }
  function gz$gma_75(){
    if(__MAML_GLOBAL__.ops_cached.$gma_75)return __MAML_GLOBAL__.ops_cached.$gma_75
    __MAML_GLOBAL__.ops_cached.$gma_75=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"textarea"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'page-section-title']);
      Z([3,'The height of the input area is adaptive, and the scroll bar is not displayed']);
      Z([3,'textarea-wrp']);
      Z([3,'true']);
      Z([3,'bindblur']);
      Z([3,'bindconfirm']);
      Z([3,'bindfocus']);
      Z([3,'bindinput']);
      Z([3,'bindlinechange']);
      Z([3,'textarea1']);
      Z([3,'color:#4ba9f9f5;font-size:16px;']);
      Z([3,'height:30px']);
      Z([3,'This is a textarea with autofocus.']);
      Z([3,'textarea2']);
      Z([3,'10']);
      Z([3,'3']);
      Z([3,'1']);
      Z([3,'height: 3em']);
      Z([3,'auto-focus']);
      Z([3,'page-section3']);
      Z([3,'page-section-title2']);
      Z([3,'Automatic Test Textarea']);
      Z([3,'textarea3']);
      Z([3,'Automatic test of disabled textarea3']);
      Z([3,'textarea4']);
      Z([3,'Automatic Test Textarea4']);
      Z([3,'textarea5']);
      Z([3,'Automated Test 5']);
      Z([3,'placeholderClass']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_75);
    return __MAML_GLOBAL__.ops_cached.$gma_75
  }
  function gz$gma_76(){
    if(__MAML_GLOBAL__.ops_cached.$gma_76)return __MAML_GLOBAL__.ops_cached.$gma_76
    __MAML_GLOBAL__.ops_cached.$gma_76=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"video"]]);
      Z([3,'page-body']);
      Z([3,'page-section tc']);
      Z([[7],[3,"autoplay"]]);
      Z([3,'bindended']);
      Z([3,'binderror']);
      Z([3,'bindpause']);
      Z([3,'bindplay']);
      Z([3,'bindtimeupdate']);
      Z([[7],[3,"controls"]]);
      Z([[7],[3,"hidden"]]);
      Z([3,'myVideo']);
      Z([[7],[3,"loop"]]);
      Z([[7],[3,"muted"]]);
      Z([[7],[3,"objectFit"]]);
      Z([[7],[3,"poster"]]);
      Z([[7],[3,"src"]]);
      Z([3,'weui-cells']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'JumpLocation']);
      Z([3,'weui-cell__bd']);
      Z([3,'false']);
      Z([3,'bindInput']);
      Z([3,'weui-input']);
      Z([3,'Enter the specified location here']);
      Z([3,'text']);
      Z([[7],[3,"position"]]);
      Z([3,'btn-area']);
      Z([3,'play']);
      Z([3,'page-body-button play']);
      Z([3,'primary']);
      Z([3,'playout']);
      Z([3,'pause']);
      Z([3,'page-body-button pause']);
      Z([3,'seek']);
      Z([3,'page-body-button seek']);
      Z([3,'Jump to a specified position (unit:second)']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_76);
    return __MAML_GLOBAL__.ops_cached.$gma_76
  }
  function gz$gma_77(){
    if(__MAML_GLOBAL__.ops_cached.$gma_77)return __MAML_GLOBAL__.ops_cached.$gma_77
    __MAML_GLOBAL__.ops_cached.$gma_77=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"view"]]);
      Z([3,'page-body']);
      Z([3,'page-section']);
      Z([3,'page-section-title']);
      Z([3,'flex-direction: row\nHorizontal layout']);
      Z([3,'page-section-spacing']);
      Z([3,'hoverclass']);
      Z([3,'200']);
      Z([3,'1000']);
      Z([3,'flex-wrp']);
      Z([3,'flex-direction:row;']);
      Z([3,'flex-item demo-text-1']);
      Z([3,'true']);
      Z([3,'flex-item demo-text-2']);
      Z([3,'flex-item demo-text-3']);
      Z([3,'flex-direction: column\nVertical Layout']);
      Z([3,'flex-direction:column;']);
      Z([3,'flex-item flex-item-V demo-text-1']);
      Z([3,'flex-item flex-item-V demo-text-2']);
      Z([3,'flex-item flex-item-V demo-text-3']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_77);
    return __MAML_GLOBAL__.ops_cached.$gma_77
  }
  function gz$gma_78(){
    if(__MAML_GLOBAL__.ops_cached.$gma_78)return __MAML_GLOBAL__.ops_cached.$gma_78
    __MAML_GLOBAL__.ops_cached.$gma_78=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'https://www.bing.com/'])
    })(__MAML_GLOBAL__.ops_cached.$gma_78);
    return __MAML_GLOBAL__.ops_cached.$gma_78
  }
  function gz$gma_79(){
    if(__MAML_GLOBAL__.ops_cached.$gma_79)return __MAML_GLOBAL__.ops_cached.$gma_79
    __MAML_GLOBAL__.ops_cached.$gma_79=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'onMyEvent']);
      Z([[7],[3,"detail"]]);
      Z([3,'test1']);
      Z([[7],[3,"propTest"]]);
      Z([3,'showSlot']);
      Z([3,'slot scene']);
      Z([3,'clickButton']);
      Z([3,'Parent page component, which invokes the subcomponent method']);
      Z([3,'clickSelf']);
      Z([3,'No parent-child communication']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_79);
    return __MAML_GLOBAL__.ops_cached.$gma_79
  }
  function gz$gma_80(){
    if(__MAML_GLOBAL__.ops_cached.$gma_80)return __MAML_GLOBAL__.ops_cached.$gma_80
    __MAML_GLOBAL__.ops_cached.$gma_80=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'text-align:center']);
      Z([3,'head']);
      Z([[8],"title",[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"window.title"]]]]);
      Z([3,'page-body']);
      Z([11,[3,'Current locale: '],[[12],[[6],[[7],[3,"i18n"]],[3,"getLocale"]],[[5]]]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"test"]]]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[[5],[1,"test2"]],[[9],[[8],"label",[1,"sample"]],[[8],"label2",[[7],[3,"value"]]]]]]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[[5],[1,"nested"]],[[8],"test",[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"test"]]]]]]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[[5],[1,"nested2"]],[[7],[3,"value2"]]]]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"index.test"]]]]);
      Z([3,'buttonArea']);
      Z([3,'toggleLocale']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"toggle"]]]]);
      Z([3,'nativate']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"navigate"]]]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"navigate2"]]]]);
      Z([3,'cancel']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"cancelEvent"]]]]);
      Z([3,'page-section']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'height:46px']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'select']);
      Z([3,'weui-cell__bd']);
      Z([3,'bindPickerChange']);
      Z([3,'select I18N']);
      Z([3,'picker']);
      Z([[7],[3,"array"]]);
      Z([[7],[3,"index"]]);
      Z([11,[[6],[[7],[3,"array"]],[[7],[3,"index"]]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_80);
    return __MAML_GLOBAL__.ops_cached.$gma_80
  }
  function gz$gma_81(){
    if(__MAML_GLOBAL__.ops_cached.$gma_81)return __MAML_GLOBAL__.ops_cached.$gma_81
    __MAML_GLOBAL__.ops_cached.$gma_81=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'text-align:center']);
      Z([3,'head']);
      Z([[8],"title",[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"log"]]]]);
      Z([3,'page-body']);
      Z([11,[3,'Locale: '],[[12],[[6],[[7],[3,"customi18nModule"]],[3,"getLocale"]],[[5]]]]);
      Z([11,[[12],[[6],[[7],[3,"customi18nModule"]],[3,"t"]],[[5],[1,"test"]]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_81);
    return __MAML_GLOBAL__.ops_cached.$gma_81
  }
  function gz$gma_82(){
    if(__MAML_GLOBAL__.ops_cached.$gma_82)return __MAML_GLOBAL__.ops_cached.$gma_82
    __MAML_GLOBAL__.ops_cached.$gma_82=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"sjs application: drag-and-drop process"]]);
      Z([[6],[[7],[3,"comm"]],[3,"liveTouchmove"]]);
      Z([3,'enterLive liveMove']);
      Z([3,'top:202px;left:100px']);
      Z([[6],[[7],[3,"comm"]],[3,"clickLive"]]);
      Z([3,'live-block']);
      Z([3,'border:1px solid blue']);
      Z([3,'liveEnter-img']);
      Z([3,'aspectFit']);
      Z([3,'../../../../image/demo.jpg']);
      Z([3,'liveTouchmove']);
      Z([[7],[3,"windowHeight"]]);
      Z([[7],[3,"windowWidth"]]);
      Z([[7],[3,"style"]]);
      Z([3,'border:1px solid red']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_82);
    return __MAML_GLOBAL__.ops_cached.$gma_82
  }
  function gz$gma_83(){
    if(__MAML_GLOBAL__.ops_cached.$gma_83)return __MAML_GLOBAL__.ops_cached.$gma_83
    __MAML_GLOBAL__.ops_cached.$gma_83=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"sjs application:filter-time format"]]);
      Z([3,'label']);
      Z([3,'Current timestamp:']);
      Z([11,[[7],[3,"timestamp"]]]);
      Z([3,'yyyy-MM-dd：']);
      Z([11,[[12],[[6],[[7],[3,"common_filter"]],[3,"dateFormat"]],[[5],[[5],[[7],[3,"timestamp"]]],[1,"yyyy-MM-dd"]]]]);
      Z([3,'yyyy-MM-dd hh:mm:ss：']);
      Z([11,[[12],[[6],[[7],[3,"common_filter"]],[3,"dateFormat"]],[[5],[[7],[3,"timestamp"]]]]]);
      Z([3,'btn-area']);
      Z([3,'getTime']);
      Z([3,'primary']);
      Z([3,'RefreshTime']);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_83);
    return __MAML_GLOBAL__.ops_cached.$gma_83
  }
  function gz$gma_84(){
    if(__MAML_GLOBAL__.ops_cached.$gma_84)return __MAML_GLOBAL__.ops_cached.$gma_84
    __MAML_GLOBAL__.ops_cached.$gma_84=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"tabBar"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'showTabBarRedDot']);
      Z([3,'tabBarRedDot']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasShownTabBarRedDot"]]],[1,"Show red dots"],[1,"Remove Red Dots"]]]);
      Z([3,'customStyle']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasCustomedStyle"]]],[1,"Custom Tab Styles"],[1,"Remove Custom Styles"]]]);
      Z([3,'customItem']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasCustomedItem"]]],[1,"Customizing Tab Information"],[1,"Remove Custom Information"]]]);
      Z([3,'hideTabBar']);
      Z([3,'showOrHideTabBar']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasHiddenTabBar"]]],[1,"Hide TabBar"],[1,"Show TabBar"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_84);
    return __MAML_GLOBAL__.ops_cached.$gma_84
  }
  function gz$gma_85(){
    if(__MAML_GLOBAL__.ops_cached.$gma_85)return __MAML_GLOBAL__.ops_cached.$gma_85
    __MAML_GLOBAL__.ops_cached.$gma_85=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([[7],[3,"isSetTabBarPage"]]);
      Z([3,'leaveSetTabBarPage']);
      Z([3,'index']);
      Z([3,'index-hd']);
      Z([3,'index-desc']);
      Z([3,'following describes the API capability of the applet. For details about the attribute parameters, see the applet development document.']);
      Z([3,'index-bd']);
      Z([3,'kind-list']);
      Z([[7],[3,"list"]]);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'kind-list-item']);
      Z([3,'kindToggle']);
      Z([11,[3,'kind-list-item-hd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-hd-show"],[1,""]]]);
      Z([3,'kind-list-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([11,[3,'kind-list-img kind-list-img-'],[[6],[[7],[3,"item"]],[3,"id"]]]);
      Z([11,[3,'/page/tabbar/resources/api/kind/'],[[6],[[7],[3,"item"]],[3,"id"]],[3,'.png']]);
      Z([11,[3,'kind-list-item-bd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-bd-show"],[1,""]]]);
      Z([11,[3,'navigator-box '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"navigator-box-show"],[1,""]]]);
      Z([[6],[[7],[3,"item"]],[3,"pages"]]);
      Z([3,'page']);
      Z([3,'*item']);
      Z([[2,"!=="], [[6],[[7],[3,"page"]],[3,"url"]], [1,"set-tab-bar/set-tab-bar"]]);
      Z([3,'navigator']);
      Z([11,[3,'/page/API/pages/'],[[6],[[7],[3,"page"]],[3,"url"]]]);
      Z([3,'navigator-content']);
      Z([[6],[[7],[3,"page"]],[3,"id"]]);
      Z([11,[[6],[[7],[3,"page"]],[3,"zh"]]]);
      Z([3,'navigator-arrow']);
      Z([3,'enterSetTabBarPage'])
    })(__MAML_GLOBAL__.ops_cached.$gma_85);
    return __MAML_GLOBAL__.ops_cached.$gma_85
  }
  function gz$gma_86(){
    if(__MAML_GLOBAL__.ops_cached.$gma_86)return __MAML_GLOBAL__.ops_cached.$gma_86
    __MAML_GLOBAL__.ops_cached.$gma_86=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'index']);
      Z([3,'index-hd']);
      Z([3,'index-desc']);
      Z([3,'The following describes the capabilities of the applet component. For details about the attributes and parameters, see the applet development document.']);
      Z([3,'index-bd']);
      Z([3,'kind-list']);
      Z([[7],[3,"list"]]);
      Z([3,'item']);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'kind-list-item']);
      Z([3,'kindToggle']);
      Z([11,[3,'kind-list-'],[[6],[[7],[3,"item"]],[3,"id"]],[3,' kind-list-item-hd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-hd-show"],[1,""]]]);
      Z([3,'kind-list-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([[2,"!=="], [[6],[[7],[3,"item"]],[3,"id"]], [1,"page-meta"]]);
      Z([11,[3,'kind-list-img kind-list-img-'],[[6],[[7],[3,"item"]],[3,"id"]]]);
      Z([11,[3,'/page/tabbar/resources/component/kind/'],[[6],[[7],[3,"item"]],[3,"id"]],[3,'.png']]);
      Z([11,[3,'kind-list-item-bd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-bd-show"],[1,""]]]);
      Z([11,[3,'navigator-box '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"navigator-box-show"],[1,""]]]);
      Z([[6],[[7],[3,"item"]],[3,"pages"]]);
      Z([3,'page']);
      Z([3,'*item']);
      Z([11,[3,'navigator navigator-'],[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([11,[3,'navigator-'],[[6],[[7],[3,"page"]],[3,"id"]]]);
      Z([11,[3,'/page/component/pages/'],[[6],[[7],[3,"page"]],[3,"name"]],[3,'/'],[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([3,'navigator-content']);
      Z([[6],[[7],[3,"page"]],[3,"id"]]);
      Z([11,[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([3,'navigator-arrow'])
    })(__MAML_GLOBAL__.ops_cached.$gma_86);
    return __MAML_GLOBAL__.ops_cached.$gma_86
  }
  function gz$gma_87(){
    if(__MAML_GLOBAL__.ops_cached.$gma_87)return __MAML_GLOBAL__.ops_cached.$gma_87
    __MAML_GLOBAL__.ops_cached.$gma_87=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'index']);
      Z([3,'index-hd']);
      Z([3,'index-desc']);
      Z([3,'The following describes the applet framework capability. For details about the attributes and parameters, see the applet development document。']);
      Z([3,'index-bd']);
      Z([3,'kind-list']);
      Z([[7],[3,"list"]]);
      Z([3,'item']);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'kind-list-item']);
      Z([3,'kindToggle']);
      Z([11,[3,'kind-list-'],[[6],[[7],[3,"item"]],[3,"id"]],[3,' kind-list-item-hd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-hd-show"],[1,""]]]);
      Z([3,'kind-list-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([11,[3,'kind-list-item-bd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-bd-show"],[1,""]]]);
      Z([11,[3,'navigator-box '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"navigator-box-show"],[1,""]]]);
      Z([[6],[[7],[3,"item"]],[3,"pages"]]);
      Z([3,'page']);
      Z([3,'*item']);
      Z([11,[3,'navigator navigator-'],[[7],[3,"page"]]]);
      Z([11,[3,'/page/framework/pages/'],[[7],[3,"page"]],[3,'/'],[[7],[3,"page"]]]);
      Z([3,'navigator-content']);
      Z([11,[[7],[3,"page"]]]);
      Z([3,'navigator-arrow'])
    })(__MAML_GLOBAL__.ops_cached.$gma_87);
    return __MAML_GLOBAL__.ops_cached.$gma_87
  }
  function gz$gma_88(){
    if(__MAML_GLOBAL__.ops_cached.$gma_88)return __MAML_GLOBAL__.ops_cached.$gma_88
    __MAML_GLOBAL__.ops_cached.$gma_88=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'page-foot']);
      Z([3,'none']);
      Z([3,'switchTab']);
      Z([3,'/page/tabbar/component/index']);
      Z([3,'icon-foot']);
      Z([3,'../../../../image/icon_foot.png'])
    })(__MAML_GLOBAL__.ops_cached.$gma_88);
    return __MAML_GLOBAL__.ops_cached.$gma_88
  }
  function gz$gma_89(){
    if(__MAML_GLOBAL__.ops_cached.$gma_89)return __MAML_GLOBAL__.ops_cached.$gma_89
    __MAML_GLOBAL__.ops_cached.$gma_89=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'page-head']);
      Z([3,'page-head-title']);
      Z([11,[[7],[3,"title"]]]);
      Z([3,'page-head-line']);
      Z([[7],[3,"desc"]]);
      Z([3,'page-head-desc']);
      Z([11,[[7],[3,"desc"]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_89);
    return __MAML_GLOBAL__.ops_cached.$gma_89
  }
  function gz$gma_90(){
    if(__MAML_GLOBAL__.ops_cached.$gma_90)return __MAML_GLOBAL__.ops_cached.$gma_90
    __MAML_GLOBAL__.ops_cached.$gma_90=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"tabBar"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'showTabBarRedDot']);
      Z([3,'tabBarRedDot']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasShownTabBarRedDot"]]],[1,"Show red dots"],[1,"Remove Red Dots"]]]);
      Z([3,'customStyle']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasCustomedStyle"]]],[1,"Custom Tab Styles"],[1,"Remove Custom Styles"]]]);
      Z([3,'customItem']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasCustomedItem"]]],[1,"Customizing Tab Information"],[1,"Remove Custom Information"]]]);
      Z([3,'hideTabBar']);
      Z([3,'showOrHideTabBar']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasHiddenTabBar"]]],[1,"Hide TabBar"],[1,"Show TabBar"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_90);
    return __MAML_GLOBAL__.ops_cached.$gma_90
  }
  function gz$gma_91(){
    if(__MAML_GLOBAL__.ops_cached.$gma_91)return __MAML_GLOBAL__.ops_cached.$gma_91
    __MAML_GLOBAL__.ops_cached.$gma_91=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([[7],[3,"isSetTabBarPage"]]);
      Z([3,'leaveSetTabBarPage']);
      Z([3,'index']);
      Z([3,'index-hd']);
      Z([3,'index-desc']);
      Z([3,'The following describes the API capability of the applet. For details about the attribute parameters, see the applet development document.']);
      Z([3,'index-bd']);
      Z([3,'kind-list']);
      Z([[7],[3,"list"]]);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'kind-list-item']);
      Z([3,'kindToggle']);
      Z([11,[3,'kind-list-item-hd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-hd-show"],[1,""]]]);
      Z([3,'kind-list-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([11,[3,'kind-list-img kind-list-img-'],[[6],[[7],[3,"item"]],[3,"id"]]]);
      Z([11,[3,'/page/tabbar/resources/api/kind/'],[[6],[[7],[3,"item"]],[3,"id"]],[3,'.png']]);
      Z([11,[3,'kind-list-item-bd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-bd-show"],[1,""]]]);
      Z([11,[3,'navigator-box '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"navigator-box-show"],[1,""]]]);
      Z([[6],[[7],[3,"item"]],[3,"pages"]]);
      Z([3,'page']);
      Z([3,'*item']);
      Z([[2,"!=="], [[6],[[7],[3,"page"]],[3,"url"]], [1,"set-tab-bar/set-tab-bar"]]);
      Z([3,'navigator']);
      Z([11,[3,'/page/API/pages/'],[[6],[[7],[3,"page"]],[3,"url"]]]);
      Z([3,'navigator-content']);
      Z([[6],[[7],[3,"page"]],[3,"id"]]);
      Z([11,[[6],[[7],[3,"page"]],[3,"zh"]]]);
      Z([3,'navigator-arrow']);
      Z([3,'enterSetTabBarPage'])
    })(__MAML_GLOBAL__.ops_cached.$gma_91);
    return __MAML_GLOBAL__.ops_cached.$gma_91
  }
  function gz$gma_92(){
    if(__MAML_GLOBAL__.ops_cached.$gma_92)return __MAML_GLOBAL__.ops_cached.$gma_92
    __MAML_GLOBAL__.ops_cached.$gma_92=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'index']);
      Z([3,'index-hd']);
      Z([3,'index-desc']);
      Z([3,'The following describes the capabilities of the applet component. For details about the attributes and parameters, see the applet development document.']);
      Z([3,'index-bd']);
      Z([3,'kind-list']);
      Z([[7],[3,"list"]]);
      Z([3,'item']);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'kind-list-item']);
      Z([3,'kindToggle']);
      Z([11,[3,'kind-list-'],[[6],[[7],[3,"item"]],[3,"id"]],[3,' kind-list-item-hd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-hd-show"],[1,""]]]);
      Z([3,'kind-list-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([[2,"!=="], [[6],[[7],[3,"item"]],[3,"id"]], [1,"page-meta"]]);
      Z([11,[3,'kind-list-img kind-list-img-'],[[6],[[7],[3,"item"]],[3,"id"]]]);
      Z([11,[3,'/page/tabbar/resources/component/kind/'],[[6],[[7],[3,"item"]],[3,"id"]],[3,'.png']]);
      Z([11,[3,'kind-list-item-bd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-bd-show"],[1,""]]]);
      Z([11,[3,'navigator-box '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"navigator-box-show"],[1,""]]]);
      Z([[6],[[7],[3,"item"]],[3,"pages"]]);
      Z([3,'page']);
      Z([3,'*item']);
      Z([11,[3,'navigator navigator-'],[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([11,[3,'navigator-'],[[6],[[7],[3,"page"]],[3,"id"]]]);
      Z([11,[3,'/page/component/pages/'],[[6],[[7],[3,"page"]],[3,"name"]],[3,'/'],[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([3,'navigator-content']);
      Z([[6],[[7],[3,"page"]],[3,"id"]]);
      Z([11,[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([3,'navigator-arrow'])
    })(__MAML_GLOBAL__.ops_cached.$gma_92);
    return __MAML_GLOBAL__.ops_cached.$gma_92
  }
  function gz$gma_93(){
    if(__MAML_GLOBAL__.ops_cached.$gma_93)return __MAML_GLOBAL__.ops_cached.$gma_93
    __MAML_GLOBAL__.ops_cached.$gma_93=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'index']);
      Z([3,'index-hd']);
      Z([3,'index-desc']);
      Z([3,'The following describes the applet framework capability. For details about the attributes and parameters, see the applet development document。']);
      Z([3,'index-bd']);
      Z([3,'kind-list']);
      Z([[7],[3,"list"]]);
      Z([3,'item']);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'kind-list-item']);
      Z([3,'kindToggle']);
      Z([11,[3,'kind-list-'],[[6],[[7],[3,"item"]],[3,"id"]],[3,' kind-list-item-hd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-hd-show"],[1,""]]]);
      Z([3,'kind-list-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([11,[3,'kind-list-item-bd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-bd-show"],[1,""]]]);
      Z([11,[3,'navigator-box '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"navigator-box-show"],[1,""]]]);
      Z([[6],[[7],[3,"item"]],[3,"pages"]]);
      Z([3,'page']);
      Z([3,'*item']);
      Z([11,[3,'navigator navigator-'],[[7],[3,"page"]]]);
      Z([11,[3,'/page/framework/pages/'],[[7],[3,"page"]],[3,'/'],[[7],[3,"page"]]]);
      Z([3,'navigator-content']);
      Z([11,[[7],[3,"page"]]]);
      Z([3,'navigator-arrow'])
    })(__MAML_GLOBAL__.ops_cached.$gma_93);
    return __MAML_GLOBAL__.ops_cached.$gma_93
  }
  function gz$gma_94(){
    if(__MAML_GLOBAL__.ops_cached.$gma_94)return __MAML_GLOBAL__.ops_cached.$gma_94
    __MAML_GLOBAL__.ops_cached.$gma_94=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'index']);
      Z([3,'true']);
      Z([3,'https://maps.googleapis.com/maps/api/js?key\x3d\x26callback\x3dinitMap\x26v\x3dweekly']);
      Z([3,'./index']);
      Z([3,'googleMap']);
      Z([3,'Loading']);
      Z([3,'http://127.0.0.1:5500/public/index.html']);
      Z([3,'index-bd']);
      Z([3,'kind-list']);
      Z([[7],[3,"list"]]);
      Z([3,'item']);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'kind-list-item']);
      Z([3,'kindToggle']);
      Z([11,[3,'kind-list-'],[[6],[[7],[3,"item"]],[3,"id"]],[3,' kind-list-item-hd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-hd-show"],[1,""]]]);
      Z([3,'kind-list-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([[2,"!=="], [[6],[[7],[3,"item"]],[3,"id"]], [1,"page-meta"]]);
      Z([11,[3,'kind-list-img kind-list-img-'],[[6],[[7],[3,"item"]],[3,"id"]]]);
      Z([11,[3,'/page/tabbar/resources/component/kind/'],[[6],[[7],[3,"item"]],[3,"id"]],[3,'.png']]);
      Z([11,[3,'kind-list-item-bd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-bd-show"],[1,""]]]);
      Z([11,[3,'navigator-box '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"navigator-box-show"],[1,""]]]);
      Z([[6],[[7],[3,"item"]],[3,"pages"]]);
      Z([3,'page']);
      Z([3,'*item']);
      Z([11,[3,'navigator navigator-'],[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([11,[3,'navigator-'],[[6],[[7],[3,"page"]],[3,"id"]]]);
      Z([11,[3,'/page/component/pages/'],[[6],[[7],[3,"page"]],[3,"name"]],[3,'/'],[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([3,'navigator-content']);
      Z([[6],[[7],[3,"page"]],[3,"id"]]);
      Z([11,[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([3,'navigator-arrow'])
    })(__MAML_GLOBAL__.ops_cached.$gma_94);
    return __MAML_GLOBAL__.ops_cached.$gma_94
  }
  __MAML_GLOBAL__.ops_set.$gma=z;
  __MAML_GLOBAL__.ops_init.$gma=true;
  
  var sjs_require=function(){
    var smm={"p_./macle_demo_EN/page/framework/pages/macle-sub-i18n/i18n.sjs":sm_0,"p_./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.sjs":sm_1,"p_./macle_demo_EN/page/util/common.sjs":sm_2,"p_./page/util/common.sjs":sm_3}; // sjs modules map
    var smem={}; // sjs modules exports map
    return function(mp){ // module path
      if(mp[0]==='p'&&mp[1]==='_'&&f_[mp.slice(2)])return f_[mp.slice(2)];
      return function(){
        if(!smm[mp]) return undefined;
        try{
          if(!smem[mp])smem[mp]=smm[mp]();
          return smem[mp];
        }catch(e){
          e.message=e.message.replace(/sjs_/g,'');
          var t = e.stack.substring(0,e.stack.lastIndexOf(mp));
          e.stack = t.substring(0,t.lastIndexOf('\n'));
          e.stack = e.stack.replace(/\ssjs_/g,' ');
          e.stack = $gstack(e.stack);
          e.stack += '\n    at ' + mp.substring(2);
          console.error(e);
        }
      }
    }
  }()
  f_['./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml']={};
  f_['./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml']['customi18nModule']=f_['./macle_demo_EN/page/framework/pages/macle-sub-i18n/i18n.sjs']||sjs_require("p_./macle_demo_EN/page/framework/pages/macle-sub-i18n/i18n.sjs");
  f_['./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml']['customi18nModule']();
  f_['./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml']={};
  f_['./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml']['comm']=f_['./macle_demo_EN/page/util/common.sjs']||sjs_require("p_./macle_demo_EN/page/util/common.sjs");
  f_['./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml']['comm']();
  f_['./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml']={};
  f_['./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml']['common_filter']=f_['./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.sjs']||sjs_require("p_./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.sjs");
  f_['./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml']['common_filter']();
  f_['./macle_demo_EN/page/framework/pages/macle-sub-i18n/i18n.sjs']=sjs_require("p_./macle_demo_EN/page/framework/pages/macle-sub-i18n/i18n.sjs");
  function sm_0(){var sjs_module={sjs_exports:{}};function sjs_t(sjs_str,sjs_arr){return i18n.sjs_t(sjs_str,sjs_arr)}function sjs_getLocale(sjs_str,sjs_arr){return i18n.sjs_getLocale(sjs_str,sjs_arr)}sjs_module.sjs_exports={sjs_t:sjs_t,sjs_getLocale:sjs_getLocale};return sjs_module.sjs_exports;}
  f_['./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.sjs']=sjs_require("p_./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.sjs");
  function sm_1(){var sjs_module={sjs_exports:{}};function sjs_dateFormat(sjs_timestamp,sjs_format){if(!sjs_format){sjs_format="yyyy-MM-dd hh:mm:ss"}sjs_timestamp=sjs_parseInt(sjs_timestamp);var sjs_realDate=sjs_getDate(sjs_timestamp);function sjs_timeFormat(sjs_num){return sjs_num<10?"0"+sjs_num:sjs_num}var sjs_date=[["M+",sjs_timeFormat(sjs_realDate.sjs_getMonth()+1)],["d+",sjs_timeFormat(sjs_realDate.sjs_getDate())],["h+",sjs_timeFormat(sjs_realDate.sjs_getHours())],["m+",sjs_timeFormat(sjs_realDate.sjs_getMinutes())],["s+",sjs_timeFormat(sjs_realDate.sjs_getSeconds())],["q+",Math.sjs_floor((sjs_realDate.sjs_getMonth()+3)/3)]];var sjs_regYear=sjs_getRegExp("(y+)","i");var sjs_reg1=sjs_regYear.sjs_exec(sjs_format);if(sjs_reg1){sjs_format=sjs_format.sjs_replace(sjs_reg1[1],(sjs_realDate.sjs_getFullYear()+"").sjs_substring(4-sjs_reg1[1].sjs_length))}for(var sjs_i=0;sjs_i<sjs_date.sjs_length;sjs_i++){var sjs_k=sjs_date[_ck(sjs_i)][0];var sjs_v=sjs_date[_ck(sjs_i)][1];var sjs_reg2=sjs_getRegExp("("+sjs_k+")").sjs_exec(sjs_format);if(sjs_reg2){sjs_format=sjs_format.sjs_replace(sjs_reg2[1],sjs_reg2[1].sjs_length==1?sjs_v:("00"+sjs_v).sjs_substring((""+sjs_v).sjs_length))}}return sjs_format}sjs_module.sjs_exports={sjs_dateFormat:sjs_dateFormat};return sjs_module.sjs_exports;}
  f_['./macle_demo_EN/page/util/common.sjs']=sjs_require("p_./macle_demo_EN/page/util/common.sjs");
  function sm_2(){var sjs_module={sjs_exports:{}};var sjs_starLeft=0;var sjs_starTop=0;var sjs_starX=0;var sjs_starY=0;function sjs_liveTouchmove(sjs_event,sjs_ownerInstance){var sjs_left=0,sjs_top=0;var sjs_diffX=0,sjs_diffY=0;if(sjs_event.sjs_type==="touchstart"){sjs_starLeft=sjs_event.sjs_currentTarget.sjs_offsetLeft;sjs_starTop=sjs_event.sjs_currentTarget.sjs_offsetTop;sjs_starX=sjs_event.sjs_changedTouches[0].sjs_clientX;sjs_starY=sjs_event.sjs_changedTouches[0].sjs_clientY;sjs_left=sjs_starLeft;sjs_top=sjs_starTop}else{sjs_diffX=sjs_event.sjs_changedTouches[0].sjs_clientX-sjs_starX;sjs_diffY=sjs_event.sjs_changedTouches[0].sjs_clientY-sjs_starY;sjs_left=sjs_starLeft+sjs_diffX;sjs_top=sjs_starTop+sjs_diffY}sjs_left=sjs_left+"px";var sjs_instance=sjs_ownerInstance.sjs_selectComponent(".liveMove");sjs_instance.sjs_setStyle({sjs_left:sjs_left,sjs_top:sjs_top+"px"})}function sjs_clickLive(sjs_event,sjs_ownerInstance){sjs_ownerInstance.sjs_callMethod("bindEnter")}sjs_module.sjs_exports={sjs_liveTouchmove:sjs_liveTouchmove,sjs_clickLive:sjs_clickLive};return sjs_module.sjs_exports;}
  f_['./page/util/common.sjs']=sjs_require("p_./page/util/common.sjs");
  function sm_3(){var sjs_module={sjs_exports:{}};var sjs_starLeft=0;var sjs_starTop=0;var sjs_starX=0;var sjs_starY=0;function sjs_liveTouchmove(sjs_event,sjs_ownerInstance){var sjs_left=0,sjs_top=0;var sjs_diffX=0,sjs_diffY=0;if(sjs_event.sjs_type==="touchstart"){sjs_starLeft=sjs_event.sjs_currentTarget.sjs_offsetLeft;sjs_starTop=sjs_event.sjs_currentTarget.sjs_offsetTop;sjs_starX=sjs_event.sjs_changedTouches[0].sjs_clientX;sjs_starY=sjs_event.sjs_changedTouches[0].sjs_clientY;sjs_left=sjs_starLeft;sjs_top=sjs_starTop}else{sjs_diffX=sjs_event.sjs_changedTouches[0].sjs_clientX-sjs_starX;sjs_diffY=sjs_event.sjs_changedTouches[0].sjs_clientY-sjs_starY;sjs_left=sjs_starLeft+sjs_diffX;sjs_top=sjs_starTop+sjs_diffY}sjs_left=sjs_left+"px";var sjs_instance=sjs_ownerInstance.sjs_selectComponent(".liveMove");sjs_instance.sjs_setStyle({sjs_left:sjs_left,sjs_top:sjs_top+"px"})}function sjs_clickLive(sjs_event,sjs_ownerInstance){sjs_ownerInstance.sjs_callMethod("bindEnter")}sjs_module.sjs_exports={sjs_liveTouchmove:sjs_liveTouchmove,sjs_clickLive:sjs_clickLive};return sjs_module.sjs_exports;}

  
  d_["./component/communication-detail/index.maml"]={};
  var m0=function(e,s,r,gg){
    var z=gz$gma_1()
    var oB=e_["./component/communication-detail/index.maml"].i;_ai(oB,'../../page/common/head.maml',e_,'./component/communication-detail/index.maml',0,0);var oD=_ctn("view");var oE=_ctn("button");_setAttr(z,oE,'bindtap',0,e,s,gg);var oF=_o(z,1,e,s,gg);_ac(oE,oF);_ac(oD,oE);var oG=_ctn("button");_setAttr(z,oG,'bindtap',2,e,s,gg);var oH=_o(z,3,e,s,gg);_ac(oG,oH);_ac(oD,oG);var oI=_cvn();if(_o(z,4,e,s,gg)){oI.maVkey=1;var oJ=_ctn("view");var oL=_cvn();var oM=function(oQ,oP,oO,gg){var oN=_setAttrs(z,"detailItem",["bind:myevent",8,"class",1,"item",2],oQ,oP,gg);_ac(oO,oN);return oO;};_2(z,5,oM,e,s,gg,oL,"item","index",'name');_ac(oJ,oL);var oS=_ctn("slot");_ac(oJ,oS);_ac(oI,oJ);} _ac(oD,oI);_ac(r,oD);oB.pop();
    return r;
  };
  e_["./component/communication-detail/index.maml"]={f:m0,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./component/communication-detailItem/index.maml"]={};
  var m1=function(e,s,r,gg){
    var z=gz$gma_2()
    var oT=e_["./component/communication-detailItem/index.maml"].i;_ai(oT,'../../page/common/head.maml',e_,'./component/communication-detailItem/index.maml',0,0);var oV=_ctn("view");var oW=_ctn("button");_setAttr(z,oW,'bindtap',0,e,s,gg);var oX=_o(z,1,e,s,gg);_ac(oW,oX);_ac(oV,oW);_ac(r,oV);oT.pop();
    return r;
  };
  e_["./component/communication-detailItem/index.maml"]={f:m1,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./component/detail/index.maml"]={};
  var m2=function(e,s,r,gg){
    var z=gz$gma_3()
    var oY=e_["./component/detail/index.maml"].i;_ai(oY,'../../page/common/head.maml',e_,'./component/detail/index.maml',0,0);var oa=_ctn("view");_setAttr(z,oa,'class',0,e,s,gg);var ob=_cvn();
    var oc=_o(z,1,e,s,gg);
    var od=_gd('./component/detail/index.maml',oc,e_,d_);
    if(od){
      var oe=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      od(oe,oe,ob,gg);
      gg.f=tgf;
    }else{
      _w(oc,'./component/detail/index.maml',0,0);
    }
    _ac(oa,ob);var of=_ctn("button");_setAttr(z,of,'bindtap',3,e,s,gg);var og=_o(z,4,e,s,gg);_ac(of,og);_ac(oa,of);var oh=_ctn("button");var oi=_o(z,5,e,s,gg);_ac(oh,oi);_ac(oa,oh);var oj=_cvn();var ok=function(oo,on,om,gg){var ol=_ctn("view");_setAttr(z,ol,'style',9,oo,on,gg);var oq=_ctn("detailItem");_setAttr(z,oq,'item',10,oo,on,gg);_ac(ol,oq);_ac(om,ol);return om;};_2(z,6,ok,e,s,gg,oj,"item","index",'name');_ac(oa,oj);_ac(r,oa);oY.pop();
    return r;
  };
  e_["./component/detail/index.maml"]={f:m2,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./component/detailItem/index.maml"]={};
  var m3=function(e,s,r,gg){
    var z=gz$gma_4()
    var or=e_["./component/detailItem/index.maml"].i;_ai(or,'../../page/common/head.maml',e_,'./component/detailItem/index.maml',0,0);var ot=_ctn("view");_setAttr(z,ot,'class',0,e,s,gg);var ou=_cvn();
    var ov=_o(z,1,e,s,gg);
    var ow=_gd('./component/detailItem/index.maml',ov,e_,d_);
    if(ow){
      var ox=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ow(ox,ox,ou,gg);
      gg.f=tgf;
    }else{
      _w(ov,'./component/detailItem/index.maml',0,0);
    }
    _ac(ot,ou);var oy=_ctn("button");_setAttr(z,oy,'bindtap',3,e,s,gg);var oz=_o(z,4,e,s,gg);_ac(oy,oz);_ac(ot,oy);var o_=_ctn("button");var oAB=_o(z,5,e,s,gg);_ac(o_,oAB);_ac(ot,o_);_ac(r,ot);or.pop();
    return r;
  };
  e_["./component/detailItem/index.maml"]={f:m3,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./macle_demo_EN/component/communication-detail/index.maml"]={};
  var m4=function(e,s,r,gg){
    var z=gz$gma_5()
    var oBB=e_["./macle_demo_EN/component/communication-detail/index.maml"].i;_ai(oBB,'../../page/common/head.maml',e_,'./macle_demo_EN/component/communication-detail/index.maml',0,0);var oDB=_ctn("view");var oEB=_ctn("button");_setAttr(z,oEB,'bindtap',0,e,s,gg);var oFB=_o(z,1,e,s,gg);_ac(oEB,oFB);_ac(oDB,oEB);var oGB=_ctn("button");_setAttr(z,oGB,'bindtap',2,e,s,gg);var oHB=_o(z,3,e,s,gg);_ac(oGB,oHB);_ac(oDB,oGB);var oIB=_cvn();if(_o(z,4,e,s,gg)){oIB.maVkey=1;var oJB=_ctn("view");var oLB=_cvn();var oMB=function(oQB,oPB,oOB,gg){var oNB=_setAttrs(z,"detailItem",["bind:myevent",8,"class",1,"item",2],oQB,oPB,gg);_ac(oOB,oNB);return oOB;};_2(z,5,oMB,e,s,gg,oLB,"item","index",'name');_ac(oJB,oLB);var oSB=_ctn("slot");_ac(oJB,oSB);_ac(oIB,oJB);} _ac(oDB,oIB);_ac(r,oDB);oBB.pop();
    return r;
  };
  e_["./macle_demo_EN/component/communication-detail/index.maml"]={f:m4,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./macle_demo_EN/component/communication-detailItem/index.maml"]={};
  var m5=function(e,s,r,gg){
    var z=gz$gma_6()
    var oTB=e_["./macle_demo_EN/component/communication-detailItem/index.maml"].i;_ai(oTB,'../../page/common/head.maml',e_,'./macle_demo_EN/component/communication-detailItem/index.maml',0,0);var oVB=_ctn("view");var oWB=_ctn("button");_setAttr(z,oWB,'bindtap',0,e,s,gg);var oXB=_o(z,1,e,s,gg);_ac(oWB,oXB);_ac(oVB,oWB);_ac(r,oVB);oTB.pop();
    return r;
  };
  e_["./macle_demo_EN/component/communication-detailItem/index.maml"]={f:m5,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./macle_demo_EN/component/detail/index.maml"]={};
  var m6=function(e,s,r,gg){
    var z=gz$gma_7()
    var oYB=e_["./macle_demo_EN/component/detail/index.maml"].i;_ai(oYB,'../../page/common/head.maml',e_,'./macle_demo_EN/component/detail/index.maml',0,0);var oaB=_ctn("view");_setAttr(z,oaB,'class',0,e,s,gg);var obB=_cvn();
    var ocB=_o(z,1,e,s,gg);
    var odB=_gd('./macle_demo_EN/component/detail/index.maml',ocB,e_,d_);
    if(odB){
      var oeB=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      odB(oeB,oeB,obB,gg);
      gg.f=tgf;
    }else{
      _w(ocB,'./macle_demo_EN/component/detail/index.maml',0,0);
    }
    _ac(oaB,obB);var ofB=_ctn("button");_setAttr(z,ofB,'bindtap',3,e,s,gg);var ogB=_o(z,4,e,s,gg);_ac(ofB,ogB);_ac(oaB,ofB);var ohB=_ctn("button");var oiB=_o(z,5,e,s,gg);_ac(ohB,oiB);_ac(oaB,ohB);var ojB=_cvn();var okB=function(ooB,onB,omB,gg){var olB=_ctn("view");_setAttr(z,olB,'style',9,ooB,onB,gg);var oqB=_ctn("detailItem");_setAttr(z,oqB,'item',10,ooB,onB,gg);_ac(olB,oqB);_ac(omB,olB);return omB;};_2(z,6,okB,e,s,gg,ojB,"item","index",'name');_ac(oaB,ojB);_ac(r,oaB);oYB.pop();
    return r;
  };
  e_["./macle_demo_EN/component/detail/index.maml"]={f:m6,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./macle_demo_EN/component/detailItem/index.maml"]={};
  var m7=function(e,s,r,gg){
    var z=gz$gma_8()
    var orB=e_["./macle_demo_EN/component/detailItem/index.maml"].i;_ai(orB,'../../page/common/head.maml',e_,'./macle_demo_EN/component/detailItem/index.maml',0,0);var otB=_ctn("view");_setAttr(z,otB,'class',0,e,s,gg);var ouB=_cvn();
    var ovB=_o(z,1,e,s,gg);
    var owB=_gd('./macle_demo_EN/component/detailItem/index.maml',ovB,e_,d_);
    if(owB){
      var oxB=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      owB(oxB,oxB,ouB,gg);
      gg.f=tgf;
    }else{
      _w(ovB,'./macle_demo_EN/component/detailItem/index.maml',0,0);
    }
    _ac(otB,ouB);var oyB=_ctn("button");_setAttr(z,oyB,'bindtap',3,e,s,gg);var ozB=_o(z,4,e,s,gg);_ac(oyB,ozB);_ac(otB,oyB);var o_B=_ctn("button");var oAC=_o(z,5,e,s,gg);_ac(o_B,oAC);_ac(otB,o_B);_ac(r,otB);orB.pop();
    return r;
  };
  e_["./macle_demo_EN/component/detailItem/index.maml"]={f:m7,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/application-event/application-event.maml"]={};
  var m8=function(e,s,r,gg){
    var z=gz$gma_9()
    var oBC=e_["./macle_demo_EN/page/API/pages/application-event/application-event.maml"].i;_ai(oBC,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/application-event/application-event.maml',0,0);_ai(oBC,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/application-event/application-event.maml',0,0);var oEC=_ctn("view");_setAttr(z,oEC,'class',0,e,s,gg);var oFC=_cvn();
    var oGC=_o(z,1,e,s,gg);
    var oHC=_gd('./macle_demo_EN/page/API/pages/application-event/application-event.maml',oGC,e_,d_);
    if(oHC){
      var oIC=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oHC(oIC,oIC,oFC,gg);
      gg.f=tgf;
    }else{
      _w(oGC,'./macle_demo_EN/page/API/pages/application-event/application-event.maml',0,0);
    }
    _ac(oEC,oFC);var oJC=_ctn("view");_setAttr(z,oJC,'class',3,e,s,gg);var oKC=_setAttrs(z,"button",["bindtap",4,"class",1,"type",2],e,s,gg);var oLC=_o(z,4,e,s,gg);_ac(oKC,oLC);_ac(oJC,oKC);var oMC=_setAttrs(z,"button",["type",6,"bindtap",1,"class",1],e,s,gg);var oNC=_o(z,7,e,s,gg);_ac(oMC,oNC);_ac(oJC,oMC);var oOC=_setAttrs(z,"button",["type",6,"bindtap",2,"class",2],e,s,gg);var oPC=_o(z,8,e,s,gg);_ac(oOC,oPC);_ac(oJC,oOC);var oQC=_setAttrs(z,"button",["type",6,"bindtap",3,"class",3],e,s,gg);var oRC=_o(z,9,e,s,gg);_ac(oQC,oRC);_ac(oJC,oQC);var oSC=_setAttrs(z,"button",["type",6,"bindtap",4,"class",4],e,s,gg);var oTC=_o(z,10,e,s,gg);_ac(oSC,oTC);_ac(oJC,oSC);var oUC=_setAttrs(z,"button",["type",6,"bindtap",5,"class",5],e,s,gg);var oVC=_o(z,11,e,s,gg);_ac(oUC,oVC);_ac(oJC,oUC);var oWC=_setAttrs(z,"button",["type",6,"bindtap",6,"class",6],e,s,gg);var oXC=_o(z,12,e,s,gg);_ac(oWC,oXC);_ac(oJC,oWC);_ac(oEC,oJC);var oYC=_ctn("view");_setAttr(z,oYC,'class',13,e,s,gg);var oZC=_setAttrs(z,"view",["class",14,"style",1],e,s,gg);var oaC=_o(z,16,e,s,gg);_ac(oZC,oaC);_ac(oYC,oZC);_ac(oEC,oYC);var obC=_cvn();
    var ocC=_o(z,17,e,s,gg);
    var odC=_gd('./macle_demo_EN/page/API/pages/application-event/application-event.maml',ocC,e_,d_);
    if(odC){
      var oeC={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      odC(oeC,oeC,obC,gg);
      gg.f=tgf;
    }else{
      _w(ocC,'./macle_demo_EN/page/API/pages/application-event/application-event.maml',0,0);
    }
    _ac(oEC,obC);_ac(r,oEC);oBC.pop();oBC.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/application-event/application-event.maml"]={f:m8,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/canIUse/canIUse.maml"]={};
  var m9=function(e,s,r,gg){
    var z=gz$gma_10()
    var ofC=e_["./macle_demo_EN/page/API/pages/canIUse/canIUse.maml"].i;_ai(ofC,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/canIUse/canIUse.maml',0,0);_ai(ofC,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/canIUse/canIUse.maml',0,0);var oiC=_ctn("view");_setAttr(z,oiC,'class',0,e,s,gg);var ojC=_cvn();
    var okC=_o(z,1,e,s,gg);
    var olC=_gd('./macle_demo_EN/page/API/pages/canIUse/canIUse.maml',okC,e_,d_);
    if(olC){
      var omC=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      olC(omC,omC,ojC,gg);
      gg.f=tgf;
    }else{
      _w(okC,'./macle_demo_EN/page/API/pages/canIUse/canIUse.maml',0,0);
    }
    _ac(oiC,ojC);var onC=_ctn("view");_setAttr(z,onC,'class',3,e,s,gg);var ooC=_ctn("view");_setAttr(z,ooC,'class',4,e,s,gg);var opC=_ctn("view");_setAttr(z,opC,'class',5,e,s,gg);var oqC=_o(z,6,e,s,gg);_ac(opC,oqC);_ac(ooC,opC);var orC=_setAttrs(z,"button",["bindtap",7,"class",0,"type",1],e,s,gg);var osC=_o(z,9,e,s,gg);_ac(orC,osC);_ac(ooC,orC);var otC=_setAttrs(z,"button",["type",8,"bindtap",2,"class",2],e,s,gg);var ouC=_o(z,11,e,s,gg);_ac(otC,ouC);_ac(ooC,otC);var ovC=_setAttrs(z,"button",["type",8,"bindtap",4,"class",4],e,s,gg);var owC=_o(z,13,e,s,gg);_ac(ovC,owC);_ac(ooC,ovC);var oxC=_setAttrs(z,"button",["type",8,"bindtap",6,"class",6],e,s,gg);var oyC=_o(z,15,e,s,gg);_ac(oxC,oyC);_ac(ooC,oxC);var ozC=_setAttrs(z,"button",["type",8,"bindtap",8,"class",8],e,s,gg);var o_C=_o(z,17,e,s,gg);_ac(ozC,o_C);_ac(ooC,ozC);var oAD=_setAttrs(z,"button",["type",8,"bindtap",10,"class",10],e,s,gg);var oBD=_o(z,19,e,s,gg);_ac(oAD,oBD);_ac(ooC,oAD);var oCD=_setAttrs(z,"button",["type",8,"bindtap",12,"class",12],e,s,gg);var oDD=_o(z,21,e,s,gg);_ac(oCD,oDD);_ac(ooC,oCD);var oED=_setAttrs(z,"button",["type",8,"bindtap",14,"class",14],e,s,gg);var oFD=_o(z,23,e,s,gg);_ac(oED,oFD);_ac(ooC,oED);var oGD=_ctn("view");_setAttr(z,oGD,'class',24,e,s,gg);var oHD=_o(z,25,e,s,gg);_ac(oGD,oHD);_ac(ooC,oGD);var oID=_setAttrs(z,"button",["type",8,"bindtap",18,"class",18],e,s,gg);var oJD=_o(z,27,e,s,gg);_ac(oID,oJD);_ac(ooC,oID);var oKD=_setAttrs(z,"button",["type",8,"bindtap",20,"class",20],e,s,gg);var oLD=_o(z,29,e,s,gg);_ac(oKD,oLD);_ac(ooC,oKD);var oMD=_setAttrs(z,"button",["type",8,"bindtap",22,"class",22],e,s,gg);var oND=_o(z,31,e,s,gg);_ac(oMD,oND);_ac(ooC,oMD);var oOD=_setAttrs(z,"button",["type",8,"bindtap",24,"class",24],e,s,gg);var oPD=_o(z,33,e,s,gg);_ac(oOD,oPD);_ac(ooC,oOD);var oQD=_setAttrs(z,"button",["type",8,"bindtap",26,"class",26],e,s,gg);var oRD=_o(z,35,e,s,gg);_ac(oQD,oRD);_ac(ooC,oQD);var oSD=_setAttrs(z,"button",["type",8,"bindtap",28,"class",28],e,s,gg);var oTD=_o(z,37,e,s,gg);_ac(oSD,oTD);_ac(ooC,oSD);_ac(onC,ooC);_ac(oiC,onC);var oUD=_cvn();
    var oVD=_o(z,38,e,s,gg);
    var oWD=_gd('./macle_demo_EN/page/API/pages/canIUse/canIUse.maml',oVD,e_,d_);
    if(oWD){
      var oXD={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oWD(oXD,oXD,oUD,gg);
      gg.f=tgf;
    }else{
      _w(oVD,'./macle_demo_EN/page/API/pages/canIUse/canIUse.maml',0,0);
    }
    _ac(oiC,oUD);_ac(r,oiC);ofC.pop();ofC.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/canIUse/canIUse.maml"]={f:m9,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml"]={};
  var m10=function(e,s,r,gg){
    var z=gz$gma_11()
    var oYD=e_["./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml"].i;_ai(oYD,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml',0,0);_ai(oYD,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml',0,0);var obD=_ctn("view");_setAttr(z,obD,'class',0,e,s,gg);var ocD=_cvn();
    var odD=_o(z,1,e,s,gg);
    var oeD=_gd('./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml',odD,e_,d_);
    if(oeD){
      var ofD=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oeD(ofD,ofD,ocD,gg);
      gg.f=tgf;
    }else{
      _w(odD,'./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml',0,0);
    }
    _ac(obD,ocD);var ogD=_ctn("view");_setAttr(z,ogD,'class',3,e,s,gg);var ohD=_ctn("view");_setAttr(z,ohD,'class',4,e,s,gg);var oiD=_setAttrs(z,"button",["bindtap",5,"type",1],e,s,gg);var ojD=_o(z,7,e,s,gg);_ac(oiD,ojD);_ac(ohD,oiD);_ac(ogD,ohD);_ac(obD,ogD);var okD=_cvn();
    var olD=_o(z,8,e,s,gg);
    var omD=_gd('./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml',olD,e_,d_);
    if(omD){
      var onD={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      omD(onD,onD,okD,gg);
      gg.f=tgf;
    }else{
      _w(olD,'./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml',0,0);
    }
    _ac(obD,okD);_ac(r,obD);oYD.pop();oYD.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml"]={f:m10,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/compressImage/compressImage.maml"]={};
  var m11=function(e,s,r,gg){
    var z=gz$gma_12()
    var ooD=e_["./macle_demo_EN/page/API/pages/compressImage/compressImage.maml"].i;_ai(ooD,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/compressImage/compressImage.maml',0,0);_ai(ooD,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/compressImage/compressImage.maml',0,0);var orD=_ctn("view");_setAttr(z,orD,'class',0,e,s,gg);var osD=_cvn();
    var otD=_o(z,1,e,s,gg);
    var ouD=_gd('./macle_demo_EN/page/API/pages/compressImage/compressImage.maml',otD,e_,d_);
    if(ouD){
      var ovD=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ouD(ovD,ovD,osD,gg);
      gg.f=tgf;
    }else{
      _w(otD,'./macle_demo_EN/page/API/pages/compressImage/compressImage.maml',0,0);
    }
    _ac(orD,osD);var owD=_ctn("view");_setAttr(z,owD,'class',3,e,s,gg);var oxD=_ctn("form");var oyD=_ctn("view");_setAttr(z,oyD,'class',4,e,s,gg);var ozD=_ctn("view");var o_D=_setAttrs(z,"image",["mode",5,"src",1,"style",2],e,s,gg);_ac(ozD,o_D);var oAE=_setAttrs(z,"button",["bindtap",8,"class",1],e,s,gg);var oBE=_o(z,10,e,s,gg);_ac(oAE,oBE);_ac(ozD,oAE);var oCE=_setAttrs(z,"button",["bindtap",11,"class",1],e,s,gg);var oDE=_o(z,13,e,s,gg);_ac(oCE,oDE);_ac(ozD,oCE);_ac(oyD,ozD);var oEE=_cvn();if(_o(z,14,e,s,gg)){oEE.maVkey=1;var oFE=_ctn("view");_setAttr(z,oFE,'class',15,e,s,gg);var oHE=_ctn("text");_setAttr(z,oHE,'class',16,e,s,gg);var oIE=_o(z,17,e,s,gg);_ac(oHE,oIE);_ac(oFE,oHE);_ac(oEE,oFE);} _ac(oyD,oEE);var oJE=_cvn();if(_o(z,18,e,s,gg)){oJE.maVkey=1;var oKE=_ctn("view");var oME=_ctn("text");_setAttr(z,oME,'class',19,e,s,gg);var oNE=_o(z,20,e,s,gg);_ac(oME,oNE);_ac(oKE,oME);_ac(oJE,oKE);} _ac(oyD,oJE);var oOE=_cvn();if(_o(z,21,e,s,gg)){oOE.maVkey=1;var oPE=_ctn("view");var oRE=_ctn("text");_setAttr(z,oRE,'space',22,e,s,gg);var oSE=_o(z,23,e,s,gg);_ac(oRE,oSE);_ac(oPE,oRE);_ac(oOE,oPE);} _ac(oyD,oOE);_ac(oxD,oyD);_ac(owD,oxD);_ac(orD,owD);var oTE=_cvn();
    var oUE=_o(z,24,e,s,gg);
    var oVE=_gd('./macle_demo_EN/page/API/pages/compressImage/compressImage.maml',oUE,e_,d_);
    if(oVE){
      var oWE={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oVE(oWE,oWE,oTE,gg);
      gg.f=tgf;
    }else{
      _w(oUE,'./macle_demo_EN/page/API/pages/compressImage/compressImage.maml',0,0);
    }
    _ac(orD,oTE);_ac(r,orD);ooD.pop();ooD.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/compressImage/compressImage.maml"]={f:m11,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml"]={};
  var m12=function(e,s,r,gg){
    var z=gz$gma_13()
    var oXE=e_["./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml"].i;_ai(oXE,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml',0,0);_ai(oXE,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml',0,0);var oaE=_ctn("view");_setAttr(z,oaE,'class',0,e,s,gg);var obE=_cvn();
    var ocE=_o(z,1,e,s,gg);
    var odE=_gd('./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml',ocE,e_,d_);
    if(odE){
      var oeE=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      odE(oeE,oeE,obE,gg);
      gg.f=tgf;
    }else{
      _w(ocE,'./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml',0,0);
    }
    _ac(oaE,obE);var ofE=_ctn("view");_setAttr(z,ofE,'class',3,e,s,gg);var ogE=_ctn("view");_setAttr(z,ogE,'class',4,e,s,gg);var ohE=_setAttrs(z,"button",["bindtap",5,"class",1,"type",2],e,s,gg);var oiE=_o(z,8,e,s,gg);_ac(ohE,oiE);_ac(ogE,ohE);var ojE=_setAttrs(z,"button",["bindtap",6,"type",1,"class",3],e,s,gg);var okE=_o(z,10,e,s,gg);_ac(ojE,okE);_ac(ogE,ojE);_ac(ofE,ogE);var olE=_ctn("view");_setAttr(z,olE,'class',11,e,s,gg);var omE=_ctn("text");var onE=_o(z,12,e,s,gg);_ac(omE,onE);_ac(olE,omE);var ooE=_setAttrs(z,"switch",["bindchange",13,"checked",1],e,s,gg);_ac(olE,ooE);_ac(ofE,olE);var opE=_cvn();if(_o(z,15,e,s,gg)){opE.maVkey=1;var oqE=_ctn("view");_setAttr(z,oqE,'class',16,e,s,gg);var osE=_ctn("text");_setAttr(z,osE,'class',16,e,s,gg);var otE=_o(z,17,e,s,gg);_ac(osE,otE);_ac(oqE,osE);var ouE=_ctn("text");_setAttr(z,ouE,'class',18,e,s,gg);var ovE=_o(z,19,e,s,gg);_ac(ouE,ovE);_ac(oqE,ouE);_ac(opE,oqE);} _ac(ofE,opE);_ac(oaE,ofE);var owE=_cvn();
    var oxE=_o(z,20,e,s,gg);
    var oyE=_gd('./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml',oxE,e_,d_);
    if(oyE){
      var ozE={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oyE(ozE,ozE,owE,gg);
      gg.f=tgf;
    }else{
      _w(oxE,'./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml',0,0);
    }
    _ac(oaE,owE);_ac(r,oaE);oXE.pop();oXE.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml"]={f:m12,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/file/file.maml"]={};
  var m13=function(e,s,r,gg){
    var z=gz$gma_14()
    var o_E=e_["./macle_demo_EN/page/API/pages/file/file.maml"].i;_ai(o_E,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/file/file.maml',0,0);_ai(o_E,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/file/file.maml',0,0);var oCF=_ctn("view");_setAttr(z,oCF,'class',0,e,s,gg);var oDF=_cvn();
    var oEF=_o(z,1,e,s,gg);
    var oFF=_gd('./macle_demo_EN/page/API/pages/file/file.maml',oEF,e_,d_);
    if(oFF){
      var oGF=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oFF(oGF,oGF,oDF,gg);
      gg.f=tgf;
    }else{
      _w(oEF,'./macle_demo_EN/page/API/pages/file/file.maml',0,0);
    }
    _ac(oCF,oDF);var oHF=_ctn("view");_setAttr(z,oHF,'class',3,e,s,gg);var oIF=_ctn("view");_setAttr(z,oIF,'class',4,e,s,gg);var oJF=_ctn("view");_setAttr(z,oJF,'class',5,e,s,gg);var oKF=_cvn();if(_o(z,6,e,s,gg)){oKF.maVkey=1;var oNF=_setAttrs(z,"image",["class",7,"mode",1,"src",2],e,s,gg);_ac(oKF,oNF);} _ac(oJF,oKF);var oOF=_cvn();if(_o(z,10,e,s,gg)){oOF.maVkey=1;var oRF=_setAttrs(z,"image",["class",7,"mode",1,"src",4],e,s,gg);_ac(oOF,oRF);} _ac(oJF,oOF);var oSF=_cvn();if(_o(z,12,e,s,gg)){oSF.maVkey=1;var oVF=_setAttrs(z,"view",["bindtap",13,"class",1],e,s,gg);var oWF=_ctn("view");_setAttr(z,oWF,'class',15,e,s,gg);_ac(oVF,oWF);var oXF=_ctn("view");_setAttr(z,oXF,'class',16,e,s,gg);_ac(oVF,oXF);_ac(oSF,oVF);var oYF=_ctn("view");_setAttr(z,oYF,'class',17,e,s,gg);var oZF=_o(z,18,e,s,gg);_ac(oYF,oZF);_ac(oSF,oYF);} _ac(oJF,oSF);_ac(oIF,oJF);var oaF=_ctn("view");_setAttr(z,oaF,'class',19,e,s,gg);var obF=_setAttrs(z,"button",["bindtap",20,"type",1],e,s,gg);var ocF=_o(z,22,e,s,gg);_ac(obF,ocF);_ac(oaF,obF);var odF=_ctn("button");_setAttr(z,odF,'bindtap',23,e,s,gg);var oeF=_o(z,23,e,s,gg);_ac(odF,oeF);_ac(oaF,odF);var ofF=_setAttrs(z,"button",["type",21,"bindtap",3],e,s,gg);var ogF=_o(z,25,e,s,gg);_ac(ofF,ogF);_ac(oaF,ofF);var ohF=_setAttrs(z,"button",["type",21,"bindtap",5],e,s,gg);var oiF=_o(z,27,e,s,gg);_ac(ohF,oiF);_ac(oaF,ohF);var ojF=_setAttrs(z,"button",["type",21,"bindtap",7],e,s,gg);var okF=_o(z,27,e,s,gg);_ac(ojF,okF);_ac(oaF,ojF);var olF=_setAttrs(z,"button",["type",21,"bindtap",8],e,s,gg);var omF=_o(z,30,e,s,gg);_ac(olF,omF);_ac(oaF,olF);_ac(oIF,oaF);var onF=_ctn("view");_setAttr(z,onF,'class',31,e,s,gg);var ooF=_ctn("view");var opF=_o(z,32,e,s,gg);_ac(ooF,opF);_ac(onF,ooF);var oqF=_ctn("text");var orF=_o(z,33,e,s,gg);_ac(oqF,orF);_ac(onF,oqF);_ac(oIF,onF);_ac(oHF,oIF);_ac(oCF,oHF);var osF=_cvn();
    var otF=_o(z,34,e,s,gg);
    var ouF=_gd('./macle_demo_EN/page/API/pages/file/file.maml',otF,e_,d_);
    if(ouF){
      var ovF={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ouF(ovF,ovF,osF,gg);
      gg.f=tgf;
    }else{
      _w(otF,'./macle_demo_EN/page/API/pages/file/file.maml',0,0);
    }
    _ac(oCF,osF);_ac(r,oCF);o_E.pop();o_E.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/file/file.maml"]={f:m13,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml"]={};
  var m14=function(e,s,r,gg){
    var z=gz$gma_15()
    var owF=e_["./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml"].i;_ai(owF,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml',0,0);_ai(owF,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml',0,0);var ozF=_ctn("view");_setAttr(z,ozF,'class',0,e,s,gg);var o_F=_cvn();
    var oAG=_o(z,1,e,s,gg);
    var oBG=_gd('./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml',oAG,e_,d_);
    if(oBG){
      var oCG=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oBG(oCG,oCG,o_F,gg);
      gg.f=tgf;
    }else{
      _w(oAG,'./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml',0,0);
    }
    _ac(ozF,o_F);var oDG=_ctn("view");_setAttr(z,oDG,'class',3,e,s,gg);var oEG=_ctn("view");_setAttr(z,oEG,'class',4,e,s,gg);var oFG=_ctn("view");_setAttr(z,oFG,'class',5,e,s,gg);var oGG=_ctn("view");_setAttr(z,oGG,'class',6,e,s,gg);var oHG=_ctn("view");_setAttr(z,oHG,'class',7,e,s,gg);var oIG=_ctn("view");_setAttr(z,oIG,'class',8,e,s,gg);var oJG=_o(z,9,e,s,gg);_ac(oIG,oJG);_ac(oHG,oIG);_ac(oGG,oHG);var oKG=_ctn("view");_setAttr(z,oKG,'class',10,e,s,gg);var oLG=_setAttrs(z,"input",["class",11,"disabled",1,"placeholder",2,"type",3,"value",4],e,s,gg);_ac(oKG,oLG);_ac(oGG,oKG);_ac(oFG,oGG);var oMG=_ctn("view");_setAttr(z,oMG,'class',6,e,s,gg);var oNG=_ctn("view");_setAttr(z,oNG,'class',7,e,s,gg);var oOG=_ctn("view");_setAttr(z,oOG,'class',8,e,s,gg);var oPG=_o(z,16,e,s,gg);_ac(oOG,oPG);_ac(oNG,oOG);_ac(oMG,oNG);var oQG=_ctn("view");_setAttr(z,oQG,'class',10,e,s,gg);var oRG=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",5,"value",6],e,s,gg);_ac(oQG,oRG);_ac(oMG,oQG);_ac(oFG,oMG);_ac(oEG,oFG);var oSG=_setAttrs(z,"button",["bind:tap",19,"class",0,"type",1],e,s,gg);var oTG=_o(z,21,e,s,gg);_ac(oSG,oTG);_ac(oEG,oSG);_ac(oDG,oEG);_ac(ozF,oDG);var oUG=_cvn();
    var oVG=_o(z,22,e,s,gg);
    var oWG=_gd('./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml',oVG,e_,d_);
    if(oWG){
      var oXG={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oWG(oXG,oXG,oUG,gg);
      gg.f=tgf;
    }else{
      _w(oVG,'./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml',0,0);
    }
    _ac(ozF,oUG);_ac(r,ozF);owF.pop();owF.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml"]={f:m14,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml"]={};
  var m15=function(e,s,r,gg){
    var z=gz$gma_16()
    var oYG=e_["./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml"].i;_ai(oYG,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml',0,0);_ai(oYG,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml',0,0);var obG=_ctn("view");_setAttr(z,obG,'class',0,e,s,gg);var ocG=_cvn();
    var odG=_o(z,1,e,s,gg);
    var oeG=_gd('./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml',odG,e_,d_);
    if(oeG){
      var ofG=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oeG(ofG,ofG,ocG,gg);
      gg.f=tgf;
    }else{
      _w(odG,'./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml',0,0);
    }
    _ac(obG,ocG);var ogG=_ctn("view");_setAttr(z,ogG,'class',3,e,s,gg);var ohG=_ctn("form");var oiG=_ctn("view");_setAttr(z,oiG,'class',4,e,s,gg);var ojG=_ctn("view");var okG=_setAttrs(z,"image",["mode",5,"src",1,"style",2],e,s,gg);_ac(ojG,okG);var olG=_setAttrs(z,"image",["mode",5,"style",2,"src",3],e,s,gg);_ac(ojG,olG);var omG=_setAttrs(z,"button",["bindtap",9,"class",0],e,s,gg);var onG=_o(z,9,e,s,gg);_ac(omG,onG);_ac(ojG,omG);var ooG=_setAttrs(z,"button",["bindtap",10,"class",1],e,s,gg);var opG=_o(z,12,e,s,gg);_ac(ooG,opG);_ac(ojG,ooG);var oqG=_setAttrs(z,"button",["bindtap",13,"class",1],e,s,gg);var orG=_o(z,15,e,s,gg);_ac(oqG,orG);_ac(ojG,oqG);_ac(oiG,ojG);var osG=_cvn();if(_o(z,16,e,s,gg)){osG.maVkey=1;var otG=_ctn("view");_setAttr(z,otG,'class',17,e,s,gg);var ovG=_ctn("text");_setAttr(z,ovG,'class',18,e,s,gg);var owG=_o(z,19,e,s,gg);_ac(ovG,owG);_ac(otG,ovG);_ac(osG,otG);} _ac(oiG,osG);var oxG=_cvn();if(_o(z,20,e,s,gg)){oxG.maVkey=1;var oyG=_ctn("view");_setAttr(z,oyG,'class',17,e,s,gg);var o_G=_ctn("text");_setAttr(z,o_G,'space',21,e,s,gg);var oAH=_o(z,22,e,s,gg);_ac(o_G,oAH);_ac(oyG,o_G);_ac(oxG,oyG);} _ac(oiG,oxG);_ac(ohG,oiG);_ac(ogG,ohG);_ac(obG,ogG);var oBH=_cvn();
    var oCH=_o(z,23,e,s,gg);
    var oDH=_gd('./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml',oCH,e_,d_);
    if(oDH){
      var oEH={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oDH(oEH,oEH,oBH,gg);
      gg.f=tgf;
    }else{
      _w(oCH,'./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml',0,0);
    }
    _ac(obG,oBH);_ac(r,obG);oYG.pop();oYG.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml"]={f:m15,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/get-location/get-location.maml"]={};
  var m16=function(e,s,r,gg){
    var z=gz$gma_17()
    var oFH=e_["./macle_demo_EN/page/API/pages/get-location/get-location.maml"].i;_ai(oFH,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/get-location/get-location.maml',0,0);_ai(oFH,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/get-location/get-location.maml',0,0);var oIH=_ctn("view");_setAttr(z,oIH,'class',0,e,s,gg);var oJH=_cvn();
    var oKH=_o(z,1,e,s,gg);
    var oLH=_gd('./macle_demo_EN/page/API/pages/get-location/get-location.maml',oKH,e_,d_);
    if(oLH){
      var oMH=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oLH(oMH,oMH,oJH,gg);
      gg.f=tgf;
    }else{
      _w(oKH,'./macle_demo_EN/page/API/pages/get-location/get-location.maml',0,0);
    }
    _ac(oIH,oJH);var oNH=_ctn("view");_setAttr(z,oNH,'class',3,e,s,gg);var oOH=_ctn("view");_setAttr(z,oOH,'class',4,e,s,gg);var oPH=_ctn("view");_setAttr(z,oPH,'class',5,e,s,gg);var oQH=_ctn("text");_setAttr(z,oQH,'class',6,e,s,gg);var oRH=_o(z,7,e,s,gg);_ac(oQH,oRH);_ac(oPH,oQH);var oSH=_cvn();if(_o(z,8,e,s,gg)){oSH.maVkey=1;var oVH=_ctn("text");_setAttr(z,oVH,'class',9,e,s,gg);var oWH=_o(z,10,e,s,gg);_ac(oVH,oWH);_ac(oSH,oVH);} _ac(oPH,oSH);var oXH=_cvn();if(_o(z,11,e,s,gg)){oXH.maVkey=1;var oaH=_ctn("view");_setAttr(z,oaH,'class',12,e,s,gg);var obH=_ctn("text");_setAttr(z,obH,'class',13,e,s,gg);var ocH=_o(z,14,e,s,gg);_ac(obH,ocH);_ac(oaH,obH);var odH=_ctn("text");var oeH=_o(z,15,e,s,gg);_ac(odH,oeH);_ac(oaH,odH);_ac(oXH,oaH);} _ac(oPH,oXH);_ac(oOH,oPH);var ofH=_ctn("view");_setAttr(z,ofH,'class',16,e,s,gg);var ogH=_setAttrs(z,"button",["bindtap",17,"class",0,"type",1],e,s,gg);var ohH=_o(z,19,e,s,gg);_ac(ogH,ohH);_ac(ofH,ogH);var oiH=_setAttrs(z,"button",["bindtap",20,"class",0],e,s,gg);var ojH=_o(z,21,e,s,gg);_ac(oiH,ojH);_ac(ofH,oiH);_ac(oOH,ofH);_ac(oNH,oOH);_ac(oIH,oNH);var okH=_cvn();
    var olH=_o(z,22,e,s,gg);
    var omH=_gd('./macle_demo_EN/page/API/pages/get-location/get-location.maml',olH,e_,d_);
    if(omH){
      var onH={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      omH(onH,onH,okH,gg);
      gg.f=tgf;
    }else{
      _w(olH,'./macle_demo_EN/page/API/pages/get-location/get-location.maml',0,0);
    }
    _ac(oIH,okH);_ac(r,oIH);oFH.pop();oFH.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/get-location/get-location.maml"]={f:m16,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml"]={};
  var m17=function(e,s,r,gg){
    var z=gz$gma_18()
    var ooH=e_["./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml"].i;_ai(ooH,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml',0,0);_ai(ooH,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml',0,0);var orH=_ctn("view");_setAttr(z,orH,'class',0,e,s,gg);var osH=_cvn();
    var otH=_o(z,1,e,s,gg);
    var ouH=_gd('./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml',otH,e_,d_);
    if(ouH){
      var ovH=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ouH(ovH,ovH,osH,gg);
      gg.f=tgf;
    }else{
      _w(otH,'./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml',0,0);
    }
    _ac(orH,osH);var owH=_ctn("view");_setAttr(z,owH,'class',3,e,s,gg);var oxH=_ctn("view");_setAttr(z,oxH,'class',4,e,s,gg);var oyH=_ctn("view");var ozH=_o(z,5,e,s,gg);_ac(oyH,ozH);_ac(oxH,oyH);var o_H=_ctn("view");_setAttr(z,o_H,'class',6,e,s,gg);var oAI=_ctn("view");_setAttr(z,oAI,'class',7,e,s,gg);var oBI=_ctn("view");_setAttr(z,oBI,'class',8,e,s,gg);var oCI=_o(z,9,e,s,gg);_ac(oBI,oCI);_ac(oAI,oBI);_ac(o_H,oAI);var oDI=_ctn("view");_setAttr(z,oDI,'class',7,e,s,gg);var oEI=_ctn("view");_setAttr(z,oEI,'class',8,e,s,gg);var oFI=_o(z,10,e,s,gg);_ac(oEI,oFI);_ac(oDI,oEI);_ac(o_H,oDI);_ac(oxH,o_H);var oGI=_setAttrs(z,"button",["bindtap",11,"type",1],e,s,gg);var oHI=_o(z,13,e,s,gg);_ac(oGI,oHI);_ac(oxH,oGI);_ac(owH,oxH);_ac(orH,owH);var oII=_cvn();
    var oJI=_o(z,14,e,s,gg);
    var oKI=_gd('./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml',oJI,e_,d_);
    if(oKI){
      var oLI={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oKI(oLI,oLI,oII,gg);
      gg.f=tgf;
    }else{
      _w(oJI,'./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml',0,0);
    }
    _ac(orH,oII);_ac(r,orH);ooH.pop();ooH.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml"]={f:m17,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml"]={};
  var m18=function(e,s,r,gg){
    var z=gz$gma_19()
    var oMI=e_["./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml"].i;_ai(oMI,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml',0,0);_ai(oMI,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml',0,0);var oPI=_ctn("view");_setAttr(z,oPI,'class',0,e,s,gg);var oQI=_cvn();
    var oRI=_o(z,1,e,s,gg);
    var oSI=_gd('./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml',oRI,e_,d_);
    if(oSI){
      var oTI=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oSI(oTI,oTI,oQI,gg);
      gg.f=tgf;
    }else{
      _w(oRI,'./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml',0,0);
    }
    _ac(oPI,oQI);var oUI=_ctn("view");_setAttr(z,oUI,'class',3,e,s,gg);var oVI=_ctn("view");_setAttr(z,oVI,'class',4,e,s,gg);var oWI=_ctn("view");_setAttr(z,oWI,'class',5,e,s,gg);var oXI=_ctn("view");_setAttr(z,oXI,'class',6,e,s,gg);var oYI=_ctn("view");_setAttr(z,oYI,'class',7,e,s,gg);var oZI=_ctn("view");_setAttr(z,oZI,'class',8,e,s,gg);var oaI=_o(z,9,e,s,gg);_ac(oZI,oaI);_ac(oYI,oZI);_ac(oXI,oYI);var obI=_ctn("view");_setAttr(z,obI,'class',10,e,s,gg);var ocI=_setAttrs(z,"input",["class",11,"disabled",1,"placeholder",2,"type",3,"value",4],e,s,gg);_ac(obI,ocI);_ac(oXI,obI);_ac(oWI,oXI);var odI=_ctn("view");_setAttr(z,odI,'class',6,e,s,gg);var oeI=_ctn("view");_setAttr(z,oeI,'class',7,e,s,gg);var ofI=_ctn("view");_setAttr(z,ofI,'class',8,e,s,gg);var ogI=_o(z,16,e,s,gg);_ac(ofI,ogI);_ac(oeI,ofI);_ac(odI,oeI);var ohI=_ctn("view");_setAttr(z,ohI,'class',10,e,s,gg);var oiI=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",5,"value",6],e,s,gg);_ac(ohI,oiI);_ac(odI,ohI);_ac(oWI,odI);var ojI=_ctn("view");_setAttr(z,ojI,'class',6,e,s,gg);var okI=_ctn("view");_setAttr(z,okI,'class',7,e,s,gg);var olI=_ctn("view");_setAttr(z,olI,'class',8,e,s,gg);var omI=_o(z,19,e,s,gg);_ac(olI,omI);_ac(okI,olI);_ac(ojI,okI);var onI=_ctn("view");_setAttr(z,onI,'class',10,e,s,gg);var ooI=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",8,"value",9],e,s,gg);_ac(onI,ooI);_ac(ojI,onI);_ac(oWI,ojI);var opI=_ctn("view");_setAttr(z,opI,'class',6,e,s,gg);var oqI=_ctn("view");_setAttr(z,oqI,'class',7,e,s,gg);var orI=_ctn("view");_setAttr(z,orI,'class',8,e,s,gg);var osI=_o(z,22,e,s,gg);_ac(orI,osI);_ac(oqI,orI);_ac(opI,oqI);var otI=_ctn("view");_setAttr(z,otI,'class',10,e,s,gg);var ouI=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",11,"value",12],e,s,gg);_ac(otI,ouI);_ac(opI,otI);_ac(oWI,opI);var ovI=_ctn("view");_setAttr(z,ovI,'class',6,e,s,gg);var owI=_ctn("view");_setAttr(z,owI,'class',7,e,s,gg);var oxI=_ctn("view");_setAttr(z,oxI,'class',8,e,s,gg);var oyI=_o(z,25,e,s,gg);_ac(oxI,oyI);_ac(owI,oxI);_ac(ovI,owI);var ozI=_ctn("view");_setAttr(z,ozI,'class',10,e,s,gg);var o_I=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",14,"value",15],e,s,gg);_ac(ozI,o_I);_ac(ovI,ozI);_ac(oWI,ovI);var oAJ=_ctn("view");_setAttr(z,oAJ,'class',6,e,s,gg);var oBJ=_ctn("view");_setAttr(z,oBJ,'class',7,e,s,gg);var oCJ=_ctn("view");_setAttr(z,oCJ,'class',8,e,s,gg);var oDJ=_o(z,28,e,s,gg);_ac(oCJ,oDJ);_ac(oBJ,oCJ);_ac(oAJ,oBJ);var oEJ=_ctn("view");_setAttr(z,oEJ,'class',10,e,s,gg);var oFJ=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",17,"value",18],e,s,gg);_ac(oEJ,oFJ);_ac(oAJ,oEJ);_ac(oWI,oAJ);var oGJ=_ctn("view");_setAttr(z,oGJ,'class',6,e,s,gg);var oHJ=_ctn("view");_setAttr(z,oHJ,'class',7,e,s,gg);var oIJ=_ctn("view");_setAttr(z,oIJ,'class',8,e,s,gg);var oJJ=_o(z,31,e,s,gg);_ac(oIJ,oJJ);_ac(oHJ,oIJ);_ac(oGJ,oHJ);var oKJ=_ctn("view");_setAttr(z,oKJ,'class',10,e,s,gg);var oLJ=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",20,"value",21],e,s,gg);_ac(oKJ,oLJ);_ac(oGJ,oKJ);_ac(oWI,oGJ);var oMJ=_ctn("view");_setAttr(z,oMJ,'class',6,e,s,gg);var oNJ=_ctn("view");_setAttr(z,oNJ,'class',7,e,s,gg);var oOJ=_ctn("view");_setAttr(z,oOJ,'class',8,e,s,gg);var oPJ=_o(z,34,e,s,gg);_ac(oOJ,oPJ);_ac(oNJ,oOJ);_ac(oMJ,oNJ);var oQJ=_ctn("view");_setAttr(z,oQJ,'class',10,e,s,gg);var oRJ=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",23,"value",24],e,s,gg);_ac(oQJ,oRJ);_ac(oMJ,oQJ);_ac(oWI,oMJ);var oSJ=_ctn("view");_setAttr(z,oSJ,'class',6,e,s,gg);var oTJ=_ctn("view");_setAttr(z,oTJ,'class',7,e,s,gg);var oUJ=_ctn("view");_setAttr(z,oUJ,'class',8,e,s,gg);var oVJ=_o(z,37,e,s,gg);_ac(oUJ,oVJ);_ac(oTJ,oUJ);_ac(oSJ,oTJ);var oWJ=_ctn("view");_setAttr(z,oWJ,'class',10,e,s,gg);var oXJ=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",26,"value",27],e,s,gg);_ac(oWJ,oXJ);_ac(oSJ,oWJ);_ac(oWI,oSJ);var oYJ=_ctn("view");_setAttr(z,oYJ,'class',6,e,s,gg);var oZJ=_ctn("view");_setAttr(z,oZJ,'class',7,e,s,gg);var oaJ=_ctn("view");_setAttr(z,oaJ,'class',8,e,s,gg);var obJ=_o(z,40,e,s,gg);_ac(oaJ,obJ);_ac(oZJ,oaJ);_ac(oYJ,oZJ);var ocJ=_ctn("view");_setAttr(z,ocJ,'class',10,e,s,gg);var odJ=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",29,"value",30],e,s,gg);_ac(ocJ,odJ);_ac(oYJ,ocJ);_ac(oWI,oYJ);_ac(oVI,oWI);var oeJ=_ctn("view");_setAttr(z,oeJ,'class',43,e,s,gg);var ofJ=_setAttrs(z,"button",["bindtap",44,"class",1,"type",2],e,s,gg);var ogJ=_o(z,47,e,s,gg);_ac(ofJ,ogJ);_ac(oeJ,ofJ);_ac(oVI,oeJ);_ac(oUI,oVI);_ac(oPI,oUI);var ohJ=_cvn();
    var oiJ=_o(z,48,e,s,gg);
    var ojJ=_gd('./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml',oiJ,e_,d_);
    if(ojJ){
      var okJ={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ojJ(okJ,okJ,ohJ,gg);
      gg.f=tgf;
    }else{
      _w(oiJ,'./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml',0,0);
    }
    _ac(oPI,ohJ);_ac(r,oPI);oMI.pop();oMI.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml"]={f:m18,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml"]={};
  var m19=function(e,s,r,gg){
    var z=gz$gma_20()
    var olJ=e_["./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml"].i;_ai(olJ,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml',0,0);_ai(olJ,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml',0,0);var ooJ=_ctn("view");_setAttr(z,ooJ,'class',0,e,s,gg);var opJ=_cvn();
    var oqJ=_o(z,1,e,s,gg);
    var orJ=_gd('./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml',oqJ,e_,d_);
    if(orJ){
      var osJ=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      orJ(osJ,osJ,opJ,gg);
      gg.f=tgf;
    }else{
      _w(oqJ,'./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml',0,0);
    }
    _ac(ooJ,opJ);var otJ=_ctn("view");_setAttr(z,otJ,'class',3,e,s,gg);var ouJ=_ctn("view");_setAttr(z,ouJ,'class',4,e,s,gg);var ovJ=_ctn("view");_setAttr(z,ovJ,'class',5,e,s,gg);var owJ=_ctn("view");_setAttr(z,owJ,'class',6,e,s,gg);var oxJ=_ctn("view");_setAttr(z,oxJ,'class',7,e,s,gg);var oyJ=_ctn("view");_setAttr(z,oyJ,'class',8,e,s,gg);var ozJ=_o(z,9,e,s,gg);_ac(oyJ,ozJ);_ac(oxJ,oyJ);_ac(owJ,oxJ);var o_J=_ctn("view");_setAttr(z,o_J,'class',10,e,s,gg);var oAK=_setAttrs(z,"input",["class",11,"disabled",1,"placeholder",2,"type",3,"value",4],e,s,gg);_ac(o_J,oAK);_ac(owJ,o_J);_ac(ovJ,owJ);var oBK=_ctn("view");_setAttr(z,oBK,'class',6,e,s,gg);var oCK=_ctn("view");_setAttr(z,oCK,'class',7,e,s,gg);var oDK=_ctn("view");_setAttr(z,oDK,'class',8,e,s,gg);var oEK=_o(z,16,e,s,gg);_ac(oDK,oEK);_ac(oCK,oDK);_ac(oBK,oCK);var oFK=_ctn("view");_setAttr(z,oFK,'class',10,e,s,gg);var oGK=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",5,"value",6],e,s,gg);_ac(oFK,oGK);_ac(oBK,oFK);_ac(ovJ,oBK);var oHK=_ctn("view");_setAttr(z,oHK,'class',6,e,s,gg);var oIK=_ctn("view");_setAttr(z,oIK,'class',7,e,s,gg);var oJK=_ctn("view");_setAttr(z,oJK,'class',8,e,s,gg);var oKK=_o(z,19,e,s,gg);_ac(oJK,oKK);_ac(oIK,oJK);_ac(oHK,oIK);var oLK=_ctn("view");_setAttr(z,oLK,'class',10,e,s,gg);var oMK=_setAttrs(z,"input",["disabled",12,"type",2,"placeholder",7,"class",8,"value",9],e,s,gg);_ac(oLK,oMK);_ac(oHK,oLK);_ac(ovJ,oHK);var oNK=_ctn("view");_setAttr(z,oNK,'class',6,e,s,gg);var oOK=_ctn("view");_setAttr(z,oOK,'class',7,e,s,gg);var oPK=_ctn("view");_setAttr(z,oPK,'class',8,e,s,gg);var oQK=_o(z,22,e,s,gg);_ac(oPK,oQK);_ac(oOK,oPK);_ac(oNK,oOK);var oRK=_ctn("view");_setAttr(z,oRK,'class',10,e,s,gg);var oSK=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",11,"value",12],e,s,gg);_ac(oRK,oSK);_ac(oNK,oRK);_ac(ovJ,oNK);var oTK=_ctn("view");_setAttr(z,oTK,'class',6,e,s,gg);var oUK=_ctn("view");_setAttr(z,oUK,'class',7,e,s,gg);var oVK=_ctn("view");_setAttr(z,oVK,'class',8,e,s,gg);var oWK=_o(z,25,e,s,gg);_ac(oVK,oWK);_ac(oUK,oVK);_ac(oTK,oUK);var oXK=_ctn("view");_setAttr(z,oXK,'class',10,e,s,gg);var oYK=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",14,"value",15],e,s,gg);_ac(oXK,oYK);_ac(oTK,oXK);_ac(ovJ,oTK);var oZK=_ctn("view");_setAttr(z,oZK,'class',6,e,s,gg);var oaK=_ctn("view");_setAttr(z,oaK,'class',7,e,s,gg);var obK=_ctn("view");_setAttr(z,obK,'class',8,e,s,gg);var ocK=_o(z,28,e,s,gg);_ac(obK,ocK);_ac(oaK,obK);_ac(oZK,oaK);var odK=_ctn("view");_setAttr(z,odK,'class',10,e,s,gg);var oeK=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",17,"value",18],e,s,gg);_ac(odK,oeK);_ac(oZK,odK);_ac(ovJ,oZK);var ofK=_ctn("view");_setAttr(z,ofK,'class',6,e,s,gg);var ogK=_ctn("view");_setAttr(z,ogK,'class',7,e,s,gg);var ohK=_ctn("view");_setAttr(z,ohK,'class',8,e,s,gg);var oiK=_o(z,31,e,s,gg);_ac(ohK,oiK);_ac(ogK,ohK);_ac(ofK,ogK);var ojK=_ctn("view");_setAttr(z,ojK,'class',10,e,s,gg);var okK=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",20,"value",21],e,s,gg);_ac(ojK,okK);_ac(ofK,ojK);_ac(ovJ,ofK);var olK=_ctn("view");_setAttr(z,olK,'class',6,e,s,gg);var omK=_ctn("view");_setAttr(z,omK,'class',7,e,s,gg);var onK=_ctn("view");_setAttr(z,onK,'class',8,e,s,gg);var ooK=_o(z,34,e,s,gg);_ac(onK,ooK);_ac(omK,onK);_ac(olK,omK);var opK=_ctn("view");_setAttr(z,opK,'class',10,e,s,gg);var oqK=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",23,"value",24],e,s,gg);_ac(opK,oqK);_ac(olK,opK);_ac(ovJ,olK);var orK=_ctn("view");_setAttr(z,orK,'class',6,e,s,gg);var osK=_ctn("view");_setAttr(z,osK,'class',7,e,s,gg);var otK=_ctn("view");_setAttr(z,otK,'class',8,e,s,gg);var ouK=_o(z,37,e,s,gg);_ac(otK,ouK);_ac(osK,otK);_ac(orK,osK);var ovK=_ctn("view");_setAttr(z,ovK,'class',10,e,s,gg);var owK=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",26,"value",27],e,s,gg);_ac(ovK,owK);_ac(orK,ovK);_ac(ovJ,orK);var oxK=_ctn("view");_setAttr(z,oxK,'class',6,e,s,gg);var oyK=_ctn("view");_setAttr(z,oyK,'class',7,e,s,gg);var ozK=_ctn("view");_setAttr(z,ozK,'class',8,e,s,gg);var o_K=_o(z,40,e,s,gg);_ac(ozK,o_K);_ac(oyK,ozK);_ac(oxK,oyK);var oAL=_ctn("view");_setAttr(z,oAL,'class',10,e,s,gg);var oBL=_setAttrs(z,"input",["disabled",12,"placeholder",1,"type",2,"class",29,"value",30],e,s,gg);_ac(oAL,oBL);_ac(oxK,oAL);_ac(ovJ,oxK);_ac(ouJ,ovJ);var oCL=_ctn("view");_setAttr(z,oCL,'class',43,e,s,gg);var oDL=_setAttrs(z,"button",["bindtap",44,"class",0,"type",1],e,s,gg);var oEL=_o(z,46,e,s,gg);_ac(oDL,oEL);_ac(oCL,oDL);_ac(ouJ,oCL);_ac(otJ,ouJ);_ac(ooJ,otJ);var oFL=_cvn();
    var oGL=_o(z,47,e,s,gg);
    var oHL=_gd('./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml',oGL,e_,d_);
    if(oHL){
      var oIL={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oHL(oIL,oIL,oFL,gg);
      gg.f=tgf;
    }else{
      _w(oGL,'./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml',0,0);
    }
    _ac(ooJ,oFL);_ac(r,ooJ);olJ.pop();olJ.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml"]={f:m19,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml"]={};
  var m20=function(e,s,r,gg){
    var z=gz$gma_21()
    var oJL=e_["./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml"].i;_ai(oJL,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml',0,0);_ai(oJL,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml',0,0);var oML=_ctn("view");_setAttr(z,oML,'class',0,e,s,gg);var oNL=_cvn();
    var oOL=_o(z,1,e,s,gg);
    var oPL=_gd('./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml',oOL,e_,d_);
    if(oPL){
      var oQL=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oPL(oQL,oQL,oNL,gg);
      gg.f=tgf;
    }else{
      _w(oOL,'./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml',0,0);
    }
    _ac(oML,oNL);var oRL=_ctn("view");_setAttr(z,oRL,'class',3,e,s,gg);var oSL=_ctn("view");_setAttr(z,oSL,'class',4,e,s,gg);var oTL=_ctn("view");_setAttr(z,oTL,'class',5,e,s,gg);var oUL=_ctn("view");_setAttr(z,oUL,'class',6,e,s,gg);var oVL=_ctn("view");_setAttr(z,oVL,'class',7,e,s,gg);var oWL=_ctn("view");_setAttr(z,oWL,'class',8,e,s,gg);var oXL=_o(z,9,e,s,gg);_ac(oWL,oXL);_ac(oVL,oWL);_ac(oUL,oVL);var oYL=_ctn("view");_setAttr(z,oYL,'class',10,e,s,gg);var oZL=_setAttrs(z,"input",["class",11,"disabled",1,"placeholder",2,"type",3,"value",4],e,s,gg);_ac(oYL,oZL);_ac(oUL,oYL);_ac(oTL,oUL);var oaL=_ctn("view");_setAttr(z,oaL,'class',6,e,s,gg);var obL=_ctn("view");_setAttr(z,obL,'class',7,e,s,gg);var ocL=_ctn("view");_setAttr(z,ocL,'class',8,e,s,gg);var odL=_o(z,16,e,s,gg);_ac(ocL,odL);_ac(obL,ocL);_ac(oaL,obL);var oeL=_ctn("view");_setAttr(z,oeL,'class',10,e,s,gg);var ofL=_setAttrs(z,"input",["class",11,"disabled",1,"placeholder",2,"type",3,"value",6],e,s,gg);_ac(oeL,ofL);_ac(oaL,oeL);_ac(oTL,oaL);var ogL=_ctn("view");_setAttr(z,ogL,'class',6,e,s,gg);var ohL=_ctn("view");_setAttr(z,ohL,'class',7,e,s,gg);var oiL=_ctn("view");_setAttr(z,oiL,'class',8,e,s,gg);var ojL=_o(z,18,e,s,gg);_ac(oiL,ojL);_ac(ohL,oiL);_ac(ogL,ohL);var okL=_ctn("view");_setAttr(z,okL,'class',10,e,s,gg);var olL=_setAttrs(z,"input",["class",11,"disabled",1,"placeholder",2,"type",3,"value",8],e,s,gg);_ac(okL,olL);_ac(ogL,okL);_ac(oTL,ogL);var omL=_ctn("view");_setAttr(z,omL,'class',6,e,s,gg);var onL=_ctn("view");_setAttr(z,onL,'class',7,e,s,gg);var ooL=_ctn("view");_setAttr(z,ooL,'class',8,e,s,gg);var opL=_o(z,20,e,s,gg);_ac(ooL,opL);_ac(onL,ooL);_ac(omL,onL);var oqL=_ctn("view");_setAttr(z,oqL,'class',10,e,s,gg);var orL=_setAttrs(z,"input",["class",11,"disabled",1,"placeholder",2,"type",3,"value",10],e,s,gg);_ac(oqL,orL);_ac(omL,oqL);_ac(oTL,omL);var osL=_ctn("view");_setAttr(z,osL,'class',6,e,s,gg);var otL=_ctn("view");_setAttr(z,otL,'class',7,e,s,gg);var ouL=_ctn("view");_setAttr(z,ouL,'class',8,e,s,gg);var ovL=_o(z,22,e,s,gg);_ac(ouL,ovL);_ac(otL,ouL);_ac(osL,otL);var owL=_ctn("view");_setAttr(z,owL,'class',10,e,s,gg);var oxL=_setAttrs(z,"input",["class",11,"disabled",1,"placeholder",2,"type",3,"value",12],e,s,gg);_ac(owL,oxL);_ac(osL,owL);_ac(oTL,osL);var oyL=_ctn("view");_setAttr(z,oyL,'class',6,e,s,gg);var ozL=_ctn("view");_setAttr(z,ozL,'class',7,e,s,gg);var o_L=_ctn("view");_setAttr(z,o_L,'class',8,e,s,gg);var oAM=_o(z,24,e,s,gg);_ac(o_L,oAM);_ac(ozL,o_L);_ac(oyL,ozL);var oBM=_ctn("view");_setAttr(z,oBM,'class',10,e,s,gg);var oCM=_setAttrs(z,"input",["class",11,"disabled",1,"placeholder",2,"type",3,"value",14],e,s,gg);_ac(oBM,oCM);_ac(oyL,oBM);_ac(oTL,oyL);_ac(oSL,oTL);var oDM=_ctn("view");_setAttr(z,oDM,'class',26,e,s,gg);var oEM=_setAttrs(z,"button",["bindtap",27,"type",1],e,s,gg);var oFM=_o(z,29,e,s,gg);_ac(oEM,oFM);_ac(oDM,oEM);_ac(oSL,oDM);_ac(oRL,oSL);_ac(oML,oRL);var oGM=_cvn();
    var oHM=_o(z,30,e,s,gg);
    var oIM=_gd('./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml',oHM,e_,d_);
    if(oIM){
      var oJM={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oIM(oJM,oJM,oGM,gg);
      gg.f=tgf;
    }else{
      _w(oHM,'./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml',0,0);
    }
    _ac(oML,oGM);_ac(r,oML);oJL.pop();oJL.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml"]={f:m20,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml"]={};
  var m21=function(e,s,r,gg){
    var z=gz$gma_22()
    var oKM=e_["./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml"].i;_ai(oKM,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml',0,0);_ai(oKM,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml',0,0);var oNM=_ctn("view");_setAttr(z,oNM,'class',0,e,s,gg);var oOM=_cvn();
    var oPM=_o(z,1,e,s,gg);
    var oQM=_gd('./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml',oPM,e_,d_);
    if(oQM){
      var oRM=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oQM(oRM,oRM,oOM,gg);
      gg.f=tgf;
    }else{
      _w(oPM,'./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml',0,0);
    }
    _ac(oNM,oOM);var oSM=_ctn("view");_setAttr(z,oSM,'class',3,e,s,gg);var oTM=_setAttrs(z,"button",["bindtap",4,"type",1],e,s,gg);var oUM=_o(z,6,e,s,gg);_ac(oTM,oUM);_ac(oSM,oTM);var oVM=_setAttrs(z,"button",["type",5,"bindtap",2],e,s,gg);var oWM=_o(z,8,e,s,gg);_ac(oVM,oWM);_ac(oSM,oVM);var oXM=_setAttrs(z,"button",["type",5,"bindtap",4],e,s,gg);var oYM=_o(z,10,e,s,gg);_ac(oXM,oYM);_ac(oSM,oXM);var oZM=_setAttrs(z,"button",["type",5,"bindtap",6],e,s,gg);var oaM=_o(z,12,e,s,gg);_ac(oZM,oaM);_ac(oSM,oZM);var obM=_ctn("view");_setAttr(z,obM,'class',13,e,s,gg);var ocM=_ctn("text");var odM=_o(z,14,e,s,gg);_ac(ocM,odM);_ac(obM,ocM);_ac(oSM,obM);_ac(oNM,oSM);var oeM=_cvn();
    var ofM=_o(z,15,e,s,gg);
    var ogM=_gd('./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml',ofM,e_,d_);
    if(ogM){
      var ohM={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ogM(ohM,ohM,oeM,gg);
      gg.f=tgf;
    }else{
      _w(ofM,'./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml',0,0);
    }
    _ac(oNM,oeM);_ac(r,oNM);oKM.pop();oKM.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml"]={f:m21,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml"]={};
  var m22=function(e,s,r,gg){
    var z=gz$gma_23()
    var oiM=e_["./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml"].i;_ai(oiM,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml',0,0);_ai(oiM,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml',0,0);var olM=_ctn("view");_setAttr(z,olM,'class',0,e,s,gg);var omM=_cvn();
    var onM=_o(z,1,e,s,gg);
    var ooM=_gd('./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml',onM,e_,d_);
    if(ooM){
      var opM=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ooM(opM,opM,omM,gg);
      gg.f=tgf;
    }else{
      _w(onM,'./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml',0,0);
    }
    _ac(olM,omM);var oqM=_ctn("view");_setAttr(z,oqM,'class',3,e,s,gg);var orM=_ctn("view");_setAttr(z,orM,'class',4,e,s,gg);var osM=_ctn("view");_setAttr(z,osM,'class',5,e,s,gg);var otM=_o(z,6,e,s,gg);_ac(osM,otM);_ac(orM,osM);var ouM=_ctn("view");_setAttr(z,ouM,'class',7,e,s,gg);var ovM=_ctn("view");_setAttr(z,ovM,'class',8,e,s,gg);var owM=_setAttrs(z,"input",["bindblur",9,"bindfocus",1,"class",2,"placeholder",3],e,s,gg);_ac(ovM,owM);_ac(ouM,ovM);_ac(orM,ouM);_ac(oqM,orM);_ac(olM,oqM);var oxM=_cvn();
    var oyM=_o(z,13,e,s,gg);
    var ozM=_gd('./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml',oyM,e_,d_);
    if(ozM){
      var o_M={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ozM(o_M,o_M,oxM,gg);
      gg.f=tgf;
    }else{
      _w(oyM,'./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml',0,0);
    }
    _ac(olM,oxM);_ac(r,olM);oiM.pop();oiM.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml"]={f:m22,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/loading/loading.maml"]={};
  var m23=function(e,s,r,gg){
    var z=gz$gma_24()
    var oAN=e_["./macle_demo_EN/page/API/pages/loading/loading.maml"].i;_ai(oAN,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/loading/loading.maml',0,0);_ai(oAN,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/loading/loading.maml',0,0);var oDN=_ctn("view");_setAttr(z,oDN,'class',0,e,s,gg);var oEN=_cvn();
    var oFN=_o(z,1,e,s,gg);
    var oGN=_gd('./macle_demo_EN/page/API/pages/loading/loading.maml',oFN,e_,d_);
    if(oGN){
      var oHN=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oGN(oHN,oHN,oEN,gg);
      gg.f=tgf;
    }else{
      _w(oFN,'./macle_demo_EN/page/API/pages/loading/loading.maml',0,0);
    }
    _ac(oDN,oEN);var oIN=_ctn("view");_setAttr(z,oIN,'class',3,e,s,gg);var oJN=_ctn("view");_setAttr(z,oJN,'class',4,e,s,gg);var oKN=_setAttrs(z,"button",["bindtap",5,"class",1,"type",2],e,s,gg);var oLN=_o(z,8,e,s,gg);_ac(oKN,oLN);_ac(oJN,oKN);var oMN=_ctn("view");_setAttr(z,oMN,'class',9,e,s,gg);var oNN=_ctn("view");_setAttr(z,oNN,'class',10,e,s,gg);var oON=_ctn("view");_setAttr(z,oON,'class',11,e,s,gg);var oPN=_o(z,12,e,s,gg);_ac(oON,oPN);_ac(oNN,oON);_ac(oMN,oNN);_ac(oJN,oMN);_ac(oIN,oJN);_ac(oDN,oIN);var oQN=_cvn();
    var oRN=_o(z,13,e,s,gg);
    var oSN=_gd('./macle_demo_EN/page/API/pages/loading/loading.maml',oRN,e_,d_);
    if(oSN){
      var oTN={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oSN(oTN,oTN,oQN,gg);
      gg.f=tgf;
    }else{
      _w(oRN,'./macle_demo_EN/page/API/pages/loading/loading.maml',0,0);
    }
    _ac(oDN,oQN);_ac(r,oDN);oAN.pop();oAN.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/loading/loading.maml"]={f:m23,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml"]={};
  var m24=function(e,s,r,gg){
    var z=gz$gma_25()
    var oUN=e_["./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml"].i;_ai(oUN,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml',0,0);_ai(oUN,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml',0,0);var oXN=_ctn("view");_setAttr(z,oXN,'class',0,e,s,gg);var oYN=_cvn();
    var oZN=_o(z,1,e,s,gg);
    var oaN=_gd('./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml',oZN,e_,d_);
    if(oaN){
      var obN=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oaN(obN,obN,oYN,gg);
      gg.f=tgf;
    }else{
      _w(oZN,'./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml',0,0);
    }
    _ac(oXN,oYN);var ocN=_ctn("view");_setAttr(z,ocN,'class',3,e,s,gg);var odN=_ctn("view");_setAttr(z,odN,'class',4,e,s,gg);var oeN=_ctn("view");_setAttr(z,oeN,'class',5,e,s,gg);var ofN=_o(z,6,e,s,gg);_ac(oeN,ofN);_ac(odN,oeN);var ogN=_setAttrs(z,"input",["bindinput",7,"id",1,"name",2,"type",3],e,s,gg);_ac(odN,ogN);var ohN=_ctn("view");_setAttr(z,ohN,'class',11,e,s,gg);var oiN=_setAttrs(z,"button",["bindtap",12,"class",0,"disabled",1,"type",2],e,s,gg);var ojN=_o(z,15,e,s,gg);_ac(oiN,ojN);_ac(ohN,oiN);var okN=_setAttrs(z,"button",["type",14,"bindtap",2,"class",2],e,s,gg);var olN=_o(z,17,e,s,gg);_ac(okN,olN);_ac(ohN,okN);_ac(odN,ohN);_ac(ocN,odN);_ac(oXN,ocN);var omN=_cvn();
    var onN=_o(z,18,e,s,gg);
    var ooN=_gd('./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml',onN,e_,d_);
    if(ooN){
      var opN={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ooN(opN,opN,omN,gg);
      gg.f=tgf;
    }else{
      _w(onN,'./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml',0,0);
    }
    _ac(oXN,omN);_ac(r,oXN);oUN.pop();oUN.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml"]={f:m24,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml"]={};
  var m25=function(e,s,r,gg){
    var z=gz$gma_26()
    var oqN=e_["./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml"].i;_ai(oqN,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml',0,0);_ai(oqN,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml',0,0);var otN=_ctn("view");_setAttr(z,otN,'class',0,e,s,gg);var ouN=_cvn();
    var ovN=_o(z,1,e,s,gg);
    var owN=_gd('./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml',ovN,e_,d_);
    if(owN){
      var oxN=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      owN(oxN,oxN,ouN,gg);
      gg.f=tgf;
    }else{
      _w(ovN,'./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml',0,0);
    }
    _ac(otN,ouN);var oyN=_ctn("view");_setAttr(z,oyN,'class',3,e,s,gg);var ozN=_ctn("form");var o_N=_ctn("view");_setAttr(z,o_N,'class',4,e,s,gg);var oAO=_ctn("view");_setAttr(z,oAO,'class',5,e,s,gg);var oBO=_ctn("view");_setAttr(z,oBO,'class',6,e,s,gg);var oCO=_ctn("view");_setAttr(z,oCO,'class',7,e,s,gg);var oDO=_ctn("view");_setAttr(z,oDO,'class',8,e,s,gg);var oEO=_o(z,9,e,s,gg);_ac(oDO,oEO);_ac(oCO,oDO);_ac(oBO,oCO);var oFO=_ctn("view");_setAttr(z,oFO,'class',10,e,s,gg);var oGO=_setAttrs(z,"picker",["bindchange",11,"mode",1,"range",2,"value",3],e,s,gg);var oHO=_ctn("view");_setAttr(z,oHO,'class',15,e,s,gg);var oIO=_o(z,16,e,s,gg);_ac(oHO,oIO);_ac(oGO,oHO);_ac(oFO,oGO);_ac(oBO,oFO);_ac(oAO,oBO);var oJO=_ctn("view");_setAttr(z,oJO,'class',6,e,s,gg);var oKO=_ctn("view");_setAttr(z,oKO,'class',7,e,s,gg);var oLO=_ctn("view");_setAttr(z,oLO,'class',8,e,s,gg);var oMO=_o(z,17,e,s,gg);_ac(oLO,oMO);_ac(oKO,oLO);_ac(oJO,oKO);var oNO=_ctn("view");_setAttr(z,oNO,'class',10,e,s,gg);var oOO=_setAttrs(z,"picker",["mode",12,"bindchange",6,"range",7,"value",8],e,s,gg);var oPO=_ctn("view");_setAttr(z,oPO,'class',15,e,s,gg);var oQO=_o(z,21,e,s,gg);_ac(oPO,oQO);_ac(oOO,oPO);_ac(oNO,oOO);_ac(oJO,oNO);_ac(oAO,oJO);var oRO=_ctn("view");_setAttr(z,oRO,'class',6,e,s,gg);var oSO=_ctn("view");_setAttr(z,oSO,'class',7,e,s,gg);var oTO=_ctn("view");_setAttr(z,oTO,'class',8,e,s,gg);var oUO=_o(z,22,e,s,gg);_ac(oTO,oUO);_ac(oSO,oTO);_ac(oRO,oSO);var oVO=_ctn("view");_setAttr(z,oVO,'class',10,e,s,gg);var oWO=_setAttrs(z,"picker",["mode",12,"bindchange",11,"range",12,"value",13],e,s,gg);var oXO=_ctn("view");_setAttr(z,oXO,'class',15,e,s,gg);var oYO=_o(z,26,e,s,gg);_ac(oXO,oYO);_ac(oWO,oXO);_ac(oVO,oWO);_ac(oRO,oVO);_ac(oAO,oRO);_ac(o_N,oAO);var oZO=_ctn("view");_setAttr(z,oZO,'class',27,e,s,gg);var oaO=_ctn("view");_setAttr(z,oaO,'class',28,e,s,gg);var obO=_ctn("view");_setAttr(z,obO,'class',10,e,s,gg);var ocO=_ctn("view");_setAttr(z,ocO,'class',29,e,s,gg);var odO=_ctn("view");_setAttr(z,odO,'class',30,e,s,gg);var oeO=_ctn("view");_setAttr(z,oeO,'class',31,e,s,gg);var ofO=_o(z,32,e,s,gg);_ac(oeO,ofO);_ac(odO,oeO);var ogO=_ctn("view");_setAttr(z,ogO,'class',33,e,s,gg);var ohO=_o(z,34,e,s,gg);_ac(ogO,ohO);_ac(odO,ogO);_ac(ocO,odO);var oiO=_ctn("view");_setAttr(z,oiO,'class',35,e,s,gg);var ojO=_ctn("view");_setAttr(z,ojO,'class',36,e,s,gg);var okO=_cvn();var olO=function(opO,ooO,onO,gg){var orO=_ctn("view");_setAttr(z,orO,'class',39,opO,ooO,gg);var osO=_setAttrs(z,"image",["bindtap",40,"class",1,"data-src",2,"src",2],opO,ooO,gg);_ac(orO,osO);_ac(onO,orO);return onO;};_2(z,37,olO,e,s,gg,okO,"image","index",'');_ac(ojO,okO);_ac(oiO,ojO);var otO=_ctn("view");_setAttr(z,otO,'class',43,e,s,gg);var ouO=_setAttrs(z,"view",["bindtap",44,"class",1],e,s,gg);_ac(otO,ouO);_ac(oiO,otO);_ac(ocO,oiO);_ac(obO,ocO);_ac(oaO,obO);_ac(oZO,oaO);_ac(o_N,oZO);var ovO=_ctn("view");var owO=_setAttrs(z,"button",["bindtap",46,"class",1],e,s,gg);var oxO=_o(z,48,e,s,gg);_ac(owO,oxO);_ac(ovO,owO);var oyO=_setAttrs(z,"button",["bindtap",49,"class",1],e,s,gg);var ozO=_o(z,51,e,s,gg);_ac(oyO,ozO);_ac(ovO,oyO);var o_O=_setAttrs(z,"button",["bindtap",52,"class",1],e,s,gg);var oAP=_o(z,54,e,s,gg);_ac(o_O,oAP);_ac(ovO,o_O);_ac(o_N,ovO);var oBP=_cvn();if(_o(z,55,e,s,gg)){oBP.maVkey=1;var oCP=_ctn("view");_setAttr(z,oCP,'class',56,e,s,gg);var oEP=_ctn("text");_setAttr(z,oEP,'class',57,e,s,gg);var oFP=_o(z,58,e,s,gg);_ac(oEP,oFP);_ac(oCP,oEP);_ac(oBP,oCP);} _ac(o_N,oBP);var oGP=_cvn();if(_o(z,59,e,s,gg)){oGP.maVkey=1;var oHP=_ctn("view");_setAttr(z,oHP,'class',56,e,s,gg);var oJP=_ctn("text");_setAttr(z,oJP,'space',60,e,s,gg);var oKP=_o(z,61,e,s,gg);_ac(oJP,oKP);_ac(oHP,oJP);_ac(oGP,oHP);} _ac(o_N,oGP);_ac(ozN,o_N);_ac(oyN,ozN);_ac(otN,oyN);var oLP=_cvn();
    var oMP=_o(z,62,e,s,gg);
    var oNP=_gd('./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml',oMP,e_,d_);
    if(oNP){
      var oOP={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oNP(oOP,oOP,oLP,gg);
      gg.f=tgf;
    }else{
      _w(oMP,'./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml',0,0);
    }
    _ac(otN,oLP);_ac(r,otN);oqN.pop();oqN.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml"]={f:m25,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml"]={};
  var m26=function(e,s,r,gg){
    var z=gz$gma_27()
    var oPP=e_["./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml"].i;_ai(oPP,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml',0,0);_ai(oPP,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml',0,0);var oSP=_ctn("view");_setAttr(z,oSP,'class',0,e,s,gg);var oTP=_cvn();
    var oUP=_o(z,1,e,s,gg);
    var oVP=_gd('./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml',oUP,e_,d_);
    if(oVP){
      var oWP=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oVP(oWP,oWP,oTP,gg);
      gg.f=tgf;
    }else{
      _w(oUP,'./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml',0,0);
    }
    _ac(oSP,oTP);var oXP=_ctn("view");_setAttr(z,oXP,'class',3,e,s,gg);var oYP=_setAttrs(z,"button",["bindtap",4,"type",1],e,s,gg);var oZP=_o(z,6,e,s,gg);_ac(oYP,oZP);_ac(oXP,oYP);var oaP=_setAttrs(z,"button",["type",5,"bindtap",2],e,s,gg);var obP=_o(z,8,e,s,gg);_ac(oaP,obP);_ac(oXP,oaP);var ocP=_setAttrs(z,"button",["type",5,"bindtap",4],e,s,gg);var odP=_o(z,9,e,s,gg);_ac(ocP,odP);_ac(oXP,ocP);var oeP=_setAttrs(z,"button",["type",5,"bindtap",5],e,s,gg);var ofP=_o(z,11,e,s,gg);_ac(oeP,ofP);_ac(oXP,oeP);_ac(oSP,oXP);var ogP=_ctn("view");_setAttr(z,ogP,'class',12,e,s,gg);var ohP=_ctn("text");var oiP=_o(z,13,e,s,gg);_ac(ohP,oiP);_ac(ogP,ohP);_ac(oSP,ogP);var ojP=_cvn();
    var okP=_o(z,14,e,s,gg);
    var olP=_gd('./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml',okP,e_,d_);
    if(olP){
      var omP={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      olP(omP,omP,ojP,gg);
      gg.f=tgf;
    }else{
      _w(okP,'./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml',0,0);
    }
    _ac(oSP,ojP);_ac(r,oSP);oPP.pop();oPP.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml"]={f:m26,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/modal/modal.maml"]={};
  var m27=function(e,s,r,gg){
    var z=gz$gma_28()
    var onP=e_["./macle_demo_EN/page/API/pages/modal/modal.maml"].i;_ai(onP,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/modal/modal.maml',0,0);_ai(onP,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/modal/modal.maml',0,0);var oqP=_ctn("view");_setAttr(z,oqP,'class',0,e,s,gg);var orP=_cvn();
    var osP=_o(z,1,e,s,gg);
    var otP=_gd('./macle_demo_EN/page/API/pages/modal/modal.maml',osP,e_,d_);
    if(otP){
      var ouP=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      otP(ouP,ouP,orP,gg);
      gg.f=tgf;
    }else{
      _w(osP,'./macle_demo_EN/page/API/pages/modal/modal.maml',0,0);
    }
    _ac(oqP,orP);var ovP=_ctn("view");_setAttr(z,ovP,'class',3,e,s,gg);var owP=_ctn("view");_setAttr(z,owP,'class',4,e,s,gg);var oxP=_setAttrs(z,"button",["bindtap",5,"class",1,"type",2],e,s,gg);var oyP=_o(z,8,e,s,gg);_ac(oxP,oyP);_ac(owP,oxP);var ozP=_setAttrs(z,"button",["type",7,"bindtap",2,"class",2],e,s,gg);var o_P=_o(z,10,e,s,gg);_ac(ozP,o_P);_ac(owP,ozP);var oAQ=_setAttrs(z,"button",["type",7,"bindtap",4,"class",4],e,s,gg);var oBQ=_o(z,12,e,s,gg);_ac(oAQ,oBQ);_ac(owP,oAQ);_ac(ovP,owP);var oCQ=_cvn();if(_o(z,13,e,s,gg)){oCQ.maVkey=1;var oDQ=_ctn("view");_setAttr(z,oDQ,'class',14,e,s,gg);var oFQ=_ctn("text");_setAttr(z,oFQ,'class',14,e,s,gg);var oGQ=_o(z,15,e,s,gg);_ac(oFQ,oGQ);_ac(oDQ,oFQ);_ac(oCQ,oDQ);} _ac(ovP,oCQ);_ac(oqP,ovP);var oHQ=_cvn();
    var oIQ=_o(z,16,e,s,gg);
    var oJQ=_gd('./macle_demo_EN/page/API/pages/modal/modal.maml',oIQ,e_,d_);
    if(oJQ){
      var oKQ={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oJQ(oKQ,oKQ,oHQ,gg);
      gg.f=tgf;
    }else{
      _w(oIQ,'./macle_demo_EN/page/API/pages/modal/modal.maml',0,0);
    }
    _ac(oqP,oHQ);_ac(r,oqP);onP.pop();onP.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/modal/modal.maml"]={f:m27,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/navigator/navigate.maml"]={};
  var m28=function(e,s,r,gg){
    var z=gz$gma_29()
    var oLQ=e_["./macle_demo_EN/page/API/pages/navigator/navigate.maml"].i;_ai(oLQ,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/navigator/navigate.maml',0,0);_ai(oLQ,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/navigator/navigate.maml',0,0);var oOQ=_ctn("view");_setAttr(z,oOQ,'class',0,e,s,gg);var oPQ=_cvn();
    var oQQ=_o(z,1,e,s,gg);
    var oRQ=_gd('./macle_demo_EN/page/API/pages/navigator/navigate.maml',oQQ,e_,d_);
    if(oRQ){
      var oSQ=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oRQ(oSQ,oSQ,oPQ,gg);
      gg.f=tgf;
    }else{
      _w(oQQ,'./macle_demo_EN/page/API/pages/navigator/navigate.maml',0,0);
    }
    _ac(oOQ,oPQ);var oTQ=_ctn("view");_setAttr(z,oTQ,'class',3,e,s,gg);var oUQ=_ctn("view");_setAttr(z,oUQ,'class',4,e,s,gg);var oVQ=_ctn("text");_setAttr(z,oVQ,'class',5,e,s,gg);var oWQ=_o(z,6,e,s,gg);_ac(oVQ,oWQ);_ac(oUQ,oVQ);var oXQ=_setAttrs(z,"button",["bindtap",7,"class",1,"type",2],e,s,gg);var oYQ=_o(z,7,e,s,gg);_ac(oXQ,oYQ);_ac(oUQ,oXQ);var oZQ=_setAttrs(z,"navigator",["hoverClass",10,"openType",1],e,s,gg);var oaQ=_setAttrs(z,"button",["class",12,"type",1],e,s,gg);var obQ=_o(z,14,e,s,gg);_ac(oaQ,obQ);_ac(oZQ,oaQ);_ac(oUQ,oZQ);_ac(oTQ,oUQ);_ac(oOQ,oTQ);_ac(r,oOQ);oLQ.pop();oLQ.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/navigator/navigate.maml"]={f:m28,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/navigator/navigator.maml"]={};
  var m29=function(e,s,r,gg){
    var z=gz$gma_30()
    var ocQ=e_["./macle_demo_EN/page/API/pages/navigator/navigator.maml"].i;_ai(ocQ,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/navigator/navigator.maml',0,0);_ai(ocQ,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/navigator/navigator.maml',0,0);var ofQ=_ctn("view");_setAttr(z,ofQ,'class',0,e,s,gg);var ogQ=_cvn();
    var ohQ=_o(z,1,e,s,gg);
    var oiQ=_gd('./macle_demo_EN/page/API/pages/navigator/navigator.maml',ohQ,e_,d_);
    if(oiQ){
      var ojQ=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oiQ(ojQ,ojQ,ogQ,gg);
      gg.f=tgf;
    }else{
      _w(ohQ,'./macle_demo_EN/page/API/pages/navigator/navigator.maml',0,0);
    }
    _ac(ofQ,ogQ);var okQ=_ctn("view");_setAttr(z,okQ,'class',3,e,s,gg);var olQ=_ctn("view");_setAttr(z,olQ,'class',4,e,s,gg);var omQ=_ctn("view");_setAttr(z,omQ,'class',5,e,s,gg);var onQ=_ctn("view");var ooQ=_o(z,6,e,s,gg);_ac(onQ,ooQ);_ac(omQ,onQ);var opQ=_setAttrs(z,"button",["bindtap",7,"class",0,"type",1],e,s,gg);var oqQ=_o(z,7,e,s,gg);_ac(opQ,oqQ);_ac(omQ,opQ);_ac(olQ,omQ);var orQ=_ctn("view");_setAttr(z,orQ,'class',5,e,s,gg);var osQ=_ctn("view");var otQ=_o(z,9,e,s,gg);_ac(osQ,otQ);_ac(orQ,osQ);var ouQ=_setAttrs(z,"button",["type",8,"bindtap",2,"class",2],e,s,gg);var ovQ=_o(z,10,e,s,gg);_ac(ouQ,ovQ);_ac(orQ,ouQ);_ac(olQ,orQ);var owQ=_ctn("view");_setAttr(z,owQ,'class',5,e,s,gg);var oxQ=_ctn("view");var oyQ=_o(z,11,e,s,gg);_ac(oxQ,oyQ);_ac(owQ,oxQ);var ozQ=_setAttrs(z,"button",["type",8,"bindtap",4,"class",4],e,s,gg);var o_Q=_o(z,12,e,s,gg);_ac(ozQ,o_Q);_ac(owQ,ozQ);_ac(olQ,owQ);var oAR=_ctn("view");_setAttr(z,oAR,'class',5,e,s,gg);var oBR=_ctn("view");var oCR=_o(z,13,e,s,gg);_ac(oBR,oCR);_ac(oAR,oBR);var oDR=_setAttrs(z,"button",["type",8,"bindtap",6,"class",6],e,s,gg);var oER=_o(z,14,e,s,gg);_ac(oDR,oER);_ac(oAR,oDR);_ac(olQ,oAR);var oFR=_ctn("view");_setAttr(z,oFR,'class',5,e,s,gg);var oGR=_ctn("view");var oHR=_o(z,15,e,s,gg);_ac(oGR,oHR);_ac(oFR,oGR);var oIR=_setAttrs(z,"button",["type",8,"bindtap",8,"class",8],e,s,gg);var oJR=_o(z,16,e,s,gg);_ac(oIR,oJR);_ac(oFR,oIR);_ac(olQ,oFR);_ac(okQ,olQ);_ac(ofQ,okQ);var oKR=_cvn();
    var oLR=_o(z,17,e,s,gg);
    var oMR=_gd('./macle_demo_EN/page/API/pages/navigator/navigator.maml',oLR,e_,d_);
    if(oMR){
      var oNR={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oMR(oNR,oNR,oKR,gg);
      gg.f=tgf;
    }else{
      _w(oLR,'./macle_demo_EN/page/API/pages/navigator/navigator.maml',0,0);
    }
    _ac(ofQ,oKR);_ac(r,ofQ);ocQ.pop();ocQ.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/navigator/navigator.maml"]={f:m29,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/navigator/redirect.maml"]={};
  var m30=function(e,s,r,gg){
    var z=gz$gma_31()
    var oOR=e_["./macle_demo_EN/page/API/pages/navigator/redirect.maml"].i;_ai(oOR,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/navigator/redirect.maml',0,0);_ai(oOR,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/navigator/redirect.maml',0,0);var oRR=_ctn("view");_setAttr(z,oRR,'class',0,e,s,gg);var oSR=_cvn();
    var oTR=_o(z,1,e,s,gg);
    var oUR=_gd('./macle_demo_EN/page/API/pages/navigator/redirect.maml',oTR,e_,d_);
    if(oUR){
      var oVR=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oUR(oVR,oVR,oSR,gg);
      gg.f=tgf;
    }else{
      _w(oTR,'./macle_demo_EN/page/API/pages/navigator/redirect.maml',0,0);
    }
    _ac(oRR,oSR);var oWR=_ctn("view");_setAttr(z,oWR,'class',3,e,s,gg);var oXR=_o(z,4,e,s,gg);_ac(oWR,oXR);_ac(oRR,oWR);var oYR=_cvn();
    var oZR=_o(z,5,e,s,gg);
    var oaR=_gd('./macle_demo_EN/page/API/pages/navigator/redirect.maml',oZR,e_,d_);
    if(oaR){
      var obR={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oaR(obR,obR,oYR,gg);
      gg.f=tgf;
    }else{
      _w(oZR,'./macle_demo_EN/page/API/pages/navigator/redirect.maml',0,0);
    }
    _ac(oRR,oYR);_ac(r,oRR);oOR.pop();oOR.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/navigator/redirect.maml"]={f:m30,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/network/network.maml"]={};
  var m31=function(e,s,r,gg){
    var z=gz$gma_32()
    var ocR=e_["./macle_demo_EN/page/API/pages/network/network.maml"].i;_ai(ocR,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/network/network.maml',0,0);_ai(ocR,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/network/network.maml',0,0);var ofR=_ctn("view");_setAttr(z,ofR,'class',0,e,s,gg);var ogR=_cvn();
    var ohR=_o(z,1,e,s,gg);
    var oiR=_gd('./macle_demo_EN/page/API/pages/network/network.maml',ohR,e_,d_);
    if(oiR){
      var ojR=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oiR(ojR,ojR,ogR,gg);
      gg.f=tgf;
    }else{
      _w(ohR,'./macle_demo_EN/page/API/pages/network/network.maml',0,0);
    }
    _ac(ofR,ogR);var okR=_ctn("view");_setAttr(z,okR,'class',3,e,s,gg);var olR=_setAttrs(z,"button",["bindtap",4,"type",1],e,s,gg);var omR=_o(z,6,e,s,gg);_ac(olR,omR);_ac(okR,olR);var onR=_setAttrs(z,"button",["type",5,"bindtap",2],e,s,gg);var ooR=_o(z,8,e,s,gg);_ac(onR,ooR);_ac(okR,onR);_ac(ofR,okR);var opR=_ctn("view");_setAttr(z,opR,'class',9,e,s,gg);var oqR=_ctn("text");var orR=_o(z,10,e,s,gg);_ac(oqR,orR);_ac(opR,oqR);_ac(ofR,opR);var osR=_cvn();
    var otR=_o(z,11,e,s,gg);
    var ouR=_gd('./macle_demo_EN/page/API/pages/network/network.maml',otR,e_,d_);
    if(ouR){
      var ovR={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ouR(ovR,ovR,osR,gg);
      gg.f=tgf;
    }else{
      _w(otR,'./macle_demo_EN/page/API/pages/network/network.maml',0,0);
    }
    _ac(ofR,osR);_ac(r,ofR);ocR.pop();ocR.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/network/network.maml"]={f:m31,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/open-document/open-document.maml"]={};
  var m32=function(e,s,r,gg){
    var z=gz$gma_33()
    var owR=e_["./macle_demo_EN/page/API/pages/open-document/open-document.maml"].i;_ai(owR,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/open-document/open-document.maml',0,0);_ai(owR,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/open-document/open-document.maml',0,0);var ozR=_ctn("view");_setAttr(z,ozR,'class',0,e,s,gg);var o_R=_cvn();
    var oAS=_o(z,1,e,s,gg);
    var oBS=_gd('./macle_demo_EN/page/API/pages/open-document/open-document.maml',oAS,e_,d_);
    if(oBS){
      var oCS=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oBS(oCS,oCS,o_R,gg);
      gg.f=tgf;
    }else{
      _w(oAS,'./macle_demo_EN/page/API/pages/open-document/open-document.maml',0,0);
    }
    _ac(ozR,o_R);var oDS=_ctn("view");_setAttr(z,oDS,'class',3,e,s,gg);var oES=_ctn("view");_setAttr(z,oES,'class',4,e,s,gg);var oFS=_setAttrs(z,"button",["bindtap",5,"type",1],e,s,gg);var oGS=_o(z,7,e,s,gg);_ac(oFS,oGS);_ac(oES,oFS);_ac(oDS,oES);var oHS=_ctn("view");_setAttr(z,oHS,'class',8,e,s,gg);var oIS=_ctn("text");var oJS=_o(z,9,e,s,gg);_ac(oIS,oJS);_ac(oHS,oIS);var oKS=_setAttrs(z,"switch",["bindchange",10,"checked",1],e,s,gg);_ac(oHS,oKS);_ac(oDS,oHS);_ac(ozR,oDS);var oLS=_cvn();
    var oMS=_o(z,12,e,s,gg);
    var oNS=_gd('./macle_demo_EN/page/API/pages/open-document/open-document.maml',oMS,e_,d_);
    if(oNS){
      var oOS={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oNS(oOS,oOS,oLS,gg);
      gg.f=tgf;
    }else{
      _w(oMS,'./macle_demo_EN/page/API/pages/open-document/open-document.maml',0,0);
    }
    _ac(ozR,oLS);_ac(r,ozR);owR.pop();owR.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/open-document/open-document.maml"]={f:m32,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml"]={};
  var m33=function(e,s,r,gg){
    var z=gz$gma_34()
    var oPS=e_["./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml"].i;_ai(oPS,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml',0,0);_ai(oPS,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml',0,0);var oSS=_ctn("view");_setAttr(z,oSS,'class',0,e,s,gg);var oTS=_cvn();
    var oUS=_o(z,1,e,s,gg);
    var oVS=_gd('./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml',oUS,e_,d_);
    if(oVS){
      var oWS=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oVS(oWS,oWS,oTS,gg);
      gg.f=tgf;
    }else{
      _w(oUS,'./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml',0,0);
    }
    _ac(oSS,oTS);var oXS=_ctn("view");_setAttr(z,oXS,'class',3,e,s,gg);var oYS=_ctn("view");_setAttr(z,oYS,'class',4,e,s,gg);var oZS=_setAttrs(z,"button",["bindtap",5,"class",0],e,s,gg);var oaS=_o(z,6,e,s,gg);_ac(oZS,oaS);_ac(oYS,oZS);var obS=_setAttrs(z,"button",["bindtap",7,"class",0],e,s,gg);var ocS=_o(z,8,e,s,gg);_ac(obS,ocS);_ac(oYS,obS);_ac(oXS,oYS);_ac(oSS,oXS);var odS=_cvn();
    var oeS=_o(z,9,e,s,gg);
    var ofS=_gd('./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml',oeS,e_,d_);
    if(ofS){
      var ogS={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ofS(ogS,ogS,odS,gg);
      gg.f=tgf;
    }else{
      _w(oeS,'./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml',0,0);
    }
    _ac(oSS,odS);_ac(r,oSS);oPS.pop();oPS.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml"]={f:m33,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/request/request.maml"]={};
  var m34=function(e,s,r,gg){
    var z=gz$gma_35()
    var ohS=e_["./macle_demo_EN/page/API/pages/request/request.maml"].i;_ai(ohS,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/request/request.maml',0,0);_ai(ohS,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/request/request.maml',0,0);var okS=_ctn("view");_setAttr(z,okS,'class',0,e,s,gg);var olS=_cvn();
    var omS=_o(z,1,e,s,gg);
    var onS=_gd('./macle_demo_EN/page/API/pages/request/request.maml',omS,e_,d_);
    if(onS){
      var ooS=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      onS(ooS,ooS,olS,gg);
      gg.f=tgf;
    }else{
      _w(omS,'./macle_demo_EN/page/API/pages/request/request.maml',0,0);
    }
    _ac(okS,olS);var opS=_ctn("view");_setAttr(z,opS,'class',3,e,s,gg);var oqS=_ctn("view");_setAttr(z,oqS,'class',4,e,s,gg);var orS=_ctn("text");_setAttr(z,orS,'class',5,e,s,gg);var osS=_o(z,6,e,s,gg);_ac(orS,osS);_ac(oqS,orS);_ac(opS,oqS);var otS=_ctn("view");_setAttr(z,otS,'class',7,e,s,gg);var ouS=_setAttrs(z,"button",["bindtap",8,"class",1,"disabled",2,"loading",3,"type",4],e,s,gg);var ovS=_o(z,13,e,s,gg);_ac(ouS,ovS);_ac(otS,ouS);var owS=_setAttrs(z,"button",["type",12,"bindtap",2,"class",3,"disabled",4,"loading",5],e,s,gg);var oxS=_o(z,18,e,s,gg);_ac(owS,oxS);_ac(otS,owS);_ac(opS,otS);_ac(okS,opS);var oyS=_cvn();
    var ozS=_o(z,19,e,s,gg);
    var o_S=_gd('./macle_demo_EN/page/API/pages/request/request.maml',ozS,e_,d_);
    if(o_S){
      var oAT={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      o_S(oAT,oAT,oyS,gg);
      gg.f=tgf;
    }else{
      _w(ozS,'./macle_demo_EN/page/API/pages/request/request.maml',0,0);
    }
    _ac(okS,oyS);_ac(r,okS);ohS.pop();ohS.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/request/request.maml"]={f:m34,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/scanCode/scanCode.maml"]={};
  var m35=function(e,s,r,gg){
    var z=gz$gma_36()
    var oBT=e_["./macle_demo_EN/page/API/pages/scanCode/scanCode.maml"].i;_ai(oBT,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/scanCode/scanCode.maml',0,0);_ai(oBT,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/scanCode/scanCode.maml',0,0);var oET=_ctn("view");_setAttr(z,oET,'class',0,e,s,gg);var oFT=_cvn();
    var oGT=_o(z,1,e,s,gg);
    var oHT=_gd('./macle_demo_EN/page/API/pages/scanCode/scanCode.maml',oGT,e_,d_);
    if(oHT){
      var oIT=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oHT(oIT,oIT,oFT,gg);
      gg.f=tgf;
    }else{
      _w(oGT,'./macle_demo_EN/page/API/pages/scanCode/scanCode.maml',0,0);
    }
    _ac(oET,oFT);var oJT=_ctn("view");_setAttr(z,oJT,'class',3,e,s,gg);var oKT=_ctn("view");_setAttr(z,oKT,'class',4,e,s,gg);var oLT=_o(z,5,e,s,gg);_ac(oKT,oLT);_ac(oJT,oKT);var oMT=_ctn("view");_setAttr(z,oMT,'class',6,e,s,gg);var oNT=_ctn("view");_setAttr(z,oNT,'class',7,e,s,gg);var oOT=_ctn("view");_setAttr(z,oOT,'class',8,e,s,gg);var oPT=_o(z,9,e,s,gg);_ac(oOT,oPT);_ac(oNT,oOT);_ac(oMT,oNT);var oQT=_ctn("view");_setAttr(z,oQT,'class',7,e,s,gg);var oRT=_ctn("view");_setAttr(z,oRT,'class',10,e,s,gg);var oST=_o(z,11,e,s,gg);_ac(oRT,oST);_ac(oQT,oRT);_ac(oMT,oQT);_ac(oJT,oMT);var oTT=_ctn("view");_setAttr(z,oTT,'class',12,e,s,gg);var oUT=_setAttrs(z,"button",["bindtap",13,"type",1],e,s,gg);var oVT=_o(z,15,e,s,gg);_ac(oUT,oVT);_ac(oTT,oUT);_ac(oJT,oTT);_ac(oET,oJT);var oWT=_cvn();
    var oXT=_o(z,16,e,s,gg);
    var oYT=_gd('./macle_demo_EN/page/API/pages/scanCode/scanCode.maml',oXT,e_,d_);
    if(oYT){
      var oZT={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oYT(oZT,oZT,oWT,gg);
      gg.f=tgf;
    }else{
      _w(oXT,'./macle_demo_EN/page/API/pages/scanCode/scanCode.maml',0,0);
    }
    _ac(oET,oWT);_ac(r,oET);oBT.pop();oBT.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/scanCode/scanCode.maml"]={f:m35,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml"]={};
  var m36=function(e,s,r,gg){
    var z=gz$gma_37()
    var oaT=e_["./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml"].i;_ai(oaT,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml',0,0);_ai(oaT,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml',0,0);var odT=_ctn("view");_setAttr(z,odT,'class',0,e,s,gg);var oeT=_cvn();
    var ofT=_o(z,1,e,s,gg);
    var ogT=_gd('./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml',ofT,e_,d_);
    if(ogT){
      var ohT=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ogT(ohT,ohT,oeT,gg);
      gg.f=tgf;
    }else{
      _w(ofT,'./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml',0,0);
    }
    _ac(odT,oeT);var oiT=_ctn("view");_setAttr(z,oiT,'class',3,e,s,gg);var ojT=_ctn("view");_setAttr(z,ojT,'class',4,e,s,gg);var okT=_ctn("view");_setAttr(z,okT,'class',5,e,s,gg);var olT=_o(z,6,e,s,gg);_ac(okT,olT);_ac(ojT,okT);var omT=_ctn("text");_setAttr(z,omT,'class',7,e,s,gg);var onT=_o(z,8,e,s,gg);_ac(omT,onT);_ac(ojT,omT);_ac(oiT,ojT);var ooT=_ctn("view");_setAttr(z,ooT,'class',9,e,s,gg);var opT=_ctn("view");_setAttr(z,opT,'class',10,e,s,gg);var oqT=_o(z,11,e,s,gg);_ac(opT,oqT);_ac(ooT,opT);var orT=_ctn("view");_setAttr(z,orT,'class',12,e,s,gg);var osT=_setAttrs(z,"slider",["bindchange",13,"class",1,"max",2,"min",3,"step",4,"value",5],e,s,gg);_ac(orT,osT);_ac(ooT,orT);_ac(oiT,ooT);var otT=_setAttrs(z,"button",["bindtap",19,"class",1,"type",2],e,s,gg);var ouT=_o(z,22,e,s,gg);_ac(otT,ouT);_ac(oiT,otT);_ac(odT,oiT);var ovT=_cvn();
    var owT=_o(z,23,e,s,gg);
    var oxT=_gd('./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml',owT,e_,d_);
    if(oxT){
      var oyT={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oxT(oyT,oyT,ovT,gg);
      gg.f=tgf;
    }else{
      _w(owT,'./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml',0,0);
    }
    _ac(odT,ovT);_ac(r,odT);oaT.pop();oaT.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml"]={f:m36,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/set-background/set-background.maml"]={};
  var m37=function(e,s,r,gg){
    var z=gz$gma_38()
    var ozT=e_["./macle_demo_EN/page/API/pages/set-background/set-background.maml"].i;_ai(ozT,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/set-background/set-background.maml',0,0);_ai(ozT,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/set-background/set-background.maml',0,0);var oBU=_ctn("view");_setAttr(z,oBU,'class',0,e,s,gg);var oCU=_cvn();
    var oDU=_o(z,1,e,s,gg);
    var oEU=_gd('./macle_demo_EN/page/API/pages/set-background/set-background.maml',oDU,e_,d_);
    if(oEU){
      var oFU=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oEU(oFU,oFU,oCU,gg);
      gg.f=tgf;
    }else{
      _w(oDU,'./macle_demo_EN/page/API/pages/set-background/set-background.maml',0,0);
    }
    _ac(oBU,oCU);var oGU=_ctn("view");_setAttr(z,oGU,'class',3,e,s,gg);var oHU=_ctn("view");_setAttr(z,oHU,'class',4,e,s,gg);var oIU=_ctn("view");_setAttr(z,oIU,'class',5,e,s,gg);var oJU=_ctn("view");_setAttr(z,oJU,'class',6,e,s,gg);var oKU=_ctn("view");_setAttr(z,oKU,'class',7,e,s,gg);var oLU=_ctn("view");_setAttr(z,oLU,'class',8,e,s,gg);var oMU=_o(z,9,e,s,gg);_ac(oLU,oMU);_ac(oKU,oLU);_ac(oJU,oKU);var oNU=_ctn("view");_setAttr(z,oNU,'class',10,e,s,gg);var oOU=_setAttrs(z,"input",["bindinput",11,"class",1,"id",2,"name",2,"placeholder",3,"type",4,"value",5],e,s,gg);_ac(oNU,oOU);_ac(oJU,oNU);_ac(oIU,oJU);var oPU=_ctn("view");_setAttr(z,oPU,'class',6,e,s,gg);var oQU=_ctn("view");_setAttr(z,oQU,'class',7,e,s,gg);var oRU=_ctn("view");_setAttr(z,oRU,'class',8,e,s,gg);var oSU=_o(z,17,e,s,gg);_ac(oRU,oSU);_ac(oQU,oRU);_ac(oPU,oQU);var oTU=_ctn("view");_setAttr(z,oTU,'class',10,e,s,gg);var oUU=_setAttrs(z,"input",["class",12,"type",3,"bindinput",6,"id",7,"name",7,"placeholder",8,"value",9],e,s,gg);_ac(oTU,oUU);_ac(oPU,oTU);_ac(oIU,oPU);_ac(oHU,oIU);var oVU=_ctn("view");_setAttr(z,oVU,'class',22,e,s,gg);var oWU=_setAttrs(z,"button",["bindtap",23,"class",0],e,s,gg);var oXU=_o(z,24,e,s,gg);_ac(oWU,oXU);_ac(oVU,oWU);var oYU=_setAttrs(z,"button",["bindtap",25,"class",0],e,s,gg);var oZU=_o(z,26,e,s,gg);_ac(oYU,oZU);_ac(oVU,oYU);var oaU=_setAttrs(z,"button",["bindtap",27,"class",1,"type",2],e,s,gg);var obU=_o(z,30,e,s,gg);_ac(oaU,obU);_ac(oVU,oaU);_ac(oHU,oVU);var ocU=_ctn("view");_setAttr(z,ocU,'class',31,e,s,gg);var odU=_setAttrs(z,"view",["class",32,"style",1],e,s,gg);var oeU=_o(z,34,e,s,gg);_ac(odU,oeU);_ac(ocU,odU);_ac(oHU,ocU);_ac(oGU,oHU);_ac(oBU,oGU);var ofU=_cvn();
    var ogU=_o(z,35,e,s,gg);
    var ohU=_gd('./macle_demo_EN/page/API/pages/set-background/set-background.maml',ogU,e_,d_);
    if(ohU){
      var oiU={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ohU(oiU,oiU,ofU,gg);
      gg.f=tgf;
    }else{
      _w(ogU,'./macle_demo_EN/page/API/pages/set-background/set-background.maml',0,0);
    }
    _ac(oBU,ofU);_ac(r,oBU);ozT.pop();ozT.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/set-background/set-background.maml"]={f:m37,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml"]={};
  var m38=function(e,s,r,gg){
    var z=gz$gma_39()
    var ojU=e_["./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml"].i;_ai(ojU,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml',0,0);_ai(ojU,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml',0,0);var omU=_ctn("view");_setAttr(z,omU,'class',0,e,s,gg);var onU=_cvn();
    var ooU=_o(z,1,e,s,gg);
    var opU=_gd('./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml',ooU,e_,d_);
    if(opU){
      var oqU=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      opU(oqU,oqU,onU,gg);
      gg.f=tgf;
    }else{
      _w(ooU,'./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml',0,0);
    }
    _ac(omU,onU);var orU=_setAttrs(z,"form",["bindsubmit",3,"class",1],e,s,gg);var osU=_ctn("view");_setAttr(z,osU,'class',5,e,s,gg);var otU=_ctn("view");_setAttr(z,otU,'class',6,e,s,gg);var ouU=_ctn("view");_setAttr(z,ouU,'class',7,e,s,gg);var ovU=_ctn("view");_setAttr(z,ovU,'class',8,e,s,gg);var owU=_o(z,9,e,s,gg);_ac(ovU,owU);_ac(ouU,ovU);_ac(otU,ouU);var oxU=_ctn("view");_setAttr(z,oxU,'class',10,e,s,gg);var oyU=_setAttrs(z,"input",["bindinput",11,"class",1,"id",2,"name",2,"placeholder",3,"type",4,"value",5],e,s,gg);_ac(oxU,oyU);_ac(otU,oxU);_ac(osU,otU);var ozU=_ctn("view");_setAttr(z,ozU,'class',6,e,s,gg);var o_U=_ctn("view");_setAttr(z,o_U,'class',7,e,s,gg);var oAV=_ctn("view");_setAttr(z,oAV,'class',8,e,s,gg);var oBV=_o(z,17,e,s,gg);_ac(oAV,oBV);_ac(o_U,oAV);_ac(ozU,o_U);var oCV=_ctn("view");_setAttr(z,oCV,'class',10,e,s,gg);var oDV=_setAttrs(z,"input",["class",12,"placeholder",2,"type",3,"bindinput",6,"id",7,"name",7,"value",8],e,s,gg);_ac(oCV,oDV);_ac(ozU,oCV);_ac(osU,ozU);_ac(orU,osU);var oEV=_ctn("view");_setAttr(z,oEV,'class',21,e,s,gg);var oFV=_setAttrs(z,"button",["class",3,"formType",19,"type",20],e,s,gg);var oGV=_o(z,24,e,s,gg);_ac(oFV,oGV);_ac(oEV,oFV);_ac(orU,oEV);_ac(omU,orU);var oHV=_ctn("view");_setAttr(z,oHV,'class',25,e,s,gg);var oIV=_setAttrs(z,"view",["class",26,"style",1],e,s,gg);var oJV=_o(z,28,e,s,gg);_ac(oIV,oJV);_ac(oHV,oIV);_ac(omU,oHV);var oKV=_cvn();
    var oLV=_o(z,29,e,s,gg);
    var oMV=_gd('./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml',oLV,e_,d_);
    if(oMV){
      var oNV={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oMV(oNV,oNV,oKV,gg);
      gg.f=tgf;
    }else{
      _w(oLV,'./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml',0,0);
    }
    _ac(omU,oKV);_ac(r,omU);ojU.pop();ojU.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml"]={f:m38,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml"]={};
  var m39=function(e,s,r,gg){
    var z=gz$gma_40()
    var oOV=e_["./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml"].i;_ai(oOV,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml',0,0);_ai(oOV,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml',0,0);var oRV=_ctn("view");_setAttr(z,oRV,'class',0,e,s,gg);var oSV=_cvn();
    var oTV=_o(z,1,e,s,gg);
    var oUV=_gd('./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml',oTV,e_,d_);
    if(oUV){
      var oVV=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oUV(oVV,oVV,oSV,gg);
      gg.f=tgf;
    }else{
      _w(oTV,'./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml',0,0);
    }
    _ac(oRV,oSV);var oWV=_setAttrs(z,"form",["bindsubmit",3,"class",1],e,s,gg);var oXV=_ctn("view");_setAttr(z,oXV,'class',5,e,s,gg);var oYV=_ctn("view");_setAttr(z,oYV,'class',6,e,s,gg);var oZV=_ctn("view");_setAttr(z,oZV,'class',7,e,s,gg);var oaV=_ctn("view");_setAttr(z,oaV,'class',8,e,s,gg);var obV=_o(z,9,e,s,gg);_ac(oaV,obV);_ac(oZV,oaV);_ac(oYV,oZV);var ocV=_ctn("view");_setAttr(z,ocV,'class',10,e,s,gg);var odV=_setAttrs(z,"input",["id",3,"class",8,"name",9,"placeholder",10,"type",11],e,s,gg);_ac(ocV,odV);_ac(oYV,ocV);_ac(oXV,oYV);_ac(oWV,oXV);var oeV=_ctn("view");_setAttr(z,oeV,'class',15,e,s,gg);var ofV=_setAttrs(z,"button",["class",3,"formType",13,"type",14],e,s,gg);var ogV=_o(z,18,e,s,gg);_ac(ofV,ogV);_ac(oeV,ofV);var ohV=_setAttrs(z,"button",["type",17,"bindtap",2,"class",2],e,s,gg);var oiV=_o(z,20,e,s,gg);_ac(ohV,oiV);_ac(oeV,ohV);_ac(oWV,oeV);_ac(oRV,oWV);var ojV=_cvn();
    var okV=_o(z,21,e,s,gg);
    var olV=_gd('./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml',okV,e_,d_);
    if(olV){
      var omV={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      olV(omV,omV,ojV,gg);
      gg.f=tgf;
    }else{
      _w(okV,'./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml',0,0);
    }
    _ac(oRV,ojV);_ac(r,oRV);oOV.pop();oOV.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml"]={f:m39,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml"]={};
  var m40=function(e,s,r,gg){
    var z=gz$gma_41()
    var onV=e_["./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml"].i;_ai(onV,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml',0,0);_ai(onV,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml',0,0);var oqV=_ctn("view");_setAttr(z,oqV,'class',0,e,s,gg);var orV=_cvn();
    var osV=_o(z,1,e,s,gg);
    var otV=_gd('./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml',osV,e_,d_);
    if(otV){
      var ouV=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      otV(ouV,ouV,orV,gg);
      gg.f=tgf;
    }else{
      _w(osV,'./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml',0,0);
    }
    _ac(oqV,orV);var ovV=_ctn("view");_setAttr(z,ovV,'class',3,e,s,gg);var owV=_ctn("view");_setAttr(z,owV,'class',4,e,s,gg);var oxV=_setAttrs(z,"button",["bindtap",5,"class",1,"type",2],e,s,gg);var oyV=_o(z,8,e,s,gg);_ac(oxV,oyV);_ac(owV,oxV);var ozV=_setAttrs(z,"button",["type",7,"bindtap",2,"class",2],e,s,gg);var o_V=_o(z,10,e,s,gg);_ac(ozV,o_V);_ac(owV,ozV);_ac(ovV,owV);_ac(oqV,ovV);var oAW=_cvn();
    var oBW=_o(z,11,e,s,gg);
    var oCW=_gd('./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml',oBW,e_,d_);
    if(oCW){
      var oDW={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oCW(oDW,oDW,oAW,gg);
      gg.f=tgf;
    }else{
      _w(oBW,'./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml',0,0);
    }
    _ac(oqV,oAW);_ac(r,oqV);onV.pop();onV.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml"]={f:m40,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml"]={};
  var m41=function(e,s,r,gg){
    var z=gz$gma_42()
    var oEW=e_["./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml"].i;_ai(oEW,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml',0,0);_ai(oEW,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml',0,0);var oHW=_ctn("view");_setAttr(z,oHW,'class',0,e,s,gg);var oIW=_cvn();
    var oJW=_o(z,1,e,s,gg);
    var oKW=_gd('./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml',oJW,e_,d_);
    if(oKW){
      var oLW=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oKW(oLW,oLW,oIW,gg);
      gg.f=tgf;
    }else{
      _w(oJW,'./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml',0,0);
    }
    _ac(oHW,oIW);var oMW=_ctn("view");_setAttr(z,oMW,'class',3,e,s,gg);var oNW=_ctn("view");_setAttr(z,oNW,'class',4,e,s,gg);var oOW=_ctn("view");_setAttr(z,oOW,'class',5,e,s,gg);var oPW=_ctn("view");_setAttr(z,oPW,'class',6,e,s,gg);var oQW=_ctn("view");_setAttr(z,oQW,'class',7,e,s,gg);var oRW=_ctn("view");_setAttr(z,oRW,'class',8,e,s,gg);var oSW=_o(z,9,e,s,gg);_ac(oRW,oSW);_ac(oQW,oRW);_ac(oPW,oQW);var oTW=_ctn("view");_setAttr(z,oTW,'class',10,e,s,gg);var oUW=_setAttrs(z,"input",["id",9,"name",0,"bindinput",2,"class",3,"placeholder",4,"type",5,"value",6],e,s,gg);_ac(oTW,oUW);_ac(oPW,oTW);_ac(oOW,oPW);var oVW=_ctn("view");_setAttr(z,oVW,'class',6,e,s,gg);var oWW=_ctn("view");_setAttr(z,oWW,'class',7,e,s,gg);var oXW=_ctn("view");_setAttr(z,oXW,'class',8,e,s,gg);var oYW=_o(z,16,e,s,gg);_ac(oXW,oYW);_ac(oWW,oXW);_ac(oVW,oWW);var oZW=_ctn("view");_setAttr(z,oZW,'class',10,e,s,gg);var oaW=_setAttrs(z,"input",["class",12,"type",2,"id",4,"bindinput",5,"maxlength",6,"name",7,"placeholder",8,"value",9],e,s,gg);_ac(oZW,oaW);_ac(oVW,oZW);_ac(oOW,oVW);_ac(oNW,oOW);var obW=_ctn("view");_setAttr(z,obW,'class',22,e,s,gg);var ocW=_setAttrs(z,"button",["bindtap",23,"class",0,"type",1],e,s,gg);var odW=_o(z,25,e,s,gg);_ac(ocW,odW);_ac(obW,ocW);var oeW=_setAttrs(z,"button",["bindtap",26,"class",0],e,s,gg);var ofW=_o(z,27,e,s,gg);_ac(oeW,ofW);_ac(obW,oeW);var ogW=_setAttrs(z,"button",["bindtap",28,"class",0],e,s,gg);var ohW=_o(z,29,e,s,gg);_ac(ogW,ohW);_ac(obW,ogW);var oiW=_setAttrs(z,"button",["bindtap",30,"class",1],e,s,gg);var ojW=_o(z,32,e,s,gg);_ac(oiW,ojW);_ac(obW,oiW);var okW=_setAttrs(z,"button",["bindtap",33,"class",1],e,s,gg);var olW=_o(z,35,e,s,gg);_ac(okW,olW);_ac(obW,okW);var omW=_setAttrs(z,"button",["bindtap",36,"class",1],e,s,gg);var onW=_o(z,38,e,s,gg);_ac(omW,onW);_ac(obW,omW);var ooW=_setAttrs(z,"button",["bindtap",39,"class",1],e,s,gg);var opW=_o(z,41,e,s,gg);_ac(ooW,opW);_ac(obW,ooW);var oqW=_setAttrs(z,"button",["bindtap",42,"class",1],e,s,gg);var orW=_o(z,44,e,s,gg);_ac(oqW,orW);_ac(obW,oqW);var osW=_setAttrs(z,"button",["bindtap",45,"class",1],e,s,gg);var otW=_o(z,47,e,s,gg);_ac(osW,otW);_ac(obW,osW);var ouW=_setAttrs(z,"button",["bindtap",48,"class",1],e,s,gg);var ovW=_o(z,47,e,s,gg);_ac(ouW,ovW);_ac(obW,ouW);_ac(oNW,obW);_ac(oMW,oNW);_ac(oHW,oMW);var owW=_cvn();
    var oxW=_o(z,50,e,s,gg);
    var oyW=_gd('./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml',oxW,e_,d_);
    if(oyW){
      var ozW={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oyW(ozW,ozW,owW,gg);
      gg.f=tgf;
    }else{
      _w(oxW,'./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml',0,0);
    }
    _ac(oHW,owW);_ac(r,oHW);oEW.pop();oEW.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml"]={f:m41,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/storage/storage.maml"]={};
  var m42=function(e,s,r,gg){
    var z=gz$gma_43()
    var o_W=e_["./macle_demo_EN/page/API/pages/storage/storage.maml"].i;_ai(o_W,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/storage/storage.maml',0,0);_ai(o_W,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/storage/storage.maml',0,0);var oCX=_ctn("view");_setAttr(z,oCX,'class',0,e,s,gg);var oDX=_cvn();
    var oEX=_o(z,1,e,s,gg);
    var oFX=_gd('./macle_demo_EN/page/API/pages/storage/storage.maml',oEX,e_,d_);
    if(oFX){
      var oGX=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oFX(oGX,oGX,oDX,gg);
      gg.f=tgf;
    }else{
      _w(oEX,'./macle_demo_EN/page/API/pages/storage/storage.maml',0,0);
    }
    _ac(oCX,oDX);var oHX=_ctn("view");_setAttr(z,oHX,'class',3,e,s,gg);var oIX=_ctn("view");_setAttr(z,oIX,'class',4,e,s,gg);var oJX=_ctn("view");_setAttr(z,oJX,'class',5,e,s,gg);var oKX=_ctn("view");_setAttr(z,oKX,'class',6,e,s,gg);var oLX=_ctn("view");_setAttr(z,oLX,'class',7,e,s,gg);var oMX=_ctn("view");_setAttr(z,oMX,'class',8,e,s,gg);var oNX=_o(z,9,e,s,gg);_ac(oMX,oNX);_ac(oLX,oMX);_ac(oKX,oLX);var oOX=_ctn("view");_setAttr(z,oOX,'class',10,e,s,gg);var oPX=_setAttrs(z,"input",["id",9,"name",0,"bindinput",2,"class",3,"placeholder",4,"type",5,"value",6],e,s,gg);_ac(oOX,oPX);_ac(oKX,oOX);_ac(oJX,oKX);var oQX=_ctn("view");_setAttr(z,oQX,'class',6,e,s,gg);var oRX=_ctn("view");_setAttr(z,oRX,'class',7,e,s,gg);var oSX=_ctn("view");_setAttr(z,oSX,'class',8,e,s,gg);var oTX=_o(z,16,e,s,gg);_ac(oSX,oTX);_ac(oRX,oSX);_ac(oQX,oRX);var oUX=_ctn("view");_setAttr(z,oUX,'class',10,e,s,gg);var oVX=_setAttrs(z,"input",["class",12,"type",2,"id",4,"bindinput",5,"name",6,"placeholder",7,"value",8],e,s,gg);_ac(oUX,oVX);_ac(oQX,oUX);_ac(oJX,oQX);_ac(oIX,oJX);var oWX=_ctn("view");_setAttr(z,oWX,'class',21,e,s,gg);var oXX=_setAttrs(z,"button",["bindtap",22,"class",0,"type",1],e,s,gg);var oYX=_o(z,24,e,s,gg);_ac(oXX,oYX);_ac(oWX,oXX);var oZX=_setAttrs(z,"button",["bindtap",25,"class",0],e,s,gg);var oaX=_o(z,26,e,s,gg);_ac(oZX,oaX);_ac(oWX,oZX);var obX=_setAttrs(z,"button",["bindtap",27,"class",0],e,s,gg);var ocX=_o(z,28,e,s,gg);_ac(obX,ocX);_ac(oWX,obX);var odX=_setAttrs(z,"button",["bindtap",29,"class",0],e,s,gg);var oeX=_o(z,30,e,s,gg);_ac(odX,oeX);_ac(oWX,odX);var ofX=_setAttrs(z,"button",["bindtap",31,"class",0],e,s,gg);var ogX=_o(z,32,e,s,gg);_ac(ofX,ogX);_ac(oWX,ofX);var ohX=_setAttrs(z,"button",["class",22,"bindtap",11],e,s,gg);var oiX=_o(z,34,e,s,gg);_ac(ohX,oiX);_ac(oWX,ohX);var ojX=_setAttrs(z,"button",["class",25,"bindtap",10],e,s,gg);var okX=_o(z,36,e,s,gg);_ac(ojX,okX);_ac(oWX,ojX);_ac(oIX,oWX);_ac(oHX,oIX);_ac(oCX,oHX);var olX=_cvn();
    var omX=_o(z,37,e,s,gg);
    var onX=_gd('./macle_demo_EN/page/API/pages/storage/storage.maml',omX,e_,d_);
    if(onX){
      var ooX={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      onX(ooX,ooX,olX,gg);
      gg.f=tgf;
    }else{
      _w(omX,'./macle_demo_EN/page/API/pages/storage/storage.maml',0,0);
    }
    _ac(oCX,olX);_ac(r,oCX);o_W.pop();o_W.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/storage/storage.maml"]={f:m42,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/toast/toast.maml"]={};
  var m43=function(e,s,r,gg){
    var z=gz$gma_44()
    var opX=e_["./macle_demo_EN/page/API/pages/toast/toast.maml"].i;_ai(opX,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/toast/toast.maml',0,0);_ai(opX,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/toast/toast.maml',0,0);var osX=_ctn("view");_setAttr(z,osX,'class',0,e,s,gg);var otX=_cvn();
    var ouX=_o(z,1,e,s,gg);
    var ovX=_gd('./macle_demo_EN/page/API/pages/toast/toast.maml',ouX,e_,d_);
    if(ovX){
      var owX=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ovX(owX,owX,otX,gg);
      gg.f=tgf;
    }else{
      _w(ouX,'./macle_demo_EN/page/API/pages/toast/toast.maml',0,0);
    }
    _ac(osX,otX);var oxX=_ctn("view");_setAttr(z,oxX,'class',3,e,s,gg);var oyX=_ctn("view");_setAttr(z,oyX,'class',4,e,s,gg);var ozX=_setAttrs(z,"button",["bindtap",5,"id",1,"type",2],e,s,gg);var o_X=_o(z,8,e,s,gg);_ac(ozX,o_X);_ac(oyX,ozX);var oAY=_setAttrs(z,"button",["bindtap",9,"id",1,"type",2],e,s,gg);var oBY=_o(z,12,e,s,gg);_ac(oAY,oBY);_ac(oyX,oAY);var oCY=_setAttrs(z,"button",["bindtap",13,"id",1,"type",2],e,s,gg);var oDY=_o(z,16,e,s,gg);_ac(oCY,oDY);_ac(oyX,oCY);var oEY=_setAttrs(z,"button",["type",7,"bindtap",10,"id",11],e,s,gg);var oFY=_o(z,19,e,s,gg);_ac(oEY,oFY);_ac(oyX,oEY);var oGY=_setAttrs(z,"button",["type",15,"bindtap",5,"id",6],e,s,gg);var oHY=_o(z,22,e,s,gg);_ac(oGY,oHY);_ac(oyX,oGY);var oIY=_setAttrs(z,"button",["type",7,"bindtap",16,"id",17],e,s,gg);var oJY=_o(z,25,e,s,gg);_ac(oIY,oJY);_ac(oyX,oIY);var oKY=_setAttrs(z,"button",["bindtap",26,"id",1],e,s,gg);var oLY=_o(z,28,e,s,gg);_ac(oKY,oLY);_ac(oyX,oKY);var oMY=_setAttrs(z,"input",["placeholder",29,"style",1,"value",2],e,s,gg);oMY.rawAttr={"model:value":"{{toastTitle}}"};_ac(oyX,oMY);var oNY=_setAttrs(z,"button",["type",7,"bindtap",25,"id",26],e,s,gg);var oOY=_o(z,34,e,s,gg);_ac(oNY,oOY);_ac(oyX,oNY);_ac(oxX,oyX);_ac(osX,oxX);var oPY=_cvn();
    var oQY=_o(z,35,e,s,gg);
    var oRY=_gd('./macle_demo_EN/page/API/pages/toast/toast.maml',oQY,e_,d_);
    if(oRY){
      var oSY={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oRY(oSY,oSY,oPY,gg);
      gg.f=tgf;
    }else{
      _w(oQY,'./macle_demo_EN/page/API/pages/toast/toast.maml',0,0);
    }
    _ac(osX,oPY);_ac(r,osX);opX.pop();opX.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/toast/toast.maml"]={f:m43,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml"]={};
  var m44=function(e,s,r,gg){
    var z=gz$gma_45()
    var oTY=e_["./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml"].i;_ai(oTY,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml',0,0);_ai(oTY,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml',0,0);var oWY=_ctn("view");_setAttr(z,oWY,'class',0,e,s,gg);var oXY=_cvn();
    var oYY=_o(z,1,e,s,gg);
    var oZY=_gd('./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml',oYY,e_,d_);
    if(oZY){
      var oaY=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oZY(oaY,oaY,oXY,gg);
      gg.f=tgf;
    }else{
      _w(oYY,'./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml',0,0);
    }
    _ac(oWY,oXY);var obY=_ctn("view");_setAttr(z,obY,'class',3,e,s,gg);var ocY=_ctn("view");_setAttr(z,ocY,'class',4,e,s,gg);var odY=_setAttrs(z,"button",["bindtap",5,"class",1],e,s,gg);var oeY=_o(z,7,e,s,gg);_ac(odY,oeY);_ac(ocY,odY);var ofY=_setAttrs(z,"button",["bindtap",6,"class",0],e,s,gg);var ogY=_o(z,8,e,s,gg);_ac(ofY,ogY);_ac(ocY,ofY);var ohY=_setAttrs(z,"button",["bindtap",9,"class",0],e,s,gg);var oiY=_o(z,10,e,s,gg);_ac(ohY,oiY);_ac(ocY,ohY);var ojY=_setAttrs(z,"button",["bindtap",11,"class",0],e,s,gg);var okY=_o(z,12,e,s,gg);_ac(ojY,okY);_ac(ocY,ojY);_ac(obY,ocY);var olY=_cvn();if(_o(z,13,e,s,gg)){olY.maVkey=1;var omY=_ctn("view");_setAttr(z,omY,'class',14,e,s,gg);var ooY=_setAttrs(z,"textarea",["maxlength",15,"value",1],e,s,gg);_ac(omY,ooY);_ac(olY,omY);} _ac(obY,olY);_ac(oWY,obY);var opY=_cvn();
    var oqY=_o(z,17,e,s,gg);
    var orY=_gd('./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml',oqY,e_,d_);
    if(orY){
      var osY={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      orY(osY,osY,opY,gg);
      gg.f=tgf;
    }else{
      _w(oqY,'./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml',0,0);
    }
    _ac(oWY,opY);_ac(r,oWY);oTY.pop();oTY.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml"]={f:m44,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/vibrate/vibrate.maml"]={};
  var m45=function(e,s,r,gg){
    var z=gz$gma_46()
    var otY=e_["./macle_demo_EN/page/API/pages/vibrate/vibrate.maml"].i;_ai(otY,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/vibrate/vibrate.maml',0,0);_ai(otY,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/vibrate/vibrate.maml',0,0);var owY=_ctn("view");_setAttr(z,owY,'class',0,e,s,gg);var oxY=_cvn();
    var oyY=_o(z,1,e,s,gg);
    var ozY=_gd('./macle_demo_EN/page/API/pages/vibrate/vibrate.maml',oyY,e_,d_);
    if(ozY){
      var o_Y=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ozY(o_Y,o_Y,oxY,gg);
      gg.f=tgf;
    }else{
      _w(oyY,'./macle_demo_EN/page/API/pages/vibrate/vibrate.maml',0,0);
    }
    _ac(owY,oxY);var oAZ=_ctn("view");_setAttr(z,oAZ,'class',3,e,s,gg);var oBZ=_ctn("view");_setAttr(z,oBZ,'class',4,e,s,gg);var oCZ=_ctn("view");_setAttr(z,oCZ,'class',5,e,s,gg);var oDZ=_ctn("view");_setAttr(z,oDZ,'class',6,e,s,gg);var oEZ=_o(z,7,e,s,gg);_ac(oDZ,oEZ);_ac(oCZ,oDZ);_ac(oBZ,oCZ);var oFZ=_ctn("view");_setAttr(z,oFZ,'class',8,e,s,gg);var oGZ=_setAttrs(z,"picker",["bindchange",9,"mode",1,"range",2,"value",3],e,s,gg);var oHZ=_ctn("view");_setAttr(z,oHZ,'class',13,e,s,gg);var oIZ=_o(z,14,e,s,gg);_ac(oHZ,oIZ);_ac(oGZ,oHZ);_ac(oFZ,oGZ);_ac(oBZ,oFZ);_ac(oAZ,oBZ);var oJZ=_ctn("view");_setAttr(z,oJZ,'class',15,e,s,gg);var oKZ=_setAttrs(z,"button",["bindtap",16,"class",0,"type",1],e,s,gg);var oLZ=_o(z,18,e,s,gg);_ac(oKZ,oLZ);_ac(oJZ,oKZ);var oMZ=_setAttrs(z,"button",["bindtap",19,"class",0,"type",1],e,s,gg);var oNZ=_o(z,21,e,s,gg);_ac(oMZ,oNZ);_ac(oJZ,oMZ);_ac(oAZ,oJZ);var oOZ=_ctn("view");_setAttr(z,oOZ,'class',22,e,s,gg);var oPZ=_ctn("view");_setAttr(z,oPZ,'class',23,e,s,gg);var oQZ=_o(z,24,e,s,gg);_ac(oPZ,oQZ);_ac(oOZ,oPZ);_ac(oAZ,oOZ);_ac(owY,oAZ);var oRZ=_cvn();
    var oSZ=_o(z,25,e,s,gg);
    var oTZ=_gd('./macle_demo_EN/page/API/pages/vibrate/vibrate.maml',oSZ,e_,d_);
    if(oTZ){
      var oUZ={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oTZ(oUZ,oUZ,oRZ,gg);
      gg.f=tgf;
    }else{
      _w(oSZ,'./macle_demo_EN/page/API/pages/vibrate/vibrate.maml',0,0);
    }
    _ac(owY,oRZ);_ac(r,owY);otY.pop();otY.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/vibrate/vibrate.maml"]={f:m45,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/API/pages/websocket/websocket.maml"]={};
  var m46=function(e,s,r,gg){
    var z=gz$gma_47()
    var oVZ=e_["./macle_demo_EN/page/API/pages/websocket/websocket.maml"].i;_ai(oVZ,'../../../common/head.maml',e_,'./macle_demo_EN/page/API/pages/websocket/websocket.maml',0,0);_ai(oVZ,'../../../common/foot.maml',e_,'./macle_demo_EN/page/API/pages/websocket/websocket.maml',0,0);var oYZ=_ctn("view");_setAttr(z,oYZ,'class',0,e,s,gg);var oZZ=_cvn();
    var oaZ=_o(z,1,e,s,gg);
    var obZ=_gd('./macle_demo_EN/page/API/pages/websocket/websocket.maml',oaZ,e_,d_);
    if(obZ){
      var ocZ=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      obZ(ocZ,ocZ,oZZ,gg);
      gg.f=tgf;
    }else{
      _w(oaZ,'./macle_demo_EN/page/API/pages/websocket/websocket.maml',0,0);
    }
    _ac(oYZ,oZZ);var odZ=_ctn("view");_setAttr(z,odZ,'class',3,e,s,gg);var oeZ=_ctn("view");_setAttr(z,oeZ,'class',4,e,s,gg);var ofZ=_ctn("view");_setAttr(z,ofZ,'class',5,e,s,gg);var ogZ=_ctn("view");_setAttr(z,ogZ,'class',6,e,s,gg);var ohZ=_ctn("view");_setAttr(z,ohZ,'class',7,e,s,gg);var oiZ=_o(z,8,e,s,gg);_ac(ohZ,oiZ);_ac(ogZ,ohZ);var ojZ=_setAttrs(z,"input",["class",9,"id",1,"placeholder",2,"style",3,"value",4],e,s,gg);ojZ.rawAttr={"model:value":"{{wsUrl}}"};_ac(ogZ,ojZ);_ac(ofZ,ogZ);var okZ=_ctn("view");_setAttr(z,okZ,'class',6,e,s,gg);var olZ=_ctn("view");_setAttr(z,olZ,'class',7,e,s,gg);var omZ=_o(z,14,e,s,gg);_ac(olZ,omZ);_ac(okZ,olZ);var onZ=_setAttrs(z,"input",["class",9,"id",6,"placeholder",7,"style",8,"type",9,"value",10],e,s,gg);onZ.rawAttr={"model:value":"{{closeCode}}"};_ac(okZ,onZ);_ac(ofZ,okZ);var ooZ=_ctn("view");_setAttr(z,ooZ,'class',6,e,s,gg);var opZ=_ctn("view");_setAttr(z,opZ,'class',7,e,s,gg);var oqZ=_o(z,20,e,s,gg);_ac(opZ,oqZ);_ac(ooZ,opZ);var orZ=_setAttrs(z,"input",["class",9,"style",8,"id",12,"placeholder",13,"value",14],e,s,gg);orZ.rawAttr={"model:value":"{{closeReason}}"};_ac(ooZ,orZ);_ac(ofZ,ooZ);var osZ=_ctn("view");_setAttr(z,osZ,'class',24,e,s,gg);var otZ=_ctn("view");_setAttr(z,otZ,'class',7,e,s,gg);var ouZ=_o(z,25,e,s,gg);_ac(otZ,ouZ);_ac(osZ,otZ);var ovZ=_ctn("view");_setAttr(z,ovZ,'class',9,e,s,gg);var owZ=_setAttrs(z,"switch",["bindchange",26,"disabled",1],e,s,gg);_ac(ovZ,owZ);_ac(osZ,ovZ);_ac(ofZ,osZ);var oxZ=_ctn("view");_setAttr(z,oxZ,'class',6,e,s,gg);var oyZ=_ctn("view");_setAttr(z,oyZ,'class',7,e,s,gg);var ozZ=_o(z,28,e,s,gg);_ac(oyZ,ozZ);_ac(oxZ,oyZ);var o_Z=_setAttrs(z,"input",["class",9,"style",3,"id",20,"placeholder",21,"value",22],e,s,gg);o_Z.rawAttr={"model:value":"{{messageToSend}}"};_ac(oxZ,o_Z);_ac(ofZ,oxZ);_ac(oeZ,ofZ);_ac(odZ,oeZ);var oAa=_ctn("view");_setAttr(z,oAa,'class',32,e,s,gg);var oBa=_setAttrs(z,"button",["bindtap",33,"id",1,"loading",2,"size",3,"type",4],e,s,gg);var oCa=_o(z,38,e,s,gg);_ac(oBa,oCa);_ac(oAa,oBa);_ac(odZ,oAa);var oDa=_ctn("view");_setAttr(z,oDa,'class',39,e,s,gg);var oEa=_ctn("view");_setAttr(z,oEa,'class',7,e,s,gg);var oFa=_o(z,40,e,s,gg);_ac(oEa,oFa);_ac(oDa,oEa);var oGa=_setAttrs(z,"view",["class",41,"id",1],e,s,gg);var oHa=_o(z,43,e,s,gg);_ac(oGa,oHa);_ac(oDa,oGa);_ac(odZ,oDa);var oIa=_ctn("view");_setAttr(z,oIa,'class',39,e,s,gg);var oJa=_ctn("view");_setAttr(z,oJa,'class',7,e,s,gg);var oKa=_o(z,44,e,s,gg);_ac(oJa,oKa);_ac(oIa,oJa);var oLa=_setAttrs(z,"view",["class",41,"id",4],e,s,gg);var oMa=_o(z,46,e,s,gg);_ac(oLa,oMa);_ac(oIa,oLa);_ac(odZ,oIa);var oNa=_ctn("view");_setAttr(z,oNa,'class',47,e,s,gg);var oOa=_ctn("view");_setAttr(z,oOa,'class',48,e,s,gg);var oPa=_o(z,49,e,s,gg);_ac(oOa,oPa);_ac(oNa,oOa);var oQa=_setAttrs(z,"view",["class",41,"id",9],e,s,gg);var oRa=_o(z,51,e,s,gg);_ac(oQa,oRa);_ac(oNa,oQa);_ac(odZ,oNa);var oSa=_ctn("view");_setAttr(z,oSa,'class',47,e,s,gg);var oTa=_ctn("view");_setAttr(z,oTa,'class',7,e,s,gg);var oUa=_o(z,52,e,s,gg);_ac(oTa,oUa);_ac(oSa,oTa);var oVa=_setAttrs(z,"view",["class",41,"id",12],e,s,gg);var oWa=_o(z,54,e,s,gg);_ac(oVa,oWa);_ac(oSa,oVa);_ac(odZ,oSa);var oXa=_ctn("view");_setAttr(z,oXa,'class',47,e,s,gg);var oYa=_ctn("view");_setAttr(z,oYa,'class',7,e,s,gg);var oZa=_o(z,55,e,s,gg);_ac(oYa,oZa);_ac(oXa,oYa);var oaa=_setAttrs(z,"view",["class",41,"id",15],e,s,gg);var oba=_o(z,57,e,s,gg);_ac(oaa,oba);_ac(oXa,oaa);_ac(odZ,oXa);_ac(oYZ,odZ);var oca=_cvn();
    var oda=_o(z,58,e,s,gg);
    var oea=_gd('./macle_demo_EN/page/API/pages/websocket/websocket.maml',oda,e_,d_);
    if(oea){
      var ofa={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oea(ofa,ofa,oca,gg);
      gg.f=tgf;
    }else{
      _w(oda,'./macle_demo_EN/page/API/pages/websocket/websocket.maml',0,0);
    }
    _ac(oYZ,oca);_ac(r,oYZ);oVZ.pop();oVZ.pop();
    return r;
  };
  e_["./macle_demo_EN/page/API/pages/websocket/websocket.maml"]={f:m46,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/common/foot.maml"]={};
  d_["./macle_demo_EN/page/common/foot.maml"]["foot"]=function(e,s,r,gg){
    var z=gz$gma_48(),b='./macle_demo_EN/page/common/foot.maml:foot'
    r.maVkey=b
    gg.f=$gdc(f_["./macle_demo_EN/page/common/foot.maml"],"",1)
    if(p_[b]){_wl(b,'./macle_demo_EN/page/common/foot.maml');return}
    p_[b]=true
    try{
      var oha=_setAttrs(z,"navigator",["class",0,"hoverClass",1,"openType",1,"url",2],e,s,gg);var oia=_setAttrs(z,"image",["class",4,"src",1],e,s,gg);_ac(oha,oia);_ac(r,oha);
    }catch(e){
      p_[b]=false
      throw e
    }
    p_[b]=false
    return r
  };
  var m47=function(e,s,r,gg){
    var z=gz$gma_48()
    
    return r;
  };
  e_["./macle_demo_EN/page/common/foot.maml"]={f:m47,j:[],i:[],ti:[],ic:[]};

  d_["./macle_demo_EN/page/common/head.maml"]={};
  d_["./macle_demo_EN/page/common/head.maml"]["head"]=function(e,s,r,gg){
    var z=gz$gma_49(),b='./macle_demo_EN/page/common/head.maml:head'
    r.maVkey=b
    gg.f=$gdc(f_["./macle_demo_EN/page/common/head.maml"],"",1)
    if(p_[b]){_wl(b,'./macle_demo_EN/page/common/head.maml');return}
    p_[b]=true
    try{
      var oma=_ctn("view");_setAttr(z,oma,'class',0,e,s,gg);var ona=_ctn("view");_setAttr(z,ona,'class',1,e,s,gg);var ooa=_o(z,2,e,s,gg);_ac(ona,ooa);_ac(oma,ona);var opa=_ctn("view");_setAttr(z,opa,'class',3,e,s,gg);_ac(oma,opa);var oqa=_cvn();if(_o(z,4,e,s,gg)){oqa.maVkey=1;var ora=_ctn("view");_setAttr(z,ora,'class',5,e,s,gg);var ota=_o(z,6,e,s,gg);_ac(ora,ota);_ac(oqa,ora);} _ac(oma,oqa);_ac(r,oma);
    }catch(e){
      p_[b]=false
      throw e
    }
    p_[b]=false
    return r
  };
  var m48=function(e,s,r,gg){
    var z=gz$gma_49()
    
    return r;
  };
  e_["./macle_demo_EN/page/common/head.maml"]={f:m48,j:[],i:[],ti:[],ic:[]};

  d_["./macle_demo_EN/page/component/pages/audio/audio.maml"]={};
  var m49=function(e,s,r,gg){
    var z=gz$gma_50()
    var owa=e_["./macle_demo_EN/page/component/pages/audio/audio.maml"].i;_ai(owa,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/audio/audio.maml',0,0);_ai(owa,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/audio/audio.maml',0,0);var oza=_ctn("view");_setAttr(z,oza,'class',0,e,s,gg);var o_a=_cvn();
    var oAb=_o(z,1,e,s,gg);
    var oBb=_gd('./macle_demo_EN/page/component/pages/audio/audio.maml',oAb,e_,d_);
    if(oBb){
      var oCb=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oBb(oCb,oCb,o_a,gg);
      gg.f=tgf;
    }else{
      _w(oAb,'./macle_demo_EN/page/component/pages/audio/audio.maml',0,0);
    }
    _ac(oza,o_a);var oDb=_ctn("view");_setAttr(z,oDb,'class',3,e,s,gg);var oEb=_setAttrs(z,"view",["class",4,"style",1],e,s,gg);var oFb=_setAttrs(z,"audio",["author",6,"bindended",1,"binderror",2,"bindpause",3,"bindplay",4,"bindtimeupdate",5,"controls",6,"id",7,"loop",8,"name",9,"poster",10,"src",11,"style",12],e,s,gg);_ac(oEb,oFb);_ac(oDb,oEb);_ac(oza,oDb);var oGb=_ctn("view");_setAttr(z,oGb,'class',19,e,s,gg);var oHb=_ctn("text");_setAttr(z,oHb,'class',20,e,s,gg);var oIb=_o(z,21,e,s,gg);_ac(oHb,oIb);_ac(oGb,oHb);var oJb=_ctn("view");_setAttr(z,oJb,'class',22,e,s,gg);var oKb=_ctn("button");_setAttr(z,oKb,'bindtap',23,e,s,gg);var oLb=_o(z,21,e,s,gg);_ac(oKb,oLb);_ac(oJb,oKb);_ac(oGb,oJb);_ac(oza,oGb);var oMb=_ctn("view");_setAttr(z,oMb,'class',19,e,s,gg);var oNb=_ctn("text");_setAttr(z,oNb,'class',20,e,s,gg);var oOb=_o(z,24,e,s,gg);_ac(oNb,oOb);_ac(oMb,oNb);var oPb=_ctn("view");_setAttr(z,oPb,'class',25,e,s,gg);var oQb=_ctn("button");_setAttr(z,oQb,'bindtap',26,e,s,gg);var oRb=_o(z,24,e,s,gg);_ac(oQb,oRb);_ac(oPb,oQb);_ac(oMb,oPb);_ac(oza,oMb);var oSb=_ctn("view");_setAttr(z,oSb,'class',19,e,s,gg);var oTb=_ctn("text");_setAttr(z,oTb,'class',20,e,s,gg);var oUb=_o(z,27,e,s,gg);_ac(oTb,oUb);_ac(oSb,oTb);var oVb=_ctn("view");_setAttr(z,oVb,'class',28,e,s,gg);var oWb=_ctn("button");_setAttr(z,oWb,'bindtap',29,e,s,gg);var oXb=_o(z,30,e,s,gg);_ac(oWb,oXb);_ac(oVb,oWb);_ac(oSb,oVb);_ac(oza,oSb);var oYb=_cvn();
    var oZb=_o(z,31,e,s,gg);
    var oab=_gd('./macle_demo_EN/page/component/pages/audio/audio.maml',oZb,e_,d_);
    if(oab){
      var obb={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oab(obb,obb,oYb,gg);
      gg.f=tgf;
    }else{
      _w(oZb,'./macle_demo_EN/page/component/pages/audio/audio.maml',0,0);
    }
    _ac(oza,oYb);_ac(r,oza);owa.pop();owa.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/audio/audio.maml"]={f:m49,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/button/button.maml"]={};
  var m50=function(e,s,r,gg){
    var z=gz$gma_51()
    var ocb=e_["./macle_demo_EN/page/component/pages/button/button.maml"].i;_ai(ocb,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/button/button.maml',0,0);_ai(ocb,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/button/button.maml',0,0);var ofb=_ctn("view");_setAttr(z,ofb,'class',0,e,s,gg);var ogb=_cvn();
    var ohb=_o(z,1,e,s,gg);
    var oib=_gd('./macle_demo_EN/page/component/pages/button/button.maml',ohb,e_,d_);
    if(oib){
      var ojb=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oib(ojb,ojb,ogb,gg);
      gg.f=tgf;
    }else{
      _w(ohb,'./macle_demo_EN/page/component/pages/button/button.maml',0,0);
    }
    _ac(ofb,ogb);var okb=_ctn("view");_setAttr(z,okb,'class',3,e,s,gg);var olb=_setAttrs(z,"view",["class",4,"id",1],e,s,gg);var omb=_setAttrs(z,"view",["hoverClass",6,"hoverStartTime",1,"hoverStayTime",2],e,s,gg);var onb=_setAttrs(z,"button",["class",9,"size",1,"type",2],e,s,gg);var oob=_o(z,12,e,s,gg);_ac(onb,oob);_ac(omb,onb);var opb=_setAttrs(z,"button",["type",11,"class",2,"hoverStopPropagation",3,"loading",3],e,s,gg);var oqb=_o(z,15,e,s,gg);_ac(opb,oqb);_ac(omb,opb);var orb=_setAttrs(z,"button",["type",11,"disabled",3,"hoverStopPropagation",3,"class",5],e,s,gg);var osb=_o(z,17,e,s,gg);_ac(orb,osb);_ac(omb,orb);_ac(olb,omb);var otb=_setAttrs(z,"button",["type",10,"class",8,"hoverClass",9,"hoverStartTime",10,"hoverStayTime",11],e,s,gg);var oub=_o(z,22,e,s,gg);_ac(otb,oub);_ac(olb,otb);var ovb=_setAttrs(z,"button",["type",10,"disabled",4,"class",13],e,s,gg);var owb=_o(z,24,e,s,gg);_ac(ovb,owb);_ac(olb,ovb);var oxb=_setAttrs(z,"button",["class",25,"disabled",1,"hoverClass",2,"type",3],e,s,gg);var oyb=_o(z,29,e,s,gg);_ac(oxb,oyb);_ac(olb,oxb);var ozb=_setAttrs(z,"button",["disabled",14,"type",14,"class",16],e,s,gg);var o_b=_o(z,31,e,s,gg);_ac(ozb,o_b);_ac(olb,ozb);var oAc=_setAttrs(z,"button",["type",10,"hoverStartTime",11,"hoverStayTime",11,"class",22,"hoverClass",23],e,s,gg);var oBc=_o(z,34,e,s,gg);_ac(oAc,oBc);_ac(olb,oAc);var oCc=_ctn("view");_setAttr(z,oCc,'class',35,e,s,gg);var oDc=_setAttrs(z,"button",["type",11,"plain",3,"class",25],e,s,gg);var oEc=_o(z,37,e,s,gg);_ac(oDc,oEc);_ac(oCc,oDc);var oFc=_setAttrs(z,"button",["type",11,"disabled",3,"plain",3,"class",27],e,s,gg);var oGc=_o(z,39,e,s,gg);_ac(oFc,oGc);_ac(oCc,oFc);var oHc=_setAttrs(z,"button",["type",10,"plain",4,"class",30],e,s,gg);var oIc=_o(z,37,e,s,gg);_ac(oHc,oIc);_ac(oCc,oHc);var oJc=_setAttrs(z,"button",["type",10,"disabled",4,"plain",4,"class",31],e,s,gg);var oKc=_o(z,37,e,s,gg);_ac(oJc,oKc);_ac(oCc,oJc);var oLc=_setAttrs(z,"button",["type",11,"class",31,"size",32],e,s,gg);var oMc=_o(z,37,e,s,gg);_ac(oLc,oMc);_ac(oCc,oLc);var oNc=_setAttrs(z,"button",["type",10,"size",33,"class",34],e,s,gg);var oOc=_o(z,37,e,s,gg);_ac(oNc,oOc);_ac(oCc,oNc);var oPc=_setAttrs(z,"button",["type",28,"size",15,"class",17],e,s,gg);var oQc=_o(z,37,e,s,gg);_ac(oPc,oQc);_ac(oCc,oPc);_ac(olb,oCc);var oRc=_setAttrs(z,"view",["hoverClass",6,"hoverStartTime",1,"class",40,"hoverStayTime",41],e,s,gg);var oSc=_setAttrs(z,"button",["type",11,"class",37,"plain",38,"size",38],e,s,gg);var oTc=_o(z,50,e,s,gg);_ac(oSc,oTc);_ac(oRc,oSc);var oUc=_setAttrs(z,"button",["loading",49,"size",0,"class",2,"type",3],e,s,gg);var oVc=_o(z,53,e,s,gg);_ac(oUc,oVc);_ac(oRc,oUc);var oWc=_setAttrs(z,"button",["disabled",49,"class",5],e,s,gg);var oXc=_o(z,55,e,s,gg);_ac(oWc,oXc);_ac(oRc,oWc);var oYc=_setAttrs(z,"button",["hoverClass",49,"class",7],e,s,gg);var oZc=_o(z,57,e,s,gg);_ac(oYc,oZc);_ac(oRc,oYc);var oac=_setAttrs(z,"button",["type",11,"hoverStopPropagation",38,"class",47],e,s,gg);var obc=_o(z,59,e,s,gg);_ac(oac,obc);_ac(oRc,oac);var occ=_setAttrs(z,"button",["type",10,"hoverClass",9,"hoverStartTime",39,"hoverStayTime",39,"class",50],e,s,gg);var odc=_o(z,61,e,s,gg);_ac(occ,odc);_ac(oRc,occ);_ac(olb,oRc);_ac(okb,olb);_ac(ofb,okb);var oec=_cvn();
    var ofc=_o(z,62,e,s,gg);
    var ogc=_gd('./macle_demo_EN/page/component/pages/button/button.maml',ofc,e_,d_);
    if(ogc){
      var ohc={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ogc(ohc,ohc,oec,gg);
      gg.f=tgf;
    }else{
      _w(ofc,'./macle_demo_EN/page/component/pages/button/button.maml',0,0);
    }
    _ac(ofb,oec);_ac(r,ofb);ocb.pop();ocb.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/button/button.maml"]={f:m50,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/camera/camera.maml"]={};
  var m51=function(e,s,r,gg){
    var z=gz$gma_52()
    var oic=e_["./macle_demo_EN/page/component/pages/camera/camera.maml"].i;_ai(oic,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/camera/camera.maml',0,0);_ai(oic,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/camera/camera.maml',0,0);var olc=_ctn("view");_setAttr(z,olc,'class',0,e,s,gg);var omc=_cvn();
    var onc=_o(z,1,e,s,gg);
    var ooc=_gd('./macle_demo_EN/page/component/pages/camera/camera.maml',onc,e_,d_);
    if(ooc){
      var opc=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ooc(opc,opc,omc,gg);
      gg.f=tgf;
    }else{
      _w(onc,'./macle_demo_EN/page/component/pages/camera/camera.maml',0,0);
    }
    _ac(olc,omc);var oqc=_setAttrs(z,"camera",["binderror",3,"bindstop",1,"devicePosition",2,"flash",3,"style",4],e,s,gg);_ac(olc,oqc);var orc=_setAttrs(z,"button",["bindtap",8,"class",1,"type",2],e,s,gg);var osc=_o(z,11,e,s,gg);_ac(orc,osc);_ac(olc,orc);var otc=_setAttrs(z,"button",["class",9,"type",1,"bindtap",3],e,s,gg);var ouc=_o(z,13,e,s,gg);_ac(otc,ouc);_ac(olc,otc);var ovc=_setAttrs(z,"button",["class",9,"type",1,"bindtap",5],e,s,gg);var owc=_o(z,15,e,s,gg);_ac(ovc,owc);_ac(olc,ovc);var oxc=_ctn("view");var oyc=_o(z,16,e,s,gg);_ac(oxc,oyc);_ac(olc,oxc);var ozc=_setAttrs(z,"image",["style",7,"src",10],e,s,gg);_ac(olc,ozc);var o_c=_cvn();
    var oAd=_o(z,18,e,s,gg);
    var oBd=_gd('./macle_demo_EN/page/component/pages/camera/camera.maml',oAd,e_,d_);
    if(oBd){
      var oCd={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oBd(oCd,oCd,o_c,gg);
      gg.f=tgf;
    }else{
      _w(oAd,'./macle_demo_EN/page/component/pages/camera/camera.maml',0,0);
    }
    _ac(olc,o_c);_ac(r,olc);oic.pop();oic.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/camera/camera.maml"]={f:m51,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/checkbox/checkbox.maml"]={};
  var m52=function(e,s,r,gg){
    var z=gz$gma_53()
    var oDd=e_["./macle_demo_EN/page/component/pages/checkbox/checkbox.maml"].i;_ai(oDd,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/checkbox/checkbox.maml',0,0);_ai(oDd,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/checkbox/checkbox.maml',0,0);var oGd=_ctn("view");_setAttr(z,oGd,'class',0,e,s,gg);var oHd=_cvn();
    var oId=_o(z,1,e,s,gg);
    var oJd=_gd('./macle_demo_EN/page/component/pages/checkbox/checkbox.maml',oId,e_,d_);
    if(oJd){
      var oKd=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oJd(oKd,oKd,oHd,gg);
      gg.f=tgf;
    }else{
      _w(oId,'./macle_demo_EN/page/component/pages/checkbox/checkbox.maml',0,0);
    }
    _ac(oGd,oHd);var oLd=_ctn("view");_setAttr(z,oLd,'class',3,e,s,gg);var oMd=_ctn("view");_setAttr(z,oMd,'class',4,e,s,gg);var oNd=_ctn("view");_setAttr(z,oNd,'class',5,e,s,gg);var oOd=_o(z,6,e,s,gg);_ac(oNd,oOd);_ac(oMd,oNd);var oPd=_ctn("label");_setAttr(z,oPd,'class',7,e,s,gg);var oQd=_setAttrs(z,"checkbox",["checked",8,"disabled",0,"class",1,"color",2,"value",3],e,s,gg);_ac(oPd,oQd);var oRd=_o(z,12,e,s,gg);_ac(oPd,oRd);_ac(oMd,oPd);var oSd=_ctn("label");_setAttr(z,oSd,'class',7,e,s,gg);var oTd=_setAttrs(z,"checkbox",["color",10,"value",1,"class",3],e,s,gg);_ac(oSd,oTd);var oUd=_o(z,14,e,s,gg);_ac(oSd,oUd);_ac(oMd,oSd);_ac(oLd,oMd);var oVd=_ctn("view");_setAttr(z,oVd,'class',15,e,s,gg);var oWd=_ctn("view");_setAttr(z,oWd,'class',5,e,s,gg);var oXd=_o(z,16,e,s,gg);_ac(oWd,oXd);_ac(oVd,oWd);var oYd=_ctn("view");_setAttr(z,oYd,'class',17,e,s,gg);var oZd=_ctn("checkbox-group");_setAttr(z,oZd,'bindchange',18,e,s,gg);var oad=_cvn();var obd=function(ofd,oed,odd,gg){var ocd=_ctn("label");_setAttr(z,ocd,'class',21,ofd,oed,gg);var ohd=_ctn("view");_setAttr(z,ohd,'class',22,ofd,oed,gg);var oid=_setAttrs(z,"checkbox",["value",20,"checked",3,"class",4,"color",5],ofd,oed,gg);_ac(ohd,oid);_ac(ocd,ohd);var ojd=_ctn("view");_setAttr(z,ojd,'class',26,ofd,oed,gg);var okd=_o(z,27,ofd,oed,gg);_ac(ojd,okd);_ac(ocd,ojd);_ac(odd,ocd);return odd;};_2(z,19,obd,e,s,gg,oad,"item","index",'{{item.value}}');_ac(oZd,oad);_ac(oYd,oZd);_ac(oVd,oYd);_ac(oLd,oVd);_ac(oGd,oLd);var old=_cvn();
    var omd=_o(z,28,e,s,gg);
    var ond=_gd('./macle_demo_EN/page/component/pages/checkbox/checkbox.maml',omd,e_,d_);
    if(ond){
      var ood={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ond(ood,ood,old,gg);
      gg.f=tgf;
    }else{
      _w(omd,'./macle_demo_EN/page/component/pages/checkbox/checkbox.maml',0,0);
    }
    _ac(oGd,old);_ac(r,oGd);oDd.pop();oDd.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/checkbox/checkbox.maml"]={f:m52,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/cover-image/cover-image.maml"]={};
  var m53=function(e,s,r,gg){
    var z=gz$gma_54()
    var opd=e_["./macle_demo_EN/page/component/pages/cover-image/cover-image.maml"].i;_ai(opd,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/cover-image/cover-image.maml',0,0);_ai(opd,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/cover-image/cover-image.maml',0,0);var osd=_ctn("view");_setAttr(z,osd,'class',0,e,s,gg);var otd=_cvn();
    var oud=_o(z,1,e,s,gg);
    var ovd=_gd('./macle_demo_EN/page/component/pages/cover-image/cover-image.maml',oud,e_,d_);
    if(ovd){
      var owd=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ovd(owd,owd,otd,gg);
      gg.f=tgf;
    }else{
      _w(oud,'./macle_demo_EN/page/component/pages/cover-image/cover-image.maml',0,0);
    }
    _ac(osd,otd);var oxd=_setAttrs(z,"camera",["binderror",3,"devicePosition",1,"flash",2,"style",3],e,s,gg);var oyd=_setAttrs(z,"cover-image",["class",7,"src",1],e,s,gg);_ac(oxd,oyd);_ac(osd,oxd);var ozd=_cvn();
    var o_d=_o(z,9,e,s,gg);
    var oAe=_gd('./macle_demo_EN/page/component/pages/cover-image/cover-image.maml',o_d,e_,d_);
    if(oAe){
      var oBe={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oAe(oBe,oBe,ozd,gg);
      gg.f=tgf;
    }else{
      _w(o_d,'./macle_demo_EN/page/component/pages/cover-image/cover-image.maml',0,0);
    }
    _ac(osd,ozd);_ac(r,osd);opd.pop();opd.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/cover-image/cover-image.maml"]={f:m53,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/cover-view/cover-view.maml"]={};
  var m54=function(e,s,r,gg){
    var z=gz$gma_55()
    var oCe=e_["./macle_demo_EN/page/component/pages/cover-view/cover-view.maml"].i;_ai(oCe,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/cover-view/cover-view.maml',0,0);_ai(oCe,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/cover-view/cover-view.maml',0,0);var oFe=_ctn("view");_setAttr(z,oFe,'class',0,e,s,gg);var oGe=_cvn();
    var oHe=_o(z,1,e,s,gg);
    var oIe=_gd('./macle_demo_EN/page/component/pages/cover-view/cover-view.maml',oHe,e_,d_);
    if(oIe){
      var oJe=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oIe(oJe,oJe,oGe,gg);
      gg.f=tgf;
    }else{
      _w(oHe,'./macle_demo_EN/page/component/pages/cover-view/cover-view.maml',0,0);
    }
    _ac(oFe,oGe);var oKe=_ctn("button");_setAttr(z,oKe,'bindtap',3,e,s,gg);var oLe=_o(z,4,e,s,gg);_ac(oKe,oLe);_ac(oFe,oKe);var oMe=_setAttrs(z,"camera",["binderror",5,"devicePosition",1,"flash",2,"style",3],e,s,gg);var oNe=_ctn("cover-view");_setAttr(z,oNe,'class',9,e,s,gg);var oOe=_ctn("cover-view");_setAttr(z,oOe,'class',10,e,s,gg);var oPe=_o(z,11,e,s,gg);_ac(oOe,oPe);_ac(oNe,oOe);var oQe=_ctn("cover-view");_setAttr(z,oQe,'class',12,e,s,gg);var oRe=_o(z,13,e,s,gg);_ac(oQe,oRe);_ac(oNe,oQe);var oSe=_ctn("cover-view");_setAttr(z,oSe,'class',14,e,s,gg);var oTe=_o(z,15,e,s,gg);_ac(oSe,oTe);_ac(oNe,oSe);_ac(oMe,oNe);_ac(oFe,oMe);var oUe=_cvn();
    var oVe=_o(z,16,e,s,gg);
    var oWe=_gd('./macle_demo_EN/page/component/pages/cover-view/cover-view.maml',oVe,e_,d_);
    if(oWe){
      var oXe={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oWe(oXe,oXe,oUe,gg);
      gg.f=tgf;
    }else{
      _w(oVe,'./macle_demo_EN/page/component/pages/cover-view/cover-view.maml',0,0);
    }
    _ac(oFe,oUe);_ac(r,oFe);oCe.pop();oCe.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/cover-view/cover-view.maml"]={f:m54,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/form/form.maml"]={};
  var m55=function(e,s,r,gg){
    var z=gz$gma_56()
    var oYe=e_["./macle_demo_EN/page/component/pages/form/form.maml"].i;_ai(oYe,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/form/form.maml',0,0);_ai(oYe,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/form/form.maml',0,0);var obe=_ctn("view");_setAttr(z,obe,'class',0,e,s,gg);var oce=_cvn();
    var ode=_o(z,1,e,s,gg);
    var oee=_gd('./macle_demo_EN/page/component/pages/form/form.maml',ode,e_,d_);
    if(oee){
      var ofe=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oee(ofe,ofe,oce,gg);
      gg.f=tgf;
    }else{
      _w(ode,'./macle_demo_EN/page/component/pages/form/form.maml',0,0);
    }
    _ac(obe,oce);var oge=_ctn("view");_setAttr(z,oge,'class',3,e,s,gg);var ohe=_setAttrs(z,"form",["bindreset",4,"bindsubmit",1,"id",2],e,s,gg);var oie=_ctn("view");_setAttr(z,oie,'class',7,e,s,gg);var oje=_ctn("view");_setAttr(z,oje,'class',8,e,s,gg);var oke=_o(z,9,e,s,gg);_ac(oje,oke);_ac(oie,oje);var ole=_setAttrs(z,"switch",["id",9,"name",0],e,s,gg);_ac(oie,ole);_ac(ohe,oie);var ome=_ctn("view");_setAttr(z,ome,'class',7,e,s,gg);var one=_ctn("view");_setAttr(z,one,'class',8,e,s,gg);var ooe=_o(z,10,e,s,gg);_ac(one,ooe);_ac(ome,one);var ope=_setAttrs(z,"radio-group",["name",10,"id",1],e,s,gg);var oqe=_ctn("label");var ore=_setAttrs(z,"radio",["id",12,"value",0],e,s,gg);_ac(oqe,ore);var ose=_o(z,13,e,s,gg);_ac(oqe,ose);_ac(ope,oqe);var ote=_ctn("label");var oue=_setAttrs(z,"radio",["id",14,"value",0],e,s,gg);_ac(ote,oue);var ove=_o(z,15,e,s,gg);_ac(ote,ove);_ac(ope,ote);_ac(ome,ope);_ac(ohe,ome);var owe=_ctn("view");_setAttr(z,owe,'class',7,e,s,gg);var oxe=_ctn("view");_setAttr(z,oxe,'class',8,e,s,gg);var oye=_o(z,16,e,s,gg);_ac(oxe,oye);_ac(owe,oxe);var oze=_setAttrs(z,"checkbox-group",["name",16,"id",1],e,s,gg);var o_e=_ctn("label");var oAf=_setAttrs(z,"checkbox",["id",18,"value",0],e,s,gg);_ac(o_e,oAf);var oBf=_o(z,13,e,s,gg);_ac(o_e,oBf);_ac(oze,o_e);var oCf=_ctn("label");var oDf=_setAttrs(z,"checkbox",["id",19,"value",0],e,s,gg);_ac(oCf,oDf);var oEf=_o(z,15,e,s,gg);_ac(oCf,oEf);_ac(oze,oCf);_ac(owe,oze);_ac(ohe,owe);var oFf=_ctn("view");_setAttr(z,oFf,'class',7,e,s,gg);var oGf=_ctn("view");_setAttr(z,oGf,'class',8,e,s,gg);var oHf=_o(z,20,e,s,gg);_ac(oGf,oHf);_ac(oFf,oGf);var oIf=_setAttrs(z,"slider",["name",20,"id",1,"showValue",2,"value",3],e,s,gg);_ac(oFf,oIf);_ac(ohe,oFf);var oJf=_ctn("view");_setAttr(z,oJf,'class',24,e,s,gg);var oKf=_ctn("view");_setAttr(z,oKf,'class',8,e,s,gg);var oLf=_o(z,25,e,s,gg);_ac(oKf,oLf);_ac(oJf,oKf);var oMf=_ctn("view");_setAttr(z,oMf,'class',26,e,s,gg);var oNf=_ctn("view");_setAttr(z,oNf,'class',27,e,s,gg);var oOf=_ctn("view");_setAttr(z,oOf,'class',28,e,s,gg);var oPf=_setAttrs(z,"input",["name",25,"class",4,"id",5,"placeholder",6],e,s,gg);_ac(oOf,oPf);_ac(oNf,oOf);_ac(oMf,oNf);_ac(oJf,oMf);_ac(ohe,oJf);var oQf=_ctn("view");_setAttr(z,oQf,'class',32,e,s,gg);var oRf=_setAttrs(z,"button",["formType",5,"id",0,"type",28],e,s,gg);var oSf=_o(z,34,e,s,gg);_ac(oRf,oSf);_ac(oQf,oRf);var oTf=_setAttrs(z,"button",["formType",4,"id",0],e,s,gg);var oUf=_o(z,35,e,s,gg);_ac(oTf,oUf);_ac(oQf,oTf);_ac(ohe,oQf);_ac(oge,ohe);_ac(obe,oge);var oVf=_cvn();
    var oWf=_o(z,36,e,s,gg);
    var oXf=_gd('./macle_demo_EN/page/component/pages/form/form.maml',oWf,e_,d_);
    if(oXf){
      var oYf={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oXf(oYf,oYf,oVf,gg);
      gg.f=tgf;
    }else{
      _w(oWf,'./macle_demo_EN/page/component/pages/form/form.maml',0,0);
    }
    _ac(obe,oVf);_ac(r,obe);oYe.pop();oYe.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/form/form.maml"]={f:m55,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/icon/icon.maml"]={};
  var m56=function(e,s,r,gg){
    var z=gz$gma_57()
    var oZf=e_["./macle_demo_EN/page/component/pages/icon/icon.maml"].i;_ai(oZf,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/icon/icon.maml',0,0);_ai(oZf,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/icon/icon.maml',0,0);var ocf=_ctn("view");_setAttr(z,ocf,'class',0,e,s,gg);var odf=_cvn();
    var oef=_o(z,1,e,s,gg);
    var off=_gd('./macle_demo_EN/page/component/pages/icon/icon.maml',oef,e_,d_);
    if(off){
      var ogf=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      off(ogf,ogf,odf,gg);
      gg.f=tgf;
    }else{
      _w(oef,'./macle_demo_EN/page/component/pages/icon/icon.maml',0,0);
    }
    _ac(ocf,odf);var ohf=_ctn("view");_setAttr(z,ohf,'class',3,e,s,gg);var oif=_setAttrs(z,"icon",["class",4,"size",1,"type",2],e,s,gg);_ac(ohf,oif);var ojf=_ctn("view");_setAttr(z,ojf,'class',7,e,s,gg);var okf=_ctn("view");_setAttr(z,okf,'class',8,e,s,gg);var olf=_o(z,6,e,s,gg);_ac(okf,olf);_ac(ojf,okf);var omf=_ctn("view");_setAttr(z,omf,'class',9,e,s,gg);var onf=_o(z,10,e,s,gg);_ac(omf,onf);_ac(ojf,omf);_ac(ohf,ojf);_ac(ocf,ohf);var oof=_ctn("view");_setAttr(z,oof,'class',3,e,s,gg);var opf=_setAttrs(z,"icon",["size",5,"class",6,"type",7],e,s,gg);_ac(oof,opf);var oqf=_ctn("view");_setAttr(z,oqf,'class',7,e,s,gg);var orf=_ctn("view");_setAttr(z,orf,'class',8,e,s,gg);var osf=_o(z,12,e,s,gg);_ac(orf,osf);_ac(oqf,orf);var otf=_ctn("view");_setAttr(z,otf,'class',9,e,s,gg);var ouf=_o(z,13,e,s,gg);_ac(otf,ouf);_ac(oqf,otf);_ac(oof,oqf);_ac(ocf,oof);var ovf=_ctn("view");_setAttr(z,ovf,'class',3,e,s,gg);var owf=_setAttrs(z,"icon",["size",5,"class",9,"color",10,"type",11],e,s,gg);_ac(ovf,owf);var oxf=_ctn("view");_setAttr(z,oxf,'class',7,e,s,gg);var oyf=_ctn("view");_setAttr(z,oyf,'class',8,e,s,gg);var ozf=_o(z,16,e,s,gg);_ac(oyf,ozf);_ac(oxf,oyf);var o_f=_ctn("view");_setAttr(z,o_f,'class',9,e,s,gg);var oAg=_o(z,17,e,s,gg);_ac(o_f,oAg);_ac(oxf,o_f);_ac(ovf,oxf);_ac(ocf,ovf);var oBg=_ctn("view");_setAttr(z,oBg,'class',3,e,s,gg);var oCg=_setAttrs(z,"icon",["size",5,"type",11,"class",13],e,s,gg);_ac(oBg,oCg);var oDg=_ctn("view");_setAttr(z,oDg,'class',7,e,s,gg);var oEg=_ctn("view");_setAttr(z,oEg,'class',8,e,s,gg);var oFg=_o(z,19,e,s,gg);_ac(oEg,oFg);_ac(oDg,oEg);var oGg=_ctn("view");_setAttr(z,oGg,'class',9,e,s,gg);var oHg=_o(z,20,e,s,gg);_ac(oGg,oHg);_ac(oDg,oGg);_ac(oBg,oDg);_ac(ocf,oBg);var oIg=_ctn("view");_setAttr(z,oIg,'class',3,e,s,gg);var oJg=_setAttrs(z,"icon",["size",5,"class",16,"type",17],e,s,gg);_ac(oIg,oJg);var oKg=_ctn("view");_setAttr(z,oKg,'class',7,e,s,gg);var oLg=_ctn("view");_setAttr(z,oLg,'class',8,e,s,gg);var oMg=_o(z,22,e,s,gg);_ac(oLg,oMg);_ac(oKg,oLg);var oNg=_ctn("view");_setAttr(z,oNg,'class',9,e,s,gg);var oOg=_o(z,23,e,s,gg);_ac(oNg,oOg);_ac(oKg,oNg);_ac(oIg,oKg);_ac(ocf,oIg);var oPg=_ctn("view");_setAttr(z,oPg,'class',3,e,s,gg);var oQg=_ctn("view");_setAttr(z,oQg,'class',24,e,s,gg);var oRg=_setAttrs(z,"icon",["type",6,"class",19,"size",20],e,s,gg);_ac(oQg,oRg);_ac(oPg,oQg);var oSg=_ctn("view");_setAttr(z,oSg,'class',7,e,s,gg);var oTg=_ctn("view");_setAttr(z,oTg,'class',8,e,s,gg);var oUg=_o(z,27,e,s,gg);_ac(oTg,oUg);_ac(oSg,oTg);var oVg=_ctn("view");_setAttr(z,oVg,'class',9,e,s,gg);var oWg=_o(z,28,e,s,gg);_ac(oVg,oWg);_ac(oSg,oVg);_ac(oPg,oSg);_ac(ocf,oPg);var oXg=_ctn("view");_setAttr(z,oXg,'class',3,e,s,gg);var oYg=_ctn("view");_setAttr(z,oYg,'class',24,e,s,gg);var oZg=_setAttrs(z,"icon",["size",26,"class",3,"type",4],e,s,gg);_ac(oYg,oZg);_ac(oXg,oYg);var oag=_ctn("view");_setAttr(z,oag,'class',7,e,s,gg);var obg=_ctn("view");_setAttr(z,obg,'class',8,e,s,gg);var ocg=_o(z,31,e,s,gg);_ac(obg,ocg);_ac(oag,obg);var odg=_ctn("view");_setAttr(z,odg,'class',9,e,s,gg);var oeg=_o(z,32,e,s,gg);_ac(odg,oeg);_ac(oag,odg);_ac(oXg,oag);_ac(ocf,oXg);var ofg=_ctn("view");_setAttr(z,ofg,'class',3,e,s,gg);var ogg=_ctn("view");_setAttr(z,ogg,'class',24,e,s,gg);var ohg=_setAttrs(z,"icon",["type",16,"class",9,"size",10],e,s,gg);_ac(ogg,ohg);_ac(ofg,ogg);var oig=_ctn("view");_setAttr(z,oig,'class',7,e,s,gg);var ojg=_ctn("view");_setAttr(z,ojg,'class',8,e,s,gg);var okg=_o(z,33,e,s,gg);_ac(ojg,okg);_ac(oig,ojg);var olg=_ctn("view");_setAttr(z,olg,'class',9,e,s,gg);var omg=_o(z,34,e,s,gg);_ac(olg,omg);_ac(oig,olg);_ac(ofg,oig);_ac(ocf,ofg);var ong=_ctn("view");_setAttr(z,ong,'class',3,e,s,gg);var oog=_ctn("view");_setAttr(z,oog,'class',24,e,s,gg);var opg=_setAttrs(z,"icon",["size",26,"class",9,"type",10],e,s,gg);_ac(oog,opg);_ac(ong,oog);var oqg=_ctn("view");_setAttr(z,oqg,'class',7,e,s,gg);var org=_ctn("view");_setAttr(z,org,'class',8,e,s,gg);var osg=_o(z,37,e,s,gg);_ac(org,osg);_ac(oqg,org);var otg=_ctn("view");_setAttr(z,otg,'class',9,e,s,gg);var oug=_o(z,38,e,s,gg);_ac(otg,oug);_ac(oqg,otg);_ac(ong,oqg);_ac(ocf,ong);var ovg=_ctn("view");_setAttr(z,ovg,'class',3,e,s,gg);var owg=_ctn("view");_setAttr(z,owg,'class',24,e,s,gg);var oxg=_setAttrs(z,"icon",["size",26,"class",13,"type",14],e,s,gg);_ac(owg,oxg);_ac(ovg,owg);var oyg=_ctn("view");_setAttr(z,oyg,'class',7,e,s,gg);var ozg=_ctn("view");_setAttr(z,ozg,'class',8,e,s,gg);var o_g=_o(z,40,e,s,gg);_ac(ozg,o_g);_ac(oyg,ozg);var oAh=_ctn("view");_setAttr(z,oAh,'class',9,e,s,gg);var oBh=_o(z,41,e,s,gg);_ac(oAh,oBh);_ac(oyg,oAh);_ac(ovg,oyg);_ac(ocf,ovg);var oCh=_ctn("view");_setAttr(z,oCh,'class',3,e,s,gg);var oDh=_ctn("view");_setAttr(z,oDh,'class',24,e,s,gg);var oEh=_setAttrs(z,"icon",["size",26,"class",16,"type",17],e,s,gg);_ac(oDh,oEh);_ac(oCh,oDh);var oFh=_ctn("view");_setAttr(z,oFh,'class',7,e,s,gg);var oGh=_ctn("view");_setAttr(z,oGh,'class',8,e,s,gg);var oHh=_o(z,43,e,s,gg);_ac(oGh,oHh);_ac(oFh,oGh);var oIh=_ctn("view");_setAttr(z,oIh,'class',9,e,s,gg);var oJh=_o(z,44,e,s,gg);_ac(oIh,oJh);_ac(oFh,oIh);_ac(oCh,oFh);_ac(ocf,oCh);var oKh=_ctn("view");_setAttr(z,oKh,'class',3,e,s,gg);var oLh=_ctn("view");_setAttr(z,oLh,'class',24,e,s,gg);var oMh=_setAttrs(z,"icon",["size",26,"class",19,"type",20],e,s,gg);_ac(oLh,oMh);_ac(oKh,oLh);var oNh=_ctn("view");_setAttr(z,oNh,'class',7,e,s,gg);var oOh=_ctn("view");_setAttr(z,oOh,'class',8,e,s,gg);var oPh=_o(z,47,e,s,gg);_ac(oOh,oPh);_ac(oNh,oOh);var oQh=_ctn("view");_setAttr(z,oQh,'class',9,e,s,gg);var oRh=_o(z,48,e,s,gg);_ac(oQh,oRh);_ac(oNh,oQh);_ac(oKh,oNh);_ac(ocf,oKh);var oSh=_ctn("view");_setAttr(z,oSh,'class',3,e,s,gg);var oTh=_ctn("view");_setAttr(z,oTh,'class',24,e,s,gg);var oUh=_setAttrs(z,"icon",["class",49,"size",1,"type",2],e,s,gg);_ac(oTh,oUh);_ac(oSh,oTh);var oVh=_ctn("view");_setAttr(z,oVh,'class',7,e,s,gg);var oWh=_ctn("view");_setAttr(z,oWh,'class',8,e,s,gg);var oXh=_o(z,51,e,s,gg);_ac(oWh,oXh);_ac(oVh,oWh);var oYh=_ctn("view");_setAttr(z,oYh,'class',9,e,s,gg);var oZh=_o(z,52,e,s,gg);_ac(oYh,oZh);_ac(oVh,oYh);_ac(oSh,oVh);_ac(ocf,oSh);var oah=_cvn();
    var obh=_o(z,53,e,s,gg);
    var och=_gd('./macle_demo_EN/page/component/pages/icon/icon.maml',obh,e_,d_);
    if(och){
      var odh={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      och(odh,odh,oah,gg);
      gg.f=tgf;
    }else{
      _w(obh,'./macle_demo_EN/page/component/pages/icon/icon.maml',0,0);
    }
    _ac(ocf,oah);_ac(r,ocf);oZf.pop();oZf.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/icon/icon.maml"]={f:m56,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/image/image.maml"]={};
  var m57=function(e,s,r,gg){
    var z=gz$gma_58()
    var oeh=e_["./macle_demo_EN/page/component/pages/image/image.maml"].i;_ai(oeh,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/image/image.maml',0,0);_ai(oeh,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/image/image.maml',0,0);var ohh=_ctn("view");_setAttr(z,ohh,'class',0,e,s,gg);var oih=_cvn();
    var ojh=_o(z,1,e,s,gg);
    var okh=_gd('./macle_demo_EN/page/component/pages/image/image.maml',ojh,e_,d_);
    if(okh){
      var olh=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      okh(olh,olh,oih,gg);
      gg.f=tgf;
    }else{
      _w(ojh,'./macle_demo_EN/page/component/pages/image/image.maml',0,0);
    }
    _ac(ohh,oih);var omh=_ctn("view");_setAttr(z,omh,'class',3,e,s,gg);var onh=_cvn();var ooh=function(osh,orh,oqh,gg){var oph=_ctn("view");_setAttr(z,oph,'class',6,osh,orh,gg);var ouh=_ctn("view");_setAttr(z,ouh,'class',7,osh,orh,gg);var ovh=_o(z,8,osh,orh,gg);_ac(ouh,ovh);_ac(oph,ouh);var owh=_ctn("view");_setAttr(z,owh,'class',9,osh,orh,gg);var oxh=_setAttrs(z,"image",["binderror",10,"bindload",1,"class",2,"mode",3,"src",4],osh,orh,gg);_ac(owh,oxh);_ac(oph,owh);_ac(oqh,oph);return oqh;};_2(z,4,ooh,e,s,gg,onh,"item","index",'');_ac(omh,onh);var oyh=_ctn("view");_setAttr(z,oyh,'class',6,e,s,gg);var ozh=_ctn("view");_setAttr(z,ozh,'class',7,e,s,gg);var o_h=_o(z,15,e,s,gg);_ac(ozh,o_h);_ac(oyh,ozh);var oAi=_ctn("view");_setAttr(z,oAi,'class',9,e,s,gg);var oBi=_setAttrs(z,"image",["binderror",10,"bindload",1,"src",4,"class",6,"mode",7],e,s,gg);_ac(oAi,oBi);_ac(oyh,oAi);_ac(omh,oyh);var oCi=_ctn("view");_setAttr(z,oCi,'class',6,e,s,gg);var oDi=_ctn("view");_setAttr(z,oDi,'class',7,e,s,gg);var oEi=_o(z,18,e,s,gg);_ac(oDi,oEi);_ac(oCi,oDi);var oFi=_ctn("view");_setAttr(z,oFi,'class',9,e,s,gg);var oGi=_setAttrs(z,"image",["src",14,"class",5,"mode",6],e,s,gg);_ac(oFi,oGi);_ac(oCi,oFi);_ac(omh,oCi);_ac(ohh,omh);var oHi=_cvn();
    var oIi=_o(z,21,e,s,gg);
    var oJi=_gd('./macle_demo_EN/page/component/pages/image/image.maml',oIi,e_,d_);
    if(oJi){
      var oKi={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oJi(oKi,oKi,oHi,gg);
      gg.f=tgf;
    }else{
      _w(oIi,'./macle_demo_EN/page/component/pages/image/image.maml',0,0);
    }
    _ac(ohh,oHi);_ac(r,ohh);oeh.pop();oeh.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/image/image.maml"]={f:m57,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/input/input.maml"]={};
  var m58=function(e,s,r,gg){
    var z=gz$gma_59()
    var oLi=e_["./macle_demo_EN/page/component/pages/input/input.maml"].i;_ai(oLi,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/input/input.maml',0,0);_ai(oLi,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/input/input.maml',0,0);var oOi=_ctn("view");_setAttr(z,oOi,'class',0,e,s,gg);var oPi=_cvn();
    var oQi=_o(z,1,e,s,gg);
    var oRi=_gd('./macle_demo_EN/page/component/pages/input/input.maml',oQi,e_,d_);
    if(oRi){
      var oSi=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oRi(oSi,oSi,oPi,gg);
      gg.f=tgf;
    }else{
      _w(oQi,'./macle_demo_EN/page/component/pages/input/input.maml',0,0);
    }
    _ac(oOi,oPi);var oTi=_ctn("view");_setAttr(z,oTi,'class',3,e,s,gg);var oUi=_ctn("view");_setAttr(z,oUi,'class',4,e,s,gg);var oVi=_ctn("view");_setAttr(z,oVi,'class',5,e,s,gg);var oWi=_o(z,6,e,s,gg);_ac(oVi,oWi);_ac(oUi,oVi);var oXi=_ctn("view");_setAttr(z,oXi,'class',7,e,s,gg);var oYi=_ctn("view");_setAttr(z,oYi,'class',8,e,s,gg);var oZi=_setAttrs(z,"input",["class",9,"disabled",1,"value",2],e,s,gg);_ac(oYi,oZi);_ac(oXi,oYi);_ac(oUi,oXi);_ac(oTi,oUi);var oai=_ctn("view");_setAttr(z,oai,'class',4,e,s,gg);var obi=_ctn("view");_setAttr(z,obi,'class',5,e,s,gg);var oci=_o(z,12,e,s,gg);_ac(obi,oci);_ac(oai,obi);var odi=_ctn("view");_setAttr(z,odi,'class',7,e,s,gg);var oei=_ctn("view");_setAttr(z,oei,'class',8,e,s,gg);var ofi=_setAttrs(z,"input",["adjustPosition",10,"confirmHold",0,"focus",0,"bindblur",3,"bindconfirm",4,"bindfocus",5,"class",6,"confirmType",7,"placeholder",8,"selectionEnd",9,"selectionStart",10,"value",11],e,s,gg);_ac(oei,ofi);_ac(odi,oei);_ac(oai,odi);_ac(oTi,oai);var ogi=_ctn("view");_setAttr(z,ogi,'class',4,e,s,gg);var ohi=_ctn("view");_setAttr(z,ohi,'class',5,e,s,gg);var oii=_o(z,22,e,s,gg);_ac(ohi,oii);_ac(ogi,ohi);var oji=_ctn("view");_setAttr(z,oji,'class',7,e,s,gg);var oki=_ctn("view");_setAttr(z,oki,'class',8,e,s,gg);var oli=_setAttrs(z,"input",["bindblur",13,"bindconfirm",1,"bindfocus",2,"class",10,"maxlength",11,"placeholder",12,"value",13],e,s,gg);_ac(oki,oli);_ac(oji,oki);_ac(ogi,oji);_ac(oTi,ogi);var omi=_ctn("view");_setAttr(z,omi,'class',4,e,s,gg);var oni=_ctn("view");_setAttr(z,oni,'class',27,e,s,gg);var ooi=_o(z,28,e,s,gg);_ac(oni,ooi);_ac(omi,oni);var opi=_ctn("view");_setAttr(z,opi,'class',7,e,s,gg);var oqi=_ctn("view");_setAttr(z,oqi,'class',8,e,s,gg);var ori=_setAttrs(z,"input",["bindinput",29,"class",1,"placeholder",2],e,s,gg);_ac(oqi,ori);_ac(opi,oqi);_ac(omi,opi);_ac(oTi,omi);var osi=_ctn("view");_setAttr(z,osi,'class',4,e,s,gg);var oti=_ctn("view");_setAttr(z,oti,'class',5,e,s,gg);var oui=_o(z,32,e,s,gg);_ac(oti,oui);_ac(osi,oti);var ovi=_ctn("view");_setAttr(z,ovi,'class',7,e,s,gg);var owi=_ctn("view");_setAttr(z,owi,'class',8,e,s,gg);var oxi=_setAttrs(z,"input",["bindinput",33,"class",1,"placeholder",2],e,s,gg);_ac(owi,oxi);_ac(ovi,owi);_ac(osi,ovi);_ac(oTi,osi);var oyi=_ctn("view");_setAttr(z,oyi,'class',4,e,s,gg);var ozi=_ctn("view");_setAttr(z,ozi,'class',5,e,s,gg);var o_i=_o(z,36,e,s,gg);_ac(ozi,o_i);_ac(oyi,ozi);var oAj=_ctn("view");_setAttr(z,oAj,'class',7,e,s,gg);var oBj=_ctn("view");_setAttr(z,oBj,'class',8,e,s,gg);var oCj=_setAttrs(z,"input",["bindinput",37,"class",1,"placeholder",2,"type",3],e,s,gg);_ac(oBj,oCj);_ac(oAj,oBj);_ac(oyi,oAj);_ac(oTi,oyi);var oDj=_ctn("view");_setAttr(z,oDj,'class',4,e,s,gg);var oEj=_ctn("view");_setAttr(z,oEj,'class',5,e,s,gg);var oFj=_o(z,41,e,s,gg);_ac(oEj,oFj);_ac(oDj,oEj);var oGj=_ctn("view");_setAttr(z,oGj,'class',7,e,s,gg);var oHj=_ctn("view");_setAttr(z,oHj,'class',8,e,s,gg);var oIj=_setAttrs(z,"input",["class",42,"placeholder",1,"type",2],e,s,gg);_ac(oHj,oIj);_ac(oGj,oHj);_ac(oDj,oGj);_ac(oTi,oDj);var oJj=_ctn("view");_setAttr(z,oJj,'class',4,e,s,gg);var oKj=_ctn("view");_setAttr(z,oKj,'class',5,e,s,gg);var oLj=_o(z,45,e,s,gg);_ac(oKj,oLj);_ac(oJj,oKj);var oMj=_ctn("view");_setAttr(z,oMj,'class',7,e,s,gg);var oNj=_ctn("view");_setAttr(z,oNj,'class',8,e,s,gg);var oOj=_setAttrs(z,"input",["password",10,"class",36,"placeholder",37,"type",38],e,s,gg);_ac(oNj,oOj);_ac(oMj,oNj);_ac(oJj,oMj);_ac(oTi,oJj);var oPj=_ctn("view");_setAttr(z,oPj,'class',4,e,s,gg);var oQj=_ctn("view");_setAttr(z,oQj,'class',5,e,s,gg);var oRj=_o(z,49,e,s,gg);_ac(oQj,oRj);_ac(oPj,oQj);var oSj=_ctn("view");_setAttr(z,oSj,'class',7,e,s,gg);var oTj=_ctn("view");_setAttr(z,oTj,'class',8,e,s,gg);var oUj=_setAttrs(z,"input",["bindblur",13,"bindfocus",2,"class",37,"placeholder",38,"placeholderClass",39,"placeholderStyle",40],e,s,gg);_ac(oTj,oUj);_ac(oSj,oTj);_ac(oPj,oSj);_ac(oTi,oPj);var oVj=_ctn("view");_setAttr(z,oVj,'class',4,e,s,gg);var oWj=_ctn("view");_setAttr(z,oWj,'class',5,e,s,gg);var oXj=_o(z,54,e,s,gg);_ac(oWj,oXj);_ac(oVj,oWj);var oYj=_ctn("view");_setAttr(z,oYj,'class',7,e,s,gg);var oZj=_ctn("view");_setAttr(z,oZj,'class',8,e,s,gg);var oaj=_setAttrs(z,"input",["confirmHold",10,"type",38,"class",45,"placeholder",46],e,s,gg);_ac(oZj,oaj);_ac(oYj,oZj);_ac(oVj,oYj);_ac(oTi,oVj);var obj=_ctn("view");_setAttr(z,obj,'class',4,e,s,gg);var ocj=_ctn("view");_setAttr(z,ocj,'class',57,e,s,gg);var odj=_o(z,58,e,s,gg);_ac(ocj,odj);_ac(obj,ocj);var oej=_ctn("view");_setAttr(z,oej,'class',7,e,s,gg);var ofj=_ctn("view");_setAttr(z,ofj,'class',8,e,s,gg);var ogj=_setAttrs(z,"input",["class",59,"value",1],e,s,gg);ogj.rawAttr={"model:value":"{{modelValue}}"};_ac(ofj,ogj);_ac(oej,ofj);_ac(obj,oej);_ac(oTi,obj);_ac(oOi,oTi);var ohj=_ctn("view");_setAttr(z,ohj,'class',4,e,s,gg);var oij=_ctn("view");_setAttr(z,oij,'class',57,e,s,gg);var ojj=_o(z,61,e,s,gg);_ac(oij,ojj);_ac(ohj,oij);var okj=_ctn("view");_setAttr(z,okj,'class',7,e,s,gg);var olj=_ctn("view");_setAttr(z,olj,'class',8,e,s,gg);var omj=_setAttrs(z,"input",["placeholder",61,"class",1,"type",2],e,s,gg);_ac(olj,omj);_ac(okj,olj);_ac(ohj,okj);_ac(oOi,ohj);var onj=_ctn("view");_setAttr(z,onj,'class',4,e,s,gg);var ooj=_ctn("view");_setAttr(z,ooj,'class',57,e,s,gg);var opj=_o(z,64,e,s,gg);_ac(ooj,opj);_ac(onj,ooj);var oqj=_ctn("view");_setAttr(z,oqj,'class',7,e,s,gg);var orj=_ctn("view");_setAttr(z,orj,'class',8,e,s,gg);var osj=_setAttrs(z,"input",["placeholder",64,"class",1,"type",2],e,s,gg);_ac(orj,osj);_ac(oqj,orj);_ac(onj,oqj);_ac(oOi,onj);var otj=_ctn("view");_setAttr(z,otj,'class',4,e,s,gg);var ouj=_ctn("view");_setAttr(z,ouj,'class',57,e,s,gg);var ovj=_o(z,67,e,s,gg);_ac(ouj,ovj);_ac(otj,ouj);var owj=_ctn("view");_setAttr(z,owj,'class',7,e,s,gg);var oxj=_ctn("view");_setAttr(z,oxj,'class',8,e,s,gg);var oyj=_setAttrs(z,"input",["placeholder",67,"class",1,"type",2],e,s,gg);_ac(oxj,oyj);_ac(owj,oxj);_ac(otj,owj);_ac(oOi,otj);var ozj=_ctn("view");_setAttr(z,ozj,'class',4,e,s,gg);var o_j=_ctn("view");_setAttr(z,o_j,'class',57,e,s,gg);var oAk=_o(z,70,e,s,gg);_ac(o_j,oAk);_ac(ozj,o_j);var oBk=_ctn("view");_setAttr(z,oBk,'class',7,e,s,gg);var oCk=_ctn("view");_setAttr(z,oCk,'class',8,e,s,gg);var oDk=_setAttrs(z,"input",["type",48,"class",23,"confirmType",24,"placeholder",25,"placeholderStyle",26],e,s,gg);_ac(oCk,oDk);_ac(oBk,oCk);_ac(ozj,oBk);_ac(oOi,ozj);var oEk=_ctn("view");_setAttr(z,oEk,'class',4,e,s,gg);var oFk=_ctn("view");_setAttr(z,oFk,'class',57,e,s,gg);var oGk=_o(z,75,e,s,gg);_ac(oFk,oGk);_ac(oEk,oFk);var oHk=_ctn("view");_setAttr(z,oHk,'class',7,e,s,gg);var oIk=_ctn("view");_setAttr(z,oIk,'class',8,e,s,gg);var oJk=_setAttrs(z,"input",["type",48,"class",28,"confirmType",29,"placeholder",30],e,s,gg);_ac(oIk,oJk);_ac(oHk,oIk);_ac(oEk,oHk);_ac(oOi,oEk);var oKk=_ctn("view");_setAttr(z,oKk,'class',4,e,s,gg);var oLk=_ctn("view");_setAttr(z,oLk,'class',57,e,s,gg);var oMk=_o(z,79,e,s,gg);_ac(oLk,oMk);_ac(oKk,oLk);var oNk=_ctn("view");_setAttr(z,oNk,'class',7,e,s,gg);var oOk=_ctn("view");_setAttr(z,oOk,'class',8,e,s,gg);var oPk=_setAttrs(z,"input",["type",48,"placeholderClass",4,"class",32,"confirmType",33,"placeholder",34],e,s,gg);_ac(oOk,oPk);_ac(oNk,oOk);_ac(oKk,oNk);_ac(oOi,oKk);var oQk=_ctn("view");_setAttr(z,oQk,'class',4,e,s,gg);var oRk=_ctn("view");_setAttr(z,oRk,'class',57,e,s,gg);var oSk=_o(z,83,e,s,gg);_ac(oRk,oSk);_ac(oQk,oRk);var oTk=_ctn("view");_setAttr(z,oTk,'class',7,e,s,gg);var oUk=_ctn("view");_setAttr(z,oUk,'class',8,e,s,gg);var oVk=_setAttrs(z,"input",["class",16,"type",32,"placeholderClass",36,"confirmType",68,"placeholder",69],e,s,gg);_ac(oUk,oVk);_ac(oTk,oUk);_ac(oQk,oTk);_ac(oOi,oQk);var oWk=_ctn("view");_setAttr(z,oWk,'class',4,e,s,gg);var oXk=_ctn("view");_setAttr(z,oXk,'class',57,e,s,gg);var oYk=_o(z,86,e,s,gg);_ac(oXk,oYk);_ac(oWk,oXk);var oZk=_ctn("view");_setAttr(z,oZk,'class',7,e,s,gg);var oak=_ctn("view");_setAttr(z,oak,'class',8,e,s,gg);var obk=_setAttrs(z,"input",["confirmType",17,"type",31,"placeholderClass",35,"adjustPosition",70,"class",71,"cursor",72,"placeholder",73],e,s,gg);_ac(oak,obk);_ac(oZk,oak);_ac(oWk,oZk);_ac(oOi,oWk);var ock=_cvn();
    var odk=_o(z,91,e,s,gg);
    var oek=_gd('./macle_demo_EN/page/component/pages/input/input.maml',odk,e_,d_);
    if(oek){
      var ofk={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oek(ofk,ofk,ock,gg);
      gg.f=tgf;
    }else{
      _w(odk,'./macle_demo_EN/page/component/pages/input/input.maml',0,0);
    }
    _ac(oOi,ock);_ac(r,oOi);oLi.pop();oLi.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/input/input.maml"]={f:m58,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/label/label.maml"]={};
  var m59=function(e,s,r,gg){
    var z=gz$gma_60()
    var ogk=e_["./macle_demo_EN/page/component/pages/label/label.maml"].i;_ai(ogk,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/label/label.maml',0,0);_ai(ogk,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/label/label.maml',0,0);var ojk=_ctn("view");_setAttr(z,ojk,'class',0,e,s,gg);var okk=_cvn();
    var olk=_o(z,1,e,s,gg);
    var omk=_gd('./macle_demo_EN/page/component/pages/label/label.maml',olk,e_,d_);
    if(omk){
      var onk=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      omk(onk,onk,okk,gg);
      gg.f=tgf;
    }else{
      _w(olk,'./macle_demo_EN/page/component/pages/label/label.maml',0,0);
    }
    _ac(ojk,okk);var ook=_ctn("view");_setAttr(z,ook,'class',3,e,s,gg);var opk=_ctn("view");_setAttr(z,opk,'class',4,e,s,gg);var oqk=_ctn("view");_setAttr(z,oqk,'class',5,e,s,gg);var ork=_o(z,6,e,s,gg);_ac(oqk,ork);_ac(opk,oqk);var osk=_setAttrs(z,"checkbox-group",["bindchange",7,"class",1,"id",2],e,s,gg);var otk=_cvn();var ouk=function(oyk,oxk,owk,gg){var ovk=_ctn("view");_setAttr(z,ovk,'class',11,oyk,oxk,gg);var o_k=_ctn("label");_setAttr(z,o_k,'id',12,oyk,oxk,gg);var oAl=_setAttrs(z,"checkbox",["checked",13,"id",1,"value",2],oyk,oxk,gg);_ac(o_k,oAl);var oBl=_ctn("text");_setAttr(z,oBl,'class',16,oyk,oxk,gg);var oCl=_o(z,17,oyk,oxk,gg);_ac(oBl,oCl);_ac(o_k,oBl);_ac(ovk,o_k);_ac(owk,ovk);return owk;};_2(z,10,ouk,e,s,gg,otk,"item","index",'');_ac(osk,otk);_ac(opk,osk);_ac(ook,opk);var oDl=_ctn("view");_setAttr(z,oDl,'class',4,e,s,gg);var oEl=_ctn("view");_setAttr(z,oEl,'class',5,e,s,gg);var oFl=_o(z,18,e,s,gg);_ac(oEl,oFl);_ac(oDl,oEl);var oGl=_setAttrs(z,"radio-group",["class",8,"bindchange",11,"id",12],e,s,gg);var oHl=_cvn();var oIl=function(oMl,oLl,oKl,gg){var oJl=_ctn("view");_setAttr(z,oJl,'class',22,oMl,oLl,gg);var oOl=_setAttrs(z,"radio",["checked",13,"id",2,"value",2,"color",10],oMl,oLl,gg);_ac(oJl,oOl);var oPl=_setAttrs(z,"label",["for",15,"class",9],oMl,oLl,gg);var oQl=_ctn("text");_setAttr(z,oQl,'id',25,oMl,oLl,gg);var oRl=_o(z,26,oMl,oLl,gg);_ac(oQl,oRl);_ac(oPl,oQl);_ac(oJl,oPl);_ac(oKl,oJl);return oKl;};_2(z,21,oIl,e,s,gg,oHl,"item","index",'');_ac(oGl,oHl);_ac(oDl,oGl);_ac(ook,oDl);var oSl=_ctn("view");_setAttr(z,oSl,'class',4,e,s,gg);var oTl=_ctn("view");_setAttr(z,oTl,'class',5,e,s,gg);var oUl=_o(z,27,e,s,gg);_ac(oTl,oUl);_ac(oSl,oTl);var oVl=_ctn("label");_setAttr(z,oVl,'class',28,e,s,gg);var oWl=_setAttrs(z,"checkbox",["class",29,"id",1],e,s,gg);var oXl=_o(z,31,e,s,gg);_ac(oWl,oXl);_ac(oVl,oWl);var oYl=_setAttrs(z,"checkbox",["class",29,"id",3],e,s,gg);var oZl=_o(z,31,e,s,gg);_ac(oYl,oZl);_ac(oVl,oYl);var oal=_ctn("view");_setAttr(z,oal,'class',33,e,s,gg);var obl=_o(z,34,e,s,gg);_ac(oal,obl);_ac(oVl,oal);_ac(oSl,oVl);_ac(ook,oSl);_ac(ojk,ook);var ocl=_cvn();
    var odl=_o(z,35,e,s,gg);
    var oel=_gd('./macle_demo_EN/page/component/pages/label/label.maml',odl,e_,d_);
    if(oel){
      var ofl={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oel(ofl,ofl,ocl,gg);
      gg.f=tgf;
    }else{
      _w(odl,'./macle_demo_EN/page/component/pages/label/label.maml',0,0);
    }
    _ac(ojk,ocl);_ac(r,ojk);ogk.pop();ogk.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/label/label.maml"]={f:m59,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/navigator/navigate.maml"]={};
  var m60=function(e,s,r,gg){
    var z=gz$gma_61()
    var ogl=e_["./macle_demo_EN/page/component/pages/navigator/navigate.maml"].i;_ai(ogl,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/navigator/navigate.maml',0,0);_ai(ogl,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/navigator/navigate.maml',0,0);var ojl=_ctn("view");_setAttr(z,ojl,'class',0,e,s,gg);var okl=_cvn();
    var oll=_o(z,1,e,s,gg);
    var oml=_gd('./macle_demo_EN/page/component/pages/navigator/navigate.maml',oll,e_,d_);
    if(oml){
      var onl=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oml(onl,onl,okl,gg);
      gg.f=tgf;
    }else{
      _w(oll,'./macle_demo_EN/page/component/pages/navigator/navigate.maml',0,0);
    }
    _ac(ojl,okl);var ool=_ctn("view");_setAttr(z,ool,'class',3,e,s,gg);var opl=_setAttrs(z,"text",["class",4,"decode",1,"selectable",1,"space",1],e,s,gg);var oql=_o(z,6,e,s,gg);_ac(opl,oql);_ac(ool,opl);var orl=_ctn("view");_setAttr(z,orl,'class',7,e,s,gg);var osl=_setAttrs(z,"navigator",["delta",8,"hoverClass",1,"openType",2],e,s,gg);var otl=_ctn("button");_setAttr(z,otl,'type',11,e,s,gg);var oul=_o(z,12,e,s,gg);_ac(otl,oul);_ac(osl,otl);_ac(orl,osl);_ac(ool,orl);_ac(ojl,ool);var ovl=_cvn();
    var owl=_o(z,13,e,s,gg);
    var oxl=_gd('./macle_demo_EN/page/component/pages/navigator/navigate.maml',owl,e_,d_);
    if(oxl){
      var oyl={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oxl(oyl,oyl,ovl,gg);
      gg.f=tgf;
    }else{
      _w(owl,'./macle_demo_EN/page/component/pages/navigator/navigate.maml',0,0);
    }
    _ac(ojl,ovl);_ac(r,ojl);ogl.pop();ogl.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/navigator/navigate.maml"]={f:m60,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/navigator/navigator.maml"]={};
  var m61=function(e,s,r,gg){
    var z=gz$gma_62()
    var ozl=e_["./macle_demo_EN/page/component/pages/navigator/navigator.maml"].i;_ai(ozl,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/navigator/navigator.maml',0,0);_ai(ozl,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/navigator/navigator.maml',0,0);var oBm=_ctn("view");_setAttr(z,oBm,'class',0,e,s,gg);var oCm=_cvn();
    var oDm=_o(z,1,e,s,gg);
    var oEm=_gd('./macle_demo_EN/page/component/pages/navigator/navigator.maml',oDm,e_,d_);
    if(oEm){
      var oFm=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oEm(oFm,oFm,oCm,gg);
      gg.f=tgf;
    }else{
      _w(oDm,'./macle_demo_EN/page/component/pages/navigator/navigator.maml',0,0);
    }
    _ac(oBm,oCm);var oGm=_ctn("view");_setAttr(z,oGm,'class',3,e,s,gg);var oHm=_ctn("view");_setAttr(z,oHm,'class',4,e,s,gg);var oIm=_setAttrs(z,"navigator",["class",5,"url",1],e,s,gg);var oJm=_ctn("button");_setAttr(z,oJm,'type',7,e,s,gg);var oKm=_o(z,8,e,s,gg);_ac(oJm,oKm);_ac(oIm,oJm);_ac(oHm,oIm);var oLm=_setAttrs(z,"navigator",["class",5,"hoverClass",4,"openType",5,"url",5],e,s,gg);var oMm=_ctn("button");_setAttr(z,oMm,'type',7,e,s,gg);var oNm=_o(z,11,e,s,gg);_ac(oMm,oNm);_ac(oLm,oMm);_ac(oHm,oLm);var oOm=_setAttrs(z,"navigator",["class",5,"hoverClass",7,"openType",8,"url",9],e,s,gg);var oPm=_ctn("button");_setAttr(z,oPm,'type',7,e,s,gg);var oQm=_o(z,13,e,s,gg);_ac(oPm,oQm);_ac(oOm,oPm);_ac(oHm,oOm);var oRm=_setAttrs(z,"navigator",["class",5,"openType",10,"url",10],e,s,gg);var oSm=_ctn("button");_setAttr(z,oSm,'type',7,e,s,gg);var oTm=_o(z,16,e,s,gg);_ac(oSm,oTm);_ac(oRm,oSm);_ac(oHm,oRm);var oUm=_setAttrs(z,"navigator",["class",5,"delta",12,"openType",13],e,s,gg);var oVm=_ctn("button");_setAttr(z,oVm,'type',7,e,s,gg);var oWm=_o(z,19,e,s,gg);_ac(oVm,oWm);_ac(oUm,oVm);_ac(oHm,oUm);_ac(oGm,oHm);_ac(oBm,oGm);var oXm=_cvn();
    var oYm=_o(z,20,e,s,gg);
    var oZm=_gd('./macle_demo_EN/page/component/pages/navigator/navigator.maml',oYm,e_,d_);
    if(oZm){
      var oam={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oZm(oam,oam,oXm,gg);
      gg.f=tgf;
    }else{
      _w(oYm,'./macle_demo_EN/page/component/pages/navigator/navigator.maml',0,0);
    }
    _ac(oBm,oXm);_ac(r,oBm);ozl.pop();ozl.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/navigator/navigator.maml"]={f:m61,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/navigator/redirect.maml"]={};
  var m62=function(e,s,r,gg){
    var z=gz$gma_63()
    var obm=e_["./macle_demo_EN/page/component/pages/navigator/redirect.maml"].i;_ai(obm,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/navigator/redirect.maml',0,0);_ai(obm,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/navigator/redirect.maml',0,0);var oem=_ctn("view");_setAttr(z,oem,'class',0,e,s,gg);var ofm=_cvn();
    var ogm=_o(z,1,e,s,gg);
    var ohm=_gd('./macle_demo_EN/page/component/pages/navigator/redirect.maml',ogm,e_,d_);
    if(ohm){
      var oim=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ohm(oim,oim,ofm,gg);
      gg.f=tgf;
    }else{
      _w(ogm,'./macle_demo_EN/page/component/pages/navigator/redirect.maml',0,0);
    }
    _ac(oem,ofm);var ojm=_ctn("view");_setAttr(z,ojm,'class',3,e,s,gg);var okm=_ctn("view");var olm=_o(z,4,e,s,gg);_ac(okm,olm);_ac(ojm,okm);var omm=_ctn("view");_setAttr(z,omm,'class',5,e,s,gg);var onm=_ctn("navigator");_setAttr(z,onm,'openType',6,e,s,gg);var oom=_ctn("button");_setAttr(z,oom,'type',7,e,s,gg);var opm=_o(z,8,e,s,gg);_ac(oom,opm);_ac(onm,oom);_ac(omm,onm);_ac(ojm,omm);_ac(oem,ojm);var oqm=_cvn();
    var orm=_o(z,9,e,s,gg);
    var osm=_gd('./macle_demo_EN/page/component/pages/navigator/redirect.maml',orm,e_,d_);
    if(osm){
      var otm={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      osm(otm,otm,oqm,gg);
      gg.f=tgf;
    }else{
      _w(orm,'./macle_demo_EN/page/component/pages/navigator/redirect.maml',0,0);
    }
    _ac(oem,oqm);_ac(r,oem);obm.pop();obm.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/navigator/redirect.maml"]={f:m62,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/navigator/reLaunch.maml"]={};
  var m63=function(e,s,r,gg){
    var z=gz$gma_64()
    var oum=e_["./macle_demo_EN/page/component/pages/navigator/reLaunch.maml"].i;_ai(oum,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/navigator/reLaunch.maml',0,0);_ai(oum,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/navigator/reLaunch.maml',0,0);var oxm=_ctn("view");_setAttr(z,oxm,'class',0,e,s,gg);var oym=_cvn();
    var ozm=_o(z,1,e,s,gg);
    var o_m=_gd('./macle_demo_EN/page/component/pages/navigator/reLaunch.maml',ozm,e_,d_);
    if(o_m){
      var oAn=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      o_m(oAn,oAn,oym,gg);
      gg.f=tgf;
    }else{
      _w(ozm,'./macle_demo_EN/page/component/pages/navigator/reLaunch.maml',0,0);
    }
    _ac(oxm,oym);var oBn=_ctn("view");_setAttr(z,oBn,'class',3,e,s,gg);var oCn=_ctn("view");var oDn=_o(z,4,e,s,gg);_ac(oCn,oDn);_ac(oBn,oCn);_ac(oxm,oBn);var oEn=_cvn();
    var oFn=_o(z,5,e,s,gg);
    var oGn=_gd('./macle_demo_EN/page/component/pages/navigator/reLaunch.maml',oFn,e_,d_);
    if(oGn){
      var oHn={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oGn(oHn,oHn,oEn,gg);
      gg.f=tgf;
    }else{
      _w(oFn,'./macle_demo_EN/page/component/pages/navigator/reLaunch.maml',0,0);
    }
    _ac(oxm,oEn);_ac(r,oxm);oum.pop();oum.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/navigator/reLaunch.maml"]={f:m63,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/picker-view/picker-view.maml"]={};
  var m64=function(e,s,r,gg){
    var z=gz$gma_65()
    var oIn=e_["./macle_demo_EN/page/component/pages/picker-view/picker-view.maml"].i;_ai(oIn,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/picker-view/picker-view.maml',0,0);_ai(oIn,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/picker-view/picker-view.maml',0,0);var oLn=_ctn("view");_setAttr(z,oLn,'class',0,e,s,gg);var oMn=_cvn();
    var oNn=_o(z,1,e,s,gg);
    var oOn=_gd('./macle_demo_EN/page/component/pages/picker-view/picker-view.maml',oNn,e_,d_);
    if(oOn){
      var oPn=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oOn(oPn,oPn,oMn,gg);
      gg.f=tgf;
    }else{
      _w(oNn,'./macle_demo_EN/page/component/pages/picker-view/picker-view.maml',0,0);
    }
    _ac(oLn,oMn);var oQn=_ctn("view");_setAttr(z,oQn,'class',3,e,s,gg);var oRn=_ctn("view");_setAttr(z,oRn,'id',4,e,s,gg);var oSn=_o(z,5,e,s,gg);_ac(oRn,oSn);_ac(oQn,oRn);var oTn=_setAttrs(z,"picker-view",["bindchange",6,"bindpickend",1,"bindpickstart",2,"class",3,"indicatorClass",4,"indicatorStyle",5,"maskClass",6,"maskStyle",7,"value",8],e,s,gg);var oUn=_ctn("picker-view-column");var oVn=_cvn();var oWn=function(oan,oZn,oYn,gg){var oXn=_ctn("view");_setAttr(z,oXn,'style',16,oan,oZn,gg);var ocn=_o(z,17,oan,oZn,gg);_ac(oXn,ocn);_ac(oYn,oXn);return oYn;};_2(z,15,oWn,e,s,gg,oVn,"item","index",'');_ac(oUn,oVn);_ac(oTn,oUn);var odn=_ctn("picker-view-column");var oen=_cvn();var ofn=function(ojn,oin,ohn,gg){var ogn=_ctn("view");_setAttr(z,ogn,'style',16,ojn,oin,gg);var oln=_o(z,19,ojn,oin,gg);_ac(ogn,oln);_ac(ohn,ogn);return ohn;};_2(z,18,ofn,e,s,gg,oen,"item","index",'');_ac(odn,oen);_ac(oTn,odn);var omn=_ctn("picker-view-column");var onn=_cvn();var oon=function(osn,orn,oqn,gg){var opn=_ctn("view");_setAttr(z,opn,'style',16,osn,orn,gg);var oun=_o(z,21,osn,orn,gg);_ac(opn,oun);_ac(oqn,opn);return oqn;};_2(z,20,oon,e,s,gg,onn,"item","index",'');_ac(omn,onn);_ac(oTn,omn);_ac(oQn,oTn);var ovn=_ctn("view");_setAttr(z,ovn,'id',8,e,s,gg);var own=_o(z,22,e,s,gg);_ac(ovn,own);_ac(oQn,ovn);var oxn=_ctn("view");_setAttr(z,oxn,'id',7,e,s,gg);var oyn=_o(z,23,e,s,gg);_ac(oxn,oyn);_ac(oQn,oxn);_ac(oLn,oQn);var ozn=_cvn();
    var o_n=_o(z,24,e,s,gg);
    var oAo=_gd('./macle_demo_EN/page/component/pages/picker-view/picker-view.maml',o_n,e_,d_);
    if(oAo){
      var oBo={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oAo(oBo,oBo,ozn,gg);
      gg.f=tgf;
    }else{
      _w(o_n,'./macle_demo_EN/page/component/pages/picker-view/picker-view.maml',0,0);
    }
    _ac(oLn,ozn);_ac(r,oLn);oIn.pop();oIn.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/picker-view/picker-view.maml"]={f:m64,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/picker/picker.maml"]={};
  var m65=function(e,s,r,gg){
    var z=gz$gma_66()
    var oCo=e_["./macle_demo_EN/page/component/pages/picker/picker.maml"].i;_ai(oCo,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/picker/picker.maml',0,0);_ai(oCo,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/picker/picker.maml',0,0);var oFo=_ctn("view");_setAttr(z,oFo,'class',0,e,s,gg);var oGo=_cvn();
    var oHo=_o(z,1,e,s,gg);
    var oIo=_gd('./macle_demo_EN/page/component/pages/picker/picker.maml',oHo,e_,d_);
    if(oIo){
      var oJo=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oIo(oJo,oJo,oGo,gg);
      gg.f=tgf;
    }else{
      _w(oHo,'./macle_demo_EN/page/component/pages/picker/picker.maml',0,0);
    }
    _ac(oFo,oGo);var oKo=_ctn("view");_setAttr(z,oKo,'class',3,e,s,gg);var oLo=_ctn("view");_setAttr(z,oLo,'class',4,e,s,gg);var oMo=_setAttrs(z,"form",["catchreset",5,"catchsubmit",1],e,s,gg);var oNo=_ctn("view");_setAttr(z,oNo,'class',7,e,s,gg);var oOo=_o(z,8,e,s,gg);_ac(oNo,oOo);_ac(oMo,oNo);var oPo=_ctn("view");_setAttr(z,oPo,'class',9,e,s,gg);var oQo=_ctn("view");_setAttr(z,oQo,'class',10,e,s,gg);var oRo=_ctn("view");_setAttr(z,oRo,'class',11,e,s,gg);var oSo=_ctn("view");_setAttr(z,oSo,'class',12,e,s,gg);var oTo=_o(z,13,e,s,gg);_ac(oSo,oTo);_ac(oRo,oSo);_ac(oQo,oRo);var oUo=_ctn("view");_setAttr(z,oUo,'class',14,e,s,gg);var oVo=_setAttrs(z,"picker",["bindcancel",15,"bindchange",1,"headerText",2,"name",3,"range",4,"value",5],e,s,gg);var oWo=_ctn("view");_setAttr(z,oWo,'class',21,e,s,gg);var oXo=_o(z,22,e,s,gg);_ac(oWo,oXo);_ac(oVo,oWo);_ac(oUo,oVo);_ac(oQo,oUo);_ac(oPo,oQo);_ac(oMo,oPo);var oYo=_ctn("view");_setAttr(z,oYo,'class',7,e,s,gg);var oZo=_o(z,23,e,s,gg);_ac(oYo,oZo);_ac(oMo,oYo);var oao=_ctn("view");_setAttr(z,oao,'class',9,e,s,gg);var obo=_ctn("view");_setAttr(z,obo,'class',10,e,s,gg);var oco=_ctn("view");_setAttr(z,oco,'class',11,e,s,gg);var odo=_ctn("view");_setAttr(z,odo,'class',12,e,s,gg);var oeo=_o(z,13,e,s,gg);_ac(odo,oeo);_ac(oco,odo);_ac(obo,oco);var ofo=_ctn("view");_setAttr(z,ofo,'class',14,e,s,gg);var ogo=_setAttrs(z,"picker",["bindchange",16,"range",3,"value",4,"disabled",8,"name",9],e,s,gg);var oho=_ctn("view");_setAttr(z,oho,'class',21,e,s,gg);var oio=_o(z,26,e,s,gg);_ac(oho,oio);_ac(ogo,oho);_ac(ofo,ogo);_ac(obo,ofo);_ac(oao,obo);_ac(oMo,oao);var ojo=_ctn("view");_setAttr(z,ojo,'class',7,e,s,gg);var oko=_o(z,27,e,s,gg);_ac(ojo,oko);_ac(oMo,ojo);var olo=_ctn("view");_setAttr(z,olo,'class',9,e,s,gg);var omo=_ctn("view");_setAttr(z,omo,'class',10,e,s,gg);var ono=_ctn("view");_setAttr(z,ono,'class',11,e,s,gg);var ooo=_ctn("view");_setAttr(z,ooo,'class',12,e,s,gg);var opo=_o(z,13,e,s,gg);_ac(ooo,opo);_ac(ono,ooo);_ac(omo,ono);var oqo=_ctn("view");_setAttr(z,oqo,'class',14,e,s,gg);var oro=_setAttrs(z,"picker",["bindcancel",15,"bindchange",13,"name",14,"range",15,"rangeKey",16,"value",17],e,s,gg);var oso=_ctn("view");_setAttr(z,oso,'class',21,e,s,gg);var oto=_o(z,33,e,s,gg);_ac(oso,oto);_ac(oro,oso);_ac(oqo,oro);_ac(omo,oqo);_ac(olo,omo);_ac(oMo,olo);var ouo=_ctn("view");_setAttr(z,ouo,'class',7,e,s,gg);var ovo=_o(z,34,e,s,gg);_ac(ouo,ovo);_ac(oMo,ouo);var owo=_ctn("view");_setAttr(z,owo,'class',9,e,s,gg);var oxo=_ctn("view");_setAttr(z,oxo,'class',10,e,s,gg);var oyo=_ctn("view");_setAttr(z,oyo,'class',11,e,s,gg);var ozo=_ctn("view");_setAttr(z,ozo,'class',12,e,s,gg);var o_o=_o(z,13,e,s,gg);_ac(ozo,o_o);_ac(oyo,ozo);_ac(oxo,oyo);var oAp=_ctn("view");_setAttr(z,oAp,'class',14,e,s,gg);var oBp=_setAttrs(z,"picker",["bindchange",35,"bindcolumnchange",1,"mode",2,"name",3,"range",4,"value",5],e,s,gg);var oCp=_ctn("view");_setAttr(z,oCp,'class',21,e,s,gg);var oDp=_o(z,41,e,s,gg);_ac(oCp,oDp);_ac(oBp,oCp);_ac(oAp,oBp);_ac(oxo,oAp);_ac(owo,oxo);_ac(oMo,owo);var oEp=_ctn("view");_setAttr(z,oEp,'class',7,e,s,gg);var oFp=_o(z,42,e,s,gg);_ac(oEp,oFp);_ac(oMo,oEp);var oGp=_ctn("view");_setAttr(z,oGp,'class',9,e,s,gg);var oHp=_ctn("view");_setAttr(z,oHp,'class',10,e,s,gg);var oIp=_ctn("view");_setAttr(z,oIp,'class',11,e,s,gg);var oJp=_ctn("view");_setAttr(z,oJp,'class',12,e,s,gg);var oKp=_o(z,13,e,s,gg);_ac(oJp,oKp);_ac(oIp,oJp);_ac(oHp,oIp);var oLp=_ctn("view");_setAttr(z,oLp,'class',14,e,s,gg);var oMp=_setAttrs(z,"picker",["bindcancel",15,"bindchange",28,"end",29,"mode",30,"name",31,"start",32,"value",33],e,s,gg);var oNp=_ctn("view");_setAttr(z,oNp,'class',21,e,s,gg);var oOp=_o(z,49,e,s,gg);_ac(oNp,oOp);_ac(oMp,oNp);_ac(oLp,oMp);_ac(oHp,oLp);_ac(oGp,oHp);_ac(oMo,oGp);var oPp=_ctn("view");_setAttr(z,oPp,'class',7,e,s,gg);var oQp=_o(z,50,e,s,gg);_ac(oPp,oQp);_ac(oMo,oPp);var oRp=_ctn("view");_setAttr(z,oRp,'class',9,e,s,gg);var oSp=_ctn("view");_setAttr(z,oSp,'class',10,e,s,gg);var oTp=_ctn("view");_setAttr(z,oTp,'class',11,e,s,gg);var oUp=_ctn("view");_setAttr(z,oUp,'class',12,e,s,gg);var oVp=_o(z,13,e,s,gg);_ac(oUp,oVp);_ac(oTp,oUp);_ac(oSp,oTp);var oWp=_ctn("view");_setAttr(z,oWp,'class',14,e,s,gg);var oXp=_setAttrs(z,"picker",["bindcancel",15,"bindchange",36,"end",37,"mode",38,"name",39,"start",40,"value",41],e,s,gg);var oYp=_ctn("view");_setAttr(z,oYp,'class',21,e,s,gg);var oZp=_o(z,57,e,s,gg);_ac(oYp,oZp);_ac(oXp,oYp);_ac(oWp,oXp);_ac(oSp,oWp);_ac(oRp,oSp);_ac(oMo,oRp);var oap=_ctn("view");_setAttr(z,oap,'class',7,e,s,gg);var obp=_o(z,58,e,s,gg);_ac(oap,obp);_ac(oMo,oap);var ocp=_ctn("view");_setAttr(z,ocp,'class',9,e,s,gg);var odp=_ctn("view");_setAttr(z,odp,'class',10,e,s,gg);var oep=_ctn("view");_setAttr(z,oep,'class',11,e,s,gg);var ofp=_ctn("view");_setAttr(z,ofp,'class',12,e,s,gg);var ogp=_o(z,13,e,s,gg);_ac(ofp,ogp);_ac(oep,ofp);_ac(odp,oep);var ohp=_ctn("view");_setAttr(z,ohp,'class',14,e,s,gg);var oip=_setAttrs(z,"picker",["bindcancel",15,"mode",38,"bindchange",44,"end",45,"fields",46,"name",47,"start",48,"value",49],e,s,gg);var ojp=_ctn("view");_setAttr(z,ojp,'class',21,e,s,gg);var okp=_o(z,65,e,s,gg);_ac(ojp,okp);_ac(oip,ojp);_ac(ohp,oip);_ac(odp,ohp);_ac(ocp,odp);_ac(oMo,ocp);var olp=_ctn("view");_setAttr(z,olp,'class',7,e,s,gg);var omp=_o(z,66,e,s,gg);_ac(olp,omp);_ac(oMo,olp);var onp=_ctn("view");_setAttr(z,onp,'class',9,e,s,gg);var oop=_ctn("view");_setAttr(z,oop,'class',10,e,s,gg);var opp=_ctn("view");_setAttr(z,opp,'class',11,e,s,gg);var oqp=_ctn("view");_setAttr(z,oqp,'class',12,e,s,gg);var orp=_o(z,13,e,s,gg);_ac(oqp,orp);_ac(opp,oqp);_ac(oop,opp);var osp=_ctn("view");_setAttr(z,osp,'class',14,e,s,gg);var otp=_setAttrs(z,"picker",["bindcancel",15,"bindchange",52,"customItem",53,"mode",54,"name",55,"value",56],e,s,gg);var oup=_ctn("view");_setAttr(z,oup,'class',21,e,s,gg);var ovp=_o(z,72,e,s,gg);_ac(oup,ovp);_ac(otp,oup);_ac(osp,otp);_ac(oop,osp);_ac(onp,oop);_ac(oMo,onp);var owp=_ctn("view");_setAttr(z,owp,'class',73,e,s,gg);var oxp=_setAttrs(z,"button",["formType",6,"type",68],e,s,gg);var oyp=_o(z,75,e,s,gg);_ac(oxp,oyp);_ac(owp,oxp);var ozp=_ctn("button");_setAttr(z,ozp,'formType',5,e,s,gg);var o_p=_o(z,76,e,s,gg);_ac(ozp,o_p);_ac(owp,ozp);_ac(oMo,owp);_ac(oLo,oMo);_ac(oKo,oLo);_ac(oFo,oKo);var oAq=_cvn();
    var oBq=_o(z,77,e,s,gg);
    var oCq=_gd('./macle_demo_EN/page/component/pages/picker/picker.maml',oBq,e_,d_);
    if(oCq){
      var oDq={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oCq(oDq,oDq,oAq,gg);
      gg.f=tgf;
    }else{
      _w(oBq,'./macle_demo_EN/page/component/pages/picker/picker.maml',0,0);
    }
    _ac(oFo,oAq);_ac(r,oFo);oCo.pop();oCo.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/picker/picker.maml"]={f:m65,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/progress/progress.maml"]={};
  var m66=function(e,s,r,gg){
    var z=gz$gma_67()
    var oEq=e_["./macle_demo_EN/page/component/pages/progress/progress.maml"].i;_ai(oEq,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/progress/progress.maml',0,0);_ai(oEq,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/progress/progress.maml',0,0);var oHq=_ctn("view");_setAttr(z,oHq,'class',0,e,s,gg);var oIq=_cvn();
    var oJq=_o(z,1,e,s,gg);
    var oKq=_gd('./macle_demo_EN/page/component/pages/progress/progress.maml',oJq,e_,d_);
    if(oKq){
      var oLq=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oKq(oLq,oLq,oIq,gg);
      gg.f=tgf;
    }else{
      _w(oJq,'./macle_demo_EN/page/component/pages/progress/progress.maml',0,0);
    }
    _ac(oHq,oIq);var oMq=_ctn("view");_setAttr(z,oMq,'class',3,e,s,gg);var oNq=_ctn("view");var oOq=_o(z,4,e,s,gg);_ac(oNq,oOq);_ac(oMq,oNq);var oPq=_ctn("view");_setAttr(z,oPq,'class',5,e,s,gg);var oQq=_setAttrs(z,"progress",["class",6,"fontSize",1,"percent",1,"showInfo",2,"strokeWidth",3],e,s,gg);_ac(oPq,oQq);_ac(oMq,oPq);var oRq=_ctn("view");var oSq=_o(z,10,e,s,gg);_ac(oRq,oSq);_ac(oMq,oRq);var oTq=_ctn("view");_setAttr(z,oTq,'class',11,e,s,gg);var oUq=_setAttrs(z,"progress",["active",8,"showInfo",0,"bindactiveend",4,"class",5,"percent",6,"strokeWidth",7],e,s,gg);_ac(oTq,oUq);_ac(oMq,oTq);var oVq=_ctn("view");var oWq=_o(z,16,e,s,gg);_ac(oVq,oWq);_ac(oMq,oVq);var oXq=_ctn("view");_setAttr(z,oXq,'class',17,e,s,gg);var oYq=_setAttrs(z,"progress",["strokeWidth",7,"active",1,"showInfo",1,"activeColor",11,"backgroundColor",12,"borderRadius",13,"class",14,"percent",15],e,s,gg);_ac(oXq,oYq);_ac(oMq,oXq);var oZq=_ctn("view");var oaq=_o(z,23,e,s,gg);_ac(oZq,oaq);_ac(oMq,oZq);var obq=_ctn("view");_setAttr(z,obq,'class',24,e,s,gg);var ocq=_setAttrs(z,"progress",["active",8,"showInfo",0,"percent",6,"activeMode",17,"class",18,"duration",19],e,s,gg);_ac(obq,ocq);_ac(oMq,obq);var odq=_ctn("view");var oeq=_o(z,28,e,s,gg);_ac(odq,oeq);_ac(oMq,odq);var ofq=_ctn("view");_setAttr(z,ofq,'class',29,e,s,gg);var ogq=_setAttrs(z,"progress",["active",8,"showInfo",0,"percent",6,"duration",19,"activeMode",22,"class",23],e,s,gg);_ac(ofq,ogq);_ac(oMq,ofq);var ohq=_setAttrs(z,"button",["bindtap",32,"class",1],e,s,gg);var oiq=_o(z,34,e,s,gg);_ac(ohq,oiq);_ac(oMq,ohq);var ojq=_ctn("view");var okq=_o(z,35,e,s,gg);_ac(ojq,okq);_ac(oMq,ojq);var olq=_ctn("view");_setAttr(z,olq,'class',36,e,s,gg);var omq=_setAttrs(z,"progress",["fontSize",7,"percent",0,"strokeWidth",2,"active",30,"showInfo",30,"class",31],e,s,gg);_ac(olq,omq);_ac(oMq,olq);var onq=_ctn("view");var ooq=_o(z,39,e,s,gg);_ac(onq,ooq);_ac(oMq,onq);var opq=_ctn("view");_setAttr(z,opq,'class',40,e,s,gg);var oqq=_setAttrs(z,"progress",["percent",7,"strokeWidth",2,"class",34,"fontSize",35,"showInfo",36],e,s,gg);_ac(opq,oqq);_ac(oMq,opq);var orq=_ctn("view");var osq=_o(z,44,e,s,gg);_ac(orq,osq);_ac(oMq,orq);var otq=_ctn("view");_setAttr(z,otq,'class',45,e,s,gg);var ouq=_setAttrs(z,"progress",["fontSize",7,"percent",0,"strokeWidth",2,"class",39],e,s,gg);_ac(otq,ouq);_ac(oMq,otq);var ovq=_ctn("view");var owq=_o(z,47,e,s,gg);_ac(ovq,owq);_ac(oMq,ovq);var oxq=_ctn("view");_setAttr(z,oxq,'class',48,e,s,gg);var oyq=_setAttrs(z,"progress",["percent",7,"showInfo",1,"strokeWidth",2,"fontSize",35,"borderRadius",42,"class",43],e,s,gg);_ac(oxq,oyq);_ac(oMq,oxq);_ac(oHq,oMq);var ozq=_cvn();
    var o_q=_o(z,51,e,s,gg);
    var oAr=_gd('./macle_demo_EN/page/component/pages/progress/progress.maml',o_q,e_,d_);
    if(oAr){
      var oBr={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oAr(oBr,oBr,ozq,gg);
      gg.f=tgf;
    }else{
      _w(o_q,'./macle_demo_EN/page/component/pages/progress/progress.maml',0,0);
    }
    _ac(oHq,ozq);_ac(r,oHq);oEq.pop();oEq.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/progress/progress.maml"]={f:m66,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/radio/radio.maml"]={};
  var m67=function(e,s,r,gg){
    var z=gz$gma_68()
    var oCr=e_["./macle_demo_EN/page/component/pages/radio/radio.maml"].i;_ai(oCr,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/radio/radio.maml',0,0);_ai(oCr,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/radio/radio.maml',0,0);var oFr=_ctn("view");_setAttr(z,oFr,'class',0,e,s,gg);var oGr=_cvn();
    var oHr=_o(z,1,e,s,gg);
    var oIr=_gd('./macle_demo_EN/page/component/pages/radio/radio.maml',oHr,e_,d_);
    if(oIr){
      var oJr=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oIr(oJr,oJr,oGr,gg);
      gg.f=tgf;
    }else{
      _w(oHr,'./macle_demo_EN/page/component/pages/radio/radio.maml',0,0);
    }
    _ac(oFr,oGr);var oKr=_ctn("view");_setAttr(z,oKr,'class',3,e,s,gg);var oLr=_ctn("view");_setAttr(z,oLr,'class',4,e,s,gg);var oMr=_ctn("view");_setAttr(z,oMr,'class',5,e,s,gg);var oNr=_o(z,6,e,s,gg);_ac(oMr,oNr);_ac(oLr,oMr);var oOr=_ctn("label");_setAttr(z,oOr,'class',7,e,s,gg);var oPr=_setAttrs(z,"radio",["checked",8,"class",1,"value",2],e,s,gg);_ac(oOr,oPr);var oQr=_o(z,11,e,s,gg);_ac(oOr,oQr);_ac(oLr,oOr);var oRr=_ctn("label");_setAttr(z,oRr,'class',7,e,s,gg);var oSr=_setAttrs(z,"radio",["class",12,"value",1],e,s,gg);_ac(oRr,oSr);var oTr=_o(z,14,e,s,gg);_ac(oRr,oTr);_ac(oLr,oRr);var oUr=_ctn("label");_setAttr(z,oUr,'class',7,e,s,gg);var oVr=_setAttrs(z,"radio",["disabled",8,"class",7,"value",8],e,s,gg);_ac(oUr,oVr);var oWr=_o(z,17,e,s,gg);_ac(oUr,oWr);_ac(oLr,oUr);var oXr=_ctn("label");_setAttr(z,oXr,'class',7,e,s,gg);var oYr=_setAttrs(z,"radio",["checked",18,"class",1,"color",2,"disabled",3,"value",4],e,s,gg);_ac(oXr,oYr);var oZr=_o(z,23,e,s,gg);_ac(oXr,oZr);_ac(oLr,oXr);_ac(oKr,oLr);var oar=_ctn("view");_setAttr(z,oar,'class',24,e,s,gg);var obr=_ctn("view");_setAttr(z,obr,'class',5,e,s,gg);var ocr=_o(z,25,e,s,gg);_ac(obr,ocr);_ac(oar,obr);var odr=_ctn("view");_setAttr(z,odr,'class',26,e,s,gg);var oer=_ctn("radio-group");_setAttr(z,oer,'bindchange',27,e,s,gg);var ofr=_cvn();var ogr=function(okr,ojr,oir,gg){var ohr=_ctn("label");_setAttr(z,ohr,'class',30,okr,ojr,gg);var omr=_ctn("view");_setAttr(z,omr,'class',31,okr,ojr,gg);var onr=_setAttrs(z,"radio",["value",29,"checked",3,"class",4,"color",5],okr,ojr,gg);_ac(omr,onr);_ac(ohr,omr);var oor=_ctn("view");_setAttr(z,oor,'class',35,okr,ojr,gg);var opr=_o(z,36,okr,ojr,gg);_ac(oor,opr);_ac(ohr,oor);_ac(oir,ohr);return oir;};_2(z,28,ogr,e,s,gg,ofr,"item","index",'{{item.value}}');_ac(oer,ofr);_ac(odr,oer);_ac(oar,odr);_ac(oKr,oar);_ac(oFr,oKr);var oqr=_cvn();
    var orr=_o(z,37,e,s,gg);
    var osr=_gd('./macle_demo_EN/page/component/pages/radio/radio.maml',orr,e_,d_);
    if(osr){
      var otr={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      osr(otr,otr,oqr,gg);
      gg.f=tgf;
    }else{
      _w(orr,'./macle_demo_EN/page/component/pages/radio/radio.maml',0,0);
    }
    _ac(oFr,oqr);_ac(r,oFr);oCr.pop();oCr.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/radio/radio.maml"]={f:m67,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/rich-text/rich-text.maml"]={};
  var m68=function(e,s,r,gg){
    var z=gz$gma_69()
    var our=e_["./macle_demo_EN/page/component/pages/rich-text/rich-text.maml"].i;_ai(our,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/rich-text/rich-text.maml',0,0);_ai(our,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/rich-text/rich-text.maml',0,0);var oxr=_ctn("view");_setAttr(z,oxr,'class',0,e,s,gg);var oyr=_cvn();
    var ozr=_o(z,1,e,s,gg);
    var o_r=_gd('./macle_demo_EN/page/component/pages/rich-text/rich-text.maml',ozr,e_,d_);
    if(o_r){
      var oAs=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      o_r(oAs,oAs,oyr,gg);
      gg.f=tgf;
    }else{
      _w(ozr,'./macle_demo_EN/page/component/pages/rich-text/rich-text.maml',0,0);
    }
    _ac(oxr,oyr);var oBs=_ctn("view");_setAttr(z,oBs,'class',3,e,s,gg);var oCs=_ctn("view");_setAttr(z,oCs,'class',4,e,s,gg);var oDs=_ctn("view");_setAttr(z,oDs,'class',5,e,s,gg);var oEs=_o(z,6,e,s,gg);_ac(oDs,oEs);_ac(oCs,oDs);var oFs=_ctn("view");_setAttr(z,oFs,'class',7,e,s,gg);var oGs=_setAttrs(z,"rich-text",["class",8,"nodes",1,"space",2],e,s,gg);_ac(oFs,oGs);_ac(oCs,oFs);_ac(oBs,oCs);var oHs=_ctn("view");_setAttr(z,oHs,'class',4,e,s,gg);var oIs=_ctn("view");_setAttr(z,oIs,'class',5,e,s,gg);var oJs=_o(z,11,e,s,gg);_ac(oIs,oJs);_ac(oHs,oIs);var oKs=_ctn("view");_setAttr(z,oKs,'class',7,e,s,gg);var oLs=_setAttrs(z,"rich-text",["space",10,"nodes",2],e,s,gg);_ac(oKs,oLs);_ac(oHs,oKs);_ac(oBs,oHs);var oMs=_ctn("view");_setAttr(z,oMs,'class',4,e,s,gg);var oNs=_ctn("view");_setAttr(z,oNs,'class',5,e,s,gg);var oOs=_o(z,13,e,s,gg);_ac(oNs,oOs);_ac(oMs,oNs);var oPs=_ctn("view");_setAttr(z,oPs,'class',7,e,s,gg);var oQs=_ctn("rich-text");_setAttr(z,oQs,'nodes',14,e,s,gg);_ac(oPs,oQs);_ac(oMs,oPs);_ac(oBs,oMs);var oRs=_ctn("view");_setAttr(z,oRs,'class',4,e,s,gg);var oSs=_ctn("view");_setAttr(z,oSs,'class',5,e,s,gg);var oTs=_o(z,15,e,s,gg);_ac(oSs,oTs);_ac(oRs,oSs);var oUs=_ctn("view");_setAttr(z,oUs,'class',7,e,s,gg);var oVs=_ctn("rich-text");_setAttr(z,oVs,'nodes',16,e,s,gg);_ac(oUs,oVs);_ac(oRs,oUs);_ac(oBs,oRs);_ac(oxr,oBs);var oWs=_cvn();
    var oXs=_o(z,17,e,s,gg);
    var oYs=_gd('./macle_demo_EN/page/component/pages/rich-text/rich-text.maml',oXs,e_,d_);
    if(oYs){
      var oZs={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oYs(oZs,oZs,oWs,gg);
      gg.f=tgf;
    }else{
      _w(oXs,'./macle_demo_EN/page/component/pages/rich-text/rich-text.maml',0,0);
    }
    _ac(oxr,oWs);_ac(r,oxr);our.pop();our.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/rich-text/rich-text.maml"]={f:m68,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml"]={};
  var m69=function(e,s,r,gg){
    var z=gz$gma_70()
    var oas=e_["./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml"].i;_ai(oas,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml',0,0);_ai(oas,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml',0,0);var ods=_ctn("view");_setAttr(z,ods,'class',0,e,s,gg);var oes=_cvn();
    var ofs=_o(z,1,e,s,gg);
    var ogs=_gd('./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml',ofs,e_,d_);
    if(ogs){
      var ohs=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ogs(ohs,ohs,oes,gg);
      gg.f=tgf;
    }else{
      _w(ofs,'./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml',0,0);
    }
    _ac(ods,oes);var ois=_ctn("view");_setAttr(z,ois,'class',3,e,s,gg);var ojs=_ctn("view");_setAttr(z,ojs,'class',4,e,s,gg);var oks=_ctn("view");_setAttr(z,oks,'class',5,e,s,gg);var ols=_ctn("text");var oms=_o(z,6,e,s,gg);_ac(ols,oms);_ac(oks,ols);_ac(ojs,oks);var ons=_ctn("view");_setAttr(z,ons,'class',7,e,s,gg);var oos=_setAttrs(z,"scroll-view",["binddragend",8,"binddragging",1,"binddragstart",2,"bindscroll",3,"bindscrolltolower",4,"bindscrolltoupper",5,"class",6,"enhanced",7,"scrollY",7,"scrollWithAnimation",7,"showScrollbar",7,"lowerThreshold",8,"upperThreshold",8,"scrollIntoView",9,"scrollTop",10,"style",11],e,s,gg);var ops=_cvn();var oqs=function(ous,ots,oss,gg){var ows=_setAttrs(z,"view",["style",19,"class",5,"id",6],ous,ots,gg);_ac(oss,ows);return oss;};_2(z,20,oqs,e,s,gg,ops,"item","index",'{{item}}');_ac(oos,ops);_ac(ons,oos);_ac(ojs,ons);var oxs=_ctn("view");_setAttr(z,oxs,'class',26,e,s,gg);var oys=_cvn();var ozs=function(oCt,oBt,oAt,gg){var oEt=_setAttrs(z,"button",["bindtap",27,"data-index",1,"size",2,"type",3],oCt,oBt,gg);var oFt=_o(z,31,oCt,oBt,gg);_ac(oEt,oFt);_ac(oAt,oEt);return oAt;};_2(z,20,ozs,e,s,gg,oys,"item","index",'{{item}}');_ac(oxs,oys);var oGt=_setAttrs(z,"button",["data-scroll-top",16,"size",13,"type",14,"bindtap",16,"id",17],e,s,gg);var oHt=_o(z,34,e,s,gg);_ac(oGt,oHt);_ac(oxs,oGt);_ac(ojs,oxs);var oIt=_ctn("view");_setAttr(z,oIt,'class',26,e,s,gg);var oJt=_setAttrs(z,"button",["size",29,"type",1,"bindtap",3,"data-scroll-top",6,"id",7],e,s,gg);var oKt=_o(z,37,e,s,gg);_ac(oJt,oKt);_ac(oIt,oJt);var oLt=_setAttrs(z,"button",["size",29,"type",1,"bindtap",3,"data-scroll-top",9,"id",10],e,s,gg);var oMt=_o(z,40,e,s,gg);_ac(oLt,oMt);_ac(oIt,oLt);var oNt=_setAttrs(z,"button",["data-reverse",15,"size",14,"type",15,"bindtap",17,"data-scroll-top",20,"id",26],e,s,gg);var oOt=_o(z,42,e,s,gg);_ac(oNt,oOt);_ac(oIt,oNt);var oPt=_setAttrs(z,"button",["data-reverse",15,"size",14,"type",15,"bindtap",17,"data-scroll-top",23,"id",28],e,s,gg);var oQt=_o(z,44,e,s,gg);_ac(oPt,oQt);_ac(oIt,oPt);_ac(ojs,oIt);_ac(ois,ojs);var oRt=_ctn("view");_setAttr(z,oRt,'id',45,e,s,gg);var oSt=_o(z,46,e,s,gg);_ac(oRt,oSt);_ac(ois,oRt);var oTt=_ctn("view");_setAttr(z,oTt,'id',47,e,s,gg);var oUt=_o(z,48,e,s,gg);_ac(oTt,oUt);_ac(ois,oTt);var oVt=_ctn("view");_setAttr(z,oVt,'id',49,e,s,gg);var oWt=_o(z,50,e,s,gg);_ac(oVt,oWt);_ac(ois,oVt);var oXt=_ctn("view");_setAttr(z,oXt,'id',51,e,s,gg);var oYt=_o(z,52,e,s,gg);_ac(oXt,oYt);_ac(ois,oXt);var oZt=_ctn("view");_setAttr(z,oZt,'id',53,e,s,gg);var oat=_o(z,54,e,s,gg);_ac(oZt,oat);_ac(ois,oZt);var obt=_ctn("view");_setAttr(z,obt,'id',55,e,s,gg);var oct=_o(z,56,e,s,gg);_ac(obt,oct);_ac(ois,obt);var odt=_ctn("view");_setAttr(z,odt,'class',4,e,s,gg);var oet=_ctn("view");_setAttr(z,oet,'class',5,e,s,gg);var oft=_ctn("text");var ogt=_o(z,57,e,s,gg);_ac(oft,ogt);_ac(oet,oft);_ac(odt,oet);var oht=_ctn("view");_setAttr(z,oht,'class',7,e,s,gg);var oit=_setAttrs(z,"scroll-view",["bindscroll",11,"bindscrolltolower",1,"bindscrolltoupper",2,"enhanced",4,"scrollX",4,"scrollWithAnimation",4,"showScrollbar",4,"class",47,"scrollLeft",48,"style",49],e,s,gg);var ojt=_cvn();var okt=function(oot,ont,omt,gg){var oqt=_setAttrs(z,"view",["class",61,"id",1],oot,ont,gg);_ac(omt,oqt);return omt;};_2(z,20,okt,e,s,gg,ojt,"item","index",'{{item}}');_ac(oit,ojt);_ac(oht,oit);_ac(odt,oht);var ort=_ctn("view");_setAttr(z,ort,'class',63,e,s,gg);var ost=_ctn("text");var ott=_o(z,64,e,s,gg);_ac(ost,ott);_ac(ort,ost);_ac(odt,ort);var out=_ctn("view");_setAttr(z,out,'class',26,e,s,gg);var ovt=_setAttrs(z,"button",["size",29,"type",1,"bindtap",36,"id",37],e,s,gg);var owt=_o(z,67,e,s,gg);_ac(ovt,owt);_ac(out,ovt);var oxt=_setAttrs(z,"button",["size",29,"type",1,"bindtap",39,"id",40],e,s,gg);var oyt=_o(z,34,e,s,gg);_ac(oxt,oyt);_ac(out,oxt);_ac(odt,out);_ac(ois,odt);_ac(ods,ois);var ozt=_cvn();
    var o_t=_o(z,70,e,s,gg);
    var oAu=_gd('./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml',o_t,e_,d_);
    if(oAu){
      var oBu={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oAu(oBu,oBu,ozt,gg);
      gg.f=tgf;
    }else{
      _w(o_t,'./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml',0,0);
    }
    _ac(ods,ozt);_ac(r,ods);oas.pop();oas.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml"]={f:m69,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/slider/slider.maml"]={};
  var m70=function(e,s,r,gg){
    var z=gz$gma_71()
    var oCu=e_["./macle_demo_EN/page/component/pages/slider/slider.maml"].i;_ai(oCu,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/slider/slider.maml',0,0);_ai(oCu,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/slider/slider.maml',0,0);var oFu=_ctn("view");_setAttr(z,oFu,'class',0,e,s,gg);var oGu=_cvn();
    var oHu=_o(z,1,e,s,gg);
    var oIu=_gd('./macle_demo_EN/page/component/pages/slider/slider.maml',oHu,e_,d_);
    if(oIu){
      var oJu=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oIu(oJu,oJu,oGu,gg);
      gg.f=tgf;
    }else{
      _w(oHu,'./macle_demo_EN/page/component/pages/slider/slider.maml',0,0);
    }
    _ac(oFu,oGu);var oKu=_ctn("view");_setAttr(z,oKu,'id',3,e,s,gg);var oLu=_o(z,4,e,s,gg);_ac(oKu,oLu);_ac(oFu,oKu);var oMu=_setAttrs(z,"view",["class",0,"id",5],e,s,gg);var oNu=_ctn("text");var oOu=_o(z,6,e,s,gg);_ac(oNu,oOu);_ac(oMu,oNu);_ac(oFu,oMu);var oPu=_setAttrs(z,"view",["class",0,"id",7],e,s,gg);var oQu=_ctn("text");var oRu=_o(z,8,e,s,gg);_ac(oQu,oRu);_ac(oPu,oQu);_ac(oFu,oPu);var oSu=_ctn("view");_setAttr(z,oSu,'class',9,e,s,gg);var oTu=_ctn("view");_setAttr(z,oTu,'class',10,e,s,gg);var oUu=_ctn("view");_setAttr(z,oUu,'class',11,e,s,gg);var oVu=_o(z,12,e,s,gg);_ac(oUu,oVu);_ac(oTu,oUu);var oWu=_ctn("view");_setAttr(z,oWu,'class',13,e,s,gg);var oXu=_setAttrs(z,"slider",["activeColor",14,"backgroundColor",1,"bindchange",2,"bindchanging",3,"blockColor",4,"blockSize",5,"id",6,"showValue",7],e,s,gg);_ac(oWu,oXu);_ac(oTu,oWu);var oYu=_cvn();if(_o(z,22,e,s,gg)){oYu.maVkey=1;var oZu=_ctn("view");_setAttr(z,oZu,'class',23,e,s,gg);var obu=_o(z,24,e,s,gg);_ac(oZu,obu);_ac(oYu,oZu);} _ac(oTu,oYu);var ocu=_cvn();if(_o(z,25,e,s,gg)){ocu.maVkey=1;var odu=_ctn("view");_setAttr(z,odu,'class',26,e,s,gg);var ofu=_o(z,27,e,s,gg);_ac(odu,ofu);_ac(ocu,odu);} _ac(oTu,ocu);_ac(oSu,oTu);var ogu=_ctn("view");_setAttr(z,ogu,'class',10,e,s,gg);var ohu=_ctn("view");_setAttr(z,ohu,'class',11,e,s,gg);var oiu=_o(z,28,e,s,gg);_ac(ohu,oiu);_ac(ogu,ohu);var oju=_ctn("view");_setAttr(z,oju,'class',13,e,s,gg);var oku=_setAttrs(z,"slider",["showValue",21,"bindchange",8,"bindchanging",9,"id",10,"step",11,"value",12],e,s,gg);_ac(oju,oku);_ac(ogu,oju);_ac(oSu,ogu);var olu=_ctn("view");_setAttr(z,olu,'class',10,e,s,gg);var omu=_ctn("view");_setAttr(z,omu,'class',11,e,s,gg);var onu=_o(z,34,e,s,gg);_ac(omu,onu);_ac(olu,omu);var oou=_ctn("view");_setAttr(z,oou,'class',13,e,s,gg);var opu=_setAttrs(z,"slider",["step",32,"min",1,"bindchange",3,"id",4,"max",5,"value",6],e,s,gg);_ac(oou,opu);_ac(olu,oou);_ac(oSu,olu);var oqu=_ctn("view");_setAttr(z,oqu,'class',10,e,s,gg);var oru=_ctn("view");_setAttr(z,oru,'class',11,e,s,gg);var osu=_o(z,39,e,s,gg);_ac(oru,osu);_ac(oqu,oru);var otu=_ctn("view");_setAttr(z,otu,'class',13,e,s,gg);var ouu=_setAttrs(z,"slider",["value",38,"bindchange",2,"blockSize",3,"id",4,"min",5,"showValue",5,"step",6],e,s,gg);_ac(otu,ouu);_ac(oqu,otu);_ac(oSu,oqu);var ovu=_ctn("view");_setAttr(z,ovu,'class',10,e,s,gg);var owu=_ctn("view");_setAttr(z,owu,'class',11,e,s,gg);var oxu=_o(z,45,e,s,gg);_ac(owu,oxu);_ac(ovu,owu);var oyu=_ctn("view");_setAttr(z,oyu,'class',13,e,s,gg);var ozu=_setAttrs(z,"slider",["showValue",21,"step",11,"value",17,"max",22,"bindchange",25,"blockSize",26,"id",27],e,s,gg);_ac(oyu,ozu);_ac(ovu,oyu);_ac(oSu,ovu);var o_u=_ctn("view");_setAttr(z,o_u,'class',10,e,s,gg);var oAv=_ctn("view");_setAttr(z,oAv,'class',11,e,s,gg);var oBv=_o(z,49,e,s,gg);_ac(oAv,oBv);_ac(o_u,oAv);var oCv=_ctn("view");_setAttr(z,oCv,'class',13,e,s,gg);var oDv=_setAttrs(z,"slider",["disabled",21,"showValue",0,"step",11,"value",17,"bindchange",29,"id",30],e,s,gg);_ac(oCv,oDv);_ac(o_u,oCv);_ac(oSu,o_u);_ac(oFu,oSu);var oEv=_cvn();
    var oFv=_o(z,52,e,s,gg);
    var oGv=_gd('./macle_demo_EN/page/component/pages/slider/slider.maml',oFv,e_,d_);
    if(oGv){
      var oHv={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oGv(oHv,oHv,oEv,gg);
      gg.f=tgf;
    }else{
      _w(oFv,'./macle_demo_EN/page/component/pages/slider/slider.maml',0,0);
    }
    _ac(oFu,oEv);_ac(r,oFu);oCu.pop();oCu.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/slider/slider.maml"]={f:m70,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/swiper/swiper.maml"]={};
  var m71=function(e,s,r,gg){
    var z=gz$gma_72()
    var oIv=e_["./macle_demo_EN/page/component/pages/swiper/swiper.maml"].i;_ai(oIv,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/swiper/swiper.maml',0,0);_ai(oIv,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/swiper/swiper.maml',0,0);var oLv=_ctn("view");_setAttr(z,oLv,'class',0,e,s,gg);var oMv=_cvn();
    var oNv=_o(z,1,e,s,gg);
    var oOv=_gd('./macle_demo_EN/page/component/pages/swiper/swiper.maml',oNv,e_,d_);
    if(oOv){
      var oPv=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oOv(oPv,oPv,oMv,gg);
      gg.f=tgf;
    }else{
      _w(oNv,'./macle_demo_EN/page/component/pages/swiper/swiper.maml',0,0);
    }
    _ac(oLv,oMv);var oQv=_ctn("view");_setAttr(z,oQv,'class',3,e,s,gg);var oRv=_ctn("view");_setAttr(z,oRv,'class',4,e,s,gg);var oSv=_setAttrs(z,"swiper",["autoplay",5,"circular",1,"duration",2,"easingFunction",3,"indicatorActiveColor",4,"indicatorColor",5,"indicatorDots",6,"interval",7,"vertical",8],e,s,gg);var oTv=_cvn();var oUv=function(oYv,oXv,oWv,gg){var oav=_ctn("swiper-item");var obv=_ctn("view");_setAttr(z,obv,'class',16,oYv,oXv,gg);_ac(oav,obv);_ac(oWv,oav);return oWv;};_2(z,14,oUv,e,s,gg,oTv,"item","index",'*this');_ac(oSv,oTv);_ac(oRv,oSv);_ac(oQv,oRv);var ocv=_setAttrs(z,"view",["class",17,"style",1],e,s,gg);var odv=_ctn("view");_setAttr(z,odv,'class',19,e,s,gg);var oev=_ctn("view");_setAttr(z,oev,'class',20,e,s,gg);var ofv=_ctn("view");_setAttr(z,ofv,'class',21,e,s,gg);var ogv=_o(z,22,e,s,gg);_ac(ofv,ogv);_ac(oev,ofv);var ohv=_ctn("view");_setAttr(z,ohv,'class',23,e,s,gg);var oiv=_setAttrs(z,"switch",["checked",11,"bindchange",13],e,s,gg);_ac(ohv,oiv);_ac(oev,ohv);_ac(odv,oev);var ojv=_ctn("view");_setAttr(z,ojv,'class',20,e,s,gg);var okv=_ctn("view");_setAttr(z,okv,'class',21,e,s,gg);var olv=_o(z,25,e,s,gg);_ac(okv,olv);_ac(ojv,okv);var omv=_ctn("view");_setAttr(z,omv,'class',26,e,s,gg);var onv=_setAttrs(z,"switch",["checked",5,"bindchange",22],e,s,gg);_ac(omv,onv);_ac(ojv,omv);_ac(odv,ojv);_ac(ocv,odv);_ac(oQv,ocv);var oov=_ctn("view");_setAttr(z,oov,'class',28,e,s,gg);var opv=_ctn("view");_setAttr(z,opv,'class',29,e,s,gg);var oqv=_ctn("text");var orv=_o(z,30,e,s,gg);_ac(oqv,orv);_ac(opv,oqv);var osv=_ctn("text");_setAttr(z,osv,'class',31,e,s,gg);var otv=_o(z,32,e,s,gg);_ac(osv,otv);_ac(opv,osv);_ac(oov,opv);var ouv=_setAttrs(z,"slider",["value",7,"bindchange",26,"class",27,"max",28,"min",29],e,s,gg);_ac(oov,ouv);var ovv=_ctn("view");_setAttr(z,ovv,'class',29,e,s,gg);var owv=_ctn("text");var oxv=_o(z,37,e,s,gg);_ac(owv,oxv);_ac(ovv,owv);var oyv=_ctn("text");_setAttr(z,oyv,'class',31,e,s,gg);var ozv=_o(z,38,e,s,gg);_ac(oyv,ozv);_ac(ovv,oyv);_ac(oov,ovv);var o_v=_setAttrs(z,"slider",["value",12,"min",23,"bindchange",27,"class",28,"max",29],e,s,gg);_ac(oov,o_v);_ac(oQv,oov);_ac(oLv,oQv);var oAw=_cvn();
    var oBw=_o(z,42,e,s,gg);
    var oCw=_gd('./macle_demo_EN/page/component/pages/swiper/swiper.maml',oBw,e_,d_);
    if(oCw){
      var oDw={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oCw(oDw,oDw,oAw,gg);
      gg.f=tgf;
    }else{
      _w(oBw,'./macle_demo_EN/page/component/pages/swiper/swiper.maml',0,0);
    }
    _ac(oLv,oAw);_ac(r,oLv);oIv.pop();oIv.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/swiper/swiper.maml"]={f:m71,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/switch/switch.maml"]={};
  var m72=function(e,s,r,gg){
    var z=gz$gma_73()
    var oEw=e_["./macle_demo_EN/page/component/pages/switch/switch.maml"].i;_ai(oEw,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/switch/switch.maml',0,0);_ai(oEw,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/switch/switch.maml',0,0);var oHw=_ctn("view");_setAttr(z,oHw,'class',0,e,s,gg);var oIw=_cvn();
    var oJw=_o(z,1,e,s,gg);
    var oKw=_gd('./macle_demo_EN/page/component/pages/switch/switch.maml',oJw,e_,d_);
    if(oKw){
      var oLw=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oKw(oLw,oLw,oIw,gg);
      gg.f=tgf;
    }else{
      _w(oJw,'./macle_demo_EN/page/component/pages/switch/switch.maml',0,0);
    }
    _ac(oHw,oIw);var oMw=_ctn("view");_setAttr(z,oMw,'class',3,e,s,gg);var oNw=_ctn("view");_setAttr(z,oNw,'class',4,e,s,gg);var oOw=_ctn("view");_setAttr(z,oOw,'class',5,e,s,gg);var oPw=_o(z,6,e,s,gg);_ac(oOw,oPw);_ac(oNw,oOw);var oQw=_ctn("view");_setAttr(z,oQw,'class',7,e,s,gg);var oRw=_setAttrs(z,"switch",["bindchange",8,"id",1],e,s,gg);_ac(oQw,oRw);_ac(oNw,oQw);var oSw=_cvn();if(_o(z,10,e,s,gg)){oSw.maVkey=1;var oTw=_ctn("view");_setAttr(z,oTw,'class',11,e,s,gg);var oVw=_o(z,12,e,s,gg);_ac(oTw,oVw);_ac(oSw,oTw);} _ac(oNw,oSw);_ac(oMw,oNw);var oWw=_ctn("view");_setAttr(z,oWw,'class',4,e,s,gg);var oXw=_ctn("view");_setAttr(z,oXw,'class',5,e,s,gg);var oYw=_o(z,13,e,s,gg);_ac(oXw,oYw);_ac(oWw,oXw);var oZw=_ctn("view");_setAttr(z,oZw,'class',7,e,s,gg);var oaw=_setAttrs(z,"switch",["bindchange",14,"checked",1,"id",2,"type",3],e,s,gg);_ac(oZw,oaw);_ac(oWw,oZw);_ac(oMw,oWw);var obw=_ctn("view");_setAttr(z,obw,'class',4,e,s,gg);var ocw=_ctn("view");_setAttr(z,ocw,'class',5,e,s,gg);var odw=_o(z,18,e,s,gg);_ac(ocw,odw);_ac(obw,ocw);var oew=_ctn("view");_setAttr(z,oew,'class',7,e,s,gg);var ofw=_setAttrs(z,"switch",["checked",15,"color",4,"id",5],e,s,gg);_ac(oew,ofw);var ogw=_setAttrs(z,"switch",["checked",15,"type",2,"color",4,"id",6],e,s,gg);_ac(oew,ogw);_ac(obw,oew);_ac(oMw,obw);var ohw=_ctn("view");_setAttr(z,ohw,'class',4,e,s,gg);var oiw=_ctn("view");_setAttr(z,oiw,'class',5,e,s,gg);var ojw=_o(z,22,e,s,gg);_ac(oiw,ojw);_ac(ohw,oiw);var okw=_ctn("view");_setAttr(z,okw,'class',7,e,s,gg);var olw=_setAttrs(z,"switch",["checked",15,"disabled",0,"id",8],e,s,gg);_ac(okw,olw);var omw=_setAttrs(z,"switch",["checked",15,"disabled",0,"type",2,"id",9],e,s,gg);_ac(okw,omw);_ac(ohw,okw);_ac(oMw,ohw);_ac(oHw,oMw);var onw=_cvn();
    var oow=_o(z,25,e,s,gg);
    var opw=_gd('./macle_demo_EN/page/component/pages/switch/switch.maml',oow,e_,d_);
    if(opw){
      var oqw={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      opw(oqw,oqw,onw,gg);
      gg.f=tgf;
    }else{
      _w(oow,'./macle_demo_EN/page/component/pages/switch/switch.maml',0,0);
    }
    _ac(oHw,onw);_ac(r,oHw);oEw.pop();oEw.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/switch/switch.maml"]={f:m72,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/text/text.maml"]={};
  var m73=function(e,s,r,gg){
    var z=gz$gma_74()
    var orw=e_["./macle_demo_EN/page/component/pages/text/text.maml"].i;_ai(orw,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/text/text.maml',0,0);_ai(orw,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/text/text.maml',0,0);var ouw=_ctn("view");_setAttr(z,ouw,'class',0,e,s,gg);var ovw=_cvn();
    var oww=_o(z,1,e,s,gg);
    var oxw=_gd('./macle_demo_EN/page/component/pages/text/text.maml',oww,e_,d_);
    if(oxw){
      var oyw=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oxw(oyw,oyw,ovw,gg);
      gg.f=tgf;
    }else{
      _w(oww,'./macle_demo_EN/page/component/pages/text/text.maml',0,0);
    }
    _ac(ouw,ovw);var ozw=_ctn("view");_setAttr(z,ozw,'class',3,e,s,gg);var o_w=_ctn("view");_setAttr(z,o_w,'class',4,e,s,gg);var oAx=_setAttrs(z,"view",["class",5,"scrollTop",1,"scrollY",2],e,s,gg);var oBx=_setAttrs(z,"text",["class",8,"decode",1,"space",2,"userSelect",3],e,s,gg);var oCx=_o(z,12,e,s,gg);_ac(oBx,oCx);_ac(oAx,oBx);_ac(o_w,oAx);var oDx=_ctn("view");var oEx=_setAttrs(z,"text",["userSelect",7,"class",6,"space",7],e,s,gg);var oFx=_o(z,15,e,s,gg);_ac(oEx,oFx);_ac(oDx,oEx);_ac(o_w,oDx);var oGx=_ctn("view");var oHx=_setAttrs(z,"text",["class",16,"space",1,"userSelect",2],e,s,gg);var oIx=_o(z,19,e,s,gg);_ac(oHx,oIx);_ac(oGx,oHx);_ac(o_w,oGx);var oJx=_ctn("view");var oKx=_setAttrs(z,"text",["space",10,"class",10],e,s,gg);var oLx=_o(z,21,e,s,gg);_ac(oKx,oLx);_ac(oJx,oKx);_ac(o_w,oJx);var oMx=_ctn("view");var oNx=_setAttrs(z,"text",["class",22,"space",1,"userSelect",2],e,s,gg);var oOx=_o(z,25,e,s,gg);_ac(oNx,oOx);_ac(oMx,oNx);_ac(o_w,oMx);var oPx=_setAttrs(z,"button",["bindtap",26,"class",1,"disabled",2],e,s,gg);var oQx=_o(z,29,e,s,gg);_ac(oPx,oQx);_ac(o_w,oPx);var oRx=_setAttrs(z,"button",["bindtap",30,"disabled",1],e,s,gg);var oSx=_o(z,32,e,s,gg);_ac(oRx,oSx);_ac(o_w,oRx);var oTx=_setAttrs(z,"button",["bindtap",33,"class",1],e,s,gg);var oUx=_o(z,35,e,s,gg);_ac(oTx,oUx);_ac(o_w,oTx);var oVx=_setAttrs(z,"button",["bindtap",36,"class",1],e,s,gg);var oWx=_o(z,38,e,s,gg);_ac(oVx,oWx);_ac(o_w,oVx);_ac(ozw,o_w);_ac(ouw,ozw);var oXx=_cvn();
    var oYx=_o(z,39,e,s,gg);
    var oZx=_gd('./macle_demo_EN/page/component/pages/text/text.maml',oYx,e_,d_);
    if(oZx){
      var oax={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oZx(oax,oax,oXx,gg);
      gg.f=tgf;
    }else{
      _w(oYx,'./macle_demo_EN/page/component/pages/text/text.maml',0,0);
    }
    _ac(ouw,oXx);_ac(r,ouw);orw.pop();orw.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/text/text.maml"]={f:m73,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/textarea/textarea.maml"]={};
  var m74=function(e,s,r,gg){
    var z=gz$gma_75()
    var obx=e_["./macle_demo_EN/page/component/pages/textarea/textarea.maml"].i;_ai(obx,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/textarea/textarea.maml',0,0);_ai(obx,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/textarea/textarea.maml',0,0);var oex=_ctn("view");_setAttr(z,oex,'class',0,e,s,gg);var ofx=_cvn();
    var ogx=_o(z,1,e,s,gg);
    var ohx=_gd('./macle_demo_EN/page/component/pages/textarea/textarea.maml',ogx,e_,d_);
    if(ohx){
      var oix=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ohx(oix,oix,ofx,gg);
      gg.f=tgf;
    }else{
      _w(ogx,'./macle_demo_EN/page/component/pages/textarea/textarea.maml',0,0);
    }
    _ac(oex,ofx);var ojx=_ctn("view");_setAttr(z,ojx,'class',3,e,s,gg);var okx=_ctn("view");_setAttr(z,okx,'class',4,e,s,gg);var olx=_ctn("view");_setAttr(z,olx,'class',5,e,s,gg);var omx=_o(z,6,e,s,gg);_ac(olx,omx);_ac(okx,olx);var onx=_ctn("view");_setAttr(z,onx,'class',7,e,s,gg);var oox=_setAttrs(z,"textarea",["placeholder",6,"autoHeight",2,"bindblur",3,"bindconfirm",4,"bindfocus",5,"bindinput",6,"bindlinechange",7,"id",8,"placeholderStyle",9,"style",10],e,s,gg);_ac(onx,oox);_ac(okx,onx);_ac(ojx,okx);var opx=_ctn("view");_setAttr(z,opx,'class',4,e,s,gg);var oqx=_ctn("view");_setAttr(z,oqx,'class',5,e,s,gg);var orx=_o(z,17,e,s,gg);_ac(oqx,orx);_ac(opx,oqx);var osx=_ctn("view");_setAttr(z,osx,'class',7,e,s,gg);var otx=_setAttrs(z,"textarea",["autoHeight",8,"focus",0,"id",10,"maxlength",11,"selectionEnd",12,"selectionStart",13,"style",14,"value",15],e,s,gg);_ac(osx,otx);_ac(opx,osx);_ac(ojx,opx);var oux=_ctn("view");_setAttr(z,oux,'class',24,e,s,gg);var ovx=_ctn("view");_setAttr(z,ovx,'class',25,e,s,gg);var owx=_o(z,26,e,s,gg);_ac(ovx,owx);_ac(oux,ovx);var oxx=_ctn("view");_setAttr(z,oxx,'class',7,e,s,gg);var oyx=_setAttrs(z,"textarea",["autoHeight",8,"disabled",0,"focus",0,"maxlength",11,"selectionEnd",12,"selectionStart",13,"style",14,"id",19,"value",20],e,s,gg);_ac(oxx,oyx);var ozx=_setAttrs(z,"textarea",["autoHeight",8,"maxlength",11,"style",14,"id",21,"value",22],e,s,gg);_ac(oxx,ozx);var o_x=_setAttrs(z,"textarea",["maxlength",19,"id",12,"placeholder",13,"placeholderClass",14],e,s,gg);_ac(oxx,o_x);_ac(oux,oxx);_ac(ojx,oux);_ac(oex,ojx);var oAy=_cvn();
    var oBy=_o(z,34,e,s,gg);
    var oCy=_gd('./macle_demo_EN/page/component/pages/textarea/textarea.maml',oBy,e_,d_);
    if(oCy){
      var oDy={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oCy(oDy,oDy,oAy,gg);
      gg.f=tgf;
    }else{
      _w(oBy,'./macle_demo_EN/page/component/pages/textarea/textarea.maml',0,0);
    }
    _ac(oex,oAy);_ac(r,oex);obx.pop();obx.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/textarea/textarea.maml"]={f:m74,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/video/video.maml"]={};
  var m75=function(e,s,r,gg){
    var z=gz$gma_76()
    var oEy=e_["./macle_demo_EN/page/component/pages/video/video.maml"].i;_ai(oEy,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/video/video.maml',0,0);_ai(oEy,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/video/video.maml',0,0);var oHy=_ctn("view");_setAttr(z,oHy,'class',0,e,s,gg);var oIy=_cvn();
    var oJy=_o(z,1,e,s,gg);
    var oKy=_gd('./macle_demo_EN/page/component/pages/video/video.maml',oJy,e_,d_);
    if(oKy){
      var oLy=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oKy(oLy,oLy,oIy,gg);
      gg.f=tgf;
    }else{
      _w(oJy,'./macle_demo_EN/page/component/pages/video/video.maml',0,0);
    }
    _ac(oHy,oIy);var oMy=_ctn("view");_setAttr(z,oMy,'class',3,e,s,gg);var oNy=_ctn("view");_setAttr(z,oNy,'class',4,e,s,gg);var oOy=_setAttrs(z,"video",["autoplay",5,"bindended",1,"binderror",2,"bindpause",3,"bindplay",4,"bindtimeupdate",5,"controls",6,"hidden",7,"id",8,"loop",9,"muted",10,"objectFit",11,"poster",12,"src",13],e,s,gg);_ac(oNy,oOy);var oPy=_ctn("view");_setAttr(z,oPy,'class',19,e,s,gg);var oQy=_ctn("view");_setAttr(z,oQy,'class',20,e,s,gg);var oRy=_ctn("view");_setAttr(z,oRy,'class',21,e,s,gg);var oSy=_ctn("view");_setAttr(z,oSy,'class',22,e,s,gg);var oTy=_o(z,23,e,s,gg);_ac(oSy,oTy);_ac(oRy,oSy);_ac(oQy,oRy);var oUy=_ctn("view");_setAttr(z,oUy,'class',24,e,s,gg);var oVy=_setAttrs(z,"input",["adjustPosition",25,"bindinput",1,"class",2,"placeholder",3,"type",4,"value",5],e,s,gg);_ac(oUy,oVy);_ac(oQy,oUy);_ac(oPy,oQy);_ac(oNy,oPy);var oWy=_ctn("view");_setAttr(z,oWy,'class',31,e,s,gg);var oXy=_setAttrs(z,"button",["bindtap",32,"class",1,"type",2],e,s,gg);var oYy=_o(z,35,e,s,gg);_ac(oXy,oYy);_ac(oWy,oXy);var oZy=_setAttrs(z,"button",["type",34,"bindtap",2,"class",3],e,s,gg);var oay=_o(z,36,e,s,gg);_ac(oZy,oay);_ac(oWy,oZy);var oby=_setAttrs(z,"button",["type",34,"bindtap",4,"class",5],e,s,gg);var ocy=_o(z,40,e,s,gg);_ac(oby,ocy);_ac(oWy,oby);_ac(oNy,oWy);_ac(oMy,oNy);_ac(oHy,oMy);var ody=_cvn();
    var oey=_o(z,41,e,s,gg);
    var ofy=_gd('./macle_demo_EN/page/component/pages/video/video.maml',oey,e_,d_);
    if(ofy){
      var ogy={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ofy(ogy,ogy,ody,gg);
      gg.f=tgf;
    }else{
      _w(oey,'./macle_demo_EN/page/component/pages/video/video.maml',0,0);
    }
    _ac(oHy,ody);_ac(r,oHy);oEy.pop();oEy.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/video/video.maml"]={f:m75,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/view/view.maml"]={};
  var m76=function(e,s,r,gg){
    var z=gz$gma_77()
    var ohy=e_["./macle_demo_EN/page/component/pages/view/view.maml"].i;_ai(ohy,'../../../common/head.maml',e_,'./macle_demo_EN/page/component/pages/view/view.maml',0,0);_ai(ohy,'../../../common/foot.maml',e_,'./macle_demo_EN/page/component/pages/view/view.maml',0,0);var oky=_ctn("view");_setAttr(z,oky,'class',0,e,s,gg);var oly=_cvn();
    var omy=_o(z,1,e,s,gg);
    var ony=_gd('./macle_demo_EN/page/component/pages/view/view.maml',omy,e_,d_);
    if(ony){
      var ooy=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ony(ooy,ooy,oly,gg);
      gg.f=tgf;
    }else{
      _w(omy,'./macle_demo_EN/page/component/pages/view/view.maml',0,0);
    }
    _ac(oky,oly);var opy=_ctn("view");_setAttr(z,opy,'class',3,e,s,gg);var oqy=_ctn("view");_setAttr(z,oqy,'class',4,e,s,gg);var ory=_ctn("view");_setAttr(z,ory,'class',5,e,s,gg);var osy=_ctn("text");var oty=_o(z,6,e,s,gg);_ac(osy,oty);_ac(ory,osy);_ac(oqy,ory);var ouy=_setAttrs(z,"view",["class",7,"hoverClass",1,"hoverStartTime",2,"hoverStayTime",3],e,s,gg);var ovy=_setAttrs(z,"view",["class",11,"style",1],e,s,gg);var owy=_setAttrs(z,"view",["class",13,"hoverStopPropagation",1],e,s,gg);_ac(ovy,owy);var oxy=_ctn("view");_setAttr(z,oxy,'class',15,e,s,gg);_ac(ovy,oxy);var oyy=_ctn("view");_setAttr(z,oyy,'class',16,e,s,gg);_ac(ovy,oyy);_ac(ouy,ovy);_ac(oqy,ouy);_ac(opy,oqy);var ozy=_ctn("view");_setAttr(z,ozy,'class',4,e,s,gg);var o_y=_ctn("view");_setAttr(z,o_y,'class',5,e,s,gg);var oAz=_ctn("text");var oBz=_o(z,17,e,s,gg);_ac(oAz,oBz);_ac(o_y,oAz);_ac(ozy,o_y);var oCz=_setAttrs(z,"view",["class",11,"style",7],e,s,gg);var oDz=_ctn("view");_setAttr(z,oDz,'class',19,e,s,gg);_ac(oCz,oDz);var oEz=_ctn("view");_setAttr(z,oEz,'class',20,e,s,gg);_ac(oCz,oEz);var oFz=_ctn("view");_setAttr(z,oFz,'class',21,e,s,gg);_ac(oCz,oFz);_ac(ozy,oCz);_ac(opy,ozy);_ac(oky,opy);var oGz=_cvn();
    var oHz=_o(z,22,e,s,gg);
    var oIz=_gd('./macle_demo_EN/page/component/pages/view/view.maml',oHz,e_,d_);
    if(oIz){
      var oJz={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oIz(oJz,oJz,oGz,gg);
      gg.f=tgf;
    }else{
      _w(oHz,'./macle_demo_EN/page/component/pages/view/view.maml',0,0);
    }
    _ac(oky,oGz);_ac(r,oky);ohy.pop();ohy.pop();
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/view/view.maml"]={f:m76,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/component/pages/web-view/web-view.maml"]={};
  var m77=function(e,s,r,gg){
    var z=gz$gma_78()
    var oLz=_ctn("web-view");_setAttr(z,oLz,'src',0,e,s,gg);_ac(r,oLz);
    return r;
  };
  e_["./macle_demo_EN/page/component/pages/web-view/web-view.maml"]={f:m77,j:[],i:[],ti:[],ic:[]};

  d_["./macle_demo_EN/page/framework/pages/communication/communication.maml"]={};
  var m78=function(e,s,r,gg){
    var z=gz$gma_79()
    var oMz=e_["./macle_demo_EN/page/framework/pages/communication/communication.maml"].i;_ai(oMz,'../../../common/head.maml',e_,'./macle_demo_EN/page/framework/pages/communication/communication.maml',0,0);_ai(oMz,'../../../common/foot.maml',e_,'./macle_demo_EN/page/framework/pages/communication/communication.maml',0,0);var oPz=_ctn("view");_setAttr(z,oPz,'class',0,e,s,gg);var oQz=_setAttrs(z,"detail",["bindmyevent",1,"detail",1,"id",2,"propTest",3],e,s,gg);var oRz=_ctn("button");_setAttr(z,oRz,'bindtap',5,e,s,gg);var oSz=_o(z,6,e,s,gg);_ac(oRz,oSz);_ac(oQz,oRz);_ac(oPz,oQz);var oTz=_ctn("button");_setAttr(z,oTz,'bindtap',7,e,s,gg);var oUz=_o(z,8,e,s,gg);_ac(oTz,oUz);_ac(oPz,oTz);var oVz=_ctn("button");_setAttr(z,oVz,'bindtap',9,e,s,gg);var oWz=_o(z,10,e,s,gg);_ac(oVz,oWz);_ac(oPz,oVz);var oXz=_cvn();
    var oYz=_o(z,11,e,s,gg);
    var oZz=_gd('./macle_demo_EN/page/framework/pages/communication/communication.maml',oYz,e_,d_);
    if(oZz){
      var oaz={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oZz(oaz,oaz,oXz,gg);
      gg.f=tgf;
    }else{
      _w(oYz,'./macle_demo_EN/page/framework/pages/communication/communication.maml',0,0);
    }
    _ac(oPz,oXz);_ac(r,oPz);oMz.pop();oMz.pop();
    return r;
  };
  e_["./macle_demo_EN/page/framework/pages/communication/communication.maml"]={f:m78,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml"]={};
  var m79=function(e,s,r,gg){
    var z=gz$gma_80()
    var obz=e_["./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml"].i;_ai(obz,'../../../common/head.maml',e_,'./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml',0,0);_ai(obz,'../../../common/foot.maml',e_,'./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml',0,0);var oez=_setAttrs(z,"view",["class",0,"style",1],e,s,gg);var ofz=_cvn();
    var ogz=_o(z,2,e,s,gg);
    var ohz=_gd('./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml',ogz,e_,d_);
    if(ohz){
      var oiz=_1(z,3,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ohz(oiz,oiz,ofz,gg);
      gg.f=tgf;
    }else{
      _w(ogz,'./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml',0,0);
    }
    _ac(oez,ofz);var ojz=_ctn("view");_setAttr(z,ojz,'class',4,e,s,gg);var okz=_ctn("view");var olz=_o(z,5,e,s,gg);_ac(okz,olz);_ac(ojz,okz);var omz=_ctn("view");var onz=_o(z,6,e,s,gg);_ac(omz,onz);_ac(ojz,omz);var ooz=_ctn("view");var opz=_o(z,7,e,s,gg);_ac(ooz,opz);_ac(ojz,ooz);var oqz=_ctn("view");var orz=_o(z,8,e,s,gg);_ac(oqz,orz);_ac(ojz,oqz);var osz=_ctn("view");var otz=_o(z,9,e,s,gg);_ac(osz,otz);_ac(ojz,osz);var ouz=_ctn("view");var ovz=_o(z,10,e,s,gg);_ac(ouz,ovz);_ac(ojz,ouz);var owz=_ctn("view");_setAttr(z,owz,'class',11,e,s,gg);var oxz=_ctn("button");_setAttr(z,oxz,'bindtap',12,e,s,gg);var oyz=_o(z,13,e,s,gg);_ac(oxz,oyz);_ac(owz,oxz);var ozz=_ctn("button");_setAttr(z,ozz,'bindtap',14,e,s,gg);var o_z=_o(z,15,e,s,gg);_ac(ozz,o_z);_ac(owz,ozz);var oA_=_ctn("button");_setAttr(z,oA_,'bindtap',14,e,s,gg);var oB_=_o(z,16,e,s,gg);_ac(oA_,oB_);_ac(owz,oA_);var oC_=_ctn("button");_setAttr(z,oC_,'bindtap',17,e,s,gg);var oD_=_o(z,18,e,s,gg);_ac(oC_,oD_);_ac(owz,oC_);_ac(ojz,owz);var oE_=_ctn("view");_setAttr(z,oE_,'class',19,e,s,gg);var oF_=_ctn("view");_setAttr(z,oF_,'class',20,e,s,gg);var oG_=_setAttrs(z,"view",["class",21,"style",1],e,s,gg);var oH_=_ctn("view");_setAttr(z,oH_,'class',23,e,s,gg);var oI_=_ctn("view");_setAttr(z,oI_,'class',24,e,s,gg);var oJ_=_o(z,25,e,s,gg);_ac(oI_,oJ_);_ac(oH_,oI_);_ac(oG_,oH_);var oK_=_ctn("view");_setAttr(z,oK_,'class',26,e,s,gg);var oL_=_setAttrs(z,"picker",["bindchange",27,"headerText",1,"name",2,"range",3,"value",4],e,s,gg);var oM_=_ctn("view");var oN_=_o(z,32,e,s,gg);_ac(oM_,oN_);_ac(oL_,oM_);_ac(oK_,oL_);_ac(oG_,oK_);_ac(oF_,oG_);_ac(oE_,oF_);_ac(ojz,oE_);_ac(oez,ojz);var oO_=_cvn();
    var oP_=_o(z,33,e,s,gg);
    var oQ_=_gd('./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml',oP_,e_,d_);
    if(oQ_){
      var oR_={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oQ_(oR_,oR_,oO_,gg);
      gg.f=tgf;
    }else{
      _w(oP_,'./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml',0,0);
    }
    _ac(oez,oO_);_ac(r,oez);obz.pop();obz.pop();
    return r;
  };
  e_["./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml"]={f:m79,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml"]={};
  var m80=function(e,s,r,gg){
    var z=gz$gma_81()
    var oS_=e_["./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml"].i;_ai(oS_,'../../../common/head.maml',e_,'./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml',0,0);_ai(oS_,'../../../common/foot.maml',e_,'./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml',0,0);var oW_=_setAttrs(z,"view",["class",0,"style",1],e,s,gg);var oX_=_cvn();
    var oY_=_o(z,2,e,s,gg);
    var oZ_=_gd('./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml',oY_,e_,d_);
    if(oZ_){
      var oa_=_1(z,3,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oZ_(oa_,oa_,oX_,gg);
      gg.f=tgf;
    }else{
      _w(oY_,'./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml',0,0);
    }
    _ac(oW_,oX_);var ob_=_ctn("view");_setAttr(z,ob_,'class',4,e,s,gg);var oc_=_o(z,5,e,s,gg);_ac(ob_,oc_);var od_=_ctn("view");var oe_=_o(z,6,e,s,gg);_ac(od_,oe_);_ac(ob_,od_);_ac(oW_,ob_);var of_=_cvn();
    var og_=_o(z,7,e,s,gg);
    var oh_=_gd('./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml',og_,e_,d_);
    if(oh_){
      var oi_={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oh_(oi_,oi_,of_,gg);
      gg.f=tgf;
    }else{
      _w(og_,'./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml',0,0);
    }
    _ac(oW_,of_);_ac(r,oW_);oS_.pop();oS_.pop();
    return r;
  };
  e_["./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml"]={f:m80,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml"]={};
  var m81=function(e,s,r,gg){
    var z=gz$gma_82()
    var oj_=e_["./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml"].i;_ai(oj_,'../../../common/head.maml',e_,'./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml',0,0);_ai(oj_,'../../../common/foot.maml',e_,'./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml',0,0);var om_=_ctn("view");_setAttr(z,om_,'class',0,e,s,gg);var on_=_cvn();
    var oo_=_o(z,1,e,s,gg);
    var op_=_gd('./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml',oo_,e_,d_);
    if(op_){
      var oq_=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      op_(oq_,oq_,on_,gg);
      gg.f=tgf;
    }else{
      _w(oo_,'./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml',0,0);
    }
    _ac(om_,on_);var os_=_setAttrs(z,"view",["bind:touchend",3,"bind:touchmove",0,"bind:touchstart",0,"class",1,"style",2],e,s,gg);var ot_=_setAttrs(z,"view",["bind:tap",6,"class",1,"style",2],e,s,gg);var ou_=_setAttrs(z,"image",["class",9,"mode",1,"src",2],e,s,gg);_ac(ot_,ou_);_ac(os_,ot_);_ac(om_,os_);var ov_=_setAttrs(z,"view",["class",4,"bind:touchend",8,"bind:touchmove",8,"bind:touchstart",8,"data-maxHeight",9,"data-maxWidth",10,"style",11],e,s,gg);var ow_=_setAttrs(z,"view",["catch:tap",6,"class",1,"style",10],e,s,gg);var ox_=_setAttrs(z,"image",["class",9,"mode",1,"src",2],e,s,gg);_ac(ow_,ox_);_ac(ov_,ow_);_ac(om_,ov_);var oy_=_cvn();
    var oz_=_o(z,17,e,s,gg);
    var o__=_gd('./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml',oz_,e_,d_);
    if(o__){
      var oAAB={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      o__(oAAB,oAAB,oy_,gg);
      gg.f=tgf;
    }else{
      _w(oz_,'./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml',0,0);
    }
    _ac(om_,oy_);_ac(r,om_);oj_.pop();oj_.pop();
    return r;
  };
  e_["./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml"]={f:m81,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml"]={};
  var m82=function(e,s,r,gg){
    var z=gz$gma_83()
    var oBAB=e_["./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml"].i;_ai(oBAB,'../../../common/head.maml',e_,'./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml',0,0);_ai(oBAB,'../../../common/foot.maml',e_,'./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml',0,0);var oFAB=_ctn("view");_setAttr(z,oFAB,'class',0,e,s,gg);var oGAB=_cvn();
    var oHAB=_o(z,1,e,s,gg);
    var oIAB=_gd('./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml',oHAB,e_,d_);
    if(oIAB){
      var oJAB=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oIAB(oJAB,oJAB,oGAB,gg);
      gg.f=tgf;
    }else{
      _w(oHAB,'./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml',0,0);
    }
    _ac(oFAB,oGAB);var oKAB=_ctn("view");_setAttr(z,oKAB,'class',3,e,s,gg);var oLAB=_o(z,4,e,s,gg);_ac(oKAB,oLAB);_ac(oFAB,oKAB);var oMAB=_ctn("view");var oNAB=_o(z,5,e,s,gg);_ac(oMAB,oNAB);_ac(oFAB,oMAB);var oOAB=_ctn("view");_setAttr(z,oOAB,'class',3,e,s,gg);var oPAB=_o(z,6,e,s,gg);_ac(oOAB,oPAB);_ac(oFAB,oOAB);var oQAB=_ctn("view");var oRAB=_o(z,7,e,s,gg);_ac(oQAB,oRAB);_ac(oFAB,oQAB);var oSAB=_ctn("view");_setAttr(z,oSAB,'class',3,e,s,gg);var oTAB=_o(z,8,e,s,gg);_ac(oSAB,oTAB);_ac(oFAB,oSAB);var oUAB=_ctn("view");var oVAB=_o(z,9,e,s,gg);_ac(oUAB,oVAB);_ac(oFAB,oUAB);var oWAB=_ctn("view");_setAttr(z,oWAB,'class',10,e,s,gg);var oXAB=_setAttrs(z,"button",["bindtap",11,"type",1],e,s,gg);var oYAB=_o(z,13,e,s,gg);_ac(oXAB,oYAB);_ac(oWAB,oXAB);_ac(oFAB,oWAB);var oZAB=_cvn();
    var oaAB=_o(z,14,e,s,gg);
    var obAB=_gd('./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml',oaAB,e_,d_);
    if(obAB){
      var ocAB={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      obAB(ocAB,ocAB,oZAB,gg);
      gg.f=tgf;
    }else{
      _w(oaAB,'./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml',0,0);
    }
    _ac(oFAB,oZAB);_ac(r,oFAB);oBAB.pop();oBAB.pop();
    return r;
  };
  e_["./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml"]={f:m82,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml"]={};
  var m83=function(e,s,r,gg){
    var z=gz$gma_84()
    var odAB=e_["./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml"].i;_ai(odAB,'../../../../common/head.maml',e_,'./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);_ai(odAB,'../../../../common/foot.maml',e_,'./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);var ogAB=_ctn("view");_setAttr(z,ogAB,'class',0,e,s,gg);var ohAB=_cvn();
    var oiAB=_o(z,1,e,s,gg);
    var ojAB=_gd('./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',oiAB,e_,d_);
    if(ojAB){
      var okAB=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ojAB(okAB,okAB,ohAB,gg);
      gg.f=tgf;
    }else{
      _w(oiAB,'./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);
    }
    _ac(ogAB,ohAB);var olAB=_ctn("view");_setAttr(z,olAB,'class',3,e,s,gg);var omAB=_ctn("view");_setAttr(z,omAB,'class',4,e,s,gg);var onAB=_setAttrs(z,"button",["bindtap",5,"class",1],e,s,gg);var ooAB=_o(z,7,e,s,gg);_ac(onAB,ooAB);_ac(omAB,onAB);var opAB=_setAttrs(z,"button",["bindtap",8,"class",0],e,s,gg);var oqAB=_o(z,9,e,s,gg);_ac(opAB,oqAB);_ac(omAB,opAB);var orAB=_setAttrs(z,"button",["bindtap",10,"class",0],e,s,gg);var osAB=_o(z,11,e,s,gg);_ac(orAB,osAB);_ac(omAB,orAB);var otAB=_setAttrs(z,"button",["bindtap",12,"class",1],e,s,gg);var ouAB=_o(z,14,e,s,gg);_ac(otAB,ouAB);_ac(omAB,otAB);_ac(olAB,omAB);_ac(ogAB,olAB);var ovAB=_cvn();
    var owAB=_o(z,15,e,s,gg);
    var oxAB=_gd('./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',owAB,e_,d_);
    if(oxAB){
      var oyAB={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oxAB(oyAB,oyAB,ovAB,gg);
      gg.f=tgf;
    }else{
      _w(owAB,'./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);
    }
    _ac(ogAB,ovAB);_ac(r,ogAB);odAB.pop();odAB.pop();
    return r;
  };
  e_["./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml"]={f:m83,j:[],i:[],ti:["../../../../common/head.maml","../../../../common/foot.maml"],ic:[]};

  d_["./macle_demo_EN/page/tabbar/api/index.maml"]={};
  var m84=function(e,s,r,gg){
    var z=gz$gma_85()
    var o_AB=_cvn();if(_o(z,0,e,s,gg)){o_AB.maVkey=1;var oABB=_ctn("set-tab-bar");_setAttr(z,oABB,'bindunmount',1,e,s,gg);_ac(o_AB,oABB);}else{o_AB.maVkey=2;var oCBB=_ctn("view");_setAttr(z,oCBB,'class',2,e,s,gg);var oEBB=_ctn("view");_setAttr(z,oEBB,'class',3,e,s,gg);var oFBB=_ctn("view");_setAttr(z,oFBB,'class',4,e,s,gg);var oGBB=_o(z,5,e,s,gg);_ac(oFBB,oGBB);_ac(oEBB,oFBB);_ac(oCBB,oEBB);var oHBB=_ctn("view");_setAttr(z,oHBB,'class',6,e,s,gg);var oIBB=_ctn("view");_setAttr(z,oIBB,'class',7,e,s,gg);var oJBB=_cvn();var oKBB=function(oOBB,oNBB,oMBB,gg){var oQBB=_ctn("view");_setAttr(z,oQBB,'class',10,oOBB,oNBB,gg);var oRBB=_setAttrs(z,"view",["id",9,"bindtap",2,"class",3],oOBB,oNBB,gg);var oSBB=_ctn("view");_setAttr(z,oSBB,'class',13,oOBB,oNBB,gg);var oTBB=_o(z,14,oOBB,oNBB,gg);_ac(oSBB,oTBB);_ac(oRBB,oSBB);var oUBB=_setAttrs(z,"image",["class",15,"src",1],oOBB,oNBB,gg);_ac(oRBB,oUBB);_ac(oQBB,oRBB);var oVBB=_ctn("view");_setAttr(z,oVBB,'class',17,oOBB,oNBB,gg);var oWBB=_ctn("view");_setAttr(z,oWBB,'class',18,oOBB,oNBB,gg);var oXBB=_cvn();var oYBB=function(ocBB,obBB,oaBB,gg){var oeBB=_cvn();if(_o(z,22,ocBB,obBB,gg)){oeBB.maVkey=1;var ofBB=_setAttrs(z,"navigator",["class",23,"url",1],ocBB,obBB,gg);var ohBB=_setAttrs(z,"view",["class",25,"id",1],ocBB,obBB,gg);var oiBB=_o(z,27,ocBB,obBB,gg);_ac(ohBB,oiBB);_ac(ofBB,ohBB);var ojBB=_ctn("view");_setAttr(z,ojBB,'class',28,ocBB,obBB,gg);_ac(ofBB,ojBB);_ac(oeBB,ofBB);}else{oeBB.maVkey=2;var okBB=_setAttrs(z,"view",["class",23,"bindtap",6],e,s,gg);var omBB=_setAttrs(z,"view",["class",25,"id",1],e,s,gg);var onBB=_o(z,27,e,s,gg);_ac(omBB,onBB);_ac(okBB,omBB);var ooBB=_ctn("view");_setAttr(z,ooBB,'class',28,e,s,gg);_ac(okBB,ooBB);_ac(oeBB,okBB);}_ac(oaBB,oeBB);return oaBB;};_2(z,19,oYBB,oOBB,oNBB,gg,oXBB,"page","index",'*item');_ac(oWBB,oXBB);_ac(oVBB,oWBB);_ac(oQBB,oVBB);_ac(oMBB,oQBB);return oMBB;};_2(z,8,oKBB,e,s,gg,oJBB,"item","index",'{{item.id}}');_ac(oIBB,oJBB);_ac(oHBB,oIBB);_ac(oCBB,oHBB);_ac(o_AB,oCBB);}_ac(r,o_AB);
    return r;
  };
  e_["./macle_demo_EN/page/tabbar/api/index.maml"]={f:m84,j:[],i:[],ti:[],ic:[]};

  d_["./macle_demo_EN/page/tabbar/component/index.maml"]={};
  var m85=function(e,s,r,gg){
    var z=gz$gma_86()
    var oqBB=_ctn("view");_setAttr(z,oqBB,'class',0,e,s,gg);var orBB=_ctn("view");_setAttr(z,orBB,'class',1,e,s,gg);var osBB=_ctn("view");_setAttr(z,osBB,'class',2,e,s,gg);var otBB=_o(z,3,e,s,gg);_ac(osBB,otBB);_ac(orBB,osBB);_ac(oqBB,orBB);var ouBB=_ctn("view");_setAttr(z,ouBB,'class',4,e,s,gg);var ovBB=_ctn("view");_setAttr(z,ovBB,'class',5,e,s,gg);var owBB=_cvn();var oxBB=function(oACB,o_BB,ozBB,gg){var oCCB=_ctn("view");_setAttr(z,oCCB,'class',9,oACB,o_BB,gg);var oDCB=_setAttrs(z,"view",["id",8,"bindtap",2,"class",3],oACB,o_BB,gg);var oECB=_ctn("view");_setAttr(z,oECB,'class',12,oACB,o_BB,gg);var oFCB=_o(z,13,oACB,o_BB,gg);_ac(oECB,oFCB);_ac(oDCB,oECB);var oGCB=_cvn();if(_o(z,14,oACB,o_BB,gg)){oGCB.maVkey=1;var oHCB=_setAttrs(z,"image",["class",15,"src",1],oACB,o_BB,gg);_ac(oGCB,oHCB);} _ac(oDCB,oGCB);_ac(oCCB,oDCB);var oJCB=_ctn("view");_setAttr(z,oJCB,'class',17,oACB,o_BB,gg);var oKCB=_ctn("view");_setAttr(z,oKCB,'class',18,oACB,o_BB,gg);var oLCB=_cvn();var oMCB=function(oQCB,oPCB,oOCB,gg){var oSCB=_setAttrs(z,"navigator",["class",22,"id",1,"url",2],oQCB,oPCB,gg);var oTCB=_setAttrs(z,"view",["class",25,"id",1],oQCB,oPCB,gg);var oUCB=_o(z,27,oQCB,oPCB,gg);_ac(oTCB,oUCB);_ac(oSCB,oTCB);var oVCB=_ctn("view");_setAttr(z,oVCB,'class',28,oQCB,oPCB,gg);_ac(oSCB,oVCB);_ac(oOCB,oSCB);return oOCB;};_2(z,19,oMCB,oACB,o_BB,gg,oLCB,"page","index",'*item');_ac(oKCB,oLCB);_ac(oJCB,oKCB);_ac(oCCB,oJCB);_ac(ozBB,oCCB);return ozBB;};_2(z,6,oxBB,e,s,gg,owBB,"item","index",'{{item.id}}');_ac(ovBB,owBB);_ac(ouBB,ovBB);_ac(oqBB,ouBB);_ac(r,oqBB);
    return r;
  };
  e_["./macle_demo_EN/page/tabbar/component/index.maml"]={f:m85,j:[],i:[],ti:[],ic:[]};

  d_["./macle_demo_EN/page/tabbar/framework/index.maml"]={};
  var m86=function(e,s,r,gg){
    var z=gz$gma_87()
    var oXCB=_ctn("view");_setAttr(z,oXCB,'class',0,e,s,gg);var oYCB=_ctn("view");_setAttr(z,oYCB,'class',1,e,s,gg);var oZCB=_ctn("view");_setAttr(z,oZCB,'class',2,e,s,gg);var oaCB=_o(z,3,e,s,gg);_ac(oZCB,oaCB);_ac(oYCB,oZCB);_ac(oXCB,oYCB);var obCB=_ctn("view");_setAttr(z,obCB,'class',4,e,s,gg);var ocCB=_ctn("view");_setAttr(z,ocCB,'class',5,e,s,gg);var odCB=_cvn();var oeCB=function(oiCB,ohCB,ogCB,gg){var okCB=_ctn("view");_setAttr(z,okCB,'class',9,oiCB,ohCB,gg);var olCB=_setAttrs(z,"view",["id",8,"bindtap",2,"class",3],oiCB,ohCB,gg);var omCB=_ctn("view");_setAttr(z,omCB,'class',12,oiCB,ohCB,gg);var onCB=_o(z,13,oiCB,ohCB,gg);_ac(omCB,onCB);_ac(olCB,omCB);_ac(okCB,olCB);var ooCB=_ctn("view");_setAttr(z,ooCB,'class',14,oiCB,ohCB,gg);var opCB=_ctn("view");_setAttr(z,opCB,'class',15,oiCB,ohCB,gg);var oqCB=_cvn();var orCB=function(ovCB,ouCB,otCB,gg){var oxCB=_setAttrs(z,"navigator",["class",19,"url",1],ovCB,ouCB,gg);var oyCB=_ctn("view");_setAttr(z,oyCB,'class',21,ovCB,ouCB,gg);var ozCB=_o(z,22,ovCB,ouCB,gg);_ac(oyCB,ozCB);_ac(oxCB,oyCB);var o_CB=_ctn("view");_setAttr(z,o_CB,'class',23,ovCB,ouCB,gg);_ac(oxCB,o_CB);_ac(otCB,oxCB);return otCB;};_2(z,16,orCB,oiCB,ohCB,gg,oqCB,"page","index",'*item');_ac(opCB,oqCB);_ac(ooCB,opCB);_ac(okCB,ooCB);_ac(ogCB,okCB);return ogCB;};_2(z,6,oeCB,e,s,gg,odCB,"item","index",'{{item.id}}');_ac(ocCB,odCB);_ac(obCB,ocCB);_ac(oXCB,obCB);_ac(r,oXCB);
    return r;
  };
  e_["./macle_demo_EN/page/tabbar/framework/index.maml"]={f:m86,j:[],i:[],ti:[],ic:[]};

  d_["./page/common/foot.maml"]={};
  d_["./page/common/foot.maml"]["foot"]=function(e,s,r,gg){
    var z=gz$gma_88(),b='./page/common/foot.maml:foot'
    r.maVkey=b
    gg.f=$gdc(f_["./page/common/foot.maml"],"",1)
    if(p_[b]){_wl(b,'./page/common/foot.maml');return}
    p_[b]=true
    try{
      var oBDB=_setAttrs(z,"navigator",["class",0,"hoverClass",1,"openType",1,"url",2],e,s,gg);var oCDB=_setAttrs(z,"image",["class",4,"src",1],e,s,gg);_ac(oBDB,oCDB);_ac(r,oBDB);
    }catch(e){
      p_[b]=false
      throw e
    }
    p_[b]=false
    return r
  };
  var m87=function(e,s,r,gg){
    var z=gz$gma_88()
    
    return r;
  };
  e_["./page/common/foot.maml"]={f:m87,j:[],i:[],ti:[],ic:[]};

  d_["./page/common/head.maml"]={};
  d_["./page/common/head.maml"]["head"]=function(e,s,r,gg){
    var z=gz$gma_89(),b='./page/common/head.maml:head'
    r.maVkey=b
    gg.f=$gdc(f_["./page/common/head.maml"],"",1)
    if(p_[b]){_wl(b,'./page/common/head.maml');return}
    p_[b]=true
    try{
      var oGDB=_ctn("view");_setAttr(z,oGDB,'class',0,e,s,gg);var oHDB=_ctn("view");_setAttr(z,oHDB,'class',1,e,s,gg);var oIDB=_o(z,2,e,s,gg);_ac(oHDB,oIDB);_ac(oGDB,oHDB);var oJDB=_ctn("view");_setAttr(z,oJDB,'class',3,e,s,gg);_ac(oGDB,oJDB);var oKDB=_cvn();if(_o(z,4,e,s,gg)){oKDB.maVkey=1;var oLDB=_ctn("view");_setAttr(z,oLDB,'class',5,e,s,gg);var oNDB=_o(z,6,e,s,gg);_ac(oLDB,oNDB);_ac(oKDB,oLDB);} _ac(oGDB,oKDB);_ac(r,oGDB);
    }catch(e){
      p_[b]=false
      throw e
    }
    p_[b]=false
    return r
  };
  var m88=function(e,s,r,gg){
    var z=gz$gma_89()
    
    return r;
  };
  e_["./page/common/head.maml"]={f:m88,j:[],i:[],ti:[],ic:[]};

  d_["./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml"]={};
  var m89=function(e,s,r,gg){
    var z=gz$gma_90()
    var oQDB=e_["./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml"].i;_ai(oQDB,'../../../../common/head.maml',e_,'./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);_ai(oQDB,'../../../../common/foot.maml',e_,'./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);var oTDB=_ctn("view");_setAttr(z,oTDB,'class',0,e,s,gg);var oUDB=_cvn();
    var oVDB=_o(z,1,e,s,gg);
    var oWDB=_gd('./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',oVDB,e_,d_);
    if(oWDB){
      var oXDB=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oWDB(oXDB,oXDB,oUDB,gg);
      gg.f=tgf;
    }else{
      _w(oVDB,'./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);
    }
    _ac(oTDB,oUDB);var oYDB=_ctn("view");_setAttr(z,oYDB,'class',3,e,s,gg);var oZDB=_ctn("view");_setAttr(z,oZDB,'class',4,e,s,gg);var oaDB=_setAttrs(z,"button",["bindtap",5,"class",1],e,s,gg);var obDB=_o(z,7,e,s,gg);_ac(oaDB,obDB);_ac(oZDB,oaDB);var ocDB=_setAttrs(z,"button",["bindtap",8,"class",0],e,s,gg);var odDB=_o(z,9,e,s,gg);_ac(ocDB,odDB);_ac(oZDB,ocDB);var oeDB=_setAttrs(z,"button",["bindtap",10,"class",0],e,s,gg);var ofDB=_o(z,11,e,s,gg);_ac(oeDB,ofDB);_ac(oZDB,oeDB);var ogDB=_setAttrs(z,"button",["bindtap",12,"class",1],e,s,gg);var ohDB=_o(z,14,e,s,gg);_ac(ogDB,ohDB);_ac(oZDB,ogDB);_ac(oYDB,oZDB);_ac(oTDB,oYDB);var oiDB=_cvn();
    var ojDB=_o(z,15,e,s,gg);
    var okDB=_gd('./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',ojDB,e_,d_);
    if(okDB){
      var olDB={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      okDB(olDB,olDB,oiDB,gg);
      gg.f=tgf;
    }else{
      _w(ojDB,'./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);
    }
    _ac(oTDB,oiDB);_ac(r,oTDB);oQDB.pop();oQDB.pop();
    return r;
  };
  e_["./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml"]={f:m89,j:[],i:[],ti:["../../../../common/head.maml","../../../../common/foot.maml"],ic:[]};

  d_["./page/tabbar/api/index.maml"]={};
  var m90=function(e,s,r,gg){
    var z=gz$gma_91()
    var onDB=_cvn();if(_o(z,0,e,s,gg)){onDB.maVkey=1;var ooDB=_ctn("set-tab-bar");_setAttr(z,ooDB,'bindunmount',1,e,s,gg);_ac(onDB,ooDB);}else{onDB.maVkey=2;var oqDB=_ctn("view");_setAttr(z,oqDB,'class',2,e,s,gg);var osDB=_ctn("view");_setAttr(z,osDB,'class',3,e,s,gg);var otDB=_ctn("view");_setAttr(z,otDB,'class',4,e,s,gg);var ouDB=_o(z,5,e,s,gg);_ac(otDB,ouDB);_ac(osDB,otDB);_ac(oqDB,osDB);var ovDB=_ctn("view");_setAttr(z,ovDB,'class',6,e,s,gg);var owDB=_ctn("view");_setAttr(z,owDB,'class',7,e,s,gg);var oxDB=_cvn();var oyDB=function(oBEB,oAEB,o_DB,gg){var oDEB=_ctn("view");_setAttr(z,oDEB,'class',10,oBEB,oAEB,gg);var oEEB=_setAttrs(z,"view",["id",9,"bindtap",2,"class",3],oBEB,oAEB,gg);var oFEB=_ctn("view");_setAttr(z,oFEB,'class',13,oBEB,oAEB,gg);var oGEB=_o(z,14,oBEB,oAEB,gg);_ac(oFEB,oGEB);_ac(oEEB,oFEB);var oHEB=_setAttrs(z,"image",["class",15,"src",1],oBEB,oAEB,gg);_ac(oEEB,oHEB);_ac(oDEB,oEEB);var oIEB=_ctn("view");_setAttr(z,oIEB,'class',17,oBEB,oAEB,gg);var oJEB=_ctn("view");_setAttr(z,oJEB,'class',18,oBEB,oAEB,gg);var oKEB=_cvn();var oLEB=function(oPEB,oOEB,oNEB,gg){var oREB=_cvn();if(_o(z,22,oPEB,oOEB,gg)){oREB.maVkey=1;var oSEB=_setAttrs(z,"navigator",["class",23,"url",1],oPEB,oOEB,gg);var oUEB=_setAttrs(z,"view",["class",25,"id",1],oPEB,oOEB,gg);var oVEB=_o(z,27,oPEB,oOEB,gg);_ac(oUEB,oVEB);_ac(oSEB,oUEB);var oWEB=_ctn("view");_setAttr(z,oWEB,'class',28,oPEB,oOEB,gg);_ac(oSEB,oWEB);_ac(oREB,oSEB);}else{oREB.maVkey=2;var oXEB=_setAttrs(z,"view",["class",23,"bindtap",6],e,s,gg);var oZEB=_setAttrs(z,"view",["class",25,"id",1],e,s,gg);var oaEB=_o(z,27,e,s,gg);_ac(oZEB,oaEB);_ac(oXEB,oZEB);var obEB=_ctn("view");_setAttr(z,obEB,'class',28,e,s,gg);_ac(oXEB,obEB);_ac(oREB,oXEB);}_ac(oNEB,oREB);return oNEB;};_2(z,19,oLEB,oBEB,oAEB,gg,oKEB,"page","index",'*item');_ac(oJEB,oKEB);_ac(oIEB,oJEB);_ac(oDEB,oIEB);_ac(o_DB,oDEB);return o_DB;};_2(z,8,oyDB,e,s,gg,oxDB,"item","index",'{{item.id}}');_ac(owDB,oxDB);_ac(ovDB,owDB);_ac(oqDB,ovDB);_ac(onDB,oqDB);}_ac(r,onDB);
    return r;
  };
  e_["./page/tabbar/api/index.maml"]={f:m90,j:[],i:[],ti:[],ic:[]};

  d_["./page/tabbar/component/index.maml"]={};
  var m91=function(e,s,r,gg){
    var z=gz$gma_92()
    var odEB=_ctn("view");_setAttr(z,odEB,'class',0,e,s,gg);var oeEB=_ctn("view");_setAttr(z,oeEB,'class',1,e,s,gg);var ofEB=_ctn("view");_setAttr(z,ofEB,'class',2,e,s,gg);var ogEB=_o(z,3,e,s,gg);_ac(ofEB,ogEB);_ac(oeEB,ofEB);_ac(odEB,oeEB);var ohEB=_ctn("view");_setAttr(z,ohEB,'class',4,e,s,gg);var oiEB=_ctn("view");_setAttr(z,oiEB,'class',5,e,s,gg);var ojEB=_cvn();var okEB=function(ooEB,onEB,omEB,gg){var oqEB=_ctn("view");_setAttr(z,oqEB,'class',9,ooEB,onEB,gg);var orEB=_setAttrs(z,"view",["id",8,"bindtap",2,"class",3],ooEB,onEB,gg);var osEB=_ctn("view");_setAttr(z,osEB,'class',12,ooEB,onEB,gg);var otEB=_o(z,13,ooEB,onEB,gg);_ac(osEB,otEB);_ac(orEB,osEB);var ouEB=_cvn();if(_o(z,14,ooEB,onEB,gg)){ouEB.maVkey=1;var ovEB=_setAttrs(z,"image",["class",15,"src",1],ooEB,onEB,gg);_ac(ouEB,ovEB);} _ac(orEB,ouEB);_ac(oqEB,orEB);var oxEB=_ctn("view");_setAttr(z,oxEB,'class',17,ooEB,onEB,gg);var oyEB=_ctn("view");_setAttr(z,oyEB,'class',18,ooEB,onEB,gg);var ozEB=_cvn();var o_EB=function(oDFB,oCFB,oBFB,gg){var oFFB=_setAttrs(z,"navigator",["class",22,"id",1,"url",2],oDFB,oCFB,gg);var oGFB=_setAttrs(z,"view",["class",25,"id",1],oDFB,oCFB,gg);var oHFB=_o(z,27,oDFB,oCFB,gg);_ac(oGFB,oHFB);_ac(oFFB,oGFB);var oIFB=_ctn("view");_setAttr(z,oIFB,'class',28,oDFB,oCFB,gg);_ac(oFFB,oIFB);_ac(oBFB,oFFB);return oBFB;};_2(z,19,o_EB,ooEB,onEB,gg,ozEB,"page","index",'*item');_ac(oyEB,ozEB);_ac(oxEB,oyEB);_ac(oqEB,oxEB);_ac(omEB,oqEB);return omEB;};_2(z,6,okEB,e,s,gg,ojEB,"item","index",'{{item.id}}');_ac(oiEB,ojEB);_ac(ohEB,oiEB);_ac(odEB,ohEB);_ac(r,odEB);
    return r;
  };
  e_["./page/tabbar/component/index.maml"]={f:m91,j:[],i:[],ti:[],ic:[]};

  d_["./page/tabbar/framework/index.maml"]={};
  var m92=function(e,s,r,gg){
    var z=gz$gma_93()
    var oKFB=_ctn("view");_setAttr(z,oKFB,'class',0,e,s,gg);var oLFB=_ctn("view");_setAttr(z,oLFB,'class',1,e,s,gg);var oMFB=_ctn("view");_setAttr(z,oMFB,'class',2,e,s,gg);var oNFB=_o(z,3,e,s,gg);_ac(oMFB,oNFB);_ac(oLFB,oMFB);_ac(oKFB,oLFB);var oOFB=_ctn("view");_setAttr(z,oOFB,'class',4,e,s,gg);var oPFB=_ctn("view");_setAttr(z,oPFB,'class',5,e,s,gg);var oQFB=_cvn();var oRFB=function(oVFB,oUFB,oTFB,gg){var oXFB=_ctn("view");_setAttr(z,oXFB,'class',9,oVFB,oUFB,gg);var oYFB=_setAttrs(z,"view",["id",8,"bindtap",2,"class",3],oVFB,oUFB,gg);var oZFB=_ctn("view");_setAttr(z,oZFB,'class',12,oVFB,oUFB,gg);var oaFB=_o(z,13,oVFB,oUFB,gg);_ac(oZFB,oaFB);_ac(oYFB,oZFB);_ac(oXFB,oYFB);var obFB=_ctn("view");_setAttr(z,obFB,'class',14,oVFB,oUFB,gg);var ocFB=_ctn("view");_setAttr(z,ocFB,'class',15,oVFB,oUFB,gg);var odFB=_cvn();var oeFB=function(oiFB,ohFB,ogFB,gg){var okFB=_setAttrs(z,"navigator",["class",19,"url",1],oiFB,ohFB,gg);var olFB=_ctn("view");_setAttr(z,olFB,'class',21,oiFB,ohFB,gg);var omFB=_o(z,22,oiFB,ohFB,gg);_ac(olFB,omFB);_ac(okFB,olFB);var onFB=_ctn("view");_setAttr(z,onFB,'class',23,oiFB,ohFB,gg);_ac(okFB,onFB);_ac(ogFB,okFB);return ogFB;};_2(z,16,oeFB,oVFB,oUFB,gg,odFB,"page","index",'*item');_ac(ocFB,odFB);_ac(obFB,ocFB);_ac(oXFB,obFB);_ac(oTFB,oXFB);return oTFB;};_2(z,6,oRFB,e,s,gg,oQFB,"item","index",'{{item.id}}');_ac(oPFB,oQFB);_ac(oOFB,oPFB);_ac(oKFB,oOFB);_ac(r,oKFB);
    return r;
  };
  e_["./page/tabbar/framework/index.maml"]={f:m92,j:[],i:[],ti:[],ic:[]};

  d_["./page/tabbar/react/index.maml"]={};
  var m93=function(e,s,r,gg){
    var z=gz$gma_94()
    var opFB=_ctn("view");_setAttr(z,opFB,'class',0,e,s,gg);var oqFB=_setAttrs(z,"script",["async",1,"src",1],e,s,gg);_ac(opFB,oqFB);var orFB=_ctn("script");_setAttr(z,orFB,'src',3,e,s,gg);_ac(opFB,orFB);var osFB=_ctn("div");_setAttr(z,osFB,'id',4,e,s,gg);var otFB=_o(z,5,e,s,gg);_ac(osFB,otFB);_ac(opFB,osFB);var ouFB=_ctn("web-view");_setAttr(z,ouFB,'src',6,e,s,gg);_ac(opFB,ouFB);var ovFB=_ctn("view");_setAttr(z,ovFB,'class',7,e,s,gg);var owFB=_ctn("view");_setAttr(z,owFB,'class',8,e,s,gg);var oxFB=_cvn();var oyFB=function(oBGB,oAGB,o_FB,gg){var oDGB=_ctn("view");_setAttr(z,oDGB,'class',12,oBGB,oAGB,gg);var oEGB=_setAttrs(z,"view",["id",11,"bindtap",2,"class",3],oBGB,oAGB,gg);var oFGB=_ctn("view");_setAttr(z,oFGB,'class',15,oBGB,oAGB,gg);var oGGB=_o(z,16,oBGB,oAGB,gg);_ac(oFGB,oGGB);_ac(oEGB,oFGB);var oHGB=_cvn();if(_o(z,17,oBGB,oAGB,gg)){oHGB.maVkey=1;var oIGB=_setAttrs(z,"image",["class",18,"src",1],oBGB,oAGB,gg);_ac(oHGB,oIGB);} _ac(oEGB,oHGB);_ac(oDGB,oEGB);var oKGB=_ctn("view");_setAttr(z,oKGB,'class',20,oBGB,oAGB,gg);var oLGB=_ctn("view");_setAttr(z,oLGB,'class',21,oBGB,oAGB,gg);var oMGB=_cvn();var oNGB=function(oRGB,oQGB,oPGB,gg){var oTGB=_setAttrs(z,"navigator",["class",25,"id",1,"url",2],oRGB,oQGB,gg);var oUGB=_setAttrs(z,"view",["class",28,"id",1],oRGB,oQGB,gg);var oVGB=_o(z,30,oRGB,oQGB,gg);_ac(oUGB,oVGB);_ac(oTGB,oUGB);var oWGB=_ctn("view");_setAttr(z,oWGB,'class',31,oRGB,oQGB,gg);_ac(oTGB,oWGB);_ac(oPGB,oTGB);return oPGB;};_2(z,22,oNGB,oBGB,oAGB,gg,oMGB,"page","index",'*item');_ac(oLGB,oMGB);_ac(oKGB,oLGB);_ac(oDGB,oKGB);_ac(o_FB,oDGB);return o_FB;};_2(z,9,oyFB,e,s,gg,oxFB,"item","index",'{{item.id}}');_ac(owFB,oxFB);_ac(ovFB,owFB);_ac(opFB,ovFB);_ac(r,opFB);
    return r;
  };
  e_["./page/tabbar/react/index.maml"]={f:m93,j:[],i:[],ti:[],ic:[]};

  if(path&&e_[path]){
    return function(env,dd,global){
      $gmac=0;
      var root={"tag":"ma-page","children":[]};
      var main=e_[path].f;
      if(typeof global==="undefined")global={};
      global.f=$gdc(f_[path],"",1)||{};
      global.f.i18n=f_['i18n']
      if(window.__mergeData__)env=window.__mergeData__(env,dd);
      try{
        main(env,{},root,global);
      }catch(e){
        console.log(e)
      }
      return root;
    }
  }
}

__maAppCode__['app.json']={"pages":["page/tabbar/component/index","page/tabbar/api/index","page/tabbar/framework/index"],"subPackages":[{"root":"page/component/","pages":["page/component/pages/icon/icon","page/component/pages/image/image","page/component/pages/view/view","page/component/pages/cover-view/cover-view","page/component/pages/cover-image/cover-image","page/component/pages/text/text","page/component/pages/button/button","page/component/pages/swiper/swiper","page/component/pages/scroll-view/scroll-view","page/component/pages/input/input","page/component/pages/picker-view/picker-view","page/component/pages/radio/radio","page/component/pages/checkbox/checkbox","page/component/pages/label/label","page/component/pages/switch/switch","page/component/pages/slider/slider","page/component/pages/form/form","page/component/pages/picker/picker","page/component/pages/progress/progress","page/component/pages/navigator/navigator","page/component/pages/navigator/navigate","page/component/pages/navigator/reLaunch","page/component/pages/navigator/redirect","page/component/pages/web-view/web-view","page/component/pages/video/video","page/component/pages/camera/camera","page/component/pages/audio/audio","page/component/pages/rich-text/rich-text","page/component/pages/textarea/textarea"]},{"root":"page/API/","pages":["page/API/pages/application-event/application-event","page/API/pages/navigator/navigator","page/API/pages/get-system-info/get-system-info","page/API/pages/get-system-info-sync/get-system-info-sync","page/API/pages/get-location/get-location","page/API/pages/navigator/navigate","page/API/pages/navigator/redirect","page/API/pages/toast/toast","page/API/pages/modal/modal","page/API/pages/loading/loading","page/API/pages/request/request","page/API/pages/websocket/websocket","page/API/pages/network/network","page/API/pages/gyroscope/gyroscope","page/API/pages/memory-warning/memory-warning","page/API/pages/make-phone-call/make-phone-call","page/API/pages/get-battery-info/get-battery-info","page/API/pages/screen-brightness/screen-brightness","page/API/pages/hideKeyboard/hideKeyboard","page/API/pages/pull-down-refresh/pull-down-refresh","page/API/pages/canIUse/canIUse","page/API/pages/set-navigation-bar-title/set-navigation-bar-title","page/API/pages/set-navigation-bar-color/set-navigation-bar-color","page/API/pages/storage/storage","page/API/pages/storage-sync/storage-sync","page/API/pages/set-background/set-background","page/API/pages/downloadFile/downloadFile","page/API/pages/uploadFile/uploadFile","page/API/pages/mediaImage/mediaImage","page/API/pages/show-action-sheet/show-action-sheet","page/API/pages/file/file","page/API/pages/open-document/open-document","page/API/pages/scanCode/scanCode","page/API/pages/vibrate/vibrate","page/API/pages/chooseContact/chooseContact","page/API/pages/get-network-type/get-network-type","page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect","page/API/pages/get-image-info/get-image-info","page/API/pages/compressImage/compressImage"]},{"root":"page/framework/","pages":["page/framework/pages/communication/communication","page/framework/pages/sjs-filter/sjs-filter","page/framework/pages/sjs-drag/sjs-drag","page/framework/pages/macle-i18n/macle-i18n","page/framework/pages/macle-sub-i18n/macle-sub-i18n"]}],"window":{"navigationBarTextStyle":"black","navigationBarTitleText":"Example display","navigationBarBackgroundColor":"#F8F8F8","backgroundColor":"#F8F8F8"},"sitemapLocation":"sitemap.json","tabBar":{"color":"#7A7E45","selectedColor":"#3cc51f","borderStyle":"black","backgroundColor":"#ffffff","list":[{"pagePath":"page/tabbar/component/index","iconPath":"image/icon_component.png","selectedIconPath":"image/icon_component_HL.png","text":"components"},{"pagePath":"page/tabbar/api/index","iconPath":"image/icon_API.png","selectedIconPath":"image/icon_API_HL.png","text":"interfacess"},{"pagePath":"page/tabbar/framework/index","iconPath":"image/icon_framework.png","selectedIconPath":"image/icon_framework_HL.png","text":"frameworks__"}]},"entryPagePath":"page/tabbar/component/index"};
__maAppCode__['component/communication-detail/index.maml']=$gma('./component/communication-detail/index.maml');
__maAppCode__['component/communication-detail/index.json']={"component":true,"usingComponents":{"detailItem":"component/communication-detailItem/index"}};
__maAppCode__['component/communication-detailItem/index.maml']=$gma('./component/communication-detailItem/index.maml');
__maAppCode__['component/communication-detailItem/index.json']={"component":true};
__maAppCode__['component/detail/index.maml']=$gma('./component/detail/index.maml');
__maAppCode__['component/detail/index.json']={"component":true,"usingComponents":{"detailItem":"component/detailItem/index"}};
__maAppCode__['component/detailItem/index.maml']=$gma('./component/detailItem/index.maml');
__maAppCode__['component/detailItem/index.json']={"component":true};
__maAppCode__['macle_demo_EN/component/communication-detail/index.maml']=$gma('./macle_demo_EN/component/communication-detail/index.maml');
__maAppCode__['macle_demo_EN/component/communication-detail/index.json']={"component":true,"usingComponents":{"detailItem":"component/communication-detailItem/index"}};
__maAppCode__['macle_demo_EN/component/communication-detailItem/index.maml']=$gma('./macle_demo_EN/component/communication-detailItem/index.maml');
__maAppCode__['macle_demo_EN/component/communication-detailItem/index.json']={"component":true};
__maAppCode__['macle_demo_EN/component/detail/index.maml']=$gma('./macle_demo_EN/component/detail/index.maml');
__maAppCode__['macle_demo_EN/component/detail/index.json']={"component":true,"usingComponents":{"detailItem":"component/detailItem/index"}};
__maAppCode__['macle_demo_EN/component/detailItem/index.maml']=$gma('./macle_demo_EN/component/detailItem/index.maml');
__maAppCode__['macle_demo_EN/component/detailItem/index.json']={"component":true};
__maAppCode__['macle_demo_EN/page/API/pages/application-event/application-event.maml']=$gma('./macle_demo_EN/page/API/pages/application-event/application-event.maml');
__maAppCode__['macle_demo_EN/page/API/pages/application-event/application-event.json']={"navigationBarTitleText":"Application-level events"};
__maAppCode__['macle_demo_EN/page/API/pages/canIUse/canIUse.maml']=$gma('./macle_demo_EN/page/API/pages/canIUse/canIUse.maml');
__maAppCode__['macle_demo_EN/page/API/pages/canIUse/canIUse.json']={"navigationBarTitleText":"canIUse"};
__maAppCode__['macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml']=$gma('./macle_demo_EN/page/API/pages/chooseContact/chooseContact.maml');
__maAppCode__['macle_demo_EN/page/API/pages/chooseContact/chooseContact.json']={"navigationBarTitleText":"Select Contact"};
__maAppCode__['macle_demo_EN/page/API/pages/compressImage/compressImage.maml']=$gma('./macle_demo_EN/page/API/pages/compressImage/compressImage.maml');
__maAppCode__['macle_demo_EN/page/API/pages/compressImage/compressImage.json']={"navigationBarTitleText":"Compressed Picture"};
__maAppCode__['macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml']=$gma('./macle_demo_EN/page/API/pages/downloadFile/downloadFile.maml');
__maAppCode__['macle_demo_EN/page/API/pages/downloadFile/downloadFile.json']={"navigationBarTitleText":"Downloading files"};
__maAppCode__['macle_demo_EN/page/API/pages/file/file.maml']=$gma('./macle_demo_EN/page/API/pages/file/file.maml');
__maAppCode__['macle_demo_EN/page/API/pages/file/file.json']={"navigationBarTitleText":"document"};
__maAppCode__['macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml']=$gma('./macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.maml');
__maAppCode__['macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.json']={"navigationBarTitleText":"Obtaining the Battery Level of a Mobile Phone"};
__maAppCode__['macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml']=$gma('./macle_demo_EN/page/API/pages/get-image-info/get-image-info.maml');
__maAppCode__['macle_demo_EN/page/API/pages/get-image-info/get-image-info.json']={"navigationBarTitleText":"Obtaining Image Information"};
__maAppCode__['macle_demo_EN/page/API/pages/get-location/get-location.maml']=$gma('./macle_demo_EN/page/API/pages/get-location/get-location.maml');
__maAppCode__['macle_demo_EN/page/API/pages/get-location/get-location.json']={"navigationBarTitleText":"Get Geographic Location"};
__maAppCode__['macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml']=$gma('./macle_demo_EN/page/API/pages/get-network-type/get-network-type.maml');
__maAppCode__['macle_demo_EN/page/API/pages/get-network-type/get-network-type.json']={"navigationBarTitleText":"Obtain the network type"};
__maAppCode__['macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml']=$gma('./macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.maml');
__maAppCode__['macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.json']={"navigationBarTitleText":"Synchronously obtaining mobile phone system information"};
__maAppCode__['macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml']=$gma('./macle_demo_EN/page/API/pages/get-system-info/get-system-info.maml');
__maAppCode__['macle_demo_EN/page/API/pages/get-system-info/get-system-info.json']={"navigationBarTitleText":"Obtaining Mobile Phone System Information"};
__maAppCode__['macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml']=$gma('./macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.maml');
__maAppCode__['macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.json']={"navigationBarTitleText":"Obtains the layout position information of a menu button"};
__maAppCode__['macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml']=$gma('./macle_demo_EN/page/API/pages/gyroscope/gyroscope.maml');
__maAppCode__['macle_demo_EN/page/API/pages/gyroscope/gyroscope.json']={"navigationBarTitleText":"gyroscope"};
__maAppCode__['macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml']=$gma('./macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.maml');
__maAppCode__['macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.json']={"navigationBarTitleText":"Hide Keyboard"};
__maAppCode__['macle_demo_EN/page/API/pages/loading/loading.maml']=$gma('./macle_demo_EN/page/API/pages/loading/loading.maml');
__maAppCode__['macle_demo_EN/page/API/pages/loading/loading.json']={"navigationBarTitleText":"The Loading dialog box is displayed"};
__maAppCode__['macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml']=$gma('./macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.maml');
__maAppCode__['macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.json']={"navigationBarTitleText":"Calling"};
__maAppCode__['macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml']=$gma('./macle_demo_EN/page/API/pages/mediaImage/mediaImage.maml');
__maAppCode__['macle_demo_EN/page/API/pages/mediaImage/mediaImage.json']={"navigationBarTitleText":"mediaImage"};
__maAppCode__['macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml']=$gma('./macle_demo_EN/page/API/pages/memory-warning/memory-warning.maml');
__maAppCode__['macle_demo_EN/page/API/pages/memory-warning/memory-warning.json']={"navigationBarTitleText":"performance"};
__maAppCode__['macle_demo_EN/page/API/pages/modal/modal.maml']=$gma('./macle_demo_EN/page/API/pages/modal/modal.maml');
__maAppCode__['macle_demo_EN/page/API/pages/modal/modal.json']={"navigationBarTitleText":"Display modal pop-up window"};
__maAppCode__['macle_demo_EN/page/API/pages/navigator/navigate.maml']=$gma('./macle_demo_EN/page/API/pages/navigator/navigate.maml');
__maAppCode__['macle_demo_EN/page/API/pages/navigator/navigate.json']={"navigationBarTitleText":"navigatePage"};
__maAppCode__['macle_demo_EN/page/API/pages/navigator/navigator.maml']=$gma('./macle_demo_EN/page/API/pages/navigator/navigator.maml');
__maAppCode__['macle_demo_EN/page/API/pages/navigator/navigator.json']={"navigationBarTitleText":"interface switch"};
__maAppCode__['macle_demo_EN/page/API/pages/navigator/redirect.maml']=$gma('./macle_demo_EN/page/API/pages/navigator/redirect.maml');
__maAppCode__['macle_demo_EN/page/API/pages/navigator/redirect.json']={"navigationBarTitleText":"redirectPage"};
__maAppCode__['macle_demo_EN/page/API/pages/network/network.maml']=$gma('./macle_demo_EN/page/API/pages/network/network.maml');
__maAppCode__['macle_demo_EN/page/API/pages/network/network.json']={"navigationBarTitleText":"Network change monitor"};
__maAppCode__['macle_demo_EN/page/API/pages/open-document/open-document.maml']=$gma('./macle_demo_EN/page/API/pages/open-document/open-document.maml');
__maAppCode__['macle_demo_EN/page/API/pages/open-document/open-document.json']={"navigationBarTitleText":"Document Open"};
__maAppCode__['macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml']=$gma('./macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.maml');
__maAppCode__['macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.json']={"enablePullDownRefresh":true,"navigationBarTitleText":"pull to refres"};
__maAppCode__['macle_demo_EN/page/API/pages/request/request.maml']=$gma('./macle_demo_EN/page/API/pages/request/request.maml');
__maAppCode__['macle_demo_EN/page/API/pages/request/request.json']={"navigationBarTitleText":"network request"};
__maAppCode__['macle_demo_EN/page/API/pages/scanCode/scanCode.maml']=$gma('./macle_demo_EN/page/API/pages/scanCode/scanCode.maml');
__maAppCode__['macle_demo_EN/page/API/pages/scanCode/scanCode.json']={"navigationBarTitleText":"Scan the QR code"};
__maAppCode__['macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml']=$gma('./macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.maml');
__maAppCode__['macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.json']={"navigationBarTitleText":"screen brightness"};
__maAppCode__['macle_demo_EN/page/API/pages/set-background/set-background.maml']=$gma('./macle_demo_EN/page/API/pages/set-background/set-background.maml');
__maAppCode__['macle_demo_EN/page/API/pages/set-background/set-background.json']={"enablePullDownRefresh":true,"navigationBarTitleText":"Background settings"};
__maAppCode__['macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml']=$gma('./macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.maml');
__maAppCode__['macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.json']={"navigationBarTitleText":"Set the color of the navigation bar."};
__maAppCode__['macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml']=$gma('./macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.maml');
__maAppCode__['macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.json']={"navigationBarTitleText":"Setting the interface title"};
__maAppCode__['macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml']=$gma('./macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.maml');
__maAppCode__['macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.json']={"navigationBarTitleText":"Show Action Menu"};
__maAppCode__['macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml']=$gma('./macle_demo_EN/page/API/pages/storage-sync/storage-sync.maml');
__maAppCode__['macle_demo_EN/page/API/pages/storage-sync/storage-sync.json']={"navigationBarTitleText":"data storage"};
__maAppCode__['macle_demo_EN/page/API/pages/storage/storage.maml']=$gma('./macle_demo_EN/page/API/pages/storage/storage.maml');
__maAppCode__['macle_demo_EN/page/API/pages/storage/storage.json']={"navigationBarTitleText":"data storage"};
__maAppCode__['macle_demo_EN/page/API/pages/toast/toast.maml']=$gma('./macle_demo_EN/page/API/pages/toast/toast.maml');
__maAppCode__['macle_demo_EN/page/API/pages/toast/toast.json']={"navigationBarTitleText":"Display message prompt box"};
__maAppCode__['macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml']=$gma('./macle_demo_EN/page/API/pages/uploadFile/uploadFile.maml');
__maAppCode__['macle_demo_EN/page/API/pages/uploadFile/uploadFile.json']={"navigationBarTitleText":"Upload a file"};
__maAppCode__['macle_demo_EN/page/API/pages/vibrate/vibrate.maml']=$gma('./macle_demo_EN/page/API/pages/vibrate/vibrate.maml');
__maAppCode__['macle_demo_EN/page/API/pages/vibrate/vibrate.json']={"navigationBarTitleText":"vibrate"};
__maAppCode__['macle_demo_EN/page/API/pages/websocket/websocket.maml']=$gma('./macle_demo_EN/page/API/pages/websocket/websocket.maml');
__maAppCode__['macle_demo_EN/page/API/pages/websocket/websocket.json']={"navigationBarTitleText":"network request"};
__maAppCode__['macle_demo_EN/page/component/pages/audio/audio.maml']=$gma('./macle_demo_EN/page/component/pages/audio/audio.maml');
__maAppCode__['macle_demo_EN/page/component/pages/audio/audio.json']={"navigationBarTitleText":"audio"};
__maAppCode__['macle_demo_EN/page/component/pages/button/button.maml']=$gma('./macle_demo_EN/page/component/pages/button/button.maml');
__maAppCode__['macle_demo_EN/page/component/pages/button/button.json']={"navigationBarTitleText":"button"};
__maAppCode__['macle_demo_EN/page/component/pages/camera/camera.maml']=$gma('./macle_demo_EN/page/component/pages/camera/camera.maml');
__maAppCode__['macle_demo_EN/page/component/pages/camera/camera.json']={"navigationBarTitleText":"Camera"};
__maAppCode__['macle_demo_EN/page/component/pages/checkbox/checkbox.maml']=$gma('./macle_demo_EN/page/component/pages/checkbox/checkbox.maml');
__maAppCode__['macle_demo_EN/page/component/pages/checkbox/checkbox.json']={"navigationBarTitleText":"checkbox"};
__maAppCode__['macle_demo_EN/page/component/pages/cover-image/cover-image.maml']=$gma('./macle_demo_EN/page/component/pages/cover-image/cover-image.maml');
__maAppCode__['macle_demo_EN/page/component/pages/cover-image/cover-image.json']={"navigationBarTitleText":"Cover-Image"};
__maAppCode__['macle_demo_EN/page/component/pages/cover-view/cover-view.maml']=$gma('./macle_demo_EN/page/component/pages/cover-view/cover-view.maml');
__maAppCode__['macle_demo_EN/page/component/pages/cover-view/cover-view.json']={"navigationBarTitleText":"Cover-View"};
__maAppCode__['macle_demo_EN/page/component/pages/form/form.maml']=$gma('./macle_demo_EN/page/component/pages/form/form.maml');
__maAppCode__['macle_demo_EN/page/component/pages/form/form.json']={"navigationBarTitleText":"form"};
__maAppCode__['macle_demo_EN/page/component/pages/icon/icon.maml']=$gma('./macle_demo_EN/page/component/pages/icon/icon.maml');
__maAppCode__['macle_demo_EN/page/component/pages/icon/icon.json']={"navigationBarTitleText":"icon"};
__maAppCode__['macle_demo_EN/page/component/pages/image/image.maml']=$gma('./macle_demo_EN/page/component/pages/image/image.maml');
__maAppCode__['macle_demo_EN/page/component/pages/image/image.json']={"navigationBarTitleText":"image"};
__maAppCode__['macle_demo_EN/page/component/pages/input/input.maml']=$gma('./macle_demo_EN/page/component/pages/input/input.maml');
__maAppCode__['macle_demo_EN/page/component/pages/input/input.json']={"navigationBarTitleText":"input"};
__maAppCode__['macle_demo_EN/page/component/pages/label/label.maml']=$gma('./macle_demo_EN/page/component/pages/label/label.maml');
__maAppCode__['macle_demo_EN/page/component/pages/label/label.json']={"navigationBarTitleText":"label"};
__maAppCode__['macle_demo_EN/page/component/pages/navigator/navigate.maml']=$gma('./macle_demo_EN/page/component/pages/navigator/navigate.maml');
__maAppCode__['macle_demo_EN/page/component/pages/navigator/navigate.json']={"navigationBarTitleText":"navigatePage"};
__maAppCode__['macle_demo_EN/page/component/pages/navigator/navigator.maml']=$gma('./macle_demo_EN/page/component/pages/navigator/navigator.maml');
__maAppCode__['macle_demo_EN/page/component/pages/navigator/navigator.json']={"navigationBarTitleText":"navigator"};
__maAppCode__['macle_demo_EN/page/component/pages/navigator/redirect.maml']=$gma('./macle_demo_EN/page/component/pages/navigator/redirect.maml');
__maAppCode__['macle_demo_EN/page/component/pages/navigator/redirect.json']={"navigationBarTitleText":"redirectPage"};
__maAppCode__['macle_demo_EN/page/component/pages/navigator/reLaunch.maml']=$gma('./macle_demo_EN/page/component/pages/navigator/reLaunch.maml');
__maAppCode__['macle_demo_EN/page/component/pages/navigator/reLaunch.json']={"navigationBarTitleText":"relaunchPage"};
__maAppCode__['macle_demo_EN/page/component/pages/picker-view/picker-view.maml']=$gma('./macle_demo_EN/page/component/pages/picker-view/picker-view.maml');
__maAppCode__['macle_demo_EN/page/component/pages/picker-view/picker-view.json']={"navigationBarTitleText":"picker-view"};
__maAppCode__['macle_demo_EN/page/component/pages/picker/picker.maml']=$gma('./macle_demo_EN/page/component/pages/picker/picker.maml');
__maAppCode__['macle_demo_EN/page/component/pages/picker/picker.json']={"navigationBarTitleText":"picker"};
__maAppCode__['macle_demo_EN/page/component/pages/progress/progress.maml']=$gma('./macle_demo_EN/page/component/pages/progress/progress.maml');
__maAppCode__['macle_demo_EN/page/component/pages/progress/progress.json']={"navigationBarTitleText":"progress"};
__maAppCode__['macle_demo_EN/page/component/pages/radio/radio.maml']=$gma('./macle_demo_EN/page/component/pages/radio/radio.maml');
__maAppCode__['macle_demo_EN/page/component/pages/radio/radio.json']={"navigationBarTitleText":"radio"};
__maAppCode__['macle_demo_EN/page/component/pages/rich-text/rich-text.maml']=$gma('./macle_demo_EN/page/component/pages/rich-text/rich-text.maml');
__maAppCode__['macle_demo_EN/page/component/pages/rich-text/rich-text.json']={"navigationBarTitleText":"rich-text"};
__maAppCode__['macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml']=$gma('./macle_demo_EN/page/component/pages/scroll-view/scroll-view.maml');
__maAppCode__['macle_demo_EN/page/component/pages/scroll-view/scroll-view.json']={"navigationBarTitleText":"scroll-view"};
__maAppCode__['macle_demo_EN/page/component/pages/slider/slider.maml']=$gma('./macle_demo_EN/page/component/pages/slider/slider.maml');
__maAppCode__['macle_demo_EN/page/component/pages/slider/slider.json']={"navigationBarTitleText":"slider"};
__maAppCode__['macle_demo_EN/page/component/pages/swiper/swiper.maml']=$gma('./macle_demo_EN/page/component/pages/swiper/swiper.maml');
__maAppCode__['macle_demo_EN/page/component/pages/swiper/swiper.json']={"navigationBarTitleText":"swiper"};
__maAppCode__['macle_demo_EN/page/component/pages/switch/switch.maml']=$gma('./macle_demo_EN/page/component/pages/switch/switch.maml');
__maAppCode__['macle_demo_EN/page/component/pages/switch/switch.json']={"navigationBarTitleText":"switch"};
__maAppCode__['macle_demo_EN/page/component/pages/text/text.maml']=$gma('./macle_demo_EN/page/component/pages/text/text.maml');
__maAppCode__['macle_demo_EN/page/component/pages/text/text.json']={"navigationBarTitleText":"text"};
__maAppCode__['macle_demo_EN/page/component/pages/video/video.maml']=$gma('./macle_demo_EN/page/component/pages/video/video.maml');
__maAppCode__['macle_demo_EN/page/component/pages/video/video.json']={"navigationBarTitleText":"video"};
__maAppCode__['macle_demo_EN/page/component/pages/view/view.maml']=$gma('./macle_demo_EN/page/component/pages/view/view.maml');
__maAppCode__['macle_demo_EN/page/component/pages/view/view.json']={"navigationBarTitleText":"view","enablePullDownRefresh":true};
__maAppCode__['macle_demo_EN/page/component/pages/web-view/web-view.maml']=$gma('./macle_demo_EN/page/component/pages/web-view/web-view.maml');
__maAppCode__['macle_demo_EN/page/component/pages/web-view/web-view.json']={"navigationBarTitleText":"web-view","enablePullDownRefresh":true};
__maAppCode__['macle_demo_EN/page/framework/pages/communication/communication.maml']=$gma('./macle_demo_EN/page/framework/pages/communication/communication.maml');
__maAppCode__['macle_demo_EN/page/framework/pages/communication/communication.json']={"navigationBarTitleText":"组件间通信","usingComponents":{"detail":"component/communication-detail/index"}};
__maAppCode__['macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml']=$gma('./macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.maml');
__maAppCode__['macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.json']={"navigationBarTitleText":"macle-i18n"};
__maAppCode__['macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml']=$gma('./macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.maml');
__maAppCode__['macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.json']={"navigationBarTitleText":"View Startup Logs"};
__maAppCode__['macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml']=$gma('./macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.maml');
__maAppCode__['macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.json']={"navigationBarTitleText":"sjs-drag"};
__maAppCode__['macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml']=$gma('./macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.maml');
__maAppCode__['macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.json']={"navigationBarTitleText":"sjs-filter"};
__maAppCode__['macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml']=$gma('./macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.maml');
__maAppCode__['macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.json']={"component":true,"usingComponents":{}};
__maAppCode__['macle_demo_EN/page/tabbar/api/index.maml']=$gma('./macle_demo_EN/page/tabbar/api/index.maml');
__maAppCode__['macle_demo_EN/page/tabbar/api/index.json']={"navigationBarTitleText":"Applet interface capability display","usingComponents":{"set-tab-bar":"macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar"}};
__maAppCode__['macle_demo_EN/page/tabbar/component/index.maml']=$gma('./macle_demo_EN/page/tabbar/component/index.maml');
__maAppCode__['macle_demo_EN/page/tabbar/component/index.json']={"navigationBarTitleText":"Applet official component display"};
__maAppCode__['macle_demo_EN/page/tabbar/framework/index.maml']=$gma('./macle_demo_EN/page/tabbar/framework/index.maml');
__maAppCode__['macle_demo_EN/page/tabbar/framework/index.json']={"navigationBarTitleText":"Applet framework capability display"};
__maAppCode__['page/tabbar/api/components/set-tab-bar/set-tab-bar.maml']=$gma('./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml');
__maAppCode__['page/tabbar/api/components/set-tab-bar/set-tab-bar.json']={"component":true,"usingComponents":{}};
__maAppCode__['page/tabbar/api/index.maml']=$gma('./page/tabbar/api/index.maml');
__maAppCode__['page/tabbar/api/index.json']={"navigationBarTitleText":"Applet interface capability display","usingComponents":{"set-tab-bar":"page/tabbar/api/components/set-tab-bar/set-tab-bar"}};
__maAppCode__['page/tabbar/component/index.maml']=$gma('./page/tabbar/component/index.maml');
__maAppCode__['page/tabbar/component/index.json']={"navigationBarTitleText":"Applet official component display"};
__maAppCode__['page/tabbar/framework/index.maml']=$gma('./page/tabbar/framework/index.maml');
__maAppCode__['page/tabbar/framework/index.json']={"navigationBarTitleText":"Applet framework capability display"};
__maAppCode__['page/tabbar/react/index.maml']=$gma('./page/tabbar/react/index.maml');
__maAppCode__['page/tabbar/react/index.json']={"navigationBarTitleText":"Applet official component display"};

define("app.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
initI18n({defaultLocale:"zh-CN"});const t=getI18nInstance();App({onLaunch:function(){t.onLocaleChange((t=>{})),ma.getSystemInfo({success:e=>{t.setLocale(e.language),ma.setTabBarItem({index:0,text:t.t("component")}),ma.setTabBarItem({index:1,text:t.t("api")}),ma.setTabBarItem({index:2,text:t.t("framework")})}});const e=ma.getUpdateManager();e.onCheckForUpdate((function(t){})),e.onUpdateReady((function(){ma.showModal({title:"Update Tips",cancelText:"Cancel",confirmText:"Confirm",content:"The version is ready. Do you want to restart the application？",success:function(t){t.confirm&&e.applyUpdate()}})})),e.onUpdateFailed((function(){}))},globalData:{},onHide:function(){}});
});
define("component/communication-detail/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Component({properties:{detail:{type:Object,value:{},public:!0,observer:"_test"},propTest:{type:String,value:"123456"}},data:{isDispalyItem:!1,count:0,list:[{name:"1"},{name:"2"},{name:"3"}],text:"Click Me to trigger a custom event"},created:function(){},attached:function(){},ready:function(){},moved:function(){},detached:function(){},methods:{trigger:function(){this.setData({list:this.data.list,isDispalyItem:!0});this.triggerEvent("myevent",{},{})},onMyEvent:function(t){t.detail},onChildMethod:function(){if(!this.data.isDispalyItem)return;this.selectComponent(".test_color")[0].testData("Successfully invoked")},testSelectComponent:function(t){}}});
});
define("component/communication-detailItem/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Component({properties:{item:{type:Object,value:{}}},data:{count:0},methods:{trigger:function(){var t=this.properties.item;this.triggerEvent("myevent",t,{bubbles:!1})},testData:function(t){}}});
});
define("component/detail/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
getI18nInstance();Component({properties:{detail:{type:Object,value:{}}},data:{count:0},methods:{addCount:function(){this.setData({count:this.data.count+2})}}});
});
define("component/detailItem/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Component({properties:{item:{type:Object,value:{}}},data:{count:0},methods:{addCount:function(){this.setData({count:this.data.count+3})}}});
});
define("macle_demo_EN/app.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
initI18n({defaultLocale:"zh-CN"});const t=getI18nInstance();App({onLaunch:function(){t.onLocaleChange((t=>{})),ma.getSystemInfo({success:e=>{t.setLocale(e.language),ma.setTabBarItem({index:0,text:t.t("component")}),ma.setTabBarItem({index:1,text:t.t("api")}),ma.setTabBarItem({index:2,text:t.t("framework")})}});const e=ma.getUpdateManager();e.onCheckForUpdate((function(t){})),e.onUpdateReady((function(){ma.showModal({title:"Update Tips",cancelText:"Cancel",confirmText:"Confirm",content:"The version is ready. Do you want to restart the application？",success:function(t){t.confirm&&e.applyUpdate()}})})),e.onUpdateFailed((function(){}))},globalData:{},onHide:function(){}});
});
define("macle_demo_EN/component/communication-detail/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Component({properties:{detail:{type:Object,value:{},public:!0,observer:"_test"},propTest:{type:String,value:"123456"}},data:{isDispalyItem:!1,count:0,list:[{name:"1"},{name:"2"},{name:"3"}],text:"Click Me to trigger a custom event"},created:function(){},attached:function(){},ready:function(){},moved:function(){},detached:function(){},methods:{trigger:function(){this.setData({list:this.data.list,isDispalyItem:!0});this.triggerEvent("myevent",{},{})},onMyEvent:function(t){t.detail},onChildMethod:function(){if(!this.data.isDispalyItem)return;this.selectComponent(".test_color")[0].testData("Successfully invoked")},testSelectComponent:function(t){}}});
});
define("macle_demo_EN/component/communication-detailItem/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Component({properties:{item:{type:Object,value:{}}},data:{count:0},methods:{trigger:function(){var t=this.properties.item;this.triggerEvent("myevent",t,{bubbles:!1})},testData:function(t){}}});
});
define("macle_demo_EN/component/detail/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
getI18nInstance();Component({properties:{detail:{type:Object,value:{}}},data:{count:0},methods:{addCount:function(){this.setData({count:this.data.count+2})}}});
});
define("macle_demo_EN/component/detailItem/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Component({properties:{item:{type:Object,value:{}}},data:{count:0},methods:{addCount:function(){this.setData({count:this.data.count+3})}}});
});
define("macle_demo_EN/page/API/pages/application-event/application-event.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
let a,e=function(){a.setData({detail:a.data.detail+"\r\nonAppShow:ok"})},i=function(){a.setData({detail:a.data.detail+"\r\nonAppHide:ok"})},o=function(t){a.setData({detail:a.data.detail+"\r\nonError:ok"})};Page({data:{detail:""},onLoad(){a=this},onAppShow(){a.setData({detail:a.data.detail+"\r\nonAppShowRegistering a Listener"}),ma.onAppShow(e)},offAppShow(){a.setData({detail:a.data.detail+"\r\noffAppShowCancel Listening"}),ma.offAppShow(e)},onAppHide(){a.setData({detail:a.data.detail+"\r\nonAppHideRegistering a Listener"}),ma.onAppHide(i)},offAppHide(){a.setData({detail:a.data.detail+"\r\noffAppHideCancel Listening"}),ma.offAppHide(i)},onError(){a.setData({detail:a.data.detail+"\r\nonErrorRegistering a Listener"}),ma.onError(o)},offError(){a.setData({detail:a.data.detail+"\r\noffErrorCancel Listening"}),ma.offError(o)},Error(){a.setData({detail:a.data.detail+"\r\nErrorThrowing an error"}),maa.offAppHide()}});
});
define("macle_demo_EN/page/API/pages/canIUse/canIUse.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{success:"",popcom:""},popapi1:function(){this.data.success=!!ma.canIUse("request.object.method.GET"),this.setData({success:this.data.success})},popapi2:function(){this.data.success=!!ma.canIUse("request.object.method.OPTI"),this.setData({success:this.data.success})},popapi3:function(){this.data.success=!!ma.canIUse("request.object.method"),this.setData({success:this.data.success})},popapi4:function(){this.data.success=!!ma.canIUse("request.object.meth"),this.setData({success:this.data.success})},popapi5:function(){this.data.success=!!ma.canIUse("request.object"),this.setData({success:this.data.success})},popapi6:function(){this.data.success=!!ma.canIUse("request.obj"),this.setData({success:this.data.success})},popapi7:function(){this.data.success=!!ma.canIUse("request"),this.setData({success:this.data.success})},popapi8:function(){this.data.success=!!ma.canIUse("reque"),this.setData({success:this.data.success})},popcom1:function(){this.data.popcom=!!ma.canIUse("button.size.default"),this.setData({popcom:this.data.popcom})},popcom2:function(){this.data.popcom=!!ma.canIUse("button.size.defau"),this.setData({popcom:this.data.popcom})},popcom3:function(){this.data.popcom=!!ma.canIUse("button.size"),this.setData({popcom:this.data.popcom})},popcom4:function(){this.data.popcom=!!ma.canIUse("button.si"),this.setData({popcom:this.data.popcom})},popcom5:function(){this.data.popcom=!!ma.canIUse("button"),this.setData({popcom:this.data.popcom})},popcom6:function(){this.data.popcom=!!ma.canIUse("butt"),this.setData({popcom:this.data.popcom})}});
});
define("macle_demo_EN/page/API/pages/chooseContact/chooseContact.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({chooseContact:function(){ma.chooseContact({success(c){ma.showToast({title:"successful",icon:"success",duration:2e3})},fail(c){ma.showModal({title:"tips",cancelText:"Cancel",confirmText:"Confirm",content:c.errMsg})}})}});
});
define("macle_demo_EN/page/API/pages/compressImage/compressImage.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{src:"../../../../image/2ac8e99273bc079e40a8dc079ca11b1f.jpg",info:"",complete:"",filePath:""},compressImage(){ma.compressImage({src:this.data.src,quality:80,success:t=>{this.setData({info:t.msg,filePath:this.format(t)})},fail:t=>{this.setData({info:this.format(t)})},complete:t=>{this.setData({complete:"complete"})}})},compressImageFail(){ma.compressImage({quality:80,fail:t=>{this.setData({info:this.format(t)})},complete:t=>{this.setData({complete:"complete"})}})},format:t=>"{\n"+Object.keys(t).map((function(a){return"  "+a+": "+t[a]+","})).join("\n")+"\n}"});
});
define("macle_demo_EN/page/API/pages/downloadFile/downloadFile.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{info:"",isPublicNet:!1},isPublicNetChange(i){this.data.isPublicNet=i.detail.value},format:i=>"{\n"+Object.keys(i).map((function(t){return"  "+t+": "+i[t]+","})).join("\n")+"\n}",popdownloadFile:function(){let i=this.data.isPublicNet?"https://files.cnblogs.com/MolbyHome/%E6%83%B3%E6%B3%95.rar":"http://his.macle.inhuawei.com/300s00/300s00i1gjek5j02010vf1gjek5j/1.0.0/300s00i1gjekeg34340vf1gjekeg.zip";ma.downloadFile({url:i,timeout:5e3,success(i){this.setData({info:this.format(i)})},fail(i){}})},downloadFile:function(){ma.downloadFile({url:"",timeout:5e3,success:i=>{this.setData({info:this.format(i)})},fail:i=>{this.setData({info:this.format(i)})}})}});
});
define("macle_demo_EN/page/API/pages/file/file.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({onLoad(){ma.getStorage({key:"savedFilePath",success(e){let t=e.data;t&&ma.getSavedFileInfo({filePath:t,success(e){this.setData({filePath:t,savedFilePath:t})},fail(e){ma.showToast({title:"The resource does not exist",icon:"error"})}})}})},data:{detail:"",filePath:"",tempFilePath:"",savedFilePath:""},chooseImage(){ma.chooseImage({count:1,success(e){this.setData({tempFilePath:e.tempFilePaths[0]})}})},saveFile(){ma.saveFile({tempFilePath:this.data.tempFilePath,success(e){this.setData({filePath:e.savedFilePath,tempFilePath:"",savedFilePath:e.savedFilePath}),ma.setStorage({key:"savedFilePath",data:e.savedFilePath}),ma.showModal({title:"Saved successfully",cancelText:"Cancel",confirmText:"Confirm",content:"This file is still available when you enter the app"})},fail(){ma.showModal({title:"Saving failed",cancelText:"Cancel",confirmText:"Confirm",content:"I think there is a bug"})}})},clear(){ma.removeStorage({key:"savedFilePath"}),this.setData({tempFilePath:"",savedFilePath:""})},getFileInfo(){let e=this.data.tempFilePath?this.data.tempFilePath:this.data.savedFilePath;ma.getFileInfo({filePath:e,digestAlgorithm:"sha1",success(e){ma.showToast({title:"Obtained successfully",icon:"success"}),this.setData({detail:`\n                    size:${e.size}\n                    digest:${e.digest}\n                    `})},fail(e){ma.showToast({title:"Obtaining failed",icon:"error"})}})},getSavedFileInfo(){ma.getSavedFileInfo({filePath:this.data.savedFilePath,success(e){ma.showToast({title:"Obtained successfully",icon:"success"}),this.setData({detail:`\n                    size:${e.size}\n                    createTime:${e.createTime}\n                    `})},fail(e){ma.showToast({title:"Obtaining failed",icon:"error"})}})},getSavedFileList(){ma.getSavedFileList({success(e){ma.showToast({title:"Obtained successfully",icon:"success"}),this.setData({detail:`fileList:${JSON.stringify(e.fileList)}`})},fail(e){ma.showToast({title:"Obtaining failed",icon:"error"})}})},removeSavedFile(){ma.removeSavedFile({filePath:this.data.filePath,success(){ma.removeStorage({key:"savedFilePath"}),ma.showToast({title:"Deleted successfully",icon:"success"}),this.setData({filePath:"",tempFilePath:"",savedFilePath:""})},fail(e){ma.showToast({title:"The file does not exist",icon:"error"})}})}});
});
define("macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{},getBatteryInfo(){ma.getBatteryInfo({success(t){const a=t.isCharging?"Charging":"In the battery";this.setData({level:t.level,isCharging:a})},fail(t){ma.showToast({title:"failed",icon:"error",duration:2e3})}})}});
});
define("macle_demo_EN/page/API/pages/get-image-info/get-image-info.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{src:"../../../../image/2ac8e99273bc079e40a8dc079ca11b1f.jpg",netSrc:"http://10.29.183.231/pkg/docs_demo_rongcloud_logo.png",info:"",complete:""},getImageInfo(){ma.getImageInfo({src:this.data.src,success:t=>{this.setData({info:this.format(t)})},fail:t=>{this.setData({info:this.format(t)})},complete:t=>{this.setData({complete:"complete"})}})},getImageInfo2(){ma.getImageInfo({src:this.data.netSrc,success:t=>{this.setData({info:this.format(t)})},fail:t=>{this.setData({info:this.format(t)})},complete:t=>{this.setData({complete:"complete"})}})},getImageInfoFail(){ma.getImageInfo({fail:t=>{this.setData({info:this.format(t)})},complete:t=>{this.setData({complete:"complete"})}})},format:t=>"{\n"+Object.keys(t).map((function(e){return"  "+e+": "+t[e]+","})).join("\n")+"\n}"});
});
define("macle_demo_EN/page/API/pages/get-location/get-location.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
var c=require("../../../util/util").formatLocation;Page({data:{hasLocation:!1},getLocation:()=>{ma.getLocation({success:function(t){this.setData({hasLocation:!0,location:c(t.longitude,t.latitude)})}})},clear:function(){this.setData({hasLocation:!1})}});
});
define("macle_demo_EN/page/API/pages/get-network-type/get-network-type.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{network:"",complete:""},getNetworkType:function(){ma.getNetworkType({success(e){this.setData({network:e.networkType})},fail(e){this.setData({network:e.errMsg})},complete(e){this.setData({complete:"complete"})}})}});
});
define("macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{systemInfo:{}},getSystemInfoSync:function(){try{const t=ma.getSystemInfoSync();setTimeout((()=>{this.setData({systemInfo:t})}),3e3)}catch(t){}}});
});
define("macle_demo_EN/page/API/pages/get-system-info/get-system-info.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{systemInfo:{}},getSystemInfo:function(){ma.getSystemInfo({success:s=>{this.setData({systemInfo:s})}})}});
});
define("macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{menuButtonPosInfo:{}},getMenuButtonPosInfo:function(){let t=this;ma.getMenuButtonBoundingClientRect({success:function(n){t.setData({menuButtonPosInfo:n})},fail(t){},complete(){}})}});
});
define("macle_demo_EN/page/API/pages/gyroscope/gyroscope.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
let a,s=function(o){a.setData({detail:JSON.stringify(o)})},i=function(o){a.setData({detail:JSON.stringify(o)})};Page({data:{detail:""},onLoad(){a=this},startGyroscope:()=>{ma.startGyroscope({success(o){a.setData({detail:"startGyroscope:ok"})},fail(o){ma.showToast({title:"fail",icon:"error",duration:1e3})}})},stopGyroscope:()=>{ma.stopGyroscope({success(o){a.setData({detail:"stopGyroscope:ok"})},fail(o){ma.showToast({title:"fail",icon:"error",duration:1e3})}})},onGyroscopeChange:()=>{ma.onGyroscopeChange(s),ma.onGyroscopeChange(i)},offGyroscopeChange:function(){ma.offGyroscopeChange()}});
});
define("macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{autoHideTimer:null},setAutoHide(){this.data.autoHideTimer=setTimeout((()=>{ma.hideKeyboard({success:()=>{ma.showToast({title:"Keyboard hidden successfully",icon:"success",duration:2e3})}}),this.data.autoHideTimer=null}),5e3)},unsetAutoHide(){clearTimeout(this.data.autoHideTimer),this.data.autoHideTimer=null}});
});
define("macle_demo_EN/page/API/pages/loading/loading.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{result:""},popLoading:function(){ma.showLoading({title:"loading",success(e){},fail(e){},complete(e){}}),setTimeout((()=>{ma.hideLoading({success(e){this.setData({result:e.msg})}})}),3e3)}});
});
define("macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{disabled:!0},bindInput(a){this.inputValue=a.detail.value,this.inputValue.length>0?this.setData({disabled:!1}):this.setData({disabled:!0})},makePhoneCall(){ma.makePhoneCall({phoneNumber:this.inputValue,success(a){ma.showToast({title:"successful",icon:"success",duration:2e3})},fail(a){ma.showToast({title:"failed",icon:"error",duration:2e3})},complete(){}})},makePhoneCallFail(){ma.makePhoneCall({fail(a){ma.showToast({title:"failed",icon:"error",duration:2e3})}})}});
});
define("macle_demo_EN/page/API/pages/mediaImage/mediaImage.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
const m=[["camera"],["album"],["camera","album"]],p=[["compressed"],["original"],["compressed","original"]];Page({data:{imageList:[],sourceTypeIndex:2,sourceType:["Take a photo","album","Take a photo or album"],sizeTypeIndex:2,sizeType:["compression","original drawing","Compressed or original"],countIndex:8,count:[1,2,3,4,5,6,7,8,9],src:"./image/2ac8e99273bc079e40a8dc079ca11b1f.jpg",info:"",complete:""},sourceTypeChange(e){this.setData({sourceTypeIndex:e.detail.value})},sizeTypeChange(e){this.setData({sizeTypeIndex:e.detail.value})},countChange(e){this.setData({countIndex:e.detail.value})},chooseImage(){const e=this;ma.chooseImage({sourceType:m[this.data.sourceTypeIndex],sizeType:p[this.data.sizeTypeIndex],count:this.data.count[this.data.countIndex],success(t){e.setData({imageList:t.tempFilePaths,info:this.format(t.tempFilePaths)})},fail:e=>{this.setData({info:this.format(e)})},complete:e=>{this.setData({complete:"complete"})}})},previewImage(e){const t=e.target.dataset.src;ma.previewImage({current:t,urls:this.data.imageList,success:e=>{this.setData({info:this.format(e)})},fail:e=>{this.setData({info:this.format(e)})},complete:e=>{this.setData({complete:"complete"})}})},previewImage2(){ma.previewImage({current:"http://c.hiphotos.baidu.com/image/pic/item/30adcbef76094b36de8a2fe5a1cc7cd98d109d99.jpg",urls:["http://e.hiphotos.baidu.com/image/pic/item/a1ec08fa513d2697e542494057fbb2fb4316d81e.jpg","http://c.hiphotos.baidu.com/image/pic/item/30adcbef76094b36de8a2fe5a1cc7cd98d109d99.jpg","http://www.baidu.com/img/bdlogo.png","http://rongcloud-web.qiniudn.com/docs_demo_rongcloud_logo.png"],success:e=>{this.setData({info:this.format(e)})},fail:e=>{this.setData({info:this.format(e)})},complete:e=>{this.setData({complete:"complete"})}})},previewImageFail(){ma.previewImage({fail:e=>{this.setData({info:this.format(e)})},complete:e=>{this.setData({complete:"complete"})}})},format:e=>"{\n"+Object.keys(e).map((function(t){return"  "+t+": "+e[t]+","})).join("\n")+"\n}",saveImage(){ma.saveImageToPhotosAlbum({filePath:this.data.imageList[0],success:e=>{this.setData({info:this.format(e)})},fail:e=>{this.setData({info:this.format(e)})},complete:e=>{this.setData({complete:"complete"})}})}});
});
define("macle_demo_EN/page/API/pages/memory-warning/memory-warning.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
let a,s=function(t){a.setData({detail:a.data.detail+"\r\nreceive memory warning test"})},i=function(t){a.setData({detail:a.data.detail+"\r\nreceive memory warning test2"})};Page({data:{detail:""},onLoad(){a=this},onMemoryWarning:()=>{a.setData({detail:a.data.detail+"\r\nRegistering a Listener test、test2"}),ma.onMemoryWarning(s),ma.onMemoryWarning(i)},offMemoryWarning:function(){a.setData({detail:a.data.detail+"\r\nDeregistering a Listener test"}),ma.offMemoryWarning(s)},offAll:function(){a.setData({detail:a.data.detail+"\r\nDeregistering a Listener test、test2"}),ma.offMemoryWarning()},simulateMemoryWarning:function(){a.setData({detail:a.data.detail+"\r\nSimulator Memory Alarm IOS"}),ma.simulateMemoryWarning()}});
});
define("macle_demo_EN/page/API/pages/modal/modal.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{info:"",complete:""},format:o=>"{\n"+Object.keys(o).map((function(e){return"  "+e+": "+o[e]+","})).join("\n")+"\n}",modalSuccess:function(){ma.showModal({title:"Info",content:"This is a modal pop-up",cancelText:"Cancel",cancelColor:"#000000",confirmText:"Confirm",success(o){(o.confirm||o.cancel)&&this.setData({info:this.format(o)})},fail(o){ma.showToast({title:"Failed",icon:"error",duration:2e3})}})},showModalEditable:function(){ma.showModal({editable:!0,title:"Info",content:"editableIstrue",cancelText:"Cancel",cancelColor:"#000000",confirmText:"Confirm",success(o){(o.confirm||o.cancel)&&this.setData({info:this.format(o)})},fail(o){ma.showToast({title:"Failed",icon:"error",duration:2e3})}})},showModal2:function(){ma.showModal({title:"Info",content:"editableIstrue",cancelText:"Cancel",cancelColor:"#000000",confirmText:"More than four words",success(o){o.confirm||o.cancel},fail(o){ma.showToast({title:"Failed",icon:"error",duration:2e3})}})}});
});
define("macle_demo_EN/page/API/pages/navigator/navigate.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({eventChannel:function(){const e=this.getOpenerEventChannel();e.emit("someEvent1",{data:"test"}),e.emit("someEvent2",{}),e.off("someEvent2"),e.emit("someEvent2",{}),e.on("test1",(function(){var e;e="666",ma.showModal({title:e,cancelText:"Cancel",cancelColor:"#000000",confirmText:"Confirm"})})),e.emit("test1")}});
});
define("macle_demo_EN/page/API/pages/navigator/navigator.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({navigateTo:function(){const e=this.getOpenerEventChannel();let t=function(){};e.on("test",t),e.on("test",(function(){})),e.once("test",(function(){})),e.emit("test",{}),e.emit("test",{}),e.off("test",t),e.emit("test",{}),e.on("test",(function(){})),e.off("test"),e.emit("test",{}),ma.navigateTo({url:"./navigate",events:{someEvent:function(e){}},success:e=>{const n=e.eventChannel;n.emit("someEvent"),n.off("someEvent"),n.emit("someEvent"),n.once("someEvent",t),n.emit("someEvent"),n.emit("someEvent"),n.on("someEvent1",(function(){})),n.on("someEvent2",(function(){var e;e="Son",ma.showModal({title:e,cancelText:"Cancel",cancelColor:"#000000",confirmText:"Confirm"})}))},fail(){},complete(){}})},navigateBack:function(){ma.navigateBack()},redirectTo:function(){ma.redirectTo({url:"./redirect"})},switchTab:function(){ma.switchTab({url:"../../../tabbar/api/index"})},reLaunch:function(){ma.reLaunch({url:"./redirect"})}});
});
define("macle_demo_EN/page/API/pages/navigator/redirect.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({});
});
define("macle_demo_EN/page/API/pages/network/network.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
let a,s=function(t){a.setData({detail:a.data.detail+"\r\n"+JSON.stringify(t.networkType)})},i=function(t){a.setData({detail2:a.data.detail+"\r\n"+JSON.stringify(t.networkType)})};Page({data:{hasLocation:!1,detail:"",detail2:""},onLoad(){a=this},onNetworkStatusChange:()=>{a.setData({detail:a.data.detail+"\r\nRegister and listen to test and test2."}),ma.onNetworkStatusChange(s),ma.onNetworkStatusChange(i)},offNetworkStatusChange:function(){a.setData({detail:a.data.detail+"\r\nDeregister the listener test and test2."}),ma.offNetworkStatusChange()}});
});
define("macle_demo_EN/page/API/pages/open-document/open-document.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({isPublicNetChange(e){this.data.isPublicNet=e.detail.value},openDocument(){let e=this.data.isPublicNet?"https://www.furukawa.co.jp/cn/product/catalogue/pdf/profile_c.pdf":"http://repo.macle.inhuawei.com:8080/release/20211203-0.7.1.12171/Documents/MacleAndroid/Android客户端集成文档.pdf";ma.downloadFile({url:e,success(e){ma.openDocument({filePath:e.tempFilePath,success:function(e){ma.showToast({title:"SUCCESS",icon:"success",duration:1e3})},fail(e){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}})}})}});
});
define("macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({startPullDownRefresh:function(){ma.startPullDownRefresh({success(e){},fail(e){},complete(){}})},stopPullDownRefresh:function(){ma.stopPullDownRefresh({success(e){},fail(e){},complete(){}})},onPullDownRefresh(){}});
});
define("macle_demo_EN/page/API/pages/request/request.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{text:"点击向服务器发起请求",getUrl:"http://127.0.0.1:48080/simulator/",postUrl:"http://hwa.his.huawei.com/hwa/p"},makeRequest:function(){var t=this;let e=this.data.getUrl,a=this.data.text+"\nServer Address:"+e;t.setData({loading:!0,text:a}),ma.request({url:e,timeout:5e3,header:{"content-type":"application/json"},data:{},method:"GET",success:function(e){ma.showToast({title:"The request is successful",icon:"success",mask:!0,duration:2e3}),t.setData({loading:!1})},fail:function(e){t.setData({loading:!1})}})},makePostRequest:function(){var t=this;let e=this.data.postUrl,a=this.data.text+"\nServer Address:"+e;t.setData({PostLoading:!0,text:a}),ma.request({url:e,method:"POST",header:{"Content-type":"application/json; charset=UTF-8"},data:{},success:function(e){let a=this.data.text+"\ntoken："+e.data.access_token;t.setData({text:a}),ma.showToast({title:"The request is successful",icon:"success",mask:!0,duration:2e3}),t.setData({PostLoading:!1})},fail:function({errMsg:e}){t.setData({PostLoading:!1})}})}});
});
define("macle_demo_EN/page/API/pages/scanCode/scanCode.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{result:"",complete:""},scanCode:function(){ma.scanCode({success:e=>{this.setData({result:e.result})},fail(e){this.setData({result:e.errMsg})},complete(e){this.setData({complete:"complete"})}})}});
});
define("macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{screenBrightness:0},onLoad(){this._updateScreenBrightness()},changeBrightness(e){const s=Number.parseFloat(e.detail.value.toFixed(1));this.setData({screenBrightness:Number.parseFloat(e.detail.value.toFixed(1))}),ma.setScreenBrightness({value:s,success(e){},fail(e){},complete(){}})},setKeepScreenOn(){ma.setKeepScreenOn({keepScreenOn:!0,success(e){ma.showToast({title:"SUCCESS",icon:"success",duration:2e3})},fail(e){ma.showToast({title:"FAILED",icon:"error",duration:2e3})},complete(){}})},_updateScreenBrightness(){ma.getScreenBrightness({success:e=>{this.setData({screenBrightness:Number.parseFloat(e.value.toFixed(1))})},fail(e){},complete(){}})}});
});
define("macle_demo_EN/page/API/pages/set-background/set-background.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{detail:"",textStyle:"",backgroundColor:""},textStyleChange(t){this.data.textStyle=t.detail.value},backgroundColorChange(t){this.data.backgroundColor=t.detail.value},setBackgroundTextStyle(){const{textStyle:t}=this.data,e=this;ma.setBackgroundTextStyle({textStyle:t,success(t){e.setData({detail:JSON.stringify(t)}),ma.showToast({title:"SUCCESS",icon:"success"})},fail(t){e.setData({detail:JSON.stringify(t)}),ma.showToast({title:"FAILED",icon:"error",duration:2e3})},complete(){}})},setBackgroundColor(){const{backgroundColor:t}=this.data,e=this;ma.setBackgroundColor({backgroundColor:t,success(t){e.setData({detail:JSON.stringify(t)}),ma.showToast({title:"SUCCESS",icon:"success"})},fail(t){e.setData({detail:JSON.stringify(t)}),ma.showToast({title:"FAILED",icon:"error",duration:2e3})},complete(){}})},dropDown(){ma.startPullDownRefresh(),setTimeout((function(){ma.stopPullDownRefresh()}),1e3)}});
});
define("macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{detail:"",frontColor:"",backgroundColor:""},frontColorChange(o){this.data.frontColor=o.detail.value},backgroundColorChange(o){this.data.backgroundColor=o.detail.value},setNavigationBarColor:function(o){const{frontColor:a,backgroundColor:t}=this.data,r=this;ma.setNavigationBarColor({frontColor:a,backgroundColor:t,animation:{duration:3e3,timingFunc:"easeInOut"},success(o){r.setData({detail:JSON.stringify(o)}),ma.showToast({title:"SUCCESS",icon:"success",duration:2e3})},fail(o){r.setData({detail:JSON.stringify(o)}),ma.showToast({title:"FAILed",icon:"error",duration:2e3})},complete(){}})}});
});
define("macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({setNavigationBarTitle:function(t){const a=t.detail.value.title;ma.setNavigationBarTitle({title:a,success(t){},fail(t){ma.showToast({title:"FAILED",icon:"error",duration:2e3})},complete(){}})},setNavigationBarTitleFail(){ma.setNavigationBarTitle({fail(t){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}})}});
});
define("macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({actionSheetTap:function(){ma.showActionSheet({alertText:"alertText",itemList:["item1","item2","item3"],success(t){ma.showToast({title:`{tapIndex:${t.tapIndex}}`,icon:"success",duration:2e3})},fail(t){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}})},showActionSheetFail(){ma.showActionSheet({alertText:"alertText",itemList:["item1","item2","item3","item4","item5","item6","item7"],fail(t){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}})}});
});
define("macle_demo_EN/page/API/pages/storage-sync/storage-sync.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
var r=Date(),n=new ArrayBuffer(10);Page({data:{key:"",data:"",dialog:{title:"",content:"",hidden:!0}},keyChange(t){this.data.key=t.detail.value},dataChange(t){this.data.data=t.detail.value},getStorage(){const{key:t}=this.data;try{const e=ma.getStorageSync(t);this.setData({key:t,data:e}),ma.showModal({title:"Data read successfully",cancelText:"Cancel",confirmText:"Confirm",content:JSON.stringify(e)})}catch(e){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}},setStorage(){const{key:t,data:e}=this.data;try{ma.setStorageSync(t,e),ma.showModal({cancelText:"Cancel",confirmText:"Confirm",title:"Data stored successfully"})}catch(a){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}},clearStorage(){ma.clearStorage({success:t=>{this.setData({key:"",data:""}),ma.showModal({cancelText:"Cancel",confirmText:"Confirm",title:"Data cleared successfully"})},fail(t){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}})},setStorageWithObj(){const{key:t}=this.data,e={a:1,b:2};try{ma.setStorageSync(t,e),ma.showModal({cancelText:"Cancel",confirmText:"Confirm",title:"Succeeded in storing object {a:1,b:2}"})}catch(a){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}},setStorageWithObjArray(){const{key:t}=this.data,e={sites:[{name:"Runoob",url:"www.runoob.com"},{name:"Google",url:"www.google.com"},{name:"Taobao",url:"www.taobao.com"}]};try{ma.setStorageSync(t,e),ma.showModal({cancelText:"Cancel",confirmText:"Confirm",title:"Succeeded in storing object data JSON"})}catch(a){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}},getStorageWithObj(){const{key:t}=this.data;try{const e=ma.getStorageSync(t);ma.showModal({title:"Reading object {a:1,b:2} succeeded",cancelText:"Cancel",confirmText:"Confirm",content:JSON.stringify(e)})}catch(e){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}},setStorageWithDate(){const{key:t}=this.data,e=r;try{ma.setStorageSync(t,e),ma.showModal({cancelText:"Cancel",confirmText:"Confirm",title:"Saving the date succeeded"})}catch(a){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}},getStorageWithDate(){const{key:t}=this.data;try{const e=ma.getStorageSync(t);ma.showModal({cancelText:"Cancel",confirmText:"Confirm",title:"Reads the date type",content:e})}catch(e){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}},setStorageWithAarryBuffer(){const{key:t}=this.data;try{ma.setStorageSync(t,n),ma.showModal({cancelText:"Cancel",confirmText:"Confirm",title:"storagearraybuffer"})}catch(e){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}},getStorageWithAarryBuffer(){const{key:t}=this.data;try{const e=ma.getStorageSync(t);ma.showModal({cancelText:"Cancel",confirmText:"Confirm",title:"Reads the date type",content:e})}catch(e){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}}});
});
define("macle_demo_EN/page/API/pages/storage/storage.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{key:"",data:"",dialog:{title:"",content:"",hidden:!0}},keyChange(a){this.data.key=a.detail.value},dataChange(a){this.data.data=a.detail.value},getStorage(){const{key:a,data:t}=this.data;let e;ma.getStorage({key:a,success(t){e=t.data,this.setData({key:a,data:e}),ma.showModal({title:"Data read successfully",content:JSON.stringify(e),cancelText:"Cancel",confirmText:"Confirm"})},fail(a){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}})},setStorage(){const{key:a,data:t}=this.data;ma.setStorage({key:a,data:t,success:e=>{this.setData({key:a,data:t}),ma.showModal({title:"Data stored successfully",cancelText:"Cancel",confirmText:"Confirm"})},fail:a=>{ma.showToast({title:"FAILET",icon:"error",duration:2e3})}})},getStorageInfo(){ma.getStorageInfo({success:a=>{ma.showModal({title:"Information obtained successfully",content:JSON.stringify(a),cancelText:"Cancel",confirmText:"Confirm"})},fail(a){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}})},removeStorage(){const{key:a}=this.data;ma.removeStorage({key:a,success:a=>{this.setData({key:"",data:""}),ma.showModal({title:"Data removed successfully",cancelText:"Cancel",confirmText:"Confirm"})},fail(a){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}})},clearStorage(){ma.clearStorage({success:a=>{this.setData({key:"",data:""}),ma.showModal({title:"Data cleared successfully",cancelText:"Cancel",confirmText:"Confirm"})},fail(a){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}})},setStorageWithObj(){const{key:a}=this.data;ma.setStorage({key:a,data:{a:1,b:2},success:a=>{ma.showModal({title:"Succeeded in storing object {a:1,b:2}",cancelText:"Cancel",confirmText:"Confirm"})},fail:a=>{ma.showToast({title:"FAILED",icon:"error",duration:2e3})}})},getStorageWithObj(){const{key:a}=this.data;let t;ma.getStorage({key:a,success(a){t=a.data,ma.showModal({title:"Reading object {a:1,b:2} succeeded",content:`{a:${t.a}, b:${t.b}}`,cancelText:"Cancel",confirmText:"Confirm"})},fail(a){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}})}});
});
define("macle_demo_EN/page/API/pages/toast/toast.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{toastTitle:null},popSuccess:function(){ma.showToast({title:"success",duration:2e4,icon:"success",success(e){},fail(e){},complete(){}})},popError:function(){ma.showToast({title:"Failed",duration:2e4,icon:"error",success(e){},fail(e){},complete(){}})},popLoading:function(){ma.showToast({title:"Waiting",duration:2e4,icon:"loading",success(e){},fail(e){},complete(){}})},popOther:function(){ma.showToast({title:"If there is no icon or image, a maximum of two lines of title text can be displayed",icon:"none",duration:2e4,success(e){},fail(e){},complete(){}})},popimage:function(){ma.showToast({title:"Images",image:"../../../../image/green_tri.png",duration:2e4,success(e){},fail(e){},complete(){}})},close(){ma.hideToast({success(e){},fail(e){},complete(){}})},mask:function(){ma.showToast({title:"The page cannot be clicked",duration:2e4,icon:"loading",mask:!0,success(e){},fail(e){},complete(){}})},popInput:function(){ma.showToast({title:this.data.toastTitle,duration:2e4,icon:"success",success(e){},fail(e){},complete(){}})}});
});
define("macle_demo_EN/page/API/pages/uploadFile/uploadFile.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
const l="http://10.138.20.70:8686/sxnys/upload";Page({data:{info:""},format:a=>JSON.stringify(a),popuploadFile:function(){ma.chooseImage({success(a){const t=a.tempFilePaths;ma.uploadFile({url:l,filePath:t[0],name:"file",success(a){this.setData({info:this.format(a)})}})}})},uploadFile:function(){ma.chooseImage({success(a){const t=a.tempFilePaths;ma.uploadFile({url:l,filePath:t[0],name:"",success:a=>{this.setData({info:this.format(a)})},fail:a=>{this.setData({info:this.format(a)})}})}})},uploadFile2:function(){ma.chooseImage({success(a){const t=a.tempFilePaths;ma.uploadFile({url:"",filePath:t[0],name:"file",success:a=>{this.setData({info:this.format(a)})},fail:a=>{this.setData({info:this.format(a)})}})}})},uploadFile3:function(){ma.uploadFile({url:l,filePath:"",name:"file",success:a=>{this.setData({info:this.format(a)})},fail:a=>{this.setData({info:this.format(a)})}})}});
});
define("macle_demo_EN/page/API/pages/vibrate/vibrate.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{typeIndex:0,type:["heavy","medium","light"],result:""},typeChange(t){this.setData({typeIndex:t.detail.value})},vibrateShort(){ma.vibrateShort({type:this.data.type[this.data.typeIndex],success(t){this.setData({result:t.msg})},fail(t){},complete(){}})},vibrateLong(){ma.vibrateLong({success(t){this.setData({result:t.msg})},fail(t){},complete(){}})}});
});
define("macle_demo_EN/page/API/pages/websocket/websocket.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
function d(e,t){ma.showModal({title:e,content:t,showCancel:!1,cancelText:"Cancel",confirmText:"Confirm"})}function h(e,t){ma.showToast({title:e,icon:"success",duration:t})}Page({onShareAppMessage:()=>({title:"Web Socket",path:"packageAPI/pages/network/web-socket/web-socket"}),data:{theme:"light",socketStatus:"closed",wsUrl:"",closeCode:1e3,closeReason:"",messageToSend:"",errMsg:"",onOpenData:"",onCloseData:"",onMessageData:"",onErrorData:""},onLoad(){this.setData({theme:ma.getSystemInfoSync().theme||"light"}),ma.onThemeChange&&ma.onThemeChange((({theme:e})=>{this.setData({theme:e})}));this.setData({hasLogin:!0})},onUnload(){this.closeSocket()},toggleSocket(e){const t=e.detail.value;if(t&&"closed"===this.data.socketStatus)this.openSocket();else if(!t&&"connected"===this.data.socketStatus){const e=!0;this.closeSocket(e)}},openSocket(){ma.onSocketOpen((e=>{d("OnOPen","OnOPen"),this.clearAllData(),this.setData({loading:!1,socketStatus:"connected",onOpenData:JSON.stringify(e)})})),ma.onSocketClose((e=>{d("OnClose","OnClose"),this.setData({loading:!1,socketStatus:"closed",onCloseData:JSON.stringify(e)})})),ma.onSocketError((e=>{d("OnError","OnError"),this.clearAllData(),this.setData({loading:!1,onErrorData:e.errMsg})})),ma.onSocketMessage((e=>{h("收到信道消息",500),this.clearAllData(),this.setData({loading:!1,onMessageData:e.data})})),ma.connectSocket({url:this.data.wsUrl,timeout:1e4,success:()=>{d("OpenConnection","Open Connection")},fail:e=>{d("FailedToOpen","Failed to open"),this.setData({errMsg:e.errMsg})},complete(){d("Open Complete","Open Complete")}})},closeSocket(){"connected"===this.data.socketStatus&&ma.closeSocket({code:Number.parseInt(this.data.closeCode),reason:this.data.closeReason,success:()=>{d("CloseDisconnect","CloseDisconnect"),h("Disconnect",2e3),this.setData({socketStatus:"closed"})},fail:e=>{d("CloseFaile","CloseFaile"),this.setData({errMsg:e.errMsg})},complete(){d("CloseFinished","CloseFinished")}})},sendMessage(){ma.sendSocketMessage({data:this.data.messageToSend,success:()=>{d("Sendok","Sendok"),this.setData({loading:!1})},fail:e=>{d("SendingFailed","Sending failed"),this.setData({errMsg:e.errMsg})},complete(){d("SendFinished","SendFinished")}})},clearAllData(){this.setData({errMsg:"",onOpenData:"",onCloseData:"",onMessageData:"",onErrorData:""})}});
});
define("macle_demo_EN/page/component/pages/audio/audio.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({onReady:function(t){this.audioContext=ma.createAudioContext("myAudio"),this.audioContext.setSrc("http://10.29.183.231/pkg/NAMANANA.mp3")},onUnload:function(){this.audioContext.pause()},data:{src:"",poster:"http://10.29.183.231/pkg/T002R300x300M000003rsKF44GyaSk.jpg",name:"NAMANANA",author:"zhang",loop:!1,controls:!0,time:30},playAudio:function(){this.audioContext.play()},pauseAudio:function(){this.audioContext.pause()},seekAudio:function(){this.audioContext.seek(this.data.time)},binderror:function(t){},bindplay:function(){},bindpause:function(){},bindtimeupdate:function(t){this.duration=t.detail.duration},bindended:function(){},binderror:function(t){}});
});
define("macle_demo_EN/page/component/pages/button/button.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
for(var f=["default","primary","warn"],u={data:{defaultSize:"default",primarySize:"default",warnSize:"default",disabled:!1,plain:!1,loading:!1},setDisabled:function(a){this.setData({disabled:!this.data.disabled})},setPlain:function(a){this.setData({plain:!this.data.plain})},setLoading:function(a){this.setData({loading:!this.data.loading})}},g=0;g<f.length;++g)!function(a){u[a]=function(t){var i=a+"Size",e={};e[i]="default"===this.data[i]?"mini":"default",this.setData(e)}}(f[g]);Page(u);
});
define("macle_demo_EN/page/component/pages/camera/camera.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{src:"",showText:"",position:"back",flash:"off"},takePhoto(){ma.createCameraContext().takePhoto({quality:"high",success:t=>{this.setData({src:t.tempImagePath})}})},takePosition(){this.setData({position:"front"})},takeFlash(){this.setData({flash:"on"})},error:function(t){},stop:function(t){}});
});
define("macle_demo_EN/page/component/pages/checkbox/checkbox.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{items:[{value:"USA",name:"USA"},{value:"CHN",name:"CHN",checked:"true"},{value:"BRA",name:"BRA"},{value:"JPN",name:"JPN"},{value:"ENG",name:"ENG"},{value:"FRA",name:"FRA"}]},checkboxChange:function(e){for(var a=this.data.items,t=e.detail.value,l=0,n=a.length;l<n;++l){a[l].checked=!1;for(var u=0,v=t.length;u<v;++u)if(a[l].value==t[u]){a[l].checked=!0;break}}this.setData({items:a})}});
});
define("macle_demo_EN/page/component/pages/cover-image/cover-image.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{src:""}});
});
define("macle_demo_EN/page/component/pages/cover-view/cover-view.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{src:"",red:"red"},takePhoto(){ma.createCameraContext().takePhoto({quality:"high",success:a=>{this.setData({src:a.tempImagePath})}})},changeColor(){this.setData({red:"yellow"})}});
});
define("macle_demo_EN/page/component/pages/form/form.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({submit:function(n){},reset:function(){}});
});
define("macle_demo_EN/page/component/pages/icon/icon.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({});
});
define("macle_demo_EN/page/component/pages/image/image.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{mode:"heightFix",src:"/image/../cat.jpg",array:[{mode:"scaleToFill",text:"scaleToFill：Scale pictures without maintaining aspect ratio，Fit the picture perfectly"},{mode:"aspectFit",text:"aspectFit：Zoom picture with aspect ratio，Allows the long edges of the picture to be fully displayed."},{mode:"aspectFill",text:"aspectFill：Zoom picture with aspect ratio，Only the short edges of the picture are fully displayed."},{mode:"top",text:"top：Do not zoom the picture，Show only the top area of the picture"},{mode:"bottom",text:"bottom：Do not zoom the picture，Show only the bottom area of the picture"},{mode:"center",text:"center：-Do not zoom the picture，Show only the middle area of the picture"},{mode:"left",text:"left：Do not zoom the picture，Show only the left area of the picture"},{mode:"right",text:"right：Do not zoom the picture，Display only the right area of the image."},{mode:"top left",text:"top left：Do not zoom the picture，Show only the upper left area of the image"},{mode:"top right",text:"top right：Do not zoom the picture，Shows only the upper right area of the image"},{mode:"bottom left",text:"bottom left：Do not zoom the picture，Show only the lower left area of the image"},{mode:"bottom right",text:"bottom right：Do not zoom the picture，Only the lower right area of the image is displayed."}]},bindload:function(t){},binderror:function(t){}});
});
define("macle_demo_EN/page/component/pages/input/input.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
function d(n,t){ma.showModal({cancelText:"Cancel",confirmText:"Confirm",title:n,content:t,showCancel:!1})}Page({data:{focus:!1,inputValue:"",modelValue:"123"},bindinput:function(){return"Replace the contents of the input box."},bindKeyInput:function(n){this.setData({inputValue:n.detail.value})},bindReplaceInput:function(n){var t=n.detail.value,e=n.detail.cursor;return-1!==e&&(e=n.detail.value.slice(0,e).replace(/11/g,"2").length),{value:t.replace(/11/g,"2"),cursor:e}},bindfocus:function(n){},bindfocusauto:function(n){d("bindfocusauto",n.detail.value)},bindconfirm:function(n){},bindconfirmauto:function(n){d("bindconfirmauto",n.detail.value)},bindblur:function(n){},bindblurauto:function(n){d("bindblurauto",n.detail.value)}});
});
define("macle_demo_EN/page/component/pages/label/label.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{checkboxItems:[{name:"USA",value:"USA"},{name:"CHN",value:"CHN",checked:"true"}],radioItems:[{name:"USA",value:"USA"},{name:"CHN",value:"CHN",checked:"true"}],hidden:!1},checkboxChange:function(e){for(var a=e.detail.value,t={},c=0;c<this.data.checkboxItems.length;c++)-1!==a.indexOf(this.data.checkboxItems[c].name)?t["checkboxItems["+c+"].checked"]=!0:t["checkboxItems["+c+"].checked"]=!1;this.setData(t)},radioChange:function(e){for(var a=e.detail.value,t={},c=0;c<this.data.radioItems.length;c++)-1!==a.indexOf(this.data.radioItems[c].name)?t["radioItems["+c+"].checked"]=!0:t["radioItems["+c+"].checked"]=!1;this.setData(t)},tapEvent:function(e){}});
});
define("macle_demo_EN/page/component/pages/navigator/navigate.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({onLoad:function(t){this.setData({title:t.title})}});
});
define("macle_demo_EN/page/component/pages/navigator/navigator.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({});
});
define("macle_demo_EN/page/component/pages/navigator/redirect.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({onLoad:function(t){this.setData({title:t.title})}});
});
define("macle_demo_EN/page/component/pages/navigator/reLaunch.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({onLoad:function(t){this.setData({title:t.title})}});
});
define("macle_demo_EN/page/component/pages/picker-view/picker-view.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
const b=new Date,k=[],y=[],C=[];for(let t=1990;t<=b.getFullYear();t++)k.push(t);for(let t=1;t<=12;t++)y.push(t);for(let t=1;t<=31;t++)C.push(t);Page({data:{years:k,year:b.getFullYear(),months:y,month:2,days:C,day:2,value:[9999,1,1],bindpickstartCount:0,bindpickendCount:0},bindChange:function(t){const a=t.detail.value;this.setData({year:this.data.years[a[0]],month:this.data.months[a[1]],day:this.data.days[a[2]]})},bindpickstart:function(){this.setData({bindpickstartCount:this.data.bindpickstartCount+1})},bindpickend:function(){this.setData({bindpickendCount:this.data.bindpickendCount+1})}});
});
define("macle_demo_EN/page/component/pages/picker/picker.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{array:["美国","中国","巴西","日本"],objectArray:[{id:0,name:"美国"},{id:1,name:"中国"},{id:2,name:"巴西"},{id:3,name:"日本"}],index:0,rangeKeyIndex:2,multiArray:[["无脊柱动物","脊柱动物"],["扁形动物","线形动物","环节动物","软体动物","节肢动物"],["猪肉绦虫","吸血虫"]],multiIndex:[0,0,0],multiSelectRes:"无脊柱动物，扁形动物，猪肉绦虫",date:"2016-09-01",date_month:"2016-09",time:"12:01",region:["广东省","广州市","海珠区"],customItem:"全部"},bindPickerChange:function(t){this.setData({index:t.detail.value})},bindPickerChangeForRangeKey:function(t){this.setData({rangeKeyIndex:t.detail.value})},bindMultiPickerChange:function(t){this.setData({multiIndex:t.detail.value,multiSelectRes:this.data.multiArray.map(((t,e)=>t[this.data.multiIndex[e]])).join("，")})},bindMultiPickerColumnChange:function(t){var e={multiArray:this.data.multiArray,multiIndex:this.data.multiIndex};e.multiIndex[t.detail.column]=t.detail.value;const a={0:["扁形动物","线形动物","环节动物","软体动物","节肢动物"],1:["鱼","两栖动物","爬行动物"]},i={"00":["猪肉绦虫","吸血虫"],"01":["蛔虫"],"02":["蚂蚁","蚂蟥"],"03":["河蚌","蜗牛","蛞蝓"],"04":["昆虫","甲壳动物","蛛形动物","多足动物"],10:["鲫鱼","带鱼"],11:["青蛙","娃娃鱼"],12:["蜥蜴","龟","壁虎"]};switch(t.detail.column){case 0:e.multiArray[1]=a[t.detail.value],e.multiArray[2]=i[`${t.detail.value}0`],e.multiIndex[1]=0,e.multiIndex[2]=0;break;case 1:e.multiArray[2]=i[`${e.multiIndex[0]}${t.detail.value}`],e.multiIndex[2]=0}this.setData(e)},bindDateChange:function(t){this.setData({date:t.detail.value})},bindDateMonthChange:function(t){this.setData({date_month:t.detail.value})},bindTimeChange:function(t){this.setData({time:t.detail.value})},bindRegionChange:function(t){this.setData({region:t.detail.value})},submit:function(t){},reset:function(){},bindcancel:function(t){}});
});
define("macle_demo_EN/page/component/pages/progress/progress.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{percent:80},activeend:function(){ma.showToast({title:"Animation Complete",duration:3e3,icon:"success",success(t){},fail(t){}})},bindtap(){this.setData({percent:90})}});
});
define("macle_demo_EN/page/component/pages/radio/radio.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{items:[{value:"USA",name:"USA"},{value:"CHN",name:"CHN",checked:"true"},{value:"BRA",name:"BRA"},{value:"JPN",name:"JPN"},{value:"ENG",name:"ENG"},{value:"FRA",name:"FRA"}]},radioChange:function(e){for(var a=this.data.items,t=0,l=a.length;t<l;++t)a[t].checked=a[t].value==e.detail.value;this.setData({items:a})}});
});
define("macle_demo_EN/page/component/pages/rich-text/rich-text.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{html:'\n    <div class="div_class1" style="line-height: 60px; color: #0043ffc2;font-weight: 600;">Hello,this&nbspis Macle!\n      <img src="../../../../image/icon_foot.png"\n       style="width: 100%;">\n    </div>',nodes:[{name:"div",attrs:{class:"div_class2",style:"line-height: 60px; color: #0043ffc2;font-weight: 600;"},children:[{type:"text",text:"Hello,this&nbsp;is Macle"},{type:"node",name:"img",attrs:{src:"../../../../image/icon_foot.png",style:"width: 100%;"}}]}],html2:'\n      <table class="table1" style="width: 100%;">\n        <colgroup>\n          <col span="2" style="background-color: #0043ffc2">\n          <col style="background-color:#00d5ffc2">\n        </colgroup>\n        <tr style="text-align: center">\n          <th>NAME</th>\n          <th>AGE</th>\n          <th>SEX</th>\n        </tr>\n        <tr style="text-align: center">\n          <td>XIAOMING</td>\n          <td>18</td>\n          <td>MALE</td>\n        </tr>\n        <tr style="text-align: center">\n          <td>XIAOHONG</td>\n          <td>21</td>\n          <td>FEMALE</td>\n      </tr>\n    </table>\n    ',nodes2:[{name:"table",attrs:{class:"table2",style:"width: 100%;"},children:[{type:"node",name:"colgroup",children:[{type:"node",name:"col",attrs:{span:"2",style:"background-color: #0043ffc2"}},{type:"node",name:"col",attrs:{style:"background-color:#00d5ffc2"}}]},{type:"node",name:"tr",attrs:{style:"text-align: center"},children:[{type:"node",name:"th",children:[{type:"text",text:"NAME"}]},{type:"node",name:"th",children:[{type:"text",text:"AGE"}]},{type:"node",name:"th",children:[{type:"text",text:"SEX"}]}]},{type:"node",name:"tr",attrs:{style:"text-align: center"},children:[{type:"node",name:"td",children:[{type:"text",text:"XIAOMING"}]},{type:"node",name:"td",children:[{type:"text",text:"18"}]},{type:"node",name:"td",children:[{type:"text",text:"MALE"}]}]},{type:"node",name:"tr",attrs:{style:"text-align: center"},children:[{type:"node",name:"td",children:[{type:"text",text:"XIAOHONG"}]},{type:"node",name:"td",children:[{type:"text",text:"21"}]},{type:"node",name:"td",children:[{type:"text",text:"FEMALE"}]}]}]}]}});
});
define("macle_demo_EN/page/component/pages/scroll-view/scroll-view.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{order:[{index:"demo1",class:"demo-text-1",name:"A"},{index:"demo2",class:"demo-text-2",name:"B"},{index:"demo3",class:"demo-text-3",name:"C"}],toView:"v-demo2",scrollTop:50,scrollLeft:150,bindscrolltoupperCount:0,bindscrolltolowerCount:0,bindscrollCount:0,binddragstartCount:0,binddraggingCount:0,binddragendCount:0,scrollHeight:0,scrollItemHeight:150},onLoad(){this.setData({scrollHeight:this.data.order.length*this.data.scrollItemHeight})},upper:function(t){this.setData({bindscrolltoupperCount:this.data.bindscrolltoupperCount+1})},lower:function(t){this.setData({bindscrolltolowerCount:this.data.bindscrolltolowerCount+1})},scroll:function(t){this.setData({bindscrollCount:this.data.bindscrollCount+1})},scrollToTop:function(t){let o=Number(t.target.dataset.scrollTop);t.target.dataset.reverse&&(o=Number(this.data.scrollHeight)-o-this.data.scrollItemHeight),this.setData({scrollTop:o})},scrollToLeft:function(t){this.setData({scrollLeft:0})},scrollToLeft2:function(t){this.setData({scrollLeft:100})},binddragstart:function(t){this.setData({binddragstartCount:this.data.binddragstartCount+1})},binddragging:function(t){this.setData({binddraggingCount:this.data.binddraggingCount+1})},binddragend:function(t){this.setData({binddragendCount:this.data.binddragendCount+1})},moveTo:function(t){this.setData({toView:`v-${t.target.dataset.index}`})}});
});
define("macle_demo_EN/page/component/pages/slider/slider.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
for(var v,D={},g=1;g<=7;++g)D["slider"+(v=g)+"change"]=function(a){this.setData({isChange:a.detail.value})},D["slider"+v+"changing"]=function(a){this.setData({isChanging:a.detail.value})};Page(D);
});
define("macle_demo_EN/page/component/pages/swiper/swiper.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{background:["demo-text-1","demo-text-2","demo-text-3"],indicatorDots:!0,indicatorActiveColor:"#000000",indicatorColor:"rgba(0, 0, 0, .3)",vertical:!1,autoplay:!0,interval:2e3,duration:500,easingFunction:"default",circular:!0},changeIndicatorDots:function(t){this.setData({indicatorDots:!this.data.indicatorDots})},changeAutoplay:function(t){this.setData({autoplay:!this.data.autoplay})},intervalChange:function(t){this.setData({interval:t.detail.value})},durationChange:function(t){this.setData({duration:t.detail.value})}});
});
define("macle_demo_EN/page/component/pages/switch/switch.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({switch1Change:function(i){this.setData({isClicked:i.detail.value})},switch2Change:function(i){}});
});
define("macle_demo_EN/page/component/pages/text/text.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
var x=["Happy new years","National Day Happy","It is a nice day","......"];Page({data:{text:"It is a nice day.",canAdd:!0,canRemove:!1,decode:!1,userSelect:!1},extraLine:["It is a nice day too."],add:function(t){var e=this;this.extraLine.push(x[this.extraLine.length]),this.setData({text:this.extraLine.join("\n"),canAdd:this.extraLine.length<x.length,canRemove:this.extraLine.length>0},(function(t){})),setTimeout((function(){e.setData({scrollTop:99999})}),0)},remove:function(t){var e=this;this.extraLine.length>0&&(this.extraLine.pop(),this.setData({text:this.extraLine.join("\n"),canAdd:this.extraLine.length<x.length,canRemove:this.extraLine.length>0})),setTimeout((function(){e.setData({scrollTop:99999})}),0)},setDecode:function(t){this.setData({decode:!0})},setUserSelect:function(t){this.setData({userSelect:!0})}});
});
define("macle_demo_EN/page/component/pages/textarea/textarea.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{focus:!1},bindblur:function(n){},bindfocus:function(n){},bindlinechange:function(n){},bindinput:function(n){},bindconfirm:function(n){}});
});
define("macle_demo_EN/page/component/pages/video/video.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({onReady:function(t){this.videoContext=ma.createVideoContext("myVideo")},data:{src:"http://10.29.183.231/pkg/snsdyvideodownload.mp4",autoplay:!1,position:"",inputValue:"",controls:!0,hidden:!1,objectFit:"contain",muted:!1,loop:!1,poster:"http://10.29.183.231/pkg/background.png",showFullscreenBtn:!0},bindInput:function(t){this.setData({position:t.detail.value})},play:function(){this.videoContext.play()},pause:function(){this.videoContext.pause()},seek:function(){this.videoContext.seek(this.data.position)},binderror:function(t){},bindplay:function(){},bindpause:function(){},bindended:function(){},bindtimeupdate:function(t){}});
});
define("macle_demo_EN/page/component/pages/view/view.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{hover:!0,nodes:[{name:"div",attrs:{class:"div_class",style:"line-height: 60px; color: red;"},children:[{type:"text",text:"Hello&nbsp;World!"}]}]},tap(){this.testPromise()},testPromise:function(){new Promise(((n,o)=>{setTimeout((()=>{n(6666)}),2e3)})).then((n=>{}))},onLoad:function(n){},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onShareAppMessage:function(){},onPageScroll:function(){}});
});
define("macle_demo_EN/page/component/pages/web-view/web-view.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({onLoad:function(n){},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onShareAppMessage:function(){},onPageScroll:function(){}});
});
define("macle_demo_EN/page/framework/pages/communication/communication.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{detail:{test:"",test1:"tesdt"},count:0,propTest:"properties"},onMyEvent:function(t){t.detail,this.setData({detail:"自定义事件未使用时不执行，页面不报错"})},showSlot:function(t){this.setData({detail:{test:"slot场景的绑定事件生效"}})},clickButton:function(t){this.setData({detail:{test:"ppppp"},propTest:"788990"});this.selectComponent("#test1").testSelectComponent("test12345")},clickSelf:function(){this.setData({detail:"a223333"})}});
});
define("macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
const t=getI18nInstance();let N=null;Page({data:{value:"sample2",value2:{obj:{nested:{value:"Catch you!"}}},array:[],index:0},onLoad:function(){N=t.onLocaleChange((e=>{ma.setNavigationBarTitle({title:t.t("window.title")})})),this.updatePicker()},onReady:function(){ma.setNavigationBarTitle({title:t.t("window.title")})},toggleLocale:function(){t.setLocale("zh-CN"===t.getLocale()?"en-US":"zh-CN"),this.updatePicker()},nativate(){ma.navigateTo({url:"/page/framework/pages/macle-sub-i18n/macle-sub-i18n"})},cancel:()=>{N.off()},bindPickerChange(e){this.setData({index:e.detail.value})},updatePicker(){"zh-CN"===t.getLocale()?this.setData({array:[t.t("selectTestNest",{mood:"good",how:"好"}),t.t("selectTestNest",{mood:"sad",how:"不好"}),t.t("selectTestNest")]}):this.setData({array:[t.t("selectTestNest",{mood:"good",how:"Awesome"}),t.t("selectTestNest",{mood:"sad",how:"Unhappy"}),t.t("selectTestNest")]})}});
});
define("macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
I18nPage({data:{logs:[]},onLoad:function(){}});
});
define("macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
var T=0,X=0,Y=0,$=0;Page({data:{style:"top:352px;left:100px"},liveTouchmove(e){var t=0,c=0,a=0,o=0;"touchstart"===e.type?(T=e.currentTarget.offsetLeft,X=e.currentTarget.offsetTop,Y=e.changedTouches[0].clientX,$=e.changedTouches[0].clientY,t=T,c=X):(a=e.changedTouches[0].clientX-Y,o=e.changedTouches[0].clientY-$,t=T+a,c=X+o),t+="px",this.setData({style:`top:${c}px; left:${t}`})},callMe(e){}});
});
define("macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
var u={data:{timestamp:(new Date).getTime()},getTime:function(){this.setData({timestamp:(new Date).getTime()})}};Page(u);
});
define("macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
const B={color:"#7A7E83",selectedColor:"#3cc51f",backgroundColor:"#ffffff",borderStyle:"white"};Component({data:{hasSetTabBarBadge:!1,hasShownTabBarRedDot:!1,hasCustomedStyle:!1,hasCustomedItem:!1,hasHiddenTabBar:!1},detached(){this.hideTabBarRedDot(),this.showTabBar(),this.removeCustomStyle(),this.removeCustomItem()},methods:{showTabBarRedDot(){this.data.hasShownTabBarRedDot?this.hideTabBarRedDot():(this.setData({hasShownTabBarRedDot:!0}),ma.showTabBarRedDot({index:2,success(e){},fail(e){},complete(){}}))},hideTabBarRedDot(){this.setData({hasShownTabBarRedDot:!1}),ma.hideTabBarRedDot({index:2,success(e){},fail(e){},complete(){}})},showTabBar(){this.setData({hasHiddenTabBar:!1}),ma.showTabBar({animation:!0,success(e){},fail(e){},complete(){}})},hideTabBar(){this.data.hasHiddenTabBar?this.showTabBar():(this.setData({hasHiddenTabBar:!0}),ma.hideTabBar({animation:!0,success(e){},fail(e){},complete(){}}))},customStyle(){this.data.hasCustomedStyle?this.removeCustomStyle():(this.setData({hasCustomedStyle:!0}),ma.setTabBarStyle({color:"#FFF",selectedColor:"#f00",backgroundColor:"#000000",borderStyle:"black",success(e){},fail(e){},complete(){}}))},removeCustomStyle(){this.setData({hasCustomedStyle:!1}),ma.setTabBarStyle(B)},customItem(){this.data.hasCustomedItem?this.removeCustomItem():(this.setData({hasCustomedItem:!0}),ma.setTabBarItem({index:2,text:"Testing",iconPath:"/image/icon_component.png",selectedIconPath:"/image/icon_component_HL.png",success(e){},fail(e){},conplete(){}}))},removeCustomItem(){this.setData({hasCustomedItem:!1}),ma.setTabBarItem({index:2,text:"interface",iconPath:"/image/icon_API.png",selectedIconPath:"/image/icon_API_HL.png"})}}});
});
define("macle_demo_EN/page/tabbar/api/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
const t=getI18nInstance();Page({data:{list:[{id:"base",name:"Foundation ",open:!1,pages:[{zh:"Application-level events",url:"application-event/application-event",id:"applicationEvent"},{zh:"Obtaining System Information",url:"get-system-info/get-system-info",id:"getSystemInfo"},{zh:"Obtaining System Information Synchronously",url:"get-system-info-sync/get-system-info-sync",id:"getSystemInfoSync"},{zh:"canIUse",url:"canIUse/canIUse",id:"canIUse"}]},{id:"route",name:"Route",open:!1,pages:[{zh:"Interface Switch",url:"navigator/navigator",id:"navigator"}]},{id:"page",name:"UI",open:!1,pages:[{zh:"pull to refresh",url:"pull-down-refresh/pull-down-refresh",id:"pullDownRefresh"},{zh:"Display modal pop-up window",url:"modal/modal",id:"modal"},{zh:"Display message prompt box",url:"toast/toast",id:"toast"},{zh:"The Loading dialog box is displayed",url:"loading/loading",id:"loading"},{zh:"Setting the interface title",url:"set-navigation-bar-title/set-navigation-bar-title",id:"setNavigationBarTitle"},{zh:"Set the color of the navigation bar",url:"set-navigation-bar-color/set-navigation-bar-color",id:"setNavigationBarColor"},{zh:"Background settings",url:"set-background/set-background",id:"setBackground"},{zh:"Set tabBar",url:"set-tab-bar/set-tab-bar",id:"setTabBar"},{zh:"Show Action Menu",url:"show-action-sheet/show-action-sheet",id:"showActionSheet"},{zh:"Obtains the layout position information of a menu button",url:"getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect",id:"getMenuButtonBoundingClientRect"}]},{id:"device",name:"device",open:!1,pages:[{zh:"network",url:"network/network",id:"network"},{zh:"gyroscope",url:"gyroscope/gyroscope",id:"gyroscope"},{zh:"scanCode",url:"scanCode/scanCode",id:"scanCode"},{zh:"vibrate",url:"vibrate/vibrate",id:"vibrate"},{zh:"chooseContact",url:"chooseContact/chooseContact",id:"chooseContact"},{zh:"Obtain the network type",url:"get-network-type/get-network-type",id:"getNetworkType"},{zh:"performance",url:"memory-warning/memory-warning",id:"memoryWarning"},{zh:"Calling",url:"make-phone-call/make-phone-call",id:"makePhoneCall"},{zh:"Obtaining the Battery Level of a Mobile Phone",url:"get-battery-info/get-battery-info",id:"getBatteryInfo"},{zh:"screen brightness",url:"screen-brightness/screen-brightness",id:"screenBrightness"},{zh:"Hide Keyboard",url:"hideKeyboard/hideKeyboard",id:"hideKeyboard"}]},{id:"network",name:"network",open:!1,pages:[{zh:"network request",url:"request/request",id:"request"},{zh:"WebSocket",url:"websocket/websocket",id:"websocket"},{zh:"Downloadfiles",url:"downloadFile/downloadFile",id:"downloadFile"},{zh:"uploadFile",url:"uploadFile/uploadFile",id:"uploadFile"}]},{id:"media",name:"media",open:!1,pages:[{zh:"mediaImage",url:"mediaImage/mediaImage",id:"mediaImage"},{zh:"Obtain Image Information",url:"get-image-info/get-image-info",id:"getImageInfo"},{zh:"Compressed Picture",url:"compressImage/compressImage",id:"compressImage"},{zh:"file",url:"file/file",id:"file"},{zh:"Document Open",url:"open-document/open-document",id:"openDocument"}]},{id:"location",name:"location",open:!1,pages:[{zh:"Get Geographic Location",url:"get-location/get-location",id:"getLocation"}]},{id:"cache",name:"cache",pages:[{zh:"local storage",url:"storage/storage",id:"storage"},{zh:"Synchroniz Local Storage",url:"storage-sync/storage-sync",id:"storagesync"}]}],isSetTabBarPage:!1},onShow:function(){this.leaveSetTabBarPage(),ma.setTabBarItem({index:0,text:t.t("component")}),ma.setTabBarItem({index:1,text:t.t("api")}),ma.setTabBarItem({index:2,text:t.t("framework")})},onHide(){this.leaveSetTabBarPage()},kindToggle:function(e){for(var t=e.currentTarget.id,a=this.data.list,o=0,n=a.length;o<n;++o)if(a[o].id==t){if(a[o].url)return void ma.navigateTo({url:"pages/"+a[o].url});a[o].open=!a[o].open}else a[o].open=!1;this.setData({list:a})},enterSetTabBarPage(){this.setData({isSetTabBarPage:!0})},leaveSetTabBarPage(){this.setData({isSetTabBarPage:!1})}});
});
define("macle_demo_EN/page/tabbar/component/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
const t=getI18nInstance();Page({data:{list:[{id:"view",name:"Figure Container",open:!1,pages:[{name:"view",id:"viewPage"},{name:"scroll-view",id:"scrollViewPage"},{name:"cover-view",id:"coverViewPage"},{name:"cover-image",id:"coverImagePage"},{name:"swiper",id:"swiperPage"}]},{id:"content",name:"Basic Content",open:!1,pages:[{name:"text",id:"textPage"},{name:"icon",id:"iconPage"},{name:"rich-text",id:"richTextPage"},{name:"progress",id:"progressPage"}]},{id:"form",name:"Form Component",open:!1,pages:[{name:"button",id:"buttonPage"},{name:"checkbox",id:"Page"},{name:"form",id:"formPage"},{name:"input",id:"inputPage"},{name:"label",id:"labelPage"},{name:"picker",id:"pickerPage"},{name:"picker-view",id:"pickerViewPage"},{name:"radio",id:"radioPage"},{name:"slider",id:"sliderPage"},{name:"switch",id:"switchPage"},{name:"textarea",id:"textareaPage"}]},{id:"nav",name:"navigation",open:!1,pages:[{name:"navigator",id:"navigatorPage"}]},{id:"media",name:"Media Components",open:!1,pages:[{name:"image",id:"imagePage"},{name:"audio",id:"audioPage"},{name:"video",id:"videoPage"},{name:"camera",id:"cameraPage"}]},{id:"open-capability",name:"open capability",open:!1,pages:[{name:"web-view",id:"webViewPage"}]}]},onShow:function(){ma.setTabBarItem({index:0,text:t.t("component")}),ma.setTabBarItem({index:1,text:t.t("api")}),ma.setTabBarItem({index:2,text:t.t("framework")})},kindToggle:function(e){for(var a=e.currentTarget.id,i=this.data.list,n=0,t=i.length;n<t;++n)i[n].id==a?i[n].open=!i[n].open:i[n].open=!1;this.setData({list:i})}});
});
define("macle_demo_EN/page/tabbar/framework/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
const t=getI18nInstance();Page({data:{list:[{id:"sjs",name:"sjs",open:!1,pages:["sjs-filter","sjs-drag"]},{id:"custom",name:"Defining Components",open:!1,pages:["communication"]},{id:"language",name:"internationalized language",open:!1,pages:["macle-i18n"]}]},onShow:function(){ma.setTabBarItem({index:0,text:t.t("component")}),ma.setTabBarItem({index:1,text:t.t("api")}),ma.setTabBarItem({index:2,text:t.t("framework")})},kindToggle:function(e){for(var t=e.currentTarget.id,n=this.data.list,a=0,i=n.length;a<i;++a)n[a].id==t?n[a].open=!n[a].open:n[a].open=!1;this.setData({list:n})}});
});
define("macle_demo_EN/page/util/util.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
module.exports={formatTime:function(t){if("number"!=typeof t||t<0)return t;var r=parseInt(t/3600);return t%=3600,[r,parseInt(t/60),t%=60].map((function(t){return(t=t.toString())[1]?t:"0"+t})).join(":")},formatLocation:function(t,r){return"string"==typeof t&&"string"==typeof r&&(t=parseFloat(t),r=parseFloat(r)),t=t.toFixed(2),r=r.toFixed(2),{longitude:t.toString().split("."),latitude:r.toString().split(".")}}};
});
define("page/tabbar/api/components/set-tab-bar/set-tab-bar.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
const B={color:"#7A7E83",selectedColor:"#3cc51f",backgroundColor:"#ffffff",borderStyle:"white"};Component({data:{hasSetTabBarBadge:!1,hasShownTabBarRedDot:!1,hasCustomedStyle:!1,hasCustomedItem:!1,hasHiddenTabBar:!1},detached(){this.hideTabBarRedDot(),this.showTabBar(),this.removeCustomStyle(),this.removeCustomItem()},methods:{showTabBarRedDot(){this.data.hasShownTabBarRedDot?this.hideTabBarRedDot():(this.setData({hasShownTabBarRedDot:!0}),ma.showTabBarRedDot({index:2,success(e){},fail(e){},complete(){}}))},hideTabBarRedDot(){this.setData({hasShownTabBarRedDot:!1}),ma.hideTabBarRedDot({index:2,success(e){},fail(e){},complete(){}})},showTabBar(){this.setData({hasHiddenTabBar:!1}),ma.showTabBar({animation:!0,success(e){},fail(e){},complete(){}})},hideTabBar(){this.data.hasHiddenTabBar?this.showTabBar():(this.setData({hasHiddenTabBar:!0}),ma.hideTabBar({animation:!0,success(e){},fail(e){},complete(){}}))},customStyle(){this.data.hasCustomedStyle?this.removeCustomStyle():(this.setData({hasCustomedStyle:!0}),ma.setTabBarStyle({color:"#FFF",selectedColor:"#f00",backgroundColor:"#000000",borderStyle:"black",success(e){},fail(e){},complete(){}}))},removeCustomStyle(){this.setData({hasCustomedStyle:!1}),ma.setTabBarStyle(B)},customItem(){this.data.hasCustomedItem?this.removeCustomItem():(this.setData({hasCustomedItem:!0}),ma.setTabBarItem({index:2,text:"Testing",iconPath:"/image/icon_component.png",selectedIconPath:"/image/icon_component_HL.png",success(e){},fail(e){},conplete(){}}))},removeCustomItem(){this.setData({hasCustomedItem:!1}),ma.setTabBarItem({index:2,text:"interface",iconPath:"/image/icon_API.png",selectedIconPath:"/image/icon_API_HL.png"})}}});
});
define("page/tabbar/api/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
const t=getI18nInstance();Page({data:{list:[{id:"base",name:"Foundation ",open:!1,pages:[{zh:"Application-level events",url:"application-event/application-event",id:"applicationEvent"},{zh:"Obtaining System Information",url:"get-system-info/get-system-info",id:"getSystemInfo"},{zh:"Obtaining System Information Synchronously",url:"get-system-info-sync/get-system-info-sync",id:"getSystemInfoSync"},{zh:"canIUse",url:"canIUse/canIUse",id:"canIUse"}]},{id:"route",name:"Route",open:!1,pages:[{zh:"Interface Switch",url:"navigator/navigator",id:"navigator"}]},{id:"page",name:"UI",open:!1,pages:[{zh:"pull to refresh",url:"pull-down-refresh/pull-down-refresh",id:"pullDownRefresh"},{zh:"Display modal pop-up window",url:"modal/modal",id:"modal"},{zh:"Display message prompt box",url:"toast/toast",id:"toast"},{zh:"The Loading dialog box is displayed",url:"loading/loading",id:"loading"},{zh:"Setting the interface title",url:"set-navigation-bar-title/set-navigation-bar-title",id:"setNavigationBarTitle"},{zh:"Set the color of the navigation bar",url:"set-navigation-bar-color/set-navigation-bar-color",id:"setNavigationBarColor"},{zh:"Background settings",url:"set-background/set-background",id:"setBackground"},{zh:"Set tabBar",url:"set-tab-bar/set-tab-bar",id:"setTabBar"},{zh:"Show Action Menu",url:"show-action-sheet/show-action-sheet",id:"showActionSheet"},{zh:"Obtains the layout position information of a menu button",url:"getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect",id:"getMenuButtonBoundingClientRect"}]},{id:"device",name:"device",open:!1,pages:[{zh:"network",url:"network/network",id:"network"},{zh:"gyroscope",url:"gyroscope/gyroscope",id:"gyroscope"},{zh:"scanCode",url:"scanCode/scanCode",id:"scanCode"},{zh:"vibrate",url:"vibrate/vibrate",id:"vibrate"},{zh:"chooseContact",url:"chooseContact/chooseContact",id:"chooseContact"},{zh:"Obtain the network type",url:"get-network-type/get-network-type",id:"getNetworkType"},{zh:"performance",url:"memory-warning/memory-warning",id:"memoryWarning"},{zh:"Calling",url:"make-phone-call/make-phone-call",id:"makePhoneCall"},{zh:"Obtaining the Battery Level of a Mobile Phone",url:"get-battery-info/get-battery-info",id:"getBatteryInfo"},{zh:"screen brightness",url:"screen-brightness/screen-brightness",id:"screenBrightness"},{zh:"Hide Keyboard",url:"hideKeyboard/hideKeyboard",id:"hideKeyboard"}]},{id:"network",name:"network",open:!1,pages:[{zh:"network request",url:"request/request",id:"request"},{zh:"WebSocket",url:"websocket/websocket",id:"websocket"},{zh:"Downloadfiles",url:"downloadFile/downloadFile",id:"downloadFile"},{zh:"uploadFile",url:"uploadFile/uploadFile",id:"uploadFile"}]},{id:"media",name:"media",open:!1,pages:[{zh:"mediaImage",url:"mediaImage/mediaImage",id:"mediaImage"},{zh:"Obtain Image Information",url:"get-image-info/get-image-info",id:"getImageInfo"},{zh:"Compressed Picture",url:"compressImage/compressImage",id:"compressImage"},{zh:"file",url:"file/file",id:"file"},{zh:"Document Open",url:"open-document/open-document",id:"openDocument"}]},{id:"location",name:"location",open:!1,pages:[{zh:"Get Geographic Location",url:"get-location/get-location",id:"getLocation"}]},{id:"cache",name:"cache",pages:[{zh:"local storage",url:"storage/storage",id:"storage"},{zh:"Synchroniz Local Storage",url:"storage-sync/storage-sync",id:"storagesync"}]}],isSetTabBarPage:!1},onShow:function(){this.leaveSetTabBarPage(),ma.setTabBarItem({index:0,text:t.t("component")}),ma.setTabBarItem({index:1,text:t.t("api")}),ma.setTabBarItem({index:2,text:t.t("framework")})},onHide(){this.leaveSetTabBarPage()},kindToggle:function(e){for(var t=e.currentTarget.id,a=this.data.list,o=0,n=a.length;o<n;++o)if(a[o].id==t){if(a[o].url)return void ma.navigateTo({url:"pages/"+a[o].url});a[o].open=!a[o].open}else a[o].open=!1;this.setData({list:a})},enterSetTabBarPage(){this.setData({isSetTabBarPage:!0})},leaveSetTabBarPage(){this.setData({isSetTabBarPage:!1})}});
});
define("page/tabbar/component/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
const t=getI18nInstance();Page({data:{list:[{id:"view",name:"Figure Container",open:!1,pages:[{name:"view",id:"viewPage"},{name:"scroll-view",id:"scrollViewPage"},{name:"cover-view",id:"coverViewPage"},{name:"cover-image",id:"coverImagePage"},{name:"swiper",id:"swiperPage"}]},{id:"content",name:"Basic Content",open:!1,pages:[{name:"text",id:"textPage"},{name:"icon",id:"iconPage"},{name:"rich-text",id:"richTextPage"},{name:"progress",id:"progressPage"}]},{id:"form",name:"Form Component",open:!1,pages:[{name:"button",id:"buttonPage"},{name:"checkbox",id:"Page"},{name:"form",id:"formPage"},{name:"input",id:"inputPage"},{name:"label",id:"labelPage"},{name:"picker",id:"pickerPage"},{name:"picker-view",id:"pickerViewPage"},{name:"radio",id:"radioPage"},{name:"slider",id:"sliderPage"},{name:"switch",id:"switchPage"},{name:"textarea",id:"textareaPage"}]},{id:"nav",name:"navigation",open:!1,pages:[{name:"navigator",id:"navigatorPage"}]},{id:"media",name:"Media Components",open:!1,pages:[{name:"image",id:"imagePage"},{name:"audio",id:"audioPage"},{name:"video",id:"videoPage"},{name:"camera",id:"cameraPage"}]},{id:"open-capability",name:"open capability",open:!1,pages:[{name:"web-view",id:"webViewPage"}]}]},onShow:function(){ma.setTabBarItem({index:0,text:t.t("component")}),ma.setTabBarItem({index:1,text:t.t("api")}),ma.setTabBarItem({index:2,text:t.t("framework")})},kindToggle:function(e){for(var a=e.currentTarget.id,i=this.data.list,n=0,t=i.length;n<t;++n)i[n].id==a?i[n].open=!i[n].open:i[n].open=!1;this.setData({list:i})}});
});
define("page/tabbar/framework/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
const t=getI18nInstance();Page({data:{list:[{id:"sjs",name:"sjs",open:!1,pages:["sjs-filter","sjs-drag"]},{id:"custom",name:"Defining Components",open:!1,pages:["communication"]},{id:"language",name:"internationalized language",open:!1,pages:["macle-i18n"]}]},onShow:function(){ma.setTabBarItem({index:0,text:t.t("componentss")}),ma.setTabBarItem({index:1,text:t.t("api")}),ma.setTabBarItem({index:2,text:t.t("framework")})},kindToggle:function(e){for(var t=e.currentTarget.id,n=this.data.list,a=0,i=n.length;a<i;++a)n[a].id==t?n[a].open=!n[a].open:n[a].open=!1;this.setData({list:n})}});
});
define("page/tabbar/react/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
getI18nInstance();Page({data:{mapApi:{},ObjRef:{lat:1,lng:9,zoom:5}},onLaunch:function(){ObjRefNew={lat:51.508742,lng:-.12085,zoom:5},this.setData({ObjRef:ObjRefNew})},onReady:function(){},initMap:function(){},onShow:function(){},onHide:function(){},kindToggle:function(n){for(var t=n.currentTarget.id,e=this.data.list,o=0,a=e.length;o<a;++o)e[o].id==t?e[o].open=!e[o].open:e[o].open=!1;this.setData({list:e})}});
});
define("page/util/util.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
module.exports={formatTime:function(t){if("number"!=typeof t||t<0)return t;var r=parseInt(t/3600);return t%=3600,[r,parseInt(t/60),t%=60].map((function(t){return(t=t.toString())[1]?t:"0"+t})).join(":")},formatLocation:function(t,r){return"string"==typeof t&&"string"==typeof r&&(t=parseFloat(t),r=parseFloat(r)),t=t.toFixed(2),r=r.toFixed(2),{longitude:t.toString().split("."),latitude:r.toString().split(".")}}};
});
define("public/apiLoaders.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
import{Loader as w}from"@googlemaps/js-api-loader";module.exports.apiLoader=function(){return new w({apiKey:"",version:"weekly"})};
});
define("public/googleMap.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
module.exports.googleMap=function(){window.google=window.google||{},google.maps=google.maps||{},function(){var t=google.maps.modules={};google.maps.__gjsload__=function(e,n){t[e]=n},google.maps.Load=function(t){delete google.maps.Load,t([.009999999776482582,[null,[["https://khms0.googleapis.com/kh?v=939&hl=en-US&","https://khms1.googleapis.com/kh?v=939&hl=en-US&"],null,null,null,1,"939",["https://khms0.google.com/kh?v=939&hl=en-US&","https://khms1.google.com/kh?v=939&hl=en-US&"]],null,null,null,null,[["https://cbks0.googleapis.com/cbk?","https://cbks1.googleapis.com/cbk?"]],[["https://khms0.googleapis.com/kh?v=150&hl=en-US&","https://khms1.googleapis.com/kh?v=150&hl=en-US&"],null,null,null,null,"150",["https://khms0.google.com/kh?v=150&hl=en-US&","https://khms1.google.com/kh?v=150&hl=en-US&"]],null,null,null,null,null,null,null,[["https://streetviewpixels-pa.googleapis.com/v1/thumbnail?hl=en-US&","https://streetviewpixels-pa.googleapis.com/v1/thumbnail?hl=en-US&"]]],["en-US","US",null,0,null,null,"https://maps.gstatic.com/mapfiles/",null,"https://maps.googleapis.com","https://maps.googleapis.com",null,"https://maps.google.com",null,"https://maps.gstatic.com/maps-api-v3/api/images/","https://www.google.com/maps",null,"https://www.google.com",1,"https://maps.googleapis.com/maps_api_js_slo/log?hasfast=true",0,1],["https://maps.googleapis.com/maps-api-v3/api/js/51/8","3.51.8"],[95652144],null,null,null,null,null,null,"initMap",null,null,1,"https://khms.googleapis.com/mz?v=939&","","https://earthbuilder.googleapis.com","https://earthbuilder.googleapis.com",null,"https://mts.googleapis.com/maps/vt/icon",[["https://maps.googleapis.com/maps/vt"],["https://maps.googleapis.com/maps/vt"],null,null,null,null,null,null,null,null,null,null,["https://www.google.com/maps/vt"],"/maps/vt",632e6,632,632371263],2,500,[null,null,null,null,"https://www.google.com/maps/preview/log204","","https://static.panoramio.com.storage.googleapis.com/photos/",["https://geo0.ggpht.com/cbk","https://geo1.ggpht.com/cbk","https://geo2.ggpht.com/cbk","https://geo3.ggpht.com/cbk"],"https://maps.googleapis.com/maps/api/js/GeoPhotoService.GetMetadata","https://maps.googleapis.com/maps/api/js/GeoPhotoService.SingleImageSearch",["https://lh3.ggpht.com/","https://lh4.ggpht.com/","https://lh5.ggpht.com/","https://lh6.ggpht.com/"],"https://streetviewpixels-pa.googleapis.com/v1/tile"],null,null,null,null,"/maps/api/js/ApplicationService.GetEntityDetails",0,null,null,null,null,[],["51.8"],1,0,[1],null,null,1,.009999999776482582],e)};var e=(new Date).getTime()}(),function(t){var e,n,o,i,r,a,s,h,u,c,f,l,p,g,d,y,v,m,b,E,w,A,j,L,T,_,C,M,S,O,x,I,P,R,N,D,k,F,U,B,G,z,H,q,V,W,J,Z,Y,X,K,Q,$,tt,et,nt,ot,it,rt,at,st,ht,ut,ct,ft,lt,pt,gt,dt,yt,vt,mt,bt,Et,wt,At,jt,Lt,Tt,_t,Ct,Mt,St,Ot,xt,It,Pt,Rt,Nt,Dt,kt,Ft,Ut,Bt,Gt,zt,Ht,qt,Vt,Wt,Jt,Zt,Yt,Xt,Kt,Qt,$t,te,ee,ne,oe,ie,re,ae,se,he,ue,ce,fe,le,pe,ge,de,ye,ve,me,be,Ee,we,Ae,je,Le,Te,_e,Ce,Me,Se,Oe,xe,Ie,Pe,Re,Ne,De,ke,Fe,Ue,Be,Ge,ze,He,qe,Ve,We,Je,Ze,Ye,Xe,Ke,Qe,$e,tn,en,nn,on,rn,an,sn,hn,un,cn,fn,ln,pn,gn,dn,yn,vn,mn,bn,En,wn,An,jn,Ln,Tn,_n,Cn,Mn,Sn,On,xn,In,Pn,Rn,Nn,Dn,kn,Fn,Un,Bn,Gn,zn,Hn,qn,Vn,Wn,Jn,Zn,Yn,Xn,Kn,Qn,$n,to,eo,no,oo,io,ro,ao,so,ho,uo,co,fo,lo,po,go;t.aa=function(e){return function(){return t.aaa[e].apply(this,arguments)}},e=function(t){var e=0;return function(){return e<t.length?{done:!1,value:t[e++]}:{done:!0}}},n=function(t){t=["object"==typeof globalThis&&globalThis,t,"object"==typeof window&&window,"object"==typeof self&&self,"object"==typeof global&&global];for(var e=0;e<t.length;++e){var n=t[e];if(n&&n.Math==Math)return n}throw Error("Cannot find global object")},t.v=function(t,e){var n=fo[e];return null==n?t[e]:void 0!==(n=t[n])?n:t[e]},o=function(e,n,o){if(n)t:{var i=e.split(".");e=1===i.length;var r,a=i[0];r=!e&&a in t.x?t.x:t.ca;for(a=0;a<i.length-1;a++){var s=i[a];if(!(s in r))break t;r=r[s]}i=i[i.length-1],null!=(n=n(o=co&&"es6"===o?r[i]:null))&&(e?uo(t.x,i,{configurable:!0,writable:!0,value:n}):n!==o&&(void 0===fo[i]&&(e=1e9*Math.random()>>>0,fo[i]=co?t.ca.Symbol(i):"$jscp$"+e+"$"+i),uo(r,fo[i],{configurable:!0,writable:!0,value:n})))}},i=function(e){return(e={next:e})[t.v(t.x.Symbol,"iterator")]=function(){return this},e},t.A=function(n){var o=void 0!==t.x.Symbol&&t.v(t.x.Symbol,"iterator")&&n[t.v(t.x.Symbol,"iterator")];return o?o.call(n):{next:e(n)}},t.la=function(t){for(var e,n=[];!(e=t.next()).done;)n.push(e.value);return n},t.ma=function(e){return e instanceof Array?e:t.la(t.A(e))},r=function(t,e){return Object.prototype.hasOwnProperty.call(t,e)},t.B=function(e,n){if(e.prototype=bo(n.prototype),e.prototype.constructor=e,t.oa)(0,t.oa)(e,n);else for(var o in n)if("prototype"!=o)if(Object.defineProperties){var i=Object.getOwnPropertyDescriptor(n,o);i&&Object.defineProperty(e,o,i)}else e[o]=n[o];e.Ne=n.prototype},a=function(){this.F=!1,this.C=null,this.j=void 0,this.h=1,this.H=this.o=0,this.D=null},s=function(t){if(t.F)throw new TypeError("Generator is already running");t.F=!0},h=function(t,e){t.D={Uw:e,by:!0},t.h=t.o||t.H},t.sa=function(t,e,n){return t.h=n,{value:e}},t.va=function(t,e){t.h=e,t.o=0},t.wa=function(t){t.o=0,t.D=null},t.faa=function(t){this.h=new a,this.j=t},u=function(t,e){s(t.h);var n=t.h.C;return n?c(t,"return"in n?n.return:function(t){return{value:t,done:!0}},e,t.h.return):(t.h.return(e),f(t))},c=function(t,e,n,o){try{var i=e.call(t.h.C,n);if(!(i instanceof Object))throw new TypeError("Iterator result "+i+" is not an object");if(!i.done)return t.h.F=!1,i;var r=i.value}catch(a){return t.h.C=null,h(t.h,a),f(t)}return t.h.C=null,o.call(t.h,r),f(t)},f=function(t){for(;t.h.h;)try{var e=t.j(t.h);if(e)return t.h.F=!1,{value:e.value,done:!1}}catch(n){t.h.j=void 0,h(t.h,n)}if(t.h.F=!1,t.h.D){if(e=t.h.D,t.h.D=null,e.by)throw e.Uw;return{value:e.return,done:!0}}return{value:void 0,done:!0}},t.haa=function(e){this.next=function(t){return s(e.h),e.h.C?t=c(e,e.h.C.next,t,e.h.G):(e.h.G(t),t=f(e)),t},this.throw=function(t){return s(e.h),e.h.C?t=c(e,e.h.C.throw,t,e.h.G):(h(e.h,t),t=f(e)),t},this.return=function(t){return u(e,t)},this[t.v(t.x.Symbol,"iterator")]=function(){return this}},l=function(e){function n(t){return e.next(t)}function o(t){return e.throw(t)}return new t.x.Promise((function(i,r){!function e(a){a.done?i(a.value):t.x.Promise.resolve(a.value).then(n,o).then(e,r)}(e.next())}))},t.Ba=function(e){return l(new t.haa(new t.faa(e)))},t.Ca=function(){for(var t=Number(this),e=[],n=t;n<arguments.length;n++)e[n-t]=arguments[n];return e},p=function(t,e,n){if(null==t)throw new TypeError("The 'this' value for String.prototype."+n+" must not be null or undefined");if(e instanceof RegExp)throw new TypeError("First argument to String.prototype."+n+" must not be a regular expression");return t+""},g=function(e,n){e instanceof String&&(e+="");var o=0,i=!1,r={next:function(){if(!i&&o<e.length){var t=o++;return{value:n(t,e[t]),done:!1}}return i=!0,{done:!0,value:void 0}}};return r[t.v(t.x.Symbol,"iterator")]=function(){return r},r},d=function(e){return e||t.v(Array.prototype,"fill")},t.jaa=function(t){var e=typeof t;return"object"!=e?e:t?Array.isArray(t)?"array":e:"null"},t.Ha=function(e){var n=t.jaa(e);return"array"==n||"object"==n&&"number"==typeof e.length},t.Ia=function(t){var e=typeof t;return"object"==e&&null!=t||"function"==e},t.La=function(t){return Object.prototype.hasOwnProperty.call(t,po)&&t[po]||(t[po]=++go)},y=function(t,e,n){return t.call.apply(t.bind,arguments)},v=function(t,e,n){if(!t)throw Error();if(2<arguments.length){var o=Array.prototype.slice.call(arguments,2);return function(){var n=Array.prototype.slice.call(arguments);return Array.prototype.unshift.apply(n,o),t.apply(e,n)}}return function(){return t.apply(e,arguments)}},t.Ma=function(e,n,o){return Function.prototype.bind&&-1!=Function.prototype.bind.toString().indexOf("native code")?t.Ma=y:t.Ma=v,t.Ma.apply(null,arguments)},t.Na=function(){return Date.now()},t.Oa=function(e,n){e=e.split(".");var o,i=t.C;e[0]in i||void 0===i.execScript||i.execScript("var "+e[0]);for(;e.length&&(o=e.shift());)e.length||void 0===n?i=i[o]&&i[o]!==Object.prototype[o]?i[o]:i[o]={}:i[o]=n},t.Pa=function(t,e){function n(){}n.prototype=e.prototype,t.Ne=e.prototype,t.prototype=new n,t.prototype.constructor=t,t.Wl=function(t,n,o){for(var i=Array(arguments.length-2),r=2;r<arguments.length;r++)i[r-2]=arguments[r];return e.prototype[n].apply(t,i)}},m=function(t){return t},t.Ra=function(e,n){if(Error.captureStackTrace)Error.captureStackTrace(this,t.Ra);else{var o=Error().stack;o&&(this.stack=o)}e&&(this.message=String(e)),void 0!==n&&(this.cause=n)},t.Ta=function(){if(void 0===mo){var e=null,n=t.C.trustedTypes;if(n&&n.createPolicy){try{e=n.createPolicy("google-maps-api#html",{createHTML:m,createScript:m,createScriptURL:m})}catch(o){t.C.console&&t.C.console.error(o.message)}mo=e}else mo=e}return mo},t.Ua=function(t,e){this.h=t===To&&e||"",this.j=Lo},t.Va=function(e){return e instanceof t.Ua&&e.constructor===t.Ua&&e.j===Lo?e.h:"type_error:Const"},t.Wa=function(e){return new t.Ua(To,e)},t.Xa=function(t,e){this.h=e===Mo?t:""},t.Ya=function(e){return e instanceof t.Xa&&e.constructor===t.Xa?e.h:"type_error:TrustedResourceUrl"},t.$a=function(e){var n=t.Ta();return e=n?n.createScriptURL(e):e,new t.Xa(e,Mo)},t.ab=function(t){for(var e in t)return!1;return!0},t.bb=function(t,e){for(var n,o,i=1;i<arguments.length;i++){for(n in o=arguments[i])t[n]=o[n];for(var r=0;r<So.length;r++)n=So[r],Object.prototype.hasOwnProperty.call(o,n)&&(t[n]=o[n])}},t.raa=function(){return null},t.cb=function(){},t.db=function(t){return t},b=function(t){var e,n=!1;return function(){return n||(e=t(),n=!0),e}},t.fb=function(t,e,n){if(n=null==n?0:0>n?Math.max(0,t.length+n):n,"string"==typeof t)return"string"!=typeof e||1!=e.length?-1:t.indexOf(e,n);for(;n<t.length;n++)if(n in t&&t[n]===e)return n;return-1},t.gb=function(t,e,n){for(var o=t.length,i="string"==typeof t?t.split(""):t,r=0;r<o;r++)r in i&&e.call(n,i[r],r,t)},E=function(t,e){for(var n=t.length,o=[],i=0,r="string"==typeof t?t.split(""):t,a=0;a<n;a++)if(a in r){var s=r[a];e.call(void 0,s,a,t)&&(o[i++]=s)}return o},t.taa=function(t,e){for(var n=t.length,o="string"==typeof t?t.split(""):t,i=0;i<n;i++)if(i in o&&e.call(void 0,o[i],i,t))return!0;return!1},t.hb=function(e,n){return 0<=t.fb(e,n)},t.mb=function(e,n){var o;return(o=0<=(n=t.fb(e,n)))&&t.ib(e,n),o},t.ib=function(t,e){Array.prototype.splice.call(t,e,1)},t.nb=function(t,e){return-1!=t.indexOf(e)},t.ob=function(t,e){this.h=e===Co?t:""},t.pb=function(e){return new t.ob(e,Co)},t.sb=function(e,n){this.h=n===t.qb?e:"",this.Qg=!0},t.ub=function(e,n){this.h=n===t.tb?e:"",this.Qg=!0},t.zb=function(){var e=t.C.navigator;return e&&(e=e.userAgent)?e:""},t.Ab=function(e){return t.nb(t.zb(),e)},t.Bb=function(){return t.Ab("Opera")},t.Cb=function(){return t.Ab("Trident")||t.Ab("MSIE")},t.Gb=function(){return t.Ab("Firefox")||t.Ab("FxiOS")},t.Kb=function(){return t.Ab("Safari")&&!(t.Jb()||t.Ab("Coast")||t.Bb()||t.Ab("Edge")||t.Ab("Edg/")||t.Ab("OPR")||t.Gb()||t.Ab("Silk")||t.Ab("Android"))},t.Jb=function(){return(t.Ab("Chrome")||t.Ab("CriOS"))&&!t.Ab("Edge")||t.Ab("Silk")},t.Lb=function(){return t.Ab("Android")&&!(t.Jb()||t.Gb()||t.Bb()||t.Ab("Silk"))},t.Rb=function(t,e){this.h=e===Oo?t:"",this.Qg=!0},t.Sb=function(e){return e instanceof t.Rb&&e.constructor===t.Rb?e.h:"type_error:SafeHtml"},t.Tb=function(e){var n=t.Ta();return e=n?n.createHTML(e):e,new t.Rb(e,Oo)},t.vaa=function(){return Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^t.Na()).toString(36)},t.Wb=function(t){return t.match(Ho)},t.Xb=function(e){t.C.setTimeout((function(){throw e}),0)},t.Yb=function(){return t.Ab("iPhone")&&!t.Ab("iPod")&&!t.Ab("iPad")},t.$b=function(){return t.Ab("Windows")},t.ac=function(){return t.nb(t.zb().toLowerCase(),"webkit")&&!t.Ab("Edge")},w=function(t){return w[" "](t),t},A=function(){var e=t.C.document;return e?e.documentMode:void 0},t.dc=function(e,n){void 0===n&&(n=0),t.yaa(),n=Do[n];for(var o=Array(Math.floor(e.length/3)),i=n[64]||"",r=0,a=0;r<e.length-2;r+=3){var s=e[r],h=e[r+1],u=e[r+2],c=n[s>>2];s=n[(3&s)<<4|h>>4],h=n[(15&h)<<2|u>>6],u=n[63&u],o[a++]=""+c+s+h+u}switch(c=0,u=i,e.length-r){case 2:u=n[(15&(c=e[r+1]))<<2]||i;case 1:e=e[r],o[a]=""+n[e>>2]+n[(3&e)<<4|c>>4]+u+i}return o.join("")},t.yaa=function(){if(!t.ec){t.ec={};for(var e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),n=["+/=","+/","-_=","-_.","-_"],o=0;5>o;o++){var i=e.concat(n[o].split(""));Do[o]=i;for(var r=0;r<i.length;r++){var a=i[r];void 0===t.ec[a]&&(t.ec[a]=r)}}}},t.gc=function(t){throw Error("unexpected value "+t+"!")},j=function(t,e){void 0===t.zm?Object.defineProperties(t,{zm:{value:e,configurable:!0,writable:!0,enumerable:!1}}):t.zm|=e},L=function(t){return t.zm||0},T=function(t,e,n,o){Object.defineProperties(t,{Wo:{value:e,configurable:!0,writable:!0,enumerable:!1},Ps:{value:n,configurable:!0,writable:!0,enumerable:!1},Ns:{value:o,configurable:!0,writable:!0,enumerable:!1},Os:{value:void 0,configurable:!0,writable:!0,enumerable:!1}})},_=function(t){return null!=t.Wo},C=function(t){return t.Wo},M=function(t,e){t.Wo=e},S=function(t){return t.Ns},O=function(t,e){t.Ns=e},x=function(t){return t.Os},I=function(t,e){t.Os=e},P=function(t){return t.Ps},R=function(t,e){return t.Ps=e},t.ic=function(t,e){this.mf=t,this.zj=e},t.jc=function(e){return null==e.zj&&(e.zj=t.dc(e.mf)),e.zj},t.mc=function(e){var n=e.length-1,o=e[n],i=t.lc(o)?o:null;return i||n++,function(t){var o;return t<=n&&(o=e[t-1]),null==o&&i&&(o=i[t]),o}},t.pc=function(){},t.sc=function(){},t.tc=function(){},t.wc=function(t,e){return Uo(t,e),e},t.lc=function(t){return null!=t&&"object"==typeof t&&!Array.isArray(t)&&t.constructor===Object},t.yc=function(e,n,o,i){n=Math.max(n||2147483647,e.length+1);var r=e.length;if(r=r&&e[r-1],t.lc(r))for(var a in n=e.length,r){var s=Number(a);s<n&&(e[s-1]=r[a],delete r[s])}return(0,t.xc)(e,n,i,o),e},t.Ac=function(e){var n=(0,t.zc)(e);return n>e.length?null:e[n-1]},t.D=function(e,n,o){var i=(0,t.zc)(e);if(n<i)e[n-1]=o;else{var r=t.Ac(e);r?r[n]=o:(r={},e[i-1]=(r[n]=o,r))}},t.Bc=function(e,n){var o;return n<(0,t.zc)(e)?e[n-1]:null==(o=t.Ac(e))?void 0:o[n]},t.Cc=function(e,n,o){return null==(e=t.Bc(e,n))?o:e},t.Jc=function(e,n,o,i){var r=e;if(Array.isArray(e))o=Array(e.length),(0,t.Gc)(e)?t.Hc(t.yc(o,(0,t.zc)(e),(0,t.Ic)(e)),e):N(o,e,n),r=o;else if(null!==e&&"object"==typeof e){if(e instanceof Uint8Array||e instanceof t.ic)return e;if(e instanceof t.pc)return e.Fk(o,i);i={},t.Naa(i,e,n,o),r=i}return r},N=function(e,n,o,i){1&(0,t.Kc)(n)&&(0,t.Lc)(e,1);for(var r=0,a=0;a<n.length;++a)if(n.hasOwnProperty(a)){var s=n[a];null!=s&&(r=a+1),e[a]=t.Jc(s,o,i,a+1)}o&&(e.length=r)},t.Naa=function(e,n,o,i){for(var r in n)if(n.hasOwnProperty(r)){var a=void 0;i&&(a=+r),e[r]=t.Jc(n[r],o,i,a)}},t.Hc=function(e,n){if(e!==n){(0,t.Gc)(n),(0,t.Gc)(e),e.length=0;var o=(0,t.Ic)(n);null!=o&&(0,t.Pc)(e,o),o=(0,t.zc)(n),n.length>=o&&Fo(e,o),(o=(0,t.Tc)(n))&&t.wc(e,o.cm()),e.length=n.length,N(e,n,!0,n)}},t.Uc=function(e,n){var o=e.length-1;if(!(0>o)){var i=e[o];if(t.lc(i))for(var r in o--,i){var a=i[r];if(null!=a&&n(a,+r))return}for(;0<=o&&(null==(i=e[o])||!n(i,o+1));o--);}},t.Vc=function(){},t.Wc=function(t){return(t=t.j).h||(t.h=(0,t.j)()),t.h},t.Xc=function(){},t.Zc=function(t,e){this.yf=0|t,this.Fe=0|e},t.ad=function(){return zo||(zo=new t.Zc(0,0)),zo},t.bd=function(e,n){return new t.Zc(e,n)},t.ed=function(e){return 0<e?new t.Zc(e,e/4294967296):0>e?t.dd(-e,-e/4294967296):t.ad()},t.jd=function(e){return 16>e.length?t.ed(Number(e)):t.fd?(e=BigInt(e),new t.Zc(Number(e&BigInt(4294967295)),Number(e>>BigInt(32)))):D(e)},D=function(e){function n(t,n){t=Number(e.slice(t,n)),r*=1e6,4294967296<=(i=1e6*i+t)&&(r+=i/4294967296|0,i%=4294967296)}var o="-"===e[0];o&&(e=e.slice(1));var i=0,r=0;return n(-24,-18),n(-18,-12),n(-12,-6),n(-6),(o?t.dd:t.bd)(i,r)},t.Paa=function(e){if(t.fd)return BigInt(e.Fe>>>0)<<BigInt(32)|BigInt(e.yf>>>0)},t.kd=function(e){if(t.fd){var n=e.yf>>>0,o=e.Fe>>>0;return String(2097151>=o?4294967296*o+n:t.Paa(e))}return n=e.yf>>>0,2097151>=(o=e.Fe>>>0)?n=String(4294967296*o+n):(n=(16777215&n)+6777216*(e=16777215&(n>>>24|o<<8))+6710656*(o=o>>16&65535),e+=8147497*o,o*=2,1e7<=n&&(e+=Math.floor(n/1e7),n%=1e7),1e7<=e&&(o+=Math.floor(e/1e7),e%=1e7),n=o+k(e)+k(n)),n},k=function(t){return t=String(t),"0000000".slice(t.length)+t},t.dd=function(e,n){return n=~n,(e|=0)?e=1+~e:n+=1,t.bd(e,n)},t.E=function(e,n){var o=t.Bc(e,n);return Array.isArray(o)?o.length:o instanceof t.tc?o.Xa(e,n):0},t.md=function(e,n,o){var i=t.Bc(e,n);return i instanceof t.tc&&(i=t.ld(e,n)),null==(e=i)?void 0:e[o]},t.ld=function(e,n){var o=t.Bc(e,n);return Array.isArray(o)||(o instanceof t.tc?o=o.Af(e,n):(o=[],t.D(e,n,o))),o},t.nd=function(e,n,o){t.ld(e,n).push(o)},t.od=function(t,e){U(new F(t),e)},F=function(t){"string"==typeof t?this.h=t:(this.h=t.M,this.T=t.T),t=this.h;var e=ei[t];if(!e){ei[t]=e=[];for(var n,o=ni.lastIndex=0;n=ni.exec(t);)n=n[0],e[o++]=ni.lastIndex-n.length,e[o++]=parseInt(n,10);e[o]=t.length}this.j=e},U=function(e,n){for(var o={be:15,ac:0,ck:e.T?e.T[0]:"",Uj:!1,ap:!1,Xs:!1,ju:!1,km:!1,Dy:!1},i=1,r=e.j[0],a=1,s=0,h=e.h.length;s<h;){o.ac++,s===r&&(o.ac=e.j[a++],r=e.j[a++],s+=Math.ceil(t.v(Math,"log10").call(Math,o.ac+1)));var u=e.h.charCodeAt(s++);if((o.Xs=42===u)&&(u=e.h.charCodeAt(s++)),(o.ju=44===u)&&(u=e.h.charCodeAt(s++)),43===u||38===u){var c=e.h.substring(s);if(s=h,c=t.qd&&t.qd[c]||null)for(c=c[t.v(t.x.Symbol,"iterator")](),o.km=!0,o.Dy=38===u,u=c.next();!u.done;u=c.next())u=u.value,o.ac=u.ac,"string"==typeof(u=t.Wc(u))?B(e,o,u.charCodeAt(0),n):u&&(o.ck=u.T[0],B(e,o,109,n))}else B(e,o,u,n),17===o.be&&i<e.T.length&&(o.ck=e.T[i++])}},B=function(t,e,n,o){var i=-33&n;e.be=Go[i],e.Uj=n===i,e.ap=0<=i&&0<(4321&1<<i-75),o(e,t)},G=function(e,n){if(e===n)return!0;var o=t.mc(n),i=!1;if(t.Uc(e,(function(t,e){return e=o(e),i=!(t===e||null==t&&null==e||!(!0!==t&&1!==t||!0!==e&&1!==e)||!(!1!==t&&0!==t||!1!==e&&0!==e)||Array.isArray(t)&&Array.isArray(e)&&G(t,e))})),i)return!1;var r=t.mc(e),a=!1;return t.Uc(n,(function(t,e){return a=null==r(e)})),!a},t.F=function(e,n){e=e||[],(0,t.Gc)(e)?(n&&n>e.length&&!t.Ac(e)&&Fo(e,n),Bo(e,this)):t.yc(e,n,void 0,this),this.m=e},z=function(){},t.td=function(e,n,o){return!!t.Cc(e,n,o||!1)},t.I=function(e,n,o){return t.Cc(e,n,o||0)},t.J=function(e,n,o){return t.xd(e,n,o)||new o},t.K=function(e,n,o){var i=t.xd(e,n,o);if(!i){var r=[];i=new o(r),t.D(e,n,r)}return i},t.zd=function(e,n,o){return o=new o,t.nd(e,n,t.yd(o)),o},t.xd=function(e,n,o){var i=t.Bc(e,n);if(i)return i instanceof t.sc&&(i=i.Af(e,n)),t.Ad(i,o)},t.Ad=function(e,n){var o=(0,t.Bd)(e);return null==o?new n(e):o},t.yd=function(e){return(0,t.Bd)(e.m),e.m},t.L=function(e,n){return t.Cc(e,n,"")},H=function(e){t.F.call(this,e)},t.Cd=function(e){return t.L(e.m,1)},t.Dd=function(e){return t.L(e.m,2)},q=function(e){t.F.call(this,e)},V=function(e){t.F.call(this,e)},t.Fd=function(e){t.F.call(this,e)},t.Gd=function(e,n,o){return+t.Cc(e,n,o||0)},W=function(e){t.F.call(this,e,46)},t.Hd=function(e){return t.J(e.m,3,H)},t.Id=function(e){return t.J(e.m,4,q)},J=function(t,e,n){t=Error.call(this,e+": "+n+": "+t),this.message=t.message,"stack"in t&&(this.stack=t.stack),this.endpoint=e,this.code=n,this.name="MapsNetworkError"},t.Nd=function(t,e,n){J.call(this,t,e,n),this.name="MapsServerError"},t.Od=function(t,e,n){J.call(this,t,e,n),this.name="MapsRequestError"},t.Pd=function(t){return t*Math.PI/180},t.Qd=function(t){return 180*t/Math.PI},t.Rd=function(e,n){if(void 0!==e.tagName){if("script"===e.tagName.toLowerCase())throw Error("");if("style"===e.tagName.toLowerCase())throw Error("")}e.innerHTML=t.Sb(n)},t.$aa=function(t){var e,n,o=null==(n=(e=(t.ownerDocument&&t.ownerDocument.defaultView||window).document).querySelector)?void 0:n.call(e,"script[nonce]");(e=o&&(o.nonce||o.getAttribute("nonce"))||"")&&t.setAttribute("nonce",e)},t.Wd=function(t){return t?t.length:0},t.Yd=function(e,n){n&&t.Xd(n,(function(t){e[t]=n[t]}))},t.Zd=function(t,e,n){return null!=e&&(t=Math.max(t,e)),null!=n&&(t=Math.min(t,n)),t},t.$d=function(t,e,n){return t>=e&&t<n||(t=((t-e)%(n-=e)+n)%n+e),t},t.ae=function(t,e,n){return Math.abs(t-e)<=(n||1e-9)},t.be=function(e,n){var o=[];if(!e)return o;for(var i=t.Wd(e),r=0;r<i;++r)o.push(n(e[r],r));return o},t.he=function(t){return"number"==typeof t},t.ie=function(t){return"object"==typeof t},t.je=function(t,e){return null==t?e:t},t.ke=function(t){return"string"==typeof t},t.aba=function(t){return t===!!t},t.Xd=function(t,e){if(t)for(var n in t)t.hasOwnProperty(n)&&e(n,t[n])},Z=function(t,e){if(Object.prototype.hasOwnProperty.call(t,e))return t[e]},t.me=function(){var e=t.Ca.apply(0,arguments);t.C.console&&t.C.console.error&&t.C.console.error.apply(t.C.console,t.ma(e))},t.ne=function(e){for(var n=t.A(t.v(Object,"entries").call(Object,e)),o=n.next();!o.done;o=n.next()){var i=t.A(o.value);o=i.next().value,void 0===(i=i.next().value)&&delete e[o]}},t.pe=function(t){var e=Error.call(this);this.message=e.message,"stack"in e&&(this.stack=e.stack),this.message=t,this.name="InvalidValueError",ai&&this.captureStackTrace()},t.qe=function(e,n){var o="";if(null!=n){if(!(n instanceof t.pe))return n;o=": "+n.message}return new t.pe(e+o)},t.re=function(e){if(!(e instanceof t.pe))throw e;t.me(e.name+": "+e.message)},t.we=function(e,n,o){return o=o?o+": ":"",function(i){if(!i||!t.ie(i))throw t.qe(o+"not an Object");var r,a={};for(r in i)if(a[r]=i[r],!n&&!e[r])throw t.qe(o+"unknown property "+r);for(var s in e)try{var h=e[s](a[s]);(void 0!==h||Object.prototype.hasOwnProperty.call(i,s))&&(a[s]=h)}catch(u){throw t.qe(o+"in property "+s,u)}return a}},Y=function(t){try{return"object"==typeof t&&null!=t&&!!("cloneNode"in t)}catch(e){return!1}},t.xe=function(e,n,o){return o?function(o){if(o instanceof e)return o;try{return new e(o)}catch(i){throw t.qe("when calling new "+n,i)}}:function(o){if(o instanceof e)return o;throw t.qe("not an instance of "+n)}},t.ye=function(e){return function(n){for(var o in e)if(e[o]===n)return n;throw t.qe(n+" is not an accepted value")}},t.ze=function(e){return function(n){if(!Array.isArray(n))throw t.qe("not an Array");return t.be(n,(function(n,o){try{return e(n)}catch(i){throw t.qe("at index "+o,i)}}))}},t.Ae=function(e,n){return function(o){if(e(o))return o;throw t.qe(n||""+o)}},t.Be=function(e){return function(n){for(var o=[],i=0,r=e.length;i<r;++i){var a=e[i];try{ai=!1,(a.oq||a)(n)}catch(s){if(!(s instanceof t.pe))throw s;o.push(s.message);continue}finally{ai=!0}return(a.then||a)(n)}throw t.qe(o.join("; and "))}},t.Ce=function(t,e){return function(n){return e(t(n))}},t.De=function(t){return function(e){return null==e?e:t(e)}},X=function(e){return function(n){if(n&&null!=n[e])return n;throw t.qe("no "+e+" property")}},t.Fe=function(e,n,o){try{return o()}catch(i){throw t.qe(e+": `"+n+"` invalid",i)}},K=function(){},t.He=function(e,n,o){var i;if(o=void 0!==o&&o,!(i=e instanceof t.He?e.toJSON():e)||void 0===i.lat&&void 0===i.lng)var r=i,a=n;else try{fi(i),o=o||!!n,a=i.lng,r=i.lat}catch(s){t.re(s)}r-=0,a-=0,o||(r=t.Zd(r,-90,90),180!=a&&(a=t.$d(a,-180,180))),this.lat=function(){return r},this.lng=function(){return a}},t.Ie=function(e){return t.Pd(e.lat())},t.Je=function(e){return t.Pd(e.lng())},Q=function(t,e){return e=Math.pow(10,e),Math.round(t*e)/e},t.Me=function(e){var n=e;t.Ke(e)&&(n={lat:e.lat(),lng:e.lng()});try{var o=li(n);return t.Ke(e)?e:t.Le(o)}catch(i){throw t.qe("not a LatLng or LatLngLiteral with finite coordinates",i)}},t.Ke=function(e){return e instanceof t.He},t.Le=function(e){try{return t.Ke(e)?e:(e=fi(e),new t.He(e.lat,e.lng))}catch(n){throw t.qe("not a LatLng or LatLngLiteral",n)}},t.Ne=function(e){this.h=t.Le(e)},$=function(e){if(e instanceof K)return e;try{return new t.Ne(t.Le(e))}catch(n){}throw t.qe("not a Geometry or LatLng or LatLngLiteral object")},t.We=function(e){return t.Pe(document,e)},t.Pe=function(t,e){return e=String(e),"application/xhtml+xml"===t.contentType&&(e=e.toLowerCase()),t.createElement(e)},t.Xe=function(t,e){e.parentNode&&e.parentNode.insertBefore(t,e.nextSibling)},t.Ye=function(t){return t&&t.parentNode?t.parentNode.removeChild(t):null},t.Ze=function(t,e){if(!t||!e)return!1;if(t.contains&&1==e.nodeType)return t==e||t.contains(e);if(void 0!==t.compareDocumentPosition)return t==e||!!(16&t.compareDocumentPosition(e));for(;e&&t!=e;)e=e.parentNode;return e==t},t.$e=function(e){this.h=e||t.C.document||document},t.af=function(e,n){return t.Pe(e.h,n)},tt=function(e){return e=t.bf(e),t.$a(e)},t.bf=function(t){return null===t?"null":void 0===t?"undefined":t},et=function(e,n){this.h=t.C.document,this.o=t.v(e,"includes").call(e,"%s")?e:ot([e,"%s"],t.Wa("js")),this.j=!n||t.v(n,"includes").call(n,"%s")?n:ot([n,"%s"],t.Wa("css.js"))},nt=function(e,n,o,i){var r=e.head;(e=t.af(new t.$e(e),"SCRIPT")).type="text/javascript",e.charset="UTF-8",e.async=!1,e.defer=!1,o&&(e.onerror=o),i&&(e.onload=i),e.src=t.Ya(n),t.$aa(e),r.appendChild(e)},ot=function(e,n){for(var o="",i=(e=t.A(e)).next();!i.done;i=e.next())(i=i.value).length&&"/"===i[0]?o=i:(o&&"/"!==o[o.length-1]&&(o+="/"),o+=i);return o+"."+t.Va(n)},t.cf=function(t){if(t.Pb&&t.hasOwnProperty("Pb"))return t.Pb;var e=new t;return t.Pb=e,t.hasOwnProperty("Pb"),e},it=function(){this.requestedModules={},this.j={},this.D={},this.h={},this.F=new t.x.Set,this.o=new ft,this.H=!1,this.C={}},rt=function(t,e,n,o){var i=void 0===i?null:i,r=void 0===r?function(){}:r,a=void 0===a?new et(e,i):a;t.G=r,t.H=!!i,lt(t.o,n,o,a)},at=function(t,e){return t.C[e]=t.C[e]||{zw:!t.H},t.C[e]},st=function(e,n){var o=at(e,n),i=o.Fy;if(i&&o.zw&&(delete e.C[n],!e.h[n])){var r=e.D;pt(e.o,(function(o){for(var a=o.h[n]||[],s=r[n]=gt(a.length,(function(){delete r[n],i(o.j),e.F.delete(n),ht(e,n)})),h=(a=t.A(a)).next();!h.done;h=a.next())e.h[h.value]&&s()}))}},ht=function(e,n){pt(e.o,(function(o){o=o.C[n]||[];var i=e.j[n];delete e.j[n];for(var r=i?i.length:0,a=0;a<r;++a)try{i[a].Fb(e.h[n])}catch(s){setTimeout((function(){throw s}))}for(i=(o=t.A(o)).next();!i.done;i=o.next())i=i.value,e.D[i]&&e.D[i]()}))},ut=function(e,n){e.requestedModules[n]||(e.requestedModules[n]=!0,pt(e.o,(function(o){for(var i=o.h[n],r=i?i.length:0,a=0;a<r;++a){var s=i[a];e.h[s]||ut(e,s)}o.o.rm(n,(function(o){for(var i=t.A(e.j[n]||[]),r=i.next();!r.done;r=i.next())(r=r.value.We)&&r(o&&o.error||Error('Could not load "'+n+'".'));delete e.j[n],e.G&&e.G(n,o)}),(function(){e.F.has(n)||ht(e,n)}))})))},ct=function(e,n,o){this.o=e,this.h=n,this.j=o,e={};for(var i=(o=t.A(t.v(Object,"keys").call(Object,n))).next();!i.done;i=o.next())for(var r=n[i=i.value],a=r.length,s=0;s<a;++s){var h=r[s];e[h]||(e[h]=[]),e[h].push(i)}this.C=e},ft=function(){this.h=[]},lt=function(t,e,n,o){for(e=t.config=new ct(o,e,n),n=t.h.length,o=0;o<n;++o)t.h[o](e);t.h.length=0},pt=function(t,e){t.config?e(t.config):t.h.push(e)},gt=function(t,e){return t?function(){--t||e()}:(e(),function(){})},t.ff=function(e){return new t.x.Promise((function(t,n){var o=it.getInstance(),i=""+e;o.h[i]?t(o.h[i]):((o.j[i]=o.j[i]||[]).push({Fb:t,We:n}),ut(o,i))}))},t.gf=function(t,e){var n=it.getInstance();if(t=""+t,n.h[t])throw Error("Module "+t+" has been provided more than once.");n.h[t]=e},t.kf=function(e){e=e||window.event,t.hf(e),t.jf(e)},t.hf=function(t){t.stopPropagation()},t.jf=function(t){t.preventDefault()},t.lf=function(t){t.handled=!0},t.mf=function(){throw new TypeError("google.maps.event is not a constructor")},t.N=function(e,n,o){return new t.nf(e,n,o,0)},dt=function(e,n){return!!e&&(!!(n=(e=e.__e3_)&&e[n])&&!t.ab(n))},t.rf=function(t){t&&t.remove()},t.tf=function(e,n){t.Xd(vt(e,n),(function(t,e){e&&e.remove()}))},t.uf=function(e){t.Xd(vt(e),(function(t,e){e&&e.remove()}))},t.vf=function(t){if("__e3_"in t)throw Error("setUpNonEnumerableEventListening() was invoked after an event was registered.");Object.defineProperty(t,"__e3_",{value:{}})},t.wf=function(e,n,o,i){var r=i?4:1;return e.addEventListener&&e.addEventListener(n,o,i),new t.nf(e,n,o,r)},t.xf=function(e,n,o,i){var r=t.wf(e,n,(function(){return r.remove(),o.apply(this,arguments)}),i);return r},t.yf=function(e,n,o,i){return t.N(e,n,(0,t.Ma)(i,o))},t.zf=function(e,n,o){var i=t.N(e,n,(function(){return i.remove(),o.apply(this,arguments)}));return i},t.Af=function(e,n,o){return t.N(e,n,t.tba(n,o))},t.O=function(e,n){var o=t.Ca.apply(2,arguments);if(dt(e,n))for(var i=vt(e,n),r=t.A(t.v(Object,"keys").call(Object,i)),a=r.next();!a.done;a=r.next())(a=i[a.value])&&a.De.apply(a.instance,o)},yt=function(t,e){return t.__e3_||(t.__e3_={}),(t=t.__e3_)[e]||(t[e]={}),t[e]},vt=function(e,n){if(e=e.__e3_||{},n)n=e[n]||{};else{n={};for(var o=(e=t.A(t.v(Object,"values").call(Object,e))).next();!o.done;o=e.next())t.Yd(n,o.value)}return n},t.tba=function(e,n,o){return function(i){var r=[n,e].concat(t.ma(arguments));t.O.apply(this,r),o&&t.lf.apply(null,arguments)}},t.nf=function(e,n,o,i,r){this.Wp=void 0===r||r,this.instance=e,this.h=n,this.De=o,this.j=i,this.id=++di,yt(e,n)[this.id]=this,this.Wp&&t.O(this.instance,this.h+"_added")},t.Bf=function(e){e=e||{},this.o=e.id,this.h=null;try{this.h=e.geometry?$(e.geometry):null}catch(n){t.re(n)}this.j=e.properties||{}},t.Cf=function(e){return""+(t.Ia(e)?t.La(e):e)},t.P=function(){},mt=function(e,n){var o=n+"_changed";for(var i in e[o]?e[o]():e.changed(n),o=Et(e,n)){var r=o[i];mt(r.Kj,r.Bf)}t.O(e,n.toLowerCase()+"_changed")},t.Jf=function(t){return vi[t]||(vi[t]=t.substr(0,1).toUpperCase()+t.substr(1))},bt=function(t){return t.gm_accessors_||(t.gm_accessors_={}),t.gm_accessors_},Et=function(t,e){return t.gm_bindings_||(t.gm_bindings_={}),t.gm_bindings_.hasOwnProperty(e)||(t.gm_bindings_[e]={}),t.gm_bindings_[e]},t.Lf=function(t){this.__gm=t},wt=function(){this.h={},this.o={},this.j={}},At=function(){this.h={}},jt=function(e){var n=this;this.h=new At,t.zf(e,"addfeature",(function(){t.ff("data").then((function(t){t.dw(n,e,n.h)}))}))},t.Of=function(e){this.h=[];try{this.h=gi(e)}catch(n){t.re(n)}},t.Qf=function(e){this.h=(0,t.Pf)(e)},t.Rf=function(e){this.h=(0,t.Pf)(e)},t.Sf=function(t){this.h=bi(t)},t.Tf=function(e){this.h=(0,t.Pf)(e)},t.Uf=function(t){this.h=Ei(t)},t.Vf=function(t){this.h=wi(t)},t.Cba=function(e,n,o){function i(e){if(!e)throw t.qe("not a Feature");if("Feature"!=e.type)throw t.qe('type != "Feature"');var n=e.geometry;try{n=null==n?null:r(n)}catch(s){throw t.qe('in property "geometry"',s)}var i=e.properties||{};if(!t.ie(i))throw t.qe("properties is not an Object");var a=o.idPropertyName;if(null!=(e=a?i[a]:e.id)&&!t.he(e)&&!t.ke(e))throw t.qe((a||"id")+" is not a string or number");return{id:e,geometry:n,properties:i}}function r(e){if(null==e)throw t.qe("is null");var n=(e.type+"").toLowerCase(),o=e.coordinates;try{switch(n){case"point":return new t.Ne(h(o));case"multipoint":return new t.Tf(c(o));case"linestring":return s(o);case"multilinestring":return new t.Sf(f(o));case"polygon":return a(o);case"multipolygon":return new t.Vf(p(o))}}catch(i){throw t.qe('in property "coordinates"',i)}if("geometrycollection"==n)try{return new t.Of(g(e.geometries))}catch(i){throw t.qe('in property "geometries"',i)}throw t.qe("invalid type")}function a(e){return new t.Uf(l(e))}function s(e){return new t.Qf(c(e))}function h(e){return e=u(e),t.Le({lat:e[1],lng:e[0]})}if(!n)return[];o=o||{};var u=t.ze(t.Zf),c=t.ze(h),f=t.ze(s),l=t.ze((function(e){if(!(e=c(e)).length)throw t.qe("contains no elements");if(!e[0].equals(e[e.length-1]))throw t.qe("first and last positions are not equal");return new t.Rf(e.slice(0,-1))})),p=t.ze(a),g=t.ze(r),d=t.ze(i);if("FeatureCollection"==n.type){n=n.features;try{return t.be(d(n),(function(t){return e.add(t)}))}catch(y){throw t.qe('in property "features"',y)}}if("Feature"==n.type)return[e.add(i(n))];throw t.qe("not a Feature or FeatureCollection")},Lt=function(t,e){-180==t&&180!=e&&(t=180),-180==e&&180!=t&&(e=180),this.lo=t,this.hi=e},t.ag=function(t){return 360==t.hi-t.lo},t.bg=function(e,n){var o=e.lo,i=e.hi;return e.Ze()?n.Ze()?n.lo>=o&&n.hi<=i:(n.lo>=o||n.hi<=i)&&!e.isEmpty():n.Ze()?t.ag(e)||n.isEmpty():n.lo>=o&&n.hi<=i},t.cg=function(t,e){var n=e-t;return 0<=n?n:e+180-(t-180)},Tt=function(t,e){this.lo=t,this.hi=e},t.fg=function(e,n){var o;if((o=e)&&"south"in o&&"west"in o&&"north"in o&&"east"in o)try{e=t.eg(e)}catch(r){}if(e instanceof t.fg?(o=e.getSouthWest(),n=e.getNorthEast()):(o=e&&t.Le(e),n=n&&t.Le(n)),o){n=n||o,e=t.Zd(o.lat(),-90,90);var i=t.Zd(n.lat(),-90,90);this.Ya=new Tt(e,i),o=o.lng(),360<=(n=n.lng())-o?this.Ma=new Lt(-180,180):(o=t.$d(o,-180,180),n=t.$d(n,-180,180),this.Ma=new Lt(o,n))}else this.Ya=new Tt(1,-1),this.Ma=new Lt(180,-180)},t.gg=function(e,n,o,i){return new t.fg(new t.He(e,n,!0),new t.He(o,i,!0))},t.eg=function(e){if(e instanceof t.fg)return e;try{return e=ji(e),t.gg(e.south,e.west,e.north,e.east)}catch(n){throw t.qe("not a LatLngBounds or LatLngBoundsLiteral",n)}},t.hg=function(t){return function(){return this.get(t)}},t.ig=function(e,n){return n?function(o){try{this.set(e,n(o))}catch(i){t.re(t.qe("set"+t.Jf(e),i))}}:function(t){this.set(e,t)}},t.jg=function(e,n){t.Xd(n,(function(n,o){var i=t.hg(n);e["get"+t.Jf(n)]=i,o&&(o=t.ig(n,o),e["set"+t.Jf(n)]=o)}))},_t=function(e){var n=this;e=e||{},this.setValues(e),this.h=new wt,t.Af(this.h,"addfeature",this),t.Af(this.h,"removefeature",this),t.Af(this.h,"setgeometry",this),t.Af(this.h,"setproperty",this),t.Af(this.h,"removeproperty",this),this.j=new jt(this.h),this.j.bindTo("map",this),this.j.bindTo("style",this),t.gb(t.kg,(function(e){t.Af(n.j,e,n)})),this.o=!1},Ct=function(e){e.o||(e.o=!0,t.ff("drawing_impl").then((function(t){t.Ux(e)})))},t.pg=function(){var e=t.mg;return!!(e&&t.td(t.Hd(e).m,18)&&t.L(t.Hd(e).m,19)&&(t.ng=t.L(t.Hd(e).m,19),t.v(t.ng,"startsWith")).call(t.ng,"http"))&&(e=t.Gd(e.m,44,1),void 0!==Ai&&Ai<e)},t.rg=function(e,n){var o;return t.Ba((function(i){switch(i.h){case 1:if(i.o=2,t.qg||!t.pg()){i.h=4;break}return t.sa(i,t.ff("log"),5);case 5:return o=i.j,i.return(o.h.Zv(e,n));case 4:t.va(i,3);break;case 2:t.wa(i);case 3:return i.return(null)}}))},t.sg=function(e,n){var o;return t.Ba((function(i){switch(i.h){case 1:if(t.qg||!t.pg()||!e){i.h=0;break}return i.o=3,t.sa(i,e,5);case 5:if(!(o=i.j)){i.h=6;break}return t.sa(i,t.ff("log"),7);case 7:i.j.h.ls(o,n);case 6:t.va(i,0);break;case 3:t.wa(i),i.h=0}}))},t.tg=function(e){var n;return t.Ba((function(o){switch(o.h){case 1:if(t.qg||!t.pg()||!e){o.h=0;break}return o.o=3,t.sa(o,e,5);case 5:if(!(n=o.j)){o.h=6;break}return t.sa(o,t.ff("log"),7);case 7:o.j.h.hw(n);case 6:t.va(o,0);break;case 3:t.wa(o),o.h=0}}))},t.ug=function(){var t;return function(){var e=performance.now();return!!(t&&6e4>e-t)||(t=e,!1)}},t.xg=function(e,n,o){return o=void 0===o?{}:o,t.Ba((function(i){if(1!=i.h){if(3!=i.h)return i.j.j.C(e,n,o),t.va(i,0);t.wa(i)}i.h=0}))},t.zg=function(e,n,o,i){o=void 0===o?"":o,(t.yg||void 0!==i&&i)&&t.ff("stats").then((function(t){t.J(e).o(n+o)}))},Mt=function(){},t.Cg=function(e){t.Bg&&e&&t.Bg.push(e)},St=function(t){this.setValues(t)},Ot=function(){},xt=function(){},It=function(){t.ff("geocoder")},t.Jg=function(e,n){function o(e){return t.Fe("LatLngAltitude","lng",(function(){return(0,t.Ig)(e)}))}function i(e){return t.Fe("LatLngAltitude","lat",(function(){return(0,t.Ig)(e)}))}n=void 0!==n&&n;var r="function"==typeof e.lat?e.lat():e.lat;r=r&&n?i(r):t.Zd(i(r),-90,90);var a,s="function"==typeof e.lng?e.lng():e.lng;n=s&&n?o(s):t.$d(o(s),-180,180),e=void 0!==e.altitude?(a=e.altitude,t.Fe("LatLngAltitude","altitude",(function(){return(0,t.Hg)(a)}))):0,this.Ya=r,this.Ma=n,this.h=e},t.R=function(t,e){this.x=t,this.y=e},Pt=function(e){if(e instanceof t.R)return e;try{t.we({x:t.Zf,y:t.Zf},!0)(e)}catch(n){throw t.qe("not a Point",n)}return new t.R(e.x,e.y)},t.Lg=function(t,e,n,o){this.width=t,this.height=e,this.j=n,this.h=o},Rt=function(e){if(e instanceof t.Lg)return e;try{t.we({height:oi,width:oi},!0)(e)}catch(n){throw t.qe("not a Size",n)}return new t.Lg(e.width,e.height)},Nt=function(e){return!!e&&e.Tx instanceof t.P},t.Pg=function(t){if(!Mi.has(t)){if(Si[t])var e=Si[t];else{e=Math.ceil(t.length/6);for(var n="",o=0;o<t.length;o+=e){for(var i=0,r=o;r-o<e&&r<t.length;r++)i+=t.charCodeAt(r);n+=26>(i%=52)?String.fromCharCode(65+i):String.fromCharCode(71+i)}e=Si[t]=n}t=e+"-"+t}return t},Dt=function(e){(e=e||{}).clickable=t.je(e.clickable,!0),e.visible=t.je(e.visible,!0),this.setValues(e),t.ff("marker")},t.Jba=function(e,n,o){var i=e;n&&(i=(0,t.Ma)(e,n)),i=Pi(i),"function"!=typeof t.C.setImmediate||!o&&t.C.Window&&t.C.Window.prototype&&!t.Ab("Edge")&&t.C.Window.prototype.setImmediate==t.C.setImmediate?(Ii||(Ii=kt()),Ii(i)):t.C.setImmediate(i)},kt=function(){var e=t.C.MessageChannel;if(void 0===e&&"undefined"!=typeof window&&window.postMessage&&window.addEventListener&&!t.Ab("Presto")&&(e=function(){var e=t.We("IFRAME");e.style.display="none",document.documentElement.appendChild(e);var n=e.contentWindow;(e=n.document).open(),e.close();var o="callImmediate"+Math.random(),i="file:"==n.location.protocol?"*":n.location.protocol+"//"+n.location.host;e=(0,t.Ma)((function(t){"*"!=i&&t.origin!=i||t.data!=o||this.port1.onmessage()}),this),n.addEventListener("message",e,!1),this.port1={},this.port2={postMessage:function(){n.postMessage(o,i)}}}),void 0!==e&&!t.Cb()){var n=new e,o={},i=o;return n.port1.onmessage=function(){if(void 0!==o.next){var t=(o=o.next).dr;o.dr=null,t()}},function(t){i.next={dr:t},i=i.next,n.port2.postMessage(0)}}return function(e){t.C.setTimeout(e,0)}},Ft=function(t,e){this.C=t,this.o=e,this.j=0,this.h=null},Ut=function(t,e){t.o(e),100>t.j&&(t.j++,e.next=t.h,t.h=e)},Bt=function(){this.j=this.h=null},Gt=function(){this.next=this.scope=this.fn=null},t.Yg=function(t,e){Ni||zt(),Di||(Ni(),Di=!0),ki.add(t,e)},zt=function(){if(t.x.Promise&&t.x.Promise.resolve){var e=t.x.Promise.resolve(void 0);Ni=function(){e.then(Ht)}}else Ni=function(){t.Jba(Ht)}},Ht=function(){for(var e;e=ki.remove();){try{e.fn.call(e.scope)}catch(n){t.Xb(n)}Ut(Ri,e)}Di=!1},t.Zg=function(t){this.listeners=[],this.Wg=t&&t.Wg?t.Wg:function(){},this.Jh=t&&t.Jh?t.Jh:function(){}},qt=function(e,n,o,i){i=i?{cr:!1}:null;var r=!e.listeners.length,a=t.v(e.listeners,"find").call(e.listeners,Vt(n,o));a?a.once=a.once&&i:e.listeners.push({fn:n,context:o||null,once:i}),r&&e.Jh()},t.Sba=function(e,n,o){function i(){for(var o={},i=t.A(r),a=i.next();!a.done;o={kh:o.kh},a=i.next())o.kh=a.value,n(function(t){return function(n){if(t.kh.once){if(t.kh.once.cr)return;t.kh.once.cr=!0,e.listeners.splice(e.listeners.indexOf(t.kh),1),e.listeners.length||e.Wg()}t.kh.fn.call(t.kh.context,n)}}(o))}var r=e.listeners.slice(0);o&&o.sync?i():(Fi||t.Yg)(i)},Vt=function(t,e){return function(n){return n.fn===t&&n.context===(e||null)}},t.$g=function(){var e=this;this.listeners=new t.Zg({Wg:function(){e.Wg()},Jh:function(){e.Jh()}})},t.ah=function(e){e=void 0!==e&&e,t.$g.call(this),this.D=e},t.ch=function(t,e){return new Wt(t,e)},t.dh=function(){return new Wt(null,void 0)},Wt=function(e,n){t.ah.call(this,n),this.value=e},t.eh=function(){this.__gm=new t.P,this.j=null},t.fh=function(t){this.__gm={set:null,xm:null,Kh:{map:null,streetView:null},Jg:null,jm:null,Sk:!1},Dt.call(this,t)},Jt=function(t,e){var n=this;this.infoWindow=t,this.Uk=e,this.infoWindow.addListener("map_changed",(function(){var t=Xt(n.get("internalAnchor"));!n.infoWindow.get("map")&&t&&t.get("map")&&n.set("internalAnchor",null)})),this.bindTo("pendingFocus",this.infoWindow),this.bindTo("map",this.infoWindow),this.bindTo("disableAutoPan",this.infoWindow),this.bindTo("maxWidth",this.infoWindow),this.bindTo("minWidth",this.infoWindow),this.bindTo("position",this.infoWindow),this.bindTo("zIndex",this.infoWindow),this.bindTo("ariaLabel",this.infoWindow),this.bindTo("internalAnchor",this.infoWindow,"anchor"),this.bindTo("internalContent",this.infoWindow,"content"),this.bindTo("internalPixelOffset",this.infoWindow,"pixelOffset"),this.bindTo("shouldFocus",this.infoWindow)},Zt=function(t,e,n,o,i){n?t.bindTo(e,n,o,i):(t.unbind(e),t.set(e,void 0))},Yt=function(e){var n=e.get("internalAnchorPoint")||t.jh,o=e.get("internalPixelOffset")||t.kh;e.set("pixelOffset",new t.Lg(o.width+Math.round(n.x),o.height+Math.round(n.y)))},Xt=function(e){return Nt(e=void 0===e?null:e)?e.Tx||null:e instanceof t.P?e:null},t.lh=function(e){function n(){r||(r=!0,t.ff("infowindow").then((function(t){t.Lv(i)})))}window.setTimeout((function(){t.ff("infowindow")}),100);var o=!!(e=e||{}).Uk;delete e.Uk;var i=new Jt(this,o),r=!1;t.zf(this,"anchor_changed",n),t.zf(this,"map_changed",n),this.setValues(e)},t.mh=function(e,n,o){this.W=null,this.set("url",e),this.set("bounds",t.De(t.eg)(n)),this.setValues(o)},Kt=function(e,n){t.ke(e)?(this.set("url",e),this.setValues(n)):this.setValues(e)},t.oh=function(){this.h=new t.R(128,128),this.o=256/360,this.C=256/(2*Math.PI),this.j=!0},t.ph=function(t,e){this.h=t,this.j=e},t.qh=function(t){this.min=0,this.max=t,this.length=t-0},t.rh=function(t){this.ij=t.ij||null,this.jk=t.jk||null},Qt=function(t,e,n,o){this.j=t,this.tilt=e,this.heading=n,this.h=o,t=Math.cos(e*Math.PI/180),e=Math.cos(n*Math.PI/180),n=Math.sin(n*Math.PI/180),this.m11=this.j*e,this.m12=this.j*n,this.m21=-this.j*t*n,this.m22=this.j*t*e,this.o=this.m11*this.m22-this.m12*this.m21},t.sh=function(t,e,n,o){var i=Math.pow(2,Math.round(t))/256;return new Qt(Math.round(Math.pow(2,t)/i)*i,e,n,o)},t.th=function(e,n){return new t.ph((e.m22*n.fa-e.m12*n.ga)/e.o,(-e.m21*n.fa+e.m11*n.ga)/e.o)},t.uh=function(){var e=this;t.ff("layers").then((function(t){t.Kv(e)}))},$t=function(e){var n=this;this.setValues(e),t.ff("layers").then((function(t){t.Pv(n)}))},te=function(){var e=this;t.ff("layers").then((function(t){t.Qv(e)}))},ee=function(t){this.h=t,this.j=!1},ne=function(t){var e=t.get("mapId"),n=new ee(e);n.bindTo("mapId",t,"mapId",!0),e&&n.bindTo("styles",t)},oe=function(){this.isAvailable=!0,this.h=[]},ie=function(t,e){t.isAvailable=!1,t.h.push(e)},re=function(){},t.Dh=function(e,n){var o=t.Xba(e.__gm.C);if(!n)return o;var i=["The map is initialized without a valid Map ID, that will prevent use of data-driven styling.","The Map Style does not have any FeatureLayers configured for data-driven styling.","The Map Style does not have any Datasets or FeatureLayers configured for data-driven styling."],r=o.h.map((function(t){return t.sh}));return r=r&&r.some((function(e){return t.v(i,"includes").call(i,e)})),(o.isAvailable||!r)&&(e=e.__gm.C.h)&&(n=ae(n,e))&&ie(o,{sh:n}),o},ae=function(e,n){var o=e.featureType;if("DATASET"===o){if(!(t.ng=n.o().map((function(e){return t.L(e.m,2)})),t.v(t.ng,"includes")).call(t.ng,e.datasetId))return"The Map Style does not have the following Dataset ID associated with it: "+e.datasetId}else if(!(t.ng=n.C(),t.v(t.ng,"includes")).call(t.ng,o))return"The Map Style does not have the following FeatureLayer configured for data-driven styling: "+o;return null},se=function(e){var n=void 0===n?"":n,o=t.Dh(e);o.isAvailable||t.Zba(e,n,o)},he=function(e){e=e.__gm;for(var n=t.A(t.v(e.o,"keys").call(e.o)),o=n.next();!o.done;o=n.next())o=o.value,e.o.get(o).isEnabled||t.me("The Map Style does not have the following FeatureLayer configured for data-driven styling:  "+o)},t.bca=function(t,e){e=void 0!==e&&e;var n=t.__gm;0<n.o.size&&se(t),e&&he(t),n.o.forEach((function(t){t.Hs()}))},t.Zba=function(t,e,n){if(0!==n.h.length){var o=e?e+": ":"",i=t.__gm.C;n.h.forEach((function(t){i.log(t,o)}))}},ue=function(e,n){var o=this;this.W=e,this.C=!1,this.o=this.j="UNKNOWN",this.h=null,this.F=new t.x.Promise((function(t){o.G=t})),n.H.then((function(t){o.h=t,o.j=t.j()?"TRUE":"FALSE",ce(o)})),this.D=this.F.then((function(t){o.o=t?"TRUE":"FALSE",ce(o)})),this.Eg={},ce(this)},t.Xba=function(t){return t.log(Ji.DATA_DRIVEN_STYLING),(t=t.Eg.Bw).clone()},ce=function(t){var e=t.Eg,n=new oe;if("TRUE"===t.j||"UNKNOWN"===t.j||ie(n,{sh:"The map is initialized without a valid Map ID, which will prevent use of Advanced Markers."}),e.JB=n,e=t.Eg,n=new oe,"TRUE"===t.j||"UNKNOWN"===t.j){var o=t.h;o&&(o.C().length||ie(n,{sh:"The Map Style does not have any FeatureLayers configured for data-driven styling."})),"UNKNOWN"!==t.o&&"TRUE"!==t.o&&ie(n,{sh:"The map is not a vector map. That will prevent use of data-driven styling."})}else ie(n,{sh:"The map is initialized without a valid Map ID, that will prevent use of data-driven styling."});e.Bw=n},t.Gh=function(){this.j={},this.o=0},t.Hh=function(e,n){var o=e.j,i=t.Cf(n);o[i]||(o[i]=n,++e.o,t.O(e,"insert",n),e.h&&e.h(n))},fe=function(t){return t.replace(/[+/]/g,(function(t){return"+"===t?"-":"_"})).replace(/[.=]+$/,"")},le=function(e,n){switch(n){case 0:case 1:return e;case 13:return e?1:0;case 15:return String(e);case 14:return pe(e);case 12:case 6:case 9:case 7:case 10:case 8:case 11:case 2:case 4:case 3:case 5:return ge(e,n);default:t.gc(n)}},pe=function(e){return t.Ha(e)?t.dc(e,4):(e.constructor===t.ic&&(e=t.jc(e)),fe(e))},ge=function(e,n){switch(n){case 7:case 2:return Number(e)>>>0;case 10:case 3:if("string"==typeof e){if("-"===e[0])return t.kd(t.jd(e))}else if(0>e)return t.kd(t.ed(e))}return"number"==typeof e?Math.floor(e):e},t.Ih=function(){},de=function(t){var e,n=0;for(e in t){var o=t[+e];null!=o&&(n+=4,Array.isArray(o)&&(n+=de(o)))}return n},ye=function(e,n,o,i){var r=t.mc(e);return t.od(n,(function(t){var e=t.ac,n=r(e);if(null!=n)if(t.Uj)for(var a=0;a<n.length;++a)i=ve(n[a],e,t,o,i);else i=ve(n,e,t,o,i)})),i},ve=function(e,n,o,i,r){if(i[r++]="!",i[r++]=n,15<o.be)i[r++]="m",i[r++]=0,n=r,r=ye(e,o.ck,i,r),i[n-1]=r-n>>2;else{if(n=o.be,o=t.Jh[n],15===n){if(e="string"==typeof e?e:""+e,qi.test(e))n=!1;else{var a=(n=encodeURIComponent(e).replace(/%20/g,"+")).match(/%[89AB]/gi);a=e.length+(a?a.length:0),n=4*Math.ceil(a/3)-(3-a%3)%3<n.length}if(n&&(o="z"),"z"===o){n=[];for(var s=a=0;s<e.length;s++){var h=e.charCodeAt(s);128>h?n[a++]=h:(2048>h?n[a++]=h>>6|192:(55296==(64512&h)&&s+1<e.length&&56320==(64512&e.charCodeAt(s+1))?(h=65536+((1023&h)<<10)+(1023&e.charCodeAt(++s)),n[a++]=h>>18|240,n[a++]=h>>12&63|128):n[a++]=h>>12|224,n[a++]=h>>6&63|128),n[a++]=63&h|128)}e=t.dc(n,4)}else-1!==e.indexOf("*")&&(e=e.replace(zi,"*2A")),-1!==e.indexOf("!")&&(e=e.replace(Hi,"*21"))}else e=le(e,n);i[r++]=o,i[r++]=e}return r},me=function(){},be=function(e,n,o){var i=t.mc(e);t.od(n,(function(t){var e=t.ac,n=i(e);if(null!=n)if(t.Uj)for(var r=0;r<n.length;++r)Ee(n[r],e,t,o);else Ee(n,e,t,o)}))},Ee=function(e,n,o,i){if(15<o.be){var r=i.length;be(e,o.ck,i),i.splice(r,0,[n,"m",i.length-r].join(""))}else 13===o.be?e=e?"1":"0":14===o.be&&(e=pe(e)),e=[n,t.Jh[o.be],encodeURIComponent(String(e))].join(""),i.push(e)},t.Lh=function(){this.Bj=this.Bj,this.X=this.X},t.Mh=function(t,e){this.type=t,this.currentTarget=this.target=e,this.defaultPrevented=this.j=!1},t.Ph=function(e,n){if(t.Mh.call(this,e?e.type:""),this.relatedTarget=this.currentTarget=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=this.offsetY=this.offsetX=0,this.key="",this.charCode=this.keyCode=0,this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.h=null,e){var o=this.type=e.type,i=e.changedTouches&&e.changedTouches.length?e.changedTouches[0]:null;if(this.target=e.target||e.srcElement,this.currentTarget=n,n=e.relatedTarget){if(t.Nh){t:{try{w(n.nodeName);var r=!0;break t}catch(a){}r=!1}r||(n=null)}}else"mouseover"==o?n=e.fromElement:"mouseout"==o&&(n=e.toElement);this.relatedTarget=n,i?(this.clientX=void 0!==i.clientX?i.clientX:i.pageX,this.clientY=void 0!==i.clientY?i.clientY:i.pageY,this.screenX=i.screenX||0,this.screenY=i.screenY||0):(this.offsetX=t.Oh||void 0!==e.offsetX?e.offsetX:e.layerX,this.offsetY=t.Oh||void 0!==e.offsetY?e.offsetY:e.layerY,this.clientX=void 0!==e.clientX?e.clientX:e.pageX,this.clientY=void 0!==e.clientY?e.clientY:e.pageY,this.screenX=e.screenX||0,this.screenY=e.screenY||0),this.button=e.button,this.keyCode=e.keyCode||0,this.key=e.key||"",this.charCode=e.charCode||("keypress"==o?e.keyCode:0),this.ctrlKey=e.ctrlKey,this.altKey=e.altKey,this.shiftKey=e.shiftKey,this.metaKey=e.metaKey,this.pointerId=e.pointerId||0,this.pointerType="string"==typeof e.pointerType?e.pointerType:Zi[e.pointerType]||"",this.state=e.state,this.h=e,e.defaultPrevented&&t.Ph.Ne.preventDefault.call(this)}},t.Qh=function(t){return!(!t||!t[Yi])},we=function(t,e,n,o,i){this.listener=t,this.proxy=null,this.src=e,this.type=n,this.capture=!!o,this.De=i,this.key=++Xi,this.Hf=this.Yl=!1},Ae=function(t){t.Hf=!0,t.listener=null,t.proxy=null,t.src=null,t.De=null},je=function(t){this.src=t,this.listeners={},this.h=0},Le=function(e,n){var o=n.type;if(!(o in e.listeners))return!1;var i=t.mb(e.listeners[o],n);return i&&(Ae(n),0==e.listeners[o].length&&(delete e.listeners[o],e.h--)),i},t.tca=function(t){var e;for(e in t.listeners){for(var n=t.listeners[e],o=0;o<n.length;o++)Ae(n[o]);delete t.listeners[e],t.h--}},Te=function(t,e,n,o){for(var i=0;i<t.length;++i){var r=t[i];if(!r.Hf&&r.listener==e&&r.capture==!!n&&r.De==o)return i}return-1},t.Wh=function(e,n,o,i,r){if(i&&i.once)return t.Vh(e,n,o,i,r);if(Array.isArray(n)){for(var a=0;a<n.length;a++)t.Wh(e,n[a],o,i,r);return null}return o=xe(o),t.Qh(e)?t.Yh(e,n,o,t.Ia(i)?!!i.capture:!!i,r):_e(e,n,o,!1,i,r)},_e=function(e,n,o,i,r,a){if(!n)throw Error("Invalid event type");var s=t.Ia(r)?!!r.capture:!!r,h=t.Zh(e);if(h||(e[Ki]=h=new je(e)),(o=h.add(n,o,i,s,a)).proxy)return o;if(i=Ce(),o.proxy=i,i.src=e,i.listener=o,e.addEventListener)Bi||(r=s),void 0===r&&(r=!1),e.addEventListener(n.toString(),i,r);else if(e.attachEvent)e.attachEvent(Se(n.toString()),i);else{if(!e.addListener||!e.removeListener)throw Error("addEventListener and attachEvent are unavailable.");e.addListener(i)}return o},Ce=function(){var t=Oe;return function e(n){return t.call(e.src,e.listener,n)}},t.Vh=function(e,n,o,i,r){if(Array.isArray(n)){for(var a=0;a<n.length;a++)t.Vh(e,n[a],o,i,r);return null}return o=xe(o),t.Qh(e)?e.qf.add(String(n),o,!0,t.Ia(i)?!!i.capture:!!i,r):_e(e,n,o,!0,i,r)},Me=function(e,n,o,i,r){if(Array.isArray(n))for(var a=0;a<n.length;a++)Me(e,n[a],o,i,r);else i=t.Ia(i)?!!i.capture:!!i,o=xe(o),t.Qh(e)?e.qf.remove(String(n),o,i,r):e&&(e=t.Zh(e))&&(n=e.listeners[n.toString()],e=-1,n&&(e=Te(n,o,i,r)),(o=-1<e?n[e]:null)&&t.ai(o))},t.ai=function(e){if("number"==typeof e||!e||e.Hf)return!1;var n=e.src;if(t.Qh(n))return Le(n.qf,e);var o=e.type,i=e.proxy;return n.removeEventListener?n.removeEventListener(o,i,e.capture):n.detachEvent?n.detachEvent(Se(o),i):n.addListener&&n.removeListener&&n.removeListener(i),(o=t.Zh(n))?(Le(o,e),0==o.h&&(o.src=null,n[Ki]=null)):Ae(e),!0},Se=function(t){return t in Qi?Qi[t]:Qi[t]="on"+t},Oe=function(e,n){if(e.Hf)e=!0;else{n=new t.Ph(n,this);var o=e.listener,i=e.De||e.src;e.Yl&&t.ai(e),e=o.call(i,n)}return e},t.Zh=function(t){return(t=t[Ki])instanceof je?t:null},xe=function(t){return"function"==typeof t?t:(t[$i]||(t[$i]=function(e){return t.handleEvent(e)}),t[$i])},t.di=function(){t.Lh.call(this),this.qf=new je(this),this.tj=this,this.Gb=null},t.Yh=function(t,e,n,o,i){return t.qf.add(String(e),n,!1,o,i)},Ie=function(t,e,n,o){if(!(e=t.qf.listeners[String(e)]))return!0;e=e.concat();for(var i=!0,r=0;r<e.length;++r){var a=e[r];if(a&&!a.Hf&&a.capture==n){var s=a.listener,h=a.De||a.src;a.Yl&&Le(t.qf,a),i=!1!==s.call(h,o)&&i}}return i&&!o.defaultPrevented},t.li=function(e){if(this.h=0,this.G=void 0,this.C=this.j=this.o=null,this.D=this.F=!1,e!=t.cb)try{var n=this;e.call(void 0,(function(t){Fe(n,2,t)}),(function(t){Fe(n,3,t)}))}catch(o){Fe(this,3,o)}},Pe=function(){this.next=this.context=this.j=this.o=this.h=null,this.C=!1},Re=function(t,e,n){var o=tr.get();return o.o=t,o.j=e,o.context=n,o},Ne=function(t,e){if(0==t.h)if(t.o){var n=t.o;if(n.j){for(var o=0,i=null,r=null,a=n.j;a&&(a.C||(o++,a.h==t&&(i=a),!(i&&1<o)));a=a.next)i||(r=a);i&&(0==n.h&&1==o?Ne(n,e):(r?((o=r).next==n.C&&(n.C=o),o.next=o.next.next):Ge(n),ze(n,i,3,e)))}t.o=null}else Fe(t,3,e)},De=function(t,e){t.j||2!=t.h&&3!=t.h||Be(t),t.C?t.C.next=e:t.j=e,t.C=e},ke=function(e,n,o,i){var r=Re(null,null,null);return r.h=new t.li((function(t,e){r.o=n?function(o){try{var r=n.call(i,o);t(r)}catch(a){e(a)}}:t,r.j=o?function(n){try{var r=o.call(i,n);void 0===r&&n instanceof Ve?e(n):t(r)}catch(a){e(a)}}:e})),r.h.o=e,De(e,r),r.h},Fe=function(e,n,o){if(0==e.h){e===o&&(n=3,o=new TypeError("Promise cannot resolve to itself")),e.h=1;t:{var i=o,r=e.J,a=e.K;if(i instanceof t.li){De(i,Re(r||t.cb,a||null,e));var s=!0}else{if(i)try{var h=!!i.$goog_Thenable}catch(c){h=!1}else h=!1;if(h)i.then(r,a,e),s=!0;else{if(t.Ia(i))try{var u=i.then;if("function"==typeof u){Ue(i,u,r,a,e),s=!0;break t}}catch(c){a.call(e,c),s=!0;break t}s=!1}}}s||(e.G=o,e.h=n,e.o=null,Be(e),3!=n||o instanceof Ve||qe(e,o))}},Ue=function(t,e,n,o,i){function r(t){a||(a=!0,o.call(i,t))}var a=!1;try{e.call(t,(function(t){a||(a=!0,n.call(i,t))}),r)}catch(s){r(s)}},Be=function(e){e.F||(e.F=!0,t.Yg(e.H,e))},Ge=function(t){var e=null;return t.j&&(e=t.j,t.j=e.next,e.next=null),t.j||(t.C=null),e},ze=function(t,e,n,o){if(3==n&&e.j&&!e.C)for(;t&&t.D;t=t.o)t.D=!1;if(e.h)e.h.o=null,He(e,n,o);else try{e.C?e.o.call(e.context):He(e,n,o)}catch(i){er.call(null,i)}Ut(tr,e)},He=function(t,e,n){2==e?t.o.call(t.context,n):t.j&&t.j.call(t.context,n)},qe=function(e,n){e.D=!0,t.Yg((function(){e.D&&er.call(null,n)}))},Ve=function(e){t.Ra.call(this,e)},t.ni=function(e,n,o){if("function"==typeof e)o&&(e=(0,t.Ma)(e,o));else{if(!e||"function"!=typeof e.handleEvent)throw Error("Invalid listener argument");e=(0,t.Ma)(e.handleEvent,e)}return 2147483647<Number(n)?-1:t.C.setTimeout(e,n||0)},t.oi=function(e,n,o){t.Lh.call(this),this.h=e,this.C=n||0,this.j=o,this.o=(0,t.Ma)(this.Jq,this)},t.pi=function(t){t.isActive()||t.start(void 0)},We=function(){var e=this;this.j=null,this.h=new t.x.Map,this.o=new t.oi((function(){Je(e)}))},Je=function(e){e.j&&window.requestAnimationFrame((function(){if(e.j){var n=[].concat(t.ma(t.v(e.h,"values").call(e.h)));e.j(n)}}))},t.qi=function(e){this.va=this.Aa=1/0,this.Ca=this.Ha=-1/0,t.gb(e||[],this.extend,this)},t.ri=function(e,n,o,i){var r=new t.qi;return r.Aa=e,r.va=n,r.Ha=o,r.Ca=i,r},t.si=function(t,e){return!(t.Aa>=e.Ha||e.Aa>=t.Ha||t.va>=e.Ca||e.va>=t.Ca)},Ze=function(){var e=this;this.h=new t.x.Map,this.j=new t.oi((function(){for(var n=[],o=[],i=t.A(t.v(e.h,"values").call(e.h)),r=i.next();!r.done;r=i.next())(r=r.value).Go()&&r.wt&&("REQUIRED_AND_HIDES_OPTIONAL"===r.collisionBehavior?(n.push(r.Go()),r.Sk=!1):o.push(r));for(o.sort(Ye),r=(o=t.A(o)).next();!r.done;r=o.next())i=r.value,Xe(i.Go(),n)?i.Sk=!0:(n.push(i.Go()),i.Sk=!1)}),0)},Ye=function(e,n){var o=e.zIndex,i=n.zIndex,r=t.he(o),a=t.he(i),s=e.wt,h=n.wt;return r&&a&&o!==i?o>i?-1:1:r!==a?r?-1:1:s.y!==h.y?h.y-s.y:(e=t.La(e))>(n=t.La(n))?-1:1},Xe=function(e,n){return n.some((function(n){return t.si(n,e)}))},t.ti=function(e,n,o){t.Lh.call(this),this.F=null!=o?(0,t.Ma)(e,o):e,this.D=n,this.C=(0,t.Ma)(this.G,this),this.j=this.h=null,this.o=[]},Ke=function(){var e=this;this.j=new Ze,this.o=new We,this.h=new t.x.Set,new t.ti((function(){t.pi(e.j.j);for(var n=e.o,o=t.A(new t.x.Set(e.h)),i=o.next();!i.done;i=o.next())if((i=i.value).Sk){var r=n;i=t.La(i),r.h.has(i)&&(r.h.delete(i),t.pi(r.o))}else{r=n;var a=i.YB();a&&(r.h.set(t.La(i),a),t.pi(r.o))}e.h.clear()}),50)},t.vi=function(t){this.Uc=t||[],Qe(this)},Qe=function(t){t.set("length",t.Uc.length)},t.wi=function(t){this.h=t},t.Uca=function(t,e){var n=e.uf();return E(t.h,(function(t){return t=t.uf(),n!=t}))},t.xi=function(e,n,o){this.heading=e,this.pitch=t.Zd(n,-90,90),this.zoom=Math.max(0,o)},t.yi=function(t,e){return(t.matches||t.msMatchesSelector||t.webkitMatchesSelector).call(t,e)},t.zi=function(t,e,n,o){var i=void 0===o?{}:o;o=void 0!==i.md&&i.md,i=void 0!==i.passive&&i.passive,this.h=t,this.C=e,this.j=n,this.o=rr?{passive:i,capture:o}:o,t.addEventListener?t.addEventListener(e,n,this.o):t.attachEvent&&t.attachEvent("on"+e,n)},$e=function(t){t.currentTarget.style.outline=""},t.Ci=function(e){if(t.yi(e,'select,textarea,input[type="date"],input[type="datetime-local"],input[type="email"],input[type="month"],input[type="number"],input[type="password"],input[type="search"],input[type="tel"],input[type="text"],input[type="time"],input[type="url"],input[type="week"],input:not([type])'))return[];var n=[];return n.push(new t.zi(e,"focus",(function(e){t.Ai||!1!==t.Bi||(e.currentTarget.style.outline="none")}))),n.push(new t.zi(e,"focusout",$e)),n},tn=function(t,e){this.h=t,this.j=void 0===e?0:e},en=function(e){this.h=this.type=0,this.version=new tn(0),this.D=new tn(0),this.j=0;for(var n=e.toLowerCase(),o=t.A(t.v(dr,"entries").call(dr)),i=o.next();!i.done;i=o.next()){var r=t.A(i.value);if(i=r.next().value,r=r.next().value,r=t.v(r,"find").call(r,(function(e){return t.v(n,"includes").call(n,e)}))){this.type=i,(o=new RegExp(r+"[ /]?([0-9]+).?([0-9]+)?").exec(n))&&(this.version=new tn(t.v(Math,"trunc").call(Math,Number(o[1])),t.v(Math,"trunc").call(Math,Number(o[2]||"0"))));break}}for(7===this.type&&(o=RegExp("^Mozilla/.*Gecko/.*[Minefield|Shiretoko][ /]?([0-9]+).?([0-9]+)?").exec(e))&&(this.type=5,this.version=new tn(t.v(Math,"trunc").call(Math,Number(o[1])),t.v(Math,"trunc").call(Math,Number(o[2]||"0")))),6===this.type&&(o=RegExp("rv:([0-9]{2,}.?[0-9]+)").exec(e))&&(this.type=1,this.version=new tn(t.v(Math,"trunc").call(Math,Number(o[1])))),o=1;7>o;++o)if(t.v(n,"includes").call(n,vr[o])){this.h=o;break}6!==this.h&&5!==this.h&&2!==this.h||(o=/OS (?:X )?(\d+)[_.]?(\d+)/.exec(e))&&(this.D=new tn(t.v(Math,"trunc").call(Math,Number(o[1])),t.v(Math,"trunc").call(Math,Number(o[2]||"0")))),4===this.h&&(e=/Android (\d+)\.?(\d+)?/.exec(e))&&(this.D=new tn(t.v(Math,"trunc").call(Math,Number(e[1])),t.v(Math,"trunc").call(Math,Number(e[2]||"0")))),this.C&&(e=/\brv:\s*(\d+\.\d+)/.exec(n))&&(this.j=Number(e[1])),this.o=document.compatMode||"",1===this.h||2===this.h||3===this.h&&t.v(n,"includes").call(n,"mobile")},nn=function(){return mr||(mr=new en(navigator.userAgent))},on=function(){this.C=this.o=null},rn=function(e){return!t.Gi[43]&&(!!e.od||(!t.C.devicePixelRatio||!t.C.requestAnimationFrame))},t.ada=function(){var e=t.Ii;return!t.Gi[43]&&(e.od||rn(e))},t.Ji=function(t,e){null!==t&&((t=t.style).width=e.width+(e.j||"px"),t.height=e.height+(e.h||"px"))},t.Ki=function(e){return new t.Lg(e.offsetWidth,e.offsetHeight)},t.Li=function(e,n){if(n=void 0!==n&&n,document.activeElement===e)return!0;var o=!1;return t.Ci(e),e.tabIndex=e.tabIndex,e.addEventListener("focus",(function t(){o=!0,e.removeEventListener("focus",t)})),e.addEventListener("focusin",(function t(){o=!0,e.removeEventListener("focusin",t)})),e.focus({preventScroll:!!n}),o},t.Ni=function(e,n){var o=this;t.eh.call(this),t.Cg(e),this.__gm=new t.P,this.__gm.set("isInitialized",!1),this.h=t.ch(!1,!0),this.h.addListener((function(t){if(o.get("visible")!=t){if(o.o){var e=o.__gm;e.set("shouldAutoFocus",t&&e.get("isMapInitialized"))}an(o,t),o.set("visible",t)}})),this.D=this.F=null,n&&n.client&&(this.D=t.cda[n.client]||null);var i=this.controls=[];t.Xd(t.Mi,(function(e,n){i[n]=new t.vi})),this.o=!1,this.Jd=n&&n.Jd||t.ch(!1),this.G=e,this.fm=n&&n.fm||this.G,this.__gm.set("developerProvidedDiv",this.fm),this.C=null,this.__gm.Jj=n&&n.Jj||new t.Gh,this.set("standAlone",!0),this.setPov(new t.xi(0,0,1)),n&&n.pov&&(e=n.pov,t.he(e.zoom)||(e.zoom="number"==typeof n.zoom?n.zoom:1)),this.setValues(n),null==this.getVisible()&&this.setVisible(!0);var r=this.__gm.Jj;t.zf(this,"pano_changed",(function(){t.ff("marker").then((function(t){t.ho(r,o,!1)}))})),t.Gi[35]&&n&&n.dE&&t.ff("util").then((function(e){e.Kf.C(new t.Fd(n.dE))})),t.yf(this,"keydown",this,this.H)},an=function(e,n){n&&(e.C=document.activeElement,t.zf(e.__gm,"panoramahidden",(function(){var n,o;null!=(n=e.j)&&(null!=(o=n.Xg)&&o.contains(document.activeElement))&&(n=e.__gm.get("focusFallbackElement"),e.C?!t.Li(e.C)&&n&&t.Li(n):n&&t.Li(n))})))},sn=function(){this.C=[],this.o=this.h=this.j=null},t.fda=function(t,e){return e=void 0===e?document:e,hn(t,e)},hn=function(t,e){return!!(e=e&&(e.fullscreenElement||e.webkitFullscreenElement||e.mozFullScreenElement||e.msFullscreenElement))&&(e===t||hn(t,e.shadowRoot))},un=function(e,n,o,i){var r=this;this.Ba=n,this.set("developerProvidedDiv",this.Ba),this.yo=o,this.h=i,this.j=t.ch(new t.wi([])),this.X=new t.Gh,this.copyrights=new t.vi,this.J=new t.Gh,this.N=new t.Gh,this.K=new t.Gh,this.Jd=t.ch(t.fda(o,"undefined"==typeof document?null:document)),this.Ug=t.dh();var a=this.Jj=new t.Gh;a.h=function(){delete a.h,t.x.Promise.all([t.ff("marker"),r.D]).then((function(n){var o=t.A(n);n=o.next().value,o=o.next().value,n.ho(a,e,o)}))},this.G=new t.Ni(o,{visible:!1,enableCloseButton:!0,Jj:a,Jd:this.Jd,fm:this.Ba}),this.G.bindTo("controlSize",e),this.G.bindTo("reportErrorControl",e),this.G.o=!0,this.F=new sn,this.ui=this.Of=this.overlayLayer=null,this.H=new t.x.Promise((function(t){r.ha=t})),this.ta=new t.x.Promise((function(t){r.na=t})),this.C=new ue(e,this),this.D=this.C.D.then((function(){return"TRUE"===r.C.o})),this.V=function(t){this.C.G(t)},this.set("isInitialized",!1),this.G.__gm.bindTo("isMapInitialized",this,"isInitialized"),this.h.then((function(){return r.set("isInitialized",!0)})),new Ke,this.Z=null,this.ca=!1,this.o=new t.x.Map,this.ba=new t.x.Map},cn=function(){},fn=function(e,n){if(this.h=!1,this.j="UNINITIALIZED",e)throw t.tg(n),Error("Setting map 'renderingType' is not supported. RenderingType is decided internally and is read-only. If you wish to create a vector map please create a map ID in the cloud console as per https://developers.google.com/maps/documentation/javascript/vector-map")},ln=function(t){t.h=!0;try{t.set("renderingType",t.j)}finally{t.h=!1}},t.Zi=function(t,e,n){return(t=t.fromLatLngToPoint(e))&&(n=Math.pow(2,n),t.x*=n,t.y*=n),t},t.$i=function(e,n){var o=e.lat()+t.Qd(n);90<o&&(o=90);var i=e.lat()-t.Qd(n);-90>i&&(i=-90),n=Math.sin(n);var r=Math.cos(t.Pd(e.lat()));return 90==o||-90==i||1e-6>r?new t.fg(new t.He(i,-180),new t.He(o,180)):(n=t.Qd(Math.asin(n/r)),new t.fg(new t.He(i,e.lng()-n),new t.He(o,e.lng()+n)))},t.ida=function(){var e=[1379903],n=t.C.google&&t.C.google.maps&&t.C.google.maps.fisfetsz;return n&&Array.isArray(n)&&t.Gi[15]&&n.forEach((function(n){t.he(n)&&e.push(n)})),e},pn=function(e){t.F.call(this,e)},t.bj=function(e){t.F.call(this,e,17)},gn=function(e){var n=t.Cd(t.Hd(t.mg));t.D(e.m,5,n)},dn=function(e){var n=t.Dd(t.Hd(t.mg)).toLowerCase();t.D(e.m,6,n)},t.cj=function(e){t.F.call(this,e)},t.dj=function(e){t.F.call(this,e)},yn=function(e){t.F.call(this,e)},vn=function(e){var n=t.fj.Va;(e=e.toArray(),pr)||(lr||(fr||(fr={M:"eedmbddemd",T:["uuuu","uuuu"]}),lr={M:"ebb5ss8Mmbbb,EI16b100b",T:[fr,",Eb"]}),$o||($o={M:"10m",T:["bb"]}),pr={M:"meummms",T:["ii","uue",lr,$o]});return n.call(t.fj,e,pr)},mn=function(e,n,o,i){var r=this;this.Ga=new t.oi((function(){var e=wn(r);if(r.o&&r.J)r.F!==e&&t.kj(r.h);else{var n="",o=r.G(),i=An(r),a=r.C();if(a){if(o&&isFinite(o.lat())&&isFinite(o.lng())&&1<i&&null!=e&&a&&a.width&&a.height&&r.j){if(t.Ji(r.j,a),o=t.Zi(r.N,o,i)){var s=new t.qi;s.Aa=Math.round(o.x-a.width/2),s.Ha=s.Aa+a.width,s.va=Math.round(o.y-a.height/2),s.Ca=s.va+a.height,o=s}else o=null;s=Er[e],o&&(r.J=!0,r.F=e,r.o&&r.h&&(n=t.sh(i,0,0),r.o.set({image:r.h,bounds:{min:t.th(n,{fa:o.Aa,ga:o.va}),max:t.th(n,{fa:o.Ha,ga:o.Ca})},size:{width:a.width,height:a.height}})),n=En(r,o,i,e,s))}r.h&&(t.Ji(r.h,a),bn(r,n))}}}),0),this.V=n,this.N=new t.oh,this.X=o+"/maps/api/js/StaticMapService.GetMapImage",this.D=i,this.h=this.j=null,this.o=t.dh(),this.F=null,this.H=this.J=!1,this.set("div",e),this.set("loading",!0)},bn=function(e,n){n!==e.h.src?(e.o||t.kj(e.h),e.h.onload=function(){jn(e,!0)},e.h.onerror=function(){jn(e,!1)},e.h.src=n):!e.h.parentNode&&n&&e.j.appendChild(e.h)},En=function(e,n,o,i,r){var a=new yn,s=t.K(a.m,1,t.cj);s.td(n.Aa),s.ud(n.va),t.D(a.m,2,r),a.setZoom(o),o=t.K(a.m,4,t.dj),t.D(o.m,1,n.Ha-n.Aa),t.D(o.m,2,n.Ca-n.va);var h=t.K(a.m,5,t.bj);return t.D(h.m,1,i),gn(h),dn(h),t.D(h.m,10,!0),t.ida().forEach((function(e){for(var n=!1,o=0,i=t.E(h.m,14);o<i;o++)if(t.md(h.m,14,o)===e){n=!0;break}n||t.nd(h.m,14,e)})),t.D(h.m,12,!0),t.Gi[13]&&(n=t.zd(h.m,8,pn),t.D(n.m,1,33),t.D(n.m,2,3),n.Lc(1)),e.D&&t.D(a.m,7,e.D),a=e.X+unescape("%3F")+vn(a),e.V(a)},wn=function(e){var n=e.get("tilt")||t.Wd(e.get("styles"));return e=e.get("mapTypeId"),n?null:br[e]},An=function(t){return"number"==typeof(t=t.get("zoom"))?Math.floor(t):t},jn=function(e,n){e.h.onload=null,e.h.onerror=null;var o=e.C();o&&(n&&(e.h.parentNode||e.j.appendChild(e.h),e.o||t.Ji(e.h,o)),e.set("loading",!1))},t.kj=function(t){t&&t.parentNode&&t.parentNode.removeChild(t)},t.mj=function(){t.vf(this)},t.nj=function(){},Ln=function(t,e,n,o,i){this.h=!!e,this.node=null,this.j=0,this.C=!1,this.o=!n,t&&this.setPosition(t,o),this.depth=null!=i?i:this.j||0,this.h&&(this.depth*=-1)},Tn=function(t,e,n,o){Ln.call(this,t,e,n,null,o)},t.tda=function(e,n){for(void 0===n||n||t.qj(e),n=e.firstChild;n;)t.qj(n),e.removeChild(n),n=e.firstChild},t.qj=function(e){for(e=new Tn(e);;){var n=e.next();if(n.done)break;(n=n.value)&&t.uf(n)}},_n=function(t){this.a=1729,this.h=t},Cn=function(t,e,n){for(var o=Array(e.length),i=0,r=e.length;i<r;++i)o[i]=e.charCodeAt(i);return o.unshift(n),t.hash(o)},Mn=function(t,e,n,o){var i=new _n(131071),r=unescape("%26%74%6F%6B%65%6E%3D"),a=unescape("%26%6B%65%79%3D"),s=unescape("%26%63%6C%69%65%6E%74%3D"),h=unescape("%26%63%68%61%6E%6E%65%6C%3D"),u="";return e&&(u+=a+encodeURIComponent(e)),n&&(u+=s+encodeURIComponent(n)),o&&(u+=h+encodeURIComponent(o)),function(e){var n=(e=e.replace(wr,"%27")+u)+r;if(Ar||(Ar=RegExp("(?:https?://[^/]+)?(.*)")),!(e=Ar.exec(e)))throw Error("Invalid URL to sign.");return n+Cn(i,e[1],t)}},Sn=function(t){t=Array(t.toString().length);for(var e=0;e<t.length;++e)t[e]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".charAt(Math.floor(62*Math.random()));return t.join("")},On=function(t){var e=void 0===e?Sn(t):e,n=new _n(131071);return function(){return[e,Cn(n,e,t).toString()]}},xn=function(){var t=new _n(2147483647);return function(e){return Cn(t,e,0)}},In=function(e,n){var o=this;Date.now();var i=t.rg(122447);if(Rn(n)||t.tg(i),!e)throw t.tg(i),t.qe("Map: Expected mapDiv of type HTMLElement but was passed "+e+".");if("string"==typeof e)throw t.tg(i),t.qe("Map: Expected mapDiv of type HTMLElement but was passed string '"+e+"'.");var r=n||{};r.noClear||t.tda(e,!1);var a="undefined"==typeof document?null:document.createElement("div");if(a&&e.appendChild&&(e.appendChild(a),a.style.width=a.style.height="100%"),rn(t.Ii))throw t.ff("controls").then((function(t){t.Xp(e)})),t.tg(i),Error("The Google Maps JavaScript API does not support this browser.");t.ff("util").then((function(o){t.Gi[35]&&n&&n.dE&&o.Kf.C(new t.Fd(n.dE)),o.Kf.h((function(n){t.ff("controls").then((function(o){var i=t.L(n.m,2)||"http://g.co/dev/maps-no-account";o.St(e,i)}))}))}));var s,h=new t.x.Promise((function(t){s=t}));t.Lf.call(this,new un(this,e,a,h)),h=this.__gm.C,this.set("mapCapabilities",h.getMapCapabilities()),h.bindTo("mapCapabilities",this,"mapCapabilities",!0),void 0===r.mapTypeId&&(r.mapTypeId="roadmap");var u=new fn(r.renderingType,i);this.set("renderingType","UNINITIALIZED"),u.bindTo("renderingType",this,"renderingType",!0),this.__gm.D.then((function(t){u.j=t?"VECTOR":"RASTER",ln(u)})),this.setValues(r),ne(this),this.h=t.Gi[15]&&r.noControlsOrLogging,this.mapTypes=new cn,this.features=new t.P,t.Cg(a),this.notify("streetView"),h=t.Ki(a);var c=null,f=r.mapId||null;Pn(r.useStaticMap,h)&&((c=new mn(a,t.uj,t.L(t.Hd(t.mg).m,10),f)).set("size",h),c.bindTo("center",this),c.bindTo("zoom",this),c.bindTo("mapTypeId",this),f||c.bindTo("styles",this)),this.overlayMapTypes=new t.vi;var l=this.controls=[];t.Xd(t.Mi,(function(e,n){l[n]=new t.vi})),t.ff("map").then((function(e){jr=e,o.getDiv()&&a?e.j(o,r,a,c,s,i):t.tg(i)}),(function(){o.getDiv()&&a?t.sg(i,8):t.tg(i)})),this.data=new _t({map:this}),this.addListener("renderingtype_changed",(function(){t.bca(o)}));var p=this.addListener("zoom_changed",(function(){t.rf(p),t.tg(i)})),g=this.addListener("dragstart",(function(){t.rf(g),t.tg(i)}));t.wf(e,"scroll",(function(){e.scrollLeft=e.scrollTop=0}))},Pn=function(e,n){return!(!t.mg||2==t.J(t.mg.m,40,t.Fd).getStatus())&&(void 0!==e?!!e:384e3>=(e=n.width)*(n=n.height)&&800>=e&&800>=n)},Rn=function(e){if(!e)return!1;for(var n=t.v(Object,"keys").call(Object,Lr),o=(n=t.A(n)).next();!o.done;o=n.next()){o=o.value;try{"function"==typeof Lr[o]&&e[o]&&Lr[o](e[o])}catch(i){return!1}}return!(!e.center||!e.zoom)},Nn=function(t,e,n,o,i){this.url=t,this.size=e||i,this.origin=n,this.anchor=o,this.scaledSize=i,this.labelOrigin=null},Dn=function(){t.ff("maxzoom")},kn=function(e,n){t.me("The Fusion Tables service will be turned down in December 2019 (see https://support.google.com/fusiontables/answer/9185417). Maps API version 3.37 is the last version that will support FusionTablesLayer."),!e||t.ke(e)||t.he(e)?(this.set("tableId",e),this.setValues(n)):this.setValues(e)},t.Aj=function(){},Fn=function(e){return(e=e||{}).visible=t.je(e.visible,!0),e},t.Cda=function(t){return t&&t.radius||6378137},Un=function(e){return e instanceof t.vi?_r(e):new t.vi(si(e))},Bn=function(e){return function(n){if(!(n instanceof t.vi))throw t.qe("not an MVCArray");return n.forEach((function(n,o){try{e(n)}catch(i){throw t.qe("at index "+o,i)}})),n}},t.Dj=function(e){var n;n=e instanceof t.Dj?e.Bi():e,this.setValues(Fn(n)),t.ff("poly")},Gn=function(e){this.set("latLngs",new t.vi([new t.vi])),this.setValues(Fn(e)),t.ff("poly")},t.Fj=function(t){Gn.call(this,t)},t.Gj=function(t){Gn.call(this,t)},t.Hj=function(e){this.setValues(Fn(e)),t.ff("poly")},zn=function(){this.h=null},t.Jj=function(){this.h=null},t.Gda=function(e,n,o,i){var r=e.h||void 0;return e=t.ff("streetview").then((function(e){return t.ff("geometry").then((function(t){return e.sx(n,o||null,t.spherical.computeHeading,t.spherical.computeOffset,r,i)}))})),o&&e.catch((function(){})),e},Hn=function(e){var n=this;this.tileSize=e.tileSize||new t.Lg(256,256),this.name=e.name,this.alt=e.alt,this.minZoom=e.minZoom,this.maxZoom=e.maxZoom,this.o=(0,t.Ma)(e.getTileUrl,e),this.h=new t.Gh,this.j=null,this.set("opacity",e.opacity),t.ff("map").then((function(e){var o=n.j=e.h,i=n.tileSize||new t.Lg(256,256);n.h.forEach((function(e){var r=e.__gmimt,a=r.rb,s=r.zoom,h=n.o(a,s);(r.Mf=o({oa:a.x,pa:a.y,za:s},i,e,h,(function(){return t.O(e,"load")}))).setOpacity(qn(n))}))}))},qn=function(t){return"number"==typeof(t=t.get("opacity"))?t:1},t.Mj=function(){},t.Nj=function(e,n){this.set("styles",e),e=n||{},this.h=e.baseMapTypeId||"roadmap",this.minZoom=e.minZoom,this.maxZoom=e.maxZoom||20,this.name=e.name,this.alt=e.alt,this.projection=null,this.tileSize=new t.Lg(256,256)},Vn=function(){this.logs=[]},Wn=function(){},Jn=function(t,e){this.setValues(e)},Zn=function(){var e=t.v(Object,"assign").call(Object,{DirectionsTravelMode:t.Rj,DirectionsUnitSystem:t.Sj,FusionTablesLayer:kn,MarkerImage:Nn,NavigationControlStyle:hi,SaveWidget:Jn,ScaleControlStyle:ui,ZoomControlStyle:ci},Mr,Sr,Or,xr,Ir,Pr,Rr);return t.Yd(_t,{Feature:t.Bf,Geometry:K,GeometryCollection:t.Of,LineString:t.Qf,LinearRing:t.Rf,MultiLineString:t.Sf,MultiPoint:t.Tf,MultiPolygon:t.Vf,Point:t.Ne,Polygon:t.Uf}),t.ne(e),e},Yn=function(t){var e=Ur,n=Hr;rt(it.getInstance(),t,e,n)},t.Tj=function(){for(var t,e=Array(36),n=0,o=0;36>o;o++)8==o||13==o||18==o||23==o?e[o]="-":14==o?e[o]="4":(2>=n&&(n=33554432+16777216*Math.random()|0),t=15&n,n>>=4,e[o]=Br[19==o?3&t|8:t]);return e.join("")},t.Uj=function(){this.Un=t.Tj()+t.vaa()},t.Wda=function(t){switch(t){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:return!0;default:return!1}},t.Vj=function(){},Xn=function(){},Kn=function(t){if(!t.o&&"undefined"==typeof XMLHttpRequest&&"undefined"!=typeof ActiveXObject){for(var e=["MSXML2.XMLHTTP.6.0","MSXML2.XMLHTTP.3.0","MSXML2.XMLHTTP","Microsoft.XMLHTTP"],n=0;n<e.length;n++){var o=e[n];try{return new ActiveXObject(o),t.o=o}catch(i){}}throw Error("Could not create ActiveXObject. ActiveX might be disabled, or MSXML might not be installed")}return t.o},t.Xj=function(e){t.di.call(this),this.headers=new t.x.Map,this.Z=e||null,this.j=!1,this.Y=this.h=null,this.N="",this.D=0,this.F="",this.C=this.ba=this.K=this.aa=!1,this.H=0,this.J=null,this.V="",this.ca=this.G=!1},Qn=function(e){return t.Yj&&"number"==typeof e.timeout&&void 0!==e.ontimeout},$n=function(t,e){t.j=!1,t.h&&(t.C=!0,t.h.abort(),t.C=!1),t.F=e,t.D=5,to(t),no(t)},to=function(t){t.aa||(t.aa=!0,t.o("complete"),t.o("error"))},eo=function(e){if(e.j&&void 0!==lo)if(e.Y[1]&&4==t.kk(e)&&2==e.getStatus())e.getStatus();else if(e.K&&4==t.kk(e))t.ni(e.qt,0,e);else if(e.o("readystatechange"),e.Zc()){e.getStatus(),e.j=!1;try{if(t.lk(e))e.o("complete"),e.o("success");else{e.D=6;try{var n=2<t.kk(e)?e.h.statusText:""}catch(o){n=""}e.F=n+" ["+e.getStatus()+"]",to(e)}}finally{no(e)}}},no=function(t,e){if(t.h){oo(t);var n=t.h,o=t.Y[0]?function(){}:null;t.h=null,t.Y=null,e||t.o("ready");try{n.onreadystatechange=o}catch(i){}}},oo=function(e){e.h&&e.ca&&(e.h.ontimeout=null),e.J&&(t.C.clearTimeout(e.J),e.J=null)},t.lk=function(e){var n,o=e.getStatus();return(n=t.Wda(o))||((o=0===o)&&(!(e=t.Wb(String(e.N))[1]||null)&&t.C.self&&t.C.self.location&&(e=t.C.self.location.protocol.slice(0,-1)),o=!Gr.test(e?e.toLowerCase():"")),n=o),n},t.kk=function(t){return t.h?t.h.readyState:0},io=function(e){var n,o=t.C.google.maps,i=ao(),r=so(o),a=t.mg=new W(e);for(t.yg=Math.random()<t.Gd(a.m,1,1),Ai=Math.random(),i&&(t.qg=!0),0===t.E(a.m,13)&&(n=t.rg(153157,{kn:"maps/api/js?"})),t.uj=Mn(t.I(t.J(a.m,5,V).m,1),t.L(a.m,17),t.L(a.m,7),t.L(a.m,14)),t.fea=On(t.I(t.J(a.m,5,V).m,1)),t.mk=xn(),ho(a,(function(e){e.blockedURI&&t.v(e.blockedURI,"includes").call(e.blockedURI,"/maps/api/mapsjs/gen_204?csp_test=true")&&(t.zg(t.C,"Cve"),t.xg(t.C,149596))})),e=0;e<t.E(a.m,9);++e)t.Gi[t.md(a.m,9,e)]=!0;e=t.Id(a),Yn(t.L(e.m,1)),i=Zn(),t.Xd(i,(function(t,e){o[t]=e})),o.version=t.L(e.m,2),setTimeout((function(){t.ff("util").then((function(e){var n;switch(t.td(a.m,43)||e.Yp.h(),e.mw(),r&&(t.zg(window,"Aale"),t.xg(window,155846)),null==(n=t.C.navigator.connection)?void 0:n.effectiveType){case"slow-2g":t.xg(t.C,166473),t.zg(t.C,"Cts2g");break;case"2g":t.xg(t.C,166474),t.zg(t.C,"Ct2g");break;case"3g":t.xg(t.C,166475),t.zg(t.C,"Ct3g");break;case"4g":t.xg(t.C,166476),t.zg(t.C,"Ct4g")}}))}),5e3),rn(t.Ii)||t.ada(),o.importLibrary=function(){return t.Ba((function(){throw Error("google.maps.importLibrary() is not available in this version of the Google Maps JavaScript API. For more details: https://developers.google.com/maps/documentation/javascript/reference/top-level#google.maps.importLibrary")}))},t.Gi[35]&&(o.logger={beginAvailabilityEvent:t.rg,cancelAvailabilityEvent:t.tg,endAvailabilityEvent:t.sg,maybeReportFeatureOnce:t.xg});var s=t.L(a.m,12);if(s){e=[],i=t.E(a.m,13);for(var h=0;h<i;h++)e.push(t.ff(t.md(a.m,13,h)));t.x.Promise.all(e).then((function(){n&&t.sg(n,0),ro(s)()}))}else n&&t.sg(n,0)},ro=function(e){for(var n=e.split("."),o=t.C,i=t.C,r=0;r<n.length;r++)if(i=o,!(o=o[n[r]]))throw t.qe(e+" is not a function");return function(){o.apply(i)}},ao=function(){function e(e,n,o){o=void 0===o?"":o,setTimeout((function(){t.zg(t.C,e,o),t.xg(t.C,n)}),0)}var n,o=!1;for(n in Object.prototype)t.C.console&&t.C.console.error("This site adds property `"+n+"` to Object.prototype. Extending Object.prototype breaks JavaScript for..in loops, which are used heavily in Google Maps JavaScript API v3."),o=!0,e("Ceo",149594);return 42!==t.v(Array,"from").call(Array,new t.x.Set([42]))[0]&&(t.C.console&&t.C.console.error("This site overrides Array.from() with an implementation that doesn't support iterables, which could cause Google Maps JavaScript API v3 to not work correctly."),o=!0,e("Cea",149590)),(n=t.C.Prototype)&&(e("Cep",149595,n.Version),o=!0),(n=t.C.MooTools)&&(e("Cem",149593,n.version),o=!0),(t.ng=[1,2],t.v(t.ng,"values")).call(t.ng)[t.v(t.x.Symbol,"iterator")]||(e("Cei",149591),o=!0),"number"!=typeof Date.now()&&(t.C.console&&t.C.console.error("This site overrides Date.now() with an implementation that doesn't return the number of milliseconds since January 1, 1970 00:00:00 UTC, which could cause Google Maps JavaScript API v3 to not work correctly."),o=!0,e("Ced",149592)),o},so=function(e){return(e="version"in e)&&t.C.console&&t.C.console.error("You have included the Google Maps JavaScript API multiple times on this page. This may cause unexpected errors."),e},ho=function(e,n){if(t.Hd(e)&&t.L(t.Hd(e).m,10))try{document.addEventListener("securitypolicyviolation",n),qr.send(t.L(t.Hd(e).m,10)+"/maps/api/mapsjs/gen_204?csp_test=true")}catch(o){}},t.nk=function(e,n){if(n=void 0===n?"LocationBias":n,"string"==typeof e){if("IP_BIAS"!==e)throw t.qe(n+" of type string was invalid: "+e);return e}if(!e||!t.ie(e))throw t.qe("Invalid "+n+": "+e);if(!(e instanceof t.He||e instanceof t.fg||e instanceof t.Dj))try{e=t.eg(e)}catch(o){try{e=t.Le(e)}catch(i){try{e=new t.Dj((0,t.kea)(e))}catch(r){throw t.qe("Invalid "+n+": "+JSON.stringify(e))}}}if(e instanceof t.Dj){if(!e||!t.ie(e))throw t.qe("Passed Circle is not an Object.");if(e instanceof t.Dj||(e=new t.Dj(e)),!e.getCenter())throw t.qe("Circle is missing center.");if(null==e.getRadius())throw t.qe("Circle is missing radius.")}return e},t.aaa=[],uo="function"==typeof Object.defineProperties?Object.defineProperty:function(t,e,n){return t==Array.prototype||t==Object.prototype||(t[e]=n.value),t},t.ca=n(this),co="function"==typeof Symbol&&"symbol"==typeof Symbol("x"),t.x={},fo={},o("Symbol",(function(t){function e(t,e){this.h=t,uo(this,"description",{configurable:!0,writable:!0,value:e})}if(t)return t;e.prototype.toString=function(){return this.h};var n="jscomp_symbol_"+(1e9*Math.random()>>>0)+"_",o=0;return function t(i){if(this instanceof t)throw new TypeError("Symbol is not a constructor");return new e(n+(i||"")+"_"+o++,i)}}),"es6"),o("Symbol.iterator",(function(n){if(n)return n;n=(0,t.x.Symbol)("Symbol.iterator");for(var o="Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "),r=0;r<o.length;r++){var a=t.ca[o[r]];"function"==typeof a&&"function"!=typeof a.prototype[n]&&uo(a.prototype,n,{configurable:!0,writable:!0,value:function(){return i(e(this))}})}return n}),"es6");var yo=co&&"function"==typeof t.v(Object,"assign")?t.v(Object,"assign"):function(t,e){for(var n=1;n<arguments.length;n++){var o=arguments[n];if(o)for(var i in o)r(o,i)&&(t[i]=o[i])}return t};o("Object.assign",(function(t){return t||yo}),"es6");var vo,mo,bo="function"==typeof Object.create?Object.create:function(t){function e(){}return e.prototype=t,new e},Eo=function(){if(co&&void 0!==t.x.Reflect&&t.v(t.x.Reflect,"construct")){if(function(){function e(){}return new e,t.v(t.x.Reflect,"construct").call(t.x.Reflect,e,[],(function(){})),new e instanceof e}())return t.v(t.x.Reflect,"construct");var e=t.v(t.x.Reflect,"construct");return function(n,o,i){return n=e(n,o),i&&t.v(t.x.Reflect,"setPrototypeOf").call(t.x.Reflect,n,i.prototype),n}}return function(t,e,n){return void 0===n&&(n=t),n=bo(n.prototype||Object.prototype),Function.prototype.apply.call(t,n,e)||n}}();if(co&&"function"==typeof t.v(Object,"setPrototypeOf"))vo=t.v(Object,"setPrototypeOf");else{var wo;t:{var Ao={a:!0},jo={};try{jo.__proto__=Ao,wo=jo.a;break t}catch(No){}wo=!1}vo=wo?function(t,e){if(t.__proto__=e,t.__proto__!==e)throw new TypeError(t+" is not extensible");return t}:null}t.oa=vo,a.prototype.G=function(t){this.j=t},a.prototype.return=function(t){this.D={return:t},this.h=this.H},o("Reflect",(function(t){return t||{}}),"es6"),o("Reflect.construct",(function(){return Eo}),"es6"),o("Reflect.setPrototypeOf",(function(e){return e||(t.oa?function(e,n){try{return(0,t.oa)(e,n),!0}catch(o){return!1}}:null)}),"es6"),o("Promise",(function(e){function n(t){this.h=0,this.o=void 0,this.j=[],this.G=!1;var e=this.C();try{t(e.resolve,e.reject)}catch(n){e.reject(n)}}function o(){this.h=null}function i(t){return t instanceof n?t:new n((function(e){e(t)}))}if(e)return e;o.prototype.j=function(t){if(null==this.h){this.h=[];var e=this;this.o((function(){e.D()}))}this.h.push(t)};var r=t.ca.setTimeout;o.prototype.o=function(t){r(t,0)},o.prototype.D=function(){for(;this.h&&this.h.length;){var t=this.h;this.h=[];for(var e=0;e<t.length;++e){var n=t[e];t[e]=null;try{n()}catch(o){this.C(o)}}}this.h=null},o.prototype.C=function(t){this.o((function(){throw t}))},n.prototype.C=function(){function t(t){return function(o){n||(n=!0,t.call(e,o))}}var e=this,n=!1;return{resolve:t(this.V),reject:t(this.D)}},n.prototype.V=function(t){if(t===this)this.D(new TypeError("A Promise cannot resolve to itself"));else if(t instanceof n)this.Y(t);else{t:switch(typeof t){case"object":var e=null!=t;break t;case"function":e=!0;break t;default:e=!1}e?this.N(t):this.F(t)}},n.prototype.N=function(t){var e=void 0;try{e=t.then}catch(n){return void this.D(n)}"function"==typeof e?this.Z(e,t):this.F(t)},n.prototype.D=function(t){this.H(2,t)},n.prototype.F=function(t){this.H(1,t)},n.prototype.H=function(t,e){if(0!=this.h)throw Error("Cannot settle("+t+", "+e+"): Promise already settled in state"+this.h);this.h=t,this.o=e,2===this.h&&this.X(),this.J()},n.prototype.X=function(){var e=this;r((function(){if(e.K()){var n=t.ca.console;void 0!==n&&n.error(e.o)}}),1)},n.prototype.K=function(){if(this.G)return!1;var e=t.ca.CustomEvent,n=t.ca.Event,o=t.ca.dispatchEvent;return void 0===o||("function"==typeof e?e=new e("unhandledrejection",{cancelable:!0}):"function"==typeof n?e=new n("unhandledrejection",{cancelable:!0}):(e=t.ca.document.createEvent("CustomEvent")).initCustomEvent("unhandledrejection",!1,!0,e),e.promise=this,e.reason=this.o,o(e))},n.prototype.J=function(){if(null!=this.j){for(var t=0;t<this.j.length;++t)a.j(this.j[t]);this.j=null}};var a=new o;return n.prototype.Y=function(t){var e=this.C();t.Zl(e.resolve,e.reject)},n.prototype.Z=function(t,e){var n=this.C();try{t.call(e,n.resolve,n.reject)}catch(o){n.reject(o)}},n.prototype.then=function(t,e){function o(t,e){return"function"==typeof t?function(e){try{i(t(e))}catch(n){r(n)}}:e}var i,r,a=new n((function(t,e){i=t,r=e}));return this.Zl(o(t,i),o(e,r)),a},n.prototype.catch=function(t){return this.then(void 0,t)},n.prototype.Zl=function(t,e){function n(){switch(o.h){case 1:t(o.o);break;case 2:e(o.o);break;default:throw Error("Unexpected state: "+o.h)}}var o=this;null==this.j?a.j(n):this.j.push(n),this.G=!0},n.resolve=i,n.reject=function(t){return new n((function(e,n){n(t)}))},n.race=function(e){return new n((function(n,o){for(var r=t.A(e),a=r.next();!a.done;a=r.next())i(a.value).Zl(n,o)}))},n.all=function(e){var o=t.A(e),r=o.next();return r.done?i([]):new n((function(t,e){function n(e){return function(n){a[e]=n,0==--s&&t(a)}}var a=[],s=0;do{a.push(void 0),s++,i(r.value).Zl(n(a.length-1),e),r=o.next()}while(!r.done)}))},n}),"es6"),o("WeakMap",(function(e){function n(e){if(this.h=(s+=Math.random()+1).toString(),e){e=t.A(e);for(var n;!(n=e.next()).done;)n=n.value,this.set(n[0],n[1])}}function o(){}function i(t){var e=typeof t;return"object"===e&&null!==t||"function"===e}if(function(){if(!e||!Object.seal)return!1;try{var t=Object.seal({}),n=Object.seal({}),o=new e([[t,2],[n,3]]);return 2==o.get(t)&&3==o.get(n)&&(o.delete(t),o.set(n,4),!o.has(t)&&4==o.get(n))}catch(i){return!1}}())return e;var a="$jscomp_hidden_"+Math.random(),s=0;return n.prototype.set=function(t,e){if(!i(t))throw Error("Invalid WeakMap key");if(!r(t,a)){var n=new o;uo(t,a,{value:n})}if(!r(t,a))throw Error("WeakMap key fail: "+t);return t[a][this.h]=e,this},n.prototype.get=function(t){return i(t)&&r(t,a)?t[a][this.h]:void 0},n.prototype.has=function(t){return i(t)&&r(t,a)&&r(t[a],this.h)},n.prototype.delete=function(t){return!!(i(t)&&r(t,a)&&r(t[a],this.h))&&delete t[a][this.h]},n}),"es6"),o("Map",(function(e){function n(){var t={};return t.Zg=t.next=t.head=t}function o(t,e){var n=t.h;return i((function(){if(n){for(;n.head!=t.h;)n=n.Zg;for(;n.next!=n.head;)return n=n.next,{done:!1,value:e(n)};n=null}return{done:!0,value:void 0}}))}function a(t,e){var n=e&&typeof e;"object"==n||"function"==n?h.has(e)?n=h.get(e):(n=""+ ++u,h.set(e,n)):n="p_"+e;var o=t.j[n];if(o&&r(t.j,n))for(t=0;t<o.length;t++){var i=o[t];if(e!=e&&i.key!=i.key||e===i.key)return{id:n,list:o,index:t,zd:i}}return{id:n,list:o,index:-1,zd:void 0}}function s(e){if(this.j={},this.h=n(),this.size=0,e){e=t.A(e);for(var o;!(o=e.next()).done;)o=o.value,this.set(o[0],o[1])}}if(function(){if(!e||"function"!=typeof e||!t.v(e.prototype,"entries")||"function"!=typeof Object.seal)return!1;try{var n=Object.seal({x:4}),o=new e(t.A([[n,"s"]]));if("s"!=o.get(n)||1!=o.size||o.get({x:4})||o.set({x:4},"t")!=o||2!=o.size)return!1;var i=t.v(o,"entries").call(o),r=i.next();return!r.done&&r.value[0]==n&&"s"==r.value[1]&&!((r=i.next()).done||4!=r.value[0].x||"t"!=r.value[1]||!i.next().done)}catch(a){return!1}}())return e;var h=new t.x.WeakMap;s.prototype.set=function(t,e){var n=a(this,t=0===t?0:t);return n.list||(n.list=this.j[n.id]=[]),n.zd?n.zd.value=e:(n.zd={next:this.h,Zg:this.h.Zg,head:this.h,key:t,value:e},n.list.push(n.zd),this.h.Zg.next=n.zd,this.h.Zg=n.zd,this.size++),this},s.prototype.delete=function(t){return!(!(t=a(this,t)).zd||!t.list)&&(t.list.splice(t.index,1),t.list.length||delete this.j[t.id],t.zd.Zg.next=t.zd.next,t.zd.next.Zg=t.zd.Zg,t.zd.head=null,this.size--,!0)},s.prototype.clear=function(){this.j={},this.h=this.h.Zg=n(),this.size=0},s.prototype.has=function(t){return!!a(this,t).zd},s.prototype.get=function(t){return(t=a(this,t).zd)&&t.value},s.prototype.entries=function(){return o(this,(function(t){return[t.key,t.value]}))},s.prototype.keys=function(){return o(this,(function(t){return t.key}))},s.prototype.values=function(){return o(this,(function(t){return t.value}))},s.prototype.forEach=function(e,n){for(var o,i=t.v(this,"entries").call(this);!(o=i.next()).done;)o=o.value,e.call(n,o[1],o[0],this)},s.prototype[t.v(t.x.Symbol,"iterator")]=t.v(s.prototype,"entries");var u=0;return s}),"es6"),o("String.prototype.endsWith",(function(t){return t||function(t,e){var n=p(this,t,"endsWith");t+="",void 0===e&&(e=n.length),e=Math.max(0,Math.min(0|e,n.length));for(var o=t.length;0<o&&0<e;)if(n[--e]!=t[--o])return!1;return 0>=o}}),"es6"),o("Array.prototype.find",(function(t){return t||function(t,e){t:{var n=this;n instanceof String&&(n=String(n));for(var o=n.length,i=0;i<o;i++){var r=n[i];if(t.call(e,r,i,n)){t=r;break t}}t=void 0}return t}}),"es6"),o("String.prototype.startsWith",(function(t){return t||function(t,e){var n=p(this,t,"startsWith");t+="";var o=n.length,i=t.length;e=Math.max(0,Math.min(0|e,n.length));for(var r=0;r<i&&e<o;)if(n[e++]!=t[r++])return!1;return r>=i}}),"es6"),o("Number.isFinite",(function(t){return t||function(t){return"number"==typeof t&&(!isNaN(t)&&1/0!==t&&-1/0!==t)}}),"es6"),o("String.prototype.repeat",(function(t){return t||function(t){var e=p(this,null,"repeat");if(0>t||1342177279<t)throw new RangeError("Invalid count value");t|=0;for(var n="";t;)1&t&&(n+=e),(t>>>=1)&&(e+=e);return n}}),"es6"),o("Array.prototype.keys",(function(t){return t||function(){return g(this,(function(t){return t}))}}),"es6"),o("Object.setPrototypeOf",(function(e){return e||t.oa}),"es6"),o("Set",(function(e){function n(e){if(this.W=new t.x.Map,e){e=t.A(e);for(var n;!(n=e.next()).done;)this.add(n.value)}this.size=this.W.size}return function(){if(!e||"function"!=typeof e||!t.v(e.prototype,"entries")||"function"!=typeof Object.seal)return!1;try{var n=Object.seal({x:4}),o=new e(t.A([n]));if(!o.has(n)||1!=o.size||o.add(n)!=o||1!=o.size||o.add({x:4})!=o||2!=o.size)return!1;var i=t.v(o,"entries").call(o),r=i.next();return!r.done&&r.value[0]==n&&r.value[1]==n&&(!(r=i.next()).done&&r.value[0]!=n&&4==r.value[0].x&&r.value[1]==r.value[0]&&i.next().done)}catch(a){return!1}}()?e:(n.prototype.add=function(t){return t=0===t?0:t,this.W.set(t,t),this.size=this.W.size,this},n.prototype.delete=function(t){return t=this.W.delete(t),this.size=this.W.size,t},n.prototype.clear=function(){this.W.clear(),this.size=0},n.prototype.has=function(t){return this.W.has(t)},n.prototype.entries=function(){return t.v(this.W,"entries").call(this.W)},n.prototype.values=function(){return t.v(this.W,"values").call(this.W)},n.prototype.keys=t.v(n.prototype,"values"),n.prototype[t.v(t.x.Symbol,"iterator")]=t.v(n.prototype,"values"),n.prototype.forEach=function(t,e){var n=this;this.W.forEach((function(o){return t.call(e,o,o,n)}))},n)}),"es6"),o("Array.from",(function(e){return e||function(e,n,o){n=null!=n?n:function(t){return t};var i=[],r=void 0!==t.x.Symbol&&t.v(t.x.Symbol,"iterator")&&e[t.v(t.x.Symbol,"iterator")];if("function"==typeof r){e=r.call(e);for(var a=0;!(r=e.next()).done;)i.push(n.call(o,r.value,a++))}else for(r=e.length,a=0;a<r;a++)i.push(n.call(o,e[a],a));return i}}),"es6"),o("Object.entries",(function(t){return t||function(t){var e,n=[];for(e in t)r(t,e)&&n.push([e,t[e]]);return n}}),"es8"),o("Number.MAX_SAFE_INTEGER",(function(){return 9007199254740991}),"es6"),o("Number.isInteger",(function(e){return e||function(e){return!!t.v(Number,"isFinite").call(Number,e)&&e===Math.floor(e)}}),"es6"),o("Math.log10",(function(t){return t||function(t){return Math.log(t)/Math.LN10}}),"es6"),o("Math.sign",(function(t){return t||function(t){return 0===(t=Number(t))||isNaN(t)?t:0<t?1:-1}}),"es6"),o("Number.isNaN",(function(t){return t||function(t){return"number"==typeof t&&isNaN(t)}}),"es6"),o("Array.prototype.entries",(function(t){return t||function(){return g(this,(function(t,e){return[t,e]}))}}),"es6"),o("Object.is",(function(t){return t||function(t,e){return t===e?0!==t||1/t==1/e:t!=t&&e!=e}}),"es6"),o("Array.prototype.includes",(function(e){return e||function(e,n){var o=this;o instanceof String&&(o=String(o));var i=o.length;for(0>(n=n||0)&&(n=Math.max(n+i,0));n<i;n++){var r=o[n];if(r===e||t.v(Object,"is").call(Object,r,e))return!0}return!1}}),"es7"),o("String.prototype.includes",(function(t){return t||function(t,e){return-1!==p(this,t,"includes").indexOf(t,e||0)}}),"es6"),o("Object.values",(function(t){return t||function(t){var e,n=[];for(e in t)r(t,e)&&n.push(t[e]);return n}}),"es8"),o("Array.prototype.values",(function(t){return t||function(){return g(this,(function(t,e){return e}))}}),"es8"),o("Math.trunc",(function(t){return t||function(t){if(t=Number(t),isNaN(t)||1/0===t||-1/0===t||0===t)return t;var e=Math.floor(Math.abs(t));return 0>t?-e:e}}),"es6"),o("WeakSet",(function(e){function n(e){if(this.W=new t.x.WeakMap,e){e=t.A(e);for(var n;!(n=e.next()).done;)this.add(n.value)}}return function(){if(!e||!Object.seal)return!1;try{var t=Object.seal({}),n=Object.seal({}),o=new e([t]);return!(!o.has(t)||o.has(n))&&(o.delete(t),o.add(n),!o.has(t)&&o.has(n))}catch(i){return!1}}()?e:(n.prototype.add=function(t){return this.W.set(t,!0),this},n.prototype.has=function(t){return this.W.has(t)},n.prototype.delete=function(t){return this.W.delete(t)},n)}),"es6"),o("Array.prototype.fill",(function(t){return t||function(t,e,n){var o=this.length||0;for(0>e&&(e=Math.max(0,o+e)),(null==n||n>o)&&(n=o),0>(n=Number(n))&&(n=Math.max(0,o+n)),e=Number(e||0);e<n;e++)this[e]=t;return this}}),"es6"),o("Int8Array.prototype.fill",d,"es6"),o("Uint8Array.prototype.fill",d,"es6"),o("Uint8ClampedArray.prototype.fill",d,"es6"),o("Int16Array.prototype.fill",d,"es6"),o("Uint16Array.prototype.fill",d,"es6"),o("Int32Array.prototype.fill",d,"es6"),o("Uint32Array.prototype.fill",d,"es6"),o("Float32Array.prototype.fill",d,"es6"),o("Float64Array.prototype.fill",d,"es6"),o("Math.hypot",(function(t){return t||function(t){if(2>arguments.length)return arguments.length?Math.abs(arguments[0]):0;var e,n,o;for(e=o=0;e<arguments.length;e++)o=Math.max(o,Math.abs(arguments[e]));if(1e100<o||1e-100>o){if(!o)return o;for(e=n=0;e<arguments.length;e++){var i=Number(arguments[e])/o;n+=i*i}return Math.sqrt(n)*o}for(e=n=0;e<arguments.length;e++)n+=(i=Number(arguments[e]))*i;return Math.sqrt(n)}}),"es6"),o("Math.log2",(function(t){return t||function(t){return Math.log(t)/Math.LN2}}),"es6"),o("Math.log1p",(function(t){return t||function(t){if(.25>(t=Number(t))&&-.25<t){for(var e=t,n=1,o=t,i=0,r=1;i!=o;)o=(i=o)+(r*=-1)*(e*=t)/++n;return o}return Math.log(1+t)}}),"es6"),o("Math.expm1",(function(t){return t||function(t){if(.25>(t=Number(t))&&-.25<t){for(var e=t,n=1,o=t,i=0;i!=o;)o=(i=o)+(e*=t/++n);return o}return Math.exp(t)-1}}),"es6"),o("Array.prototype.flat",(function(e){return e||function(e){e=void 0===e?1:e;for(var n=[],o=0;o<this.length;o++){var i=this[o];Array.isArray(i)&&0<e?(i=t.v(Array.prototype,"flat").call(i,e-1),n.push.apply(n,i)):n.push(i)}return n}}),"es9"),o("Object.fromEntries",(function(e){return e||function(e){var n={};if(!(t.v(t.x.Symbol,"iterator")in e))throw new TypeError(e+" is not iterable");for(var o=(e=e[t.v(t.x.Symbol,"iterator")].call(e)).next();!o.done;o=e.next()){if(o=o.value,Object(o)!==o)throw new TypeError("iterable for fromEntries should yield objects");n[o[0]]=o[1]}return n}}),"es_2019"),o("Array.prototype.flatMap",(function(t){return t||function(t,e){for(var n=[],o=0;o<this.length;o++){var i=t.call(e,this[o],o,this);Array.isArray(i)?n.push.apply(n,i):n.push(i)}return n}}),"es9"),lo=lo||{},t.C=this||self,po="closure_uid_"+(1e9*Math.random()>>>0),go=0,t.Pa(t.Ra,Error),t.Ra.prototype.name="CustomError",t.Ua.prototype.Qg=!0,t.Ua.prototype.Jc=t.aa(5);var Lo={},To={};t.Xa.prototype.toString=function(){return this.h+""},t.Xa.prototype.Qg=!0,t.Xa.prototype.Jc=t.aa(4);var _o,Co,Mo={},So="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");t.ob.prototype.toString=function(){return this.h.toString()},t.ob.prototype.Qg=!0,t.ob.prototype.Jc=t.aa(3),t.pea=RegExp('^(?:audio/(?:3gpp2|3gpp|aac|L16|midi|mp3|mp4|mpeg|oga|ogg|opus|x-m4a|x-matroska|x-wav|wav|webm)|font/\\w+|image/(?:bmp|gif|jpeg|jpg|png|tiff|webp|x-icon|heic|heif)|video/(?:mpeg|mp4|ogg|webm|quicktime|x-matroska))(?:;\\w+=(?:\\w+|"[\\w;,= ]+"))*$',"i");try{new URL("s://g"),_o=!0}catch(No){_o=!1}t.qea=_o,Co={},t.rea=t.pb("about:invalid#zClosurez"),t.qb={},t.sb.prototype.Jc=t.aa(2),t.sb.prototype.toString=function(){return this.h.toString()},t.sea=new t.sb("",t.qb),t.tea=RegExp("^[-+,.\"'%_!#/ a-zA-Z0-9\\[\\]]+$"),t.uea=RegExp("\\b(url\\([ \t\n]*)('[ -&(-\\[\\]-~]*'|\"[ !#-\\[\\]-~]*\"|[!#-&*-\\[\\]-~]*)([ \t\n]*\\))","g"),t.vea=RegExp("\\b(calc|cubic-bezier|fit-content|hsl|hsla|linear-gradient|matrix|minmax|radial-gradient|repeat|rgb|rgba|(rotate|scale|translate)(X|Y|Z|3d)?|steps|var)\\([-+*/0-9a-zA-Z.%#\\[\\], ]+\\)","g"),t.tb={},t.ub.prototype.toString=function(){return this.h.toString()},t.ub.prototype.Jc=t.aa(1),t.wea=new t.ub("",t.tb);var Oo={};t.Rb.prototype.Jc=t.aa(0),t.Rb.prototype.toString=function(){return this.h.toString()};var xo=new t.Rb(t.C.trustedTypes&&t.C.trustedTypes.emptyHTML||"",Oo);t.yea=b((function(){var e=document.createElement("div"),n=document.createElement("div");return n.appendChild(document.createElement("div")),e.appendChild(n),n=e.firstChild.firstChild,e.innerHTML=t.Sb(xo),!n.parentElement}));var Io,Po,Ro,No,Do,ko,Fo,Uo,Bo,Go,zo,Ho=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");w[" "]=function(){},t.zea=t.Bb(),t.Yj=t.Cb(),Io=t.Ab("Edge"),t.Nh=t.Ab("Gecko")&&!t.ac()&&!(t.Ab("Trident")||t.Ab("MSIE"))&&!t.Ab("Edge"),t.Oh=t.ac(),t.Bea=t.Ab("Macintosh"),t.rk=t.$b(),t.Cea=t.Ab("Linux")||t.Ab("CrOS"),t.Dea=t.Ab("Android"),t.Eea=t.Yb(),t.Fea=t.Ab("iPad"),t.Gea=t.Ab("iPod");t:{var qo="",Vo=(No=t.zb(),t.Nh?/rv:([^\);]+)(\)|;)/.exec(No):Io?/Edge\/([\d\.]+)/.exec(No):t.Yj?/\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(No):t.Oh?/WebKit\/(\S+)/.exec(No):t.zea?/(?:Version)[ \/]?(\S+)/.exec(No):void 0);if(Vo&&(qo=Vo?Vo[1]:""),t.Yj){var Wo=A();if(null!=Wo&&Wo>parseFloat(qo)){Po=String(Wo);break t}}Po=qo}if(t.Hea=Po,t.C.document&&t.Yj){var Jo=A();Ro=Jo||(parseInt(t.Hea,10)||void 0)}else Ro=void 0;if(t.Jea=Ro,t.Kea=t.Gb(),t.Lea=t.Yb()||t.Ab("iPod"),t.Mea=t.Ab("iPad"),t.Lb(),t.Nea=t.Jb(),t.xk=t.Kb()&&!(t.Yb()||t.Ab("iPad")||t.Ab("iPod")),Do={},t.ec=null,ko=t.Nh||t.Oh,t.Pea=ko||"function"==typeof t.C.btoa,t.Qea=ko||!t.xk&&!t.Yj&&"function"==typeof t.C.atob,t.Rea="undefined"!=typeof Uint8Array,t.Sea=!t.Yj&&"function"==typeof t.C.btoa,t.Tea=RegExp("[-_.]","g"),t.Uea="function"==typeof Uint8Array.prototype.slice,t.yk="function"==typeof BigInt,t.Vea="undefined"!=typeof TextDecoder,t.Wea="undefined"!=typeof TextEncoder,"function"==typeof t.x.Symbol&&"symbol"==typeof(0,t.x.Symbol)()){var Zo=(0,t.x.Symbol)(void 0),Yo=(0,t.x.Symbol)(void 0),Xo=(0,t.x.Symbol)(void 0),Ko=(0,t.x.Symbol)(void 0),Qo=(0,t.x.Symbol)(void 0);t.Lc=function(e,n){e[Zo]=(0,t.Kc)(e)|n},t.Kc=function(t){return t[Zo]||0},t.xc=function(t,e,n,o){t[Yo]=e,t[Qo]=n,t[Xo]=o,t[Ko]=void 0},t.Gc=function(t){return null!=t[Yo]},t.zc=function(t){return t[Yo]},Fo=function(t,e){t[Yo]=e},t.Ic=function(t){return t[Xo]},t.Pc=function(t,e){t[Xo]=e},t.Tc=function(t){return t[Ko]},Uo=function(t,e){t[Ko]=e},t.Bd=function(t){return t[Qo]},Bo=function(e,n){return(0,t.Gc)(e),e[Qo]=n}}else t.Lc=j,t.Kc=L,t.xc=T,t.Gc=_,t.zc=C,Fo=M,t.Ic=S,t.Pc=O,t.Tc=x,Uo=I,t.Bd=P,Bo=R;t.ic.prototype.Vl=t.aa(7),t.ic.prototype.fo=t.aa(8),t.ic.prototype.isEmpty=function(){return null!=this.mf&&!this.mf.byteLength||null!=this.zj&&!this.zj.length},Go=[,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,14,13,,0,12,1,4,5,6,9,9,,17,8,11,11,3,5,15,,7,10,10,2,3,15],t.Jh="dfxyghiunjvoebBsmm".split(""),t.pc.prototype.qq=t.aa(9),t.B(t.sc,t.pc),t.B(t.tc,t.pc),t.Yea=Object.freeze([]),t.Xc.prototype[t.v(t.x.Symbol,"iterator")]=function(){return this.h()},t.Zc.prototype.equals=function(e){return this===e||e instanceof t.Zc&&(this.yf===e.yf&&this.Fe===e.Fe)},t.fd="function"==typeof BigInt,t.Dk=(0,t.x.Symbol)(void 0),t.qd=null,F.prototype.fields=function(){var e={};return U(this,(function(n){e[n.ac]=t.v(Object,"assign").call(Object,{},n)})),e};var $o,ti,ei=Object.create(null),ni=RegExp("(\\d+)","g");t.n=t.F.prototype,t.n.clear=function(){this.m.length=0,t.wc(this.m)},t.n.clone=function(){var e=new this.constructor;return t.Hc(e.m,this.m),e},t.n.equals=function(e){var n=e&&e.m;return!!n&&(this===e||(e=this.m,(0,t.Vc)(n),(0,t.Vc)(e),G(e,n)))},t.n.Ib=t.aa(10),t.n.toArray=function(){var e=this.m;return(0,t.Vc)(e),e},t.B(H,t.F),t.B(q,t.F),t.B(V,t.F),t.B(t.Fd,t.F),t.Fd.prototype.getStatus=function(){return t.I(this.m,1)},t.B(W,t.F),t.Zea={ROADMAP:"roadmap",SATELLITE:"satellite",HYBRID:"hybrid",TERRAIN:"terrain"},t.B(J,Error),t.B(t.Nd,J),t.B(t.Od,J);try{new URL("s://g"),ti=!0}catch(No){ti=!1}t.$ea=ti,t.B(t.pe,Error),t.pe.prototype.captureStackTrace=function(){this.stack=Error().stack};var oi,ii,ri,ai=!0;t.Zf=t.Ae(t.he,"not a number"),oi=t.Ce(t.Zf,(function(e){if(isNaN(e))throw t.qe("NaN is not an accepted value");return e})),t.Ig=t.Ce(t.Zf,(function(e){if(isFinite(e))return e;throw t.qe(e+" is not an accepted value")})),ii=t.Ce(t.Zf,(function(e){if(0<=e)return e;throw t.qe(e+" is a negative number value")})),t.Gk=t.Ae(t.ke,"not a string"),ri=t.Ae(t.aba,"not a boolean"),t.afa=t.Ae((function(t){return"function"==typeof t}),"not a function"),t.Hg=t.De(t.Zf),t.Ik=t.De(t.Gk),t.Jk=t.De(ri),t.Kk=t.Ce(t.Gk,(function(e){if(0<e.length)return e;throw t.qe("empty string is not an accepted value")})),t.Mi={TOP_LEFT:1,TOP_CENTER:2,TOP:2,TOP_RIGHT:3,LEFT_CENTER:4,LEFT_TOP:5,LEFT:5,LEFT_BOTTOM:6,RIGHT_TOP:7,RIGHT:7,RIGHT_CENTER:8,RIGHT_BOTTOM:9,BOTTOM_LEFT:10,BOTTOM_CENTER:11,BOTTOM:11,BOTTOM_RIGHT:12,CENTER:13};var si,hi={DEFAULT:0,SMALL:1,ANDROID:2,ZOOM_PAN:3,BB:4,rv:5},ui={DEFAULT:0},ci={DEFAULT:0,SMALL:1,LARGE:2,rv:3},fi=t.we({lat:t.Zf,lng:t.Zf},!0),li=t.we({lat:t.Ig,lng:t.Ig},!0);t.He.prototype.toString=function(){return"("+this.lat()+", "+this.lng()+")"},t.He.prototype.toString=t.He.prototype.toString,t.He.prototype.toJSON=function(){return{lat:this.lat(),lng:this.lng()}},t.He.prototype.toJSON=t.He.prototype.toJSON,t.He.prototype.equals=function(e){return!!e&&(t.ae(this.lat(),e.lat())&&t.ae(this.lng(),e.lng()))},t.He.prototype.equals=t.He.prototype.equals,t.He.prototype.equals=t.He.prototype.equals,t.He.prototype.toUrlValue=function(t){return t=void 0!==t?t:6,Q(this.lat(),t)+","+Q(this.lng(),t)},t.He.prototype.toUrlValue=t.He.prototype.toUrlValue,t.Pf=t.ze(t.Le),si=t.ze(t.Me),t.Pa(t.Ne,K),t.Ne.prototype.getType=function(){return"Point"},t.Ne.prototype.getType=t.Ne.prototype.getType,t.Ne.prototype.forEachLatLng=function(t){t(this.h)},t.Ne.prototype.forEachLatLng=t.Ne.prototype.forEachLatLng,t.Ne.prototype.get=function(){return this.h},t.Ne.prototype.get=t.Ne.prototype.get;var pi,gi=t.ze($);t:{try{pi=!!new self.OffscreenCanvas(0,0).getContext("2d");break t}catch(No){}pi=!1}t.bfa=pi,t.$e.prototype.kb=t.aa(11),t.$e.prototype.appendChild=function(t,e){t.appendChild(e)},t.$e.prototype.contains=t.Ze,et.prototype.rm=function(t,e,n){if(this.j){var o=tt(this.j.replace("%s",t));nt(this.h,o)}t=tt(this.o.replace("%s",t)),nt(this.h,t,e,n)},it.prototype.Ih=function(t,e){at(this,t).Fy=e,this.F.add(t),st(this,t)},it.getInstance=function(){return t.cf(it)},t.mf.trigger=t.O,t.mf.addListenerOnce=t.zf,t.mf.addDomListenerOnce=function(e,n,o,i){return t.xf(e,n,o,i)},t.mf.addDomListener=function(e,n,o,i){return t.wf(e,n,o,i)},t.mf.clearInstanceListeners=t.uf,t.mf.clearListeners=t.tf,t.mf.removeListener=t.rf,t.mf.hasListeners=dt,t.mf.addListener=t.N,t.nf.prototype.remove=function(){if(this.instance){if(this.instance.removeEventListener)switch(this.j){case 1:this.instance.removeEventListener(this.h,this.De,!1);break;case 4:this.instance.removeEventListener(this.h,this.De,!0)}delete yt(this.instance,this.h)[this.id],this.Wp&&t.O(this.instance,this.h+"_removed"),this.De=this.instance=null}};var di=0;t.Bf.prototype.getId=function(){return this.o},t.Bf.prototype.getId=t.Bf.prototype.getId,t.Bf.prototype.getGeometry=function(){return this.h},t.Bf.prototype.getGeometry=t.Bf.prototype.getGeometry,t.Bf.prototype.setGeometry=function(e){var n=this.h;try{this.h=e?$(e):null}catch(o){return void t.re(o)}t.O(this,"setgeometry",{feature:this,newGeometry:this.h,oldGeometry:n})},t.Bf.prototype.setGeometry=t.Bf.prototype.setGeometry,t.Bf.prototype.getProperty=function(t){return Z(this.j,t)},t.Bf.prototype.getProperty=t.Bf.prototype.getProperty,t.Bf.prototype.setProperty=function(e,n){if(void 0===n)this.removeProperty(e);else{var o=this.getProperty(e);this.j[e]=n,t.O(this,"setproperty",{feature:this,name:e,newValue:n,oldValue:o})}},t.Bf.prototype.setProperty=t.Bf.prototype.setProperty,t.Bf.prototype.removeProperty=function(e){var n=this.getProperty(e);delete this.j[e],t.O(this,"removeproperty",{feature:this,name:e,oldValue:n})},t.Bf.prototype.removeProperty=t.Bf.prototype.removeProperty,t.Bf.prototype.forEachProperty=function(t){for(var e in this.j)t(this.getProperty(e),e)},t.Bf.prototype.forEachProperty=t.Bf.prototype.forEachProperty,t.Bf.prototype.toGeoJson=function(e){var n=this;t.ff("data").then((function(t){t.Ww(n,e)}))},t.Bf.prototype.toGeoJson=t.Bf.prototype.toGeoJson;var yi={CIRCLE:0,FORWARD_CLOSED_ARROW:1,FORWARD_OPEN_ARROW:2,BACKWARD_CLOSED_ARROW:3,BACKWARD_OPEN_ARROW:4};t.P.prototype.get=function(e){var n=bt(this);if(void 0!==(n=Z(n,e+=""))){if(n){e=n.Bf,n=n.Kj;var o="get"+t.Jf(e);return n[o]?n[o]():n.get(e)}return this[e]}},t.P.prototype.get=t.P.prototype.get,t.P.prototype.set=function(e,n){var o=bt(this),i=Z(o,e+="");i?(e=i.Bf,(i=i.Kj)[o="set"+t.Jf(e)]?i[o](n):i.set(e,n)):(this[e]=n,o[e]=null,mt(this,e))},t.P.prototype.set=t.P.prototype.set,t.P.prototype.notify=function(t){var e=bt(this);(e=Z(e,t+=""))?e.Kj.notify(e.Bf):mt(this,t)},t.P.prototype.notify=t.P.prototype.notify,t.P.prototype.setValues=function(e){for(var n in e){var o=e[n],i="set"+t.Jf(n);this[i]?this[i](o):this.set(n,o)}},t.P.prototype.setValues=t.P.prototype.setValues,t.P.prototype.setOptions=t.P.prototype.setValues,t.P.prototype.changed=function(){};var vi={};t.P.prototype.bindTo=function(e,n,o,i){e+="",o=(o||e)+"",this.unbind(e);var r={Kj:this,Bf:e},a={Kj:n,Bf:o,Zq:r};bt(this)[e]=a,Et(n,o)[t.Cf(r)]=r,i||mt(this,e)},t.P.prototype.bindTo=t.P.prototype.bindTo,t.P.prototype.unbind=function(e){var n=bt(this),o=n[e];o&&(o.Zq&&delete Et(o.Kj,o.Bf)[t.Cf(o.Zq)],this[e]=this.get(e),n[e]=null)},t.P.prototype.unbind=t.P.prototype.unbind,t.P.prototype.unbindAll=function(){var e,n=(0,t.Ma)(this.unbind,this),o=bt(this);for(e in o)n(e)},t.P.prototype.unbindAll=t.P.prototype.unbindAll,t.P.prototype.addListener=function(e,n){return t.N(this,e,n)},t.P.prototype.addListener=t.P.prototype.addListener,t.Pa(t.Lf,t.P),t.dfa=t.Lf.DEMO_MAP_ID="DEMO_MAP_ID";var mi={zB:"Point",vB:"LineString",POLYGON:"Polygon"};t.n=wt.prototype,t.n.contains=function(e){return this.h.hasOwnProperty(t.Cf(e))},t.n.getFeatureById=function(t){return Z(this.j,t)},t.n.add=function(e){if(e=(e=e||{})instanceof t.Bf?e:new t.Bf(e),!this.contains(e)){var n=e.getId();if(n||0===n){var o=this.getFeatureById(n);o&&this.remove(o)}o=t.Cf(e),this.h[o]=e,(n||0===n)&&(this.j[n]=e);var i=t.Af(e,"setgeometry",this),r=t.Af(e,"setproperty",this),a=t.Af(e,"removeproperty",this);this.o[o]=function(){t.rf(i),t.rf(r),t.rf(a)},t.O(this,"addfeature",{feature:e})}return e},t.n.remove=function(e){var n=t.Cf(e),o=e.getId();this.h[n]&&(delete this.h[n],o&&delete this.j[o],(o=this.o[n])&&(delete this.o[n],o()),t.O(this,"removefeature",{feature:e}))},t.n.forEach=function(t){for(var e in this.h)t(this.h[e])},t.kg="click dblclick mousedown mousemove mouseout mouseover mouseup rightclick contextmenu".split(" "),At.prototype.get=function(t){return this.h[t]},At.prototype.set=function(e,n){var o=this.h;o[e]||(o[e]={}),t.Yd(o[e],n),t.O(this,"changed",e)},At.prototype.reset=function(e){delete this.h[e],t.O(this,"changed",e)},At.prototype.forEach=function(e){t.Xd(this.h,e)},t.Pa(jt,t.P),jt.prototype.overrideStyle=function(e,n){this.h.set(t.Cf(e),n)},jt.prototype.revertStyle=function(e){e?this.h.reset(t.Cf(e)):this.h.forEach((0,t.Ma)(this.h.reset,this.h))},t.Pa(t.Of,K),t.Of.prototype.getType=function(){return"GeometryCollection"},t.Of.prototype.getType=t.Of.prototype.getType,t.Of.prototype.getLength=function(){return this.h.length},t.Of.prototype.getLength=t.Of.prototype.getLength,t.Of.prototype.getAt=function(t){return this.h[t]},t.Of.prototype.getAt=t.Of.prototype.getAt,t.Of.prototype.getArray=function(){return this.h.slice()},t.Of.prototype.getArray=t.Of.prototype.getArray,t.Of.prototype.forEachLatLng=function(t){this.h.forEach((function(e){e.forEachLatLng(t)}))},t.Of.prototype.forEachLatLng=t.Of.prototype.forEachLatLng,t.Pa(t.Qf,K),t.Qf.prototype.getType=function(){return"LineString"},t.Qf.prototype.getType=t.Qf.prototype.getType,t.Qf.prototype.getLength=function(){return this.h.length},t.Qf.prototype.getLength=t.Qf.prototype.getLength,t.Qf.prototype.getAt=function(t){return this.h[t]},t.Qf.prototype.getAt=t.Qf.prototype.getAt,t.Qf.prototype.getArray=function(){return this.h.slice()},t.Qf.prototype.getArray=t.Qf.prototype.getArray,t.Qf.prototype.forEachLatLng=function(t){this.h.forEach(t)},t.Qf.prototype.forEachLatLng=t.Qf.prototype.forEachLatLng;var bi=t.ze(t.xe(t.Qf,"google.maps.Data.LineString",!0));t.Pa(t.Rf,K),t.Rf.prototype.getType=function(){return"LinearRing"},t.Rf.prototype.getType=t.Rf.prototype.getType,t.Rf.prototype.getLength=function(){return this.h.length},t.Rf.prototype.getLength=t.Rf.prototype.getLength,t.Rf.prototype.getAt=function(t){return this.h[t]},t.Rf.prototype.getAt=t.Rf.prototype.getAt,t.Rf.prototype.getArray=function(){return this.h.slice()},t.Rf.prototype.getArray=t.Rf.prototype.getArray,t.Rf.prototype.forEachLatLng=function(t){this.h.forEach(t)},t.Rf.prototype.forEachLatLng=t.Rf.prototype.forEachLatLng;var Ei=t.ze(t.xe(t.Rf,"google.maps.Data.LinearRing",!0));t.Pa(t.Sf,K),t.Sf.prototype.getType=function(){return"MultiLineString"},t.Sf.prototype.getType=t.Sf.prototype.getType,t.Sf.prototype.getLength=function(){return this.h.length},t.Sf.prototype.getLength=t.Sf.prototype.getLength,t.Sf.prototype.getAt=function(t){return this.h[t]},t.Sf.prototype.getAt=t.Sf.prototype.getAt,t.Sf.prototype.getArray=function(){return this.h.slice()},t.Sf.prototype.getArray=t.Sf.prototype.getArray,t.Sf.prototype.forEachLatLng=function(t){this.h.forEach((function(e){e.forEachLatLng(t)}))},t.Sf.prototype.forEachLatLng=t.Sf.prototype.forEachLatLng,t.Pa(t.Tf,K),t.Tf.prototype.getType=function(){return"MultiPoint"},t.Tf.prototype.getType=t.Tf.prototype.getType,t.Tf.prototype.getLength=function(){return this.h.length},t.Tf.prototype.getLength=t.Tf.prototype.getLength,t.Tf.prototype.getAt=function(t){return this.h[t]},t.Tf.prototype.getAt=t.Tf.prototype.getAt,t.Tf.prototype.getArray=function(){return this.h.slice()},t.Tf.prototype.getArray=t.Tf.prototype.getArray,t.Tf.prototype.forEachLatLng=function(t){this.h.forEach(t)},t.Tf.prototype.forEachLatLng=t.Tf.prototype.forEachLatLng,t.Pa(t.Uf,K),t.Uf.prototype.getType=function(){return"Polygon"},t.Uf.prototype.getType=t.Uf.prototype.getType,t.Uf.prototype.getLength=function(){return this.h.length},t.Uf.prototype.getLength=t.Uf.prototype.getLength,t.Uf.prototype.getAt=function(t){return this.h[t]},t.Uf.prototype.getAt=t.Uf.prototype.getAt,t.Uf.prototype.getArray=function(){return this.h.slice()},t.Uf.prototype.getArray=t.Uf.prototype.getArray,t.Uf.prototype.forEachLatLng=function(t){this.h.forEach((function(e){e.forEachLatLng(t)}))},t.Uf.prototype.forEachLatLng=t.Uf.prototype.forEachLatLng;var wi=t.ze(t.xe(t.Uf,"google.maps.Data.Polygon",!0));t.Pa(t.Vf,K),t.Vf.prototype.getType=function(){return"MultiPolygon"},t.Vf.prototype.getType=t.Vf.prototype.getType,t.Vf.prototype.getLength=function(){return this.h.length},t.Vf.prototype.getLength=t.Vf.prototype.getLength,t.Vf.prototype.getAt=function(t){return this.h[t]},t.Vf.prototype.getAt=t.Vf.prototype.getAt,t.Vf.prototype.getArray=function(){return this.h.slice()},t.Vf.prototype.getArray=t.Vf.prototype.getArray,t.Vf.prototype.forEachLatLng=function(t){this.h.forEach((function(e){e.forEachLatLng(t)}))},t.Vf.prototype.forEachLatLng=t.Vf.prototype.forEachLatLng,t.n=Lt.prototype,t.n.Ze=function(){return this.lo>this.hi},t.n.isEmpty=function(){return 360==this.lo-this.hi},t.n.intersects=function(t){var e=this.lo,n=this.hi;return!this.isEmpty()&&!t.isEmpty()&&(this.Ze()?t.Ze()||t.lo<=this.hi||t.hi>=e:t.Ze()?t.lo<=n||t.hi>=e:t.lo<=n&&t.hi>=e)},t.n.contains=function(t){-180==t&&(t=180);var e=this.lo,n=this.hi;return this.Ze()?(t>=e||t<=n)&&!this.isEmpty():t>=e&&t<=n},t.n.extend=function(e){this.contains(e)||(this.isEmpty()?this.lo=this.hi=e:t.cg(e,this.lo)<t.cg(this.hi,e)?this.lo=e:this.hi=e)},t.n.equals=function(t){return 1e-9>=Math.abs(t.lo-this.lo)%360+Math.abs(t.span()-this.span())},t.n.span=function(){return this.isEmpty()?0:this.Ze()?360-(this.lo-this.hi):this.hi-this.lo},t.n.center=function(){var e=(this.lo+this.hi)/2;return this.Ze()&&(e=t.$d(e+180,-180,180)),e},t.n=Tt.prototype,t.n.isEmpty=function(){return this.lo>this.hi},t.n.intersects=function(t){var e=this.lo,n=this.hi;return e<=t.lo?t.lo<=n&&t.lo<=t.hi:e<=t.hi&&e<=n},t.n.contains=function(t){return t>=this.lo&&t<=this.hi},t.n.extend=function(t){this.isEmpty()?this.hi=this.lo=t:t<this.lo?this.lo=t:t>this.hi&&(this.hi=t)},t.n.equals=function(t){return this.isEmpty()?t.isEmpty():1e-9>=Math.abs(t.lo-this.lo)+Math.abs(this.hi-t.hi)},t.n.span=function(){return this.isEmpty()?0:this.hi-this.lo},t.n.center=function(){return(this.hi+this.lo)/2},t.fg.prototype.getCenter=function(){return new t.He(this.Ya.center(),this.Ma.center())},t.fg.prototype.getCenter=t.fg.prototype.getCenter,t.fg.prototype.toString=function(){return"("+this.getSouthWest()+", "+this.getNorthEast()+")"},t.fg.prototype.toString=t.fg.prototype.toString,t.fg.prototype.toJSON=function(){return{south:this.Ya.lo,west:this.Ma.lo,north:this.Ya.hi,east:this.Ma.hi}},t.fg.prototype.toJSON=t.fg.prototype.toJSON,t.fg.prototype.toUrlValue=function(t){var e=this.getSouthWest(),n=this.getNorthEast();return[e.toUrlValue(t),n.toUrlValue(t)].join()},t.fg.prototype.toUrlValue=t.fg.prototype.toUrlValue,t.fg.prototype.equals=function(e){return!!e&&(e=t.eg(e),this.Ya.equals(e.Ya)&&this.Ma.equals(e.Ma))},t.fg.prototype.equals=t.fg.prototype.equals,t.fg.prototype.equals=t.fg.prototype.equals,t.fg.prototype.contains=function(e){return e=t.Le(e),this.Ya.contains(e.lat())&&this.Ma.contains(e.lng())},t.fg.prototype.contains=t.fg.prototype.contains,t.fg.prototype.intersects=function(e){return e=t.eg(e),this.Ya.intersects(e.Ya)&&this.Ma.intersects(e.Ma)},t.fg.prototype.intersects=t.fg.prototype.intersects,t.fg.prototype.bg=t.aa(13),t.fg.prototype.extend=function(e){return e=t.Le(e),this.Ya.extend(e.lat()),this.Ma.extend(e.lng()),this},t.fg.prototype.extend=t.fg.prototype.extend,t.fg.prototype.union=function(e){if(!(e=t.eg(e))||e.isEmpty())return this;this.Ya.extend(e.getSouthWest().lat()),this.Ya.extend(e.getNorthEast().lat()),e=e.Ma;var n=t.cg(this.Ma.lo,e.hi),o=t.cg(e.lo,this.Ma.hi);return t.bg(this.Ma,e)?this:t.bg(e,this.Ma)?(this.Ma=new Lt(e.lo,e.hi),this):(this.Ma.intersects(e)?this.Ma=n>=o?new Lt(this.Ma.lo,e.hi):new Lt(e.lo,this.Ma.hi):this.Ma=n<=o?new Lt(this.Ma.lo,e.hi):new Lt(e.lo,this.Ma.hi),this)},t.fg.prototype.union=t.fg.prototype.union,t.fg.prototype.Ze=function(){return this.Ma.Ze()},t.fg.prototype.getSouthWest=function(){return new t.He(this.Ya.lo,this.Ma.lo,!0)},t.fg.prototype.getSouthWest=t.fg.prototype.getSouthWest,t.fg.prototype.getNorthEast=function(){return new t.He(this.Ya.hi,this.Ma.hi,!0)},t.fg.prototype.getNorthEast=t.fg.prototype.getNorthEast,t.fg.prototype.toSpan=function(){return new t.He(this.Ya.span(),this.Ma.span(),!0)},t.fg.prototype.toSpan=t.fg.prototype.toSpan,t.fg.prototype.isEmpty=function(){return this.Ya.isEmpty()||this.Ma.isEmpty()},t.fg.prototype.isEmpty=t.fg.prototype.isEmpty,t.fg.MAX_BOUNDS=t.gg(-90,-180,90,180);var Ai,ji=t.we({south:t.Zf,west:t.Zf,north:t.Zf,east:t.Zf},!1);t.Mk=t.De(t.xe(t.Lf,"Map")),t.Pa(_t,t.P),_t.prototype.contains=function(t){return this.h.contains(t)},_t.prototype.contains=_t.prototype.contains,_t.prototype.getFeatureById=function(t){return this.h.getFeatureById(t)},_t.prototype.getFeatureById=_t.prototype.getFeatureById,_t.prototype.add=function(t){return this.h.add(t)},_t.prototype.add=_t.prototype.add,_t.prototype.remove=function(t){this.h.remove(t)},_t.prototype.remove=_t.prototype.remove,_t.prototype.forEach=function(t){this.h.forEach(t)},_t.prototype.forEach=_t.prototype.forEach,_t.prototype.addGeoJson=function(e,n){return t.Cba(this.h,e,n)},_t.prototype.addGeoJson=_t.prototype.addGeoJson,_t.prototype.loadGeoJson=function(e,n,o){var i=this.h;t.ff("data").then((function(t){t.Zw(i,e,n,o)}))},_t.prototype.loadGeoJson=_t.prototype.loadGeoJson,_t.prototype.toGeoJson=function(e){var n=this.h;t.ff("data").then((function(t){t.Vw(n,e)}))},_t.prototype.toGeoJson=_t.prototype.toGeoJson,_t.prototype.overrideStyle=function(t,e){this.j.overrideStyle(t,e)},_t.prototype.overrideStyle=_t.prototype.overrideStyle,_t.prototype.revertStyle=function(t){this.j.revertStyle(t)},_t.prototype.revertStyle=_t.prototype.revertStyle,_t.prototype.controls_changed=function(){this.get("controls")&&Ct(this)},_t.prototype.drawingMode_changed=function(){this.get("drawingMode")&&Ct(this)},t.jg(_t.prototype,{map:t.Mk,style:t.db,controls:t.De(t.ze(t.ye(mi))),controlPosition:t.De(t.ye(t.Mi)),drawingMode:t.De(t.ye(mi))}),t.Sj={METRIC:0,IMPERIAL:1},t.Rj={DRIVING:"DRIVING",WALKING:"WALKING",BICYCLING:"BICYCLING",TRANSIT:"TRANSIT",TWO_WHEELER:"TWO_WHEELER"},t.Gi={},Mt.prototype.route=function(e,n){var o=void 0;Li()||(o=t.rg(158094)),t.zg(window,"Dsrc"),t.xg(window,154342);var i=t.ff("directions").then((function(t){return t.route(e,n,!0,o)}),(function(){o&&t.sg(o,8)}));return n&&i.catch((function(){})),i},Mt.prototype.route=Mt.prototype.route;var Li=t.ug();t.gfa={BEST_GUESS:"bestguess",OPTIMISTIC:"optimistic",PESSIMISTIC:"pessimistic"},t.hfa={BUS:"BUS",RAIL:"RAIL",SUBWAY:"SUBWAY",TRAIN:"TRAIN",TRAM:"TRAM"},t.ifa={LESS_WALKING:"LESS_WALKING",FEWER_TRANSFERS:"FEWER_TRANSFERS"};var Ti=t.we({routes:t.ze(t.Ae(t.ie))},!0);t.Bg=[],t.Pa(St,t.P),St.prototype.changed=function(e){var n=this;"map"!=e&&"panel"!=e||t.ff("directions").then((function(t){t.Vx(n,e)})),"panel"==e&&t.Cg(this.getPanel())},t.jg(St.prototype,{directions:Ti,map:t.Mk,panel:t.De(t.Ae(Y)),routeIndex:t.Hg}),Ot.prototype.getDistanceMatrix=function(e,n){t.zg(window,"Dmac"),t.xg(window,154344);var o=t.ff("distance_matrix").then((function(t){return t.getDistanceMatrix(e,n)}));return n&&o.catch((function(){})),o},Ot.prototype.getDistanceMatrix=Ot.prototype.getDistanceMatrix,xt.prototype.getElevationAlongPath=function(e,n){var o=t.ff("elevation").then((function(t){return t.getElevationAlongPath(e,n)}));return n&&o.catch((function(){})),o},xt.prototype.getElevationAlongPath=xt.prototype.getElevationAlongPath,xt.prototype.getElevationForLocations=function(e,n){var o=t.ff("elevation").then((function(t){return t.getElevationForLocations(e,n)}));return n&&o.catch((function(){})),o},xt.prototype.getElevationForLocations=xt.prototype.getElevationForLocations,It.prototype.geocode=function(e,n){var o;_i()||(o=t.rg(145570)),t.zg(window,"Gac"),t.xg(window,155468);var i=t.ff("geocoder").then((function(t){return t.geocode(e,n,o)}),(function(){o&&t.sg(o,13)}));return n&&i.catch((function(){})),i},It.prototype.geocode=It.prototype.geocode,It.prototype.constructor=It.prototype.constructor;var _i=t.ug();t.lfa={ROOFTOP:"ROOFTOP",RANGE_INTERPOLATED:"RANGE_INTERPOLATED",GEOMETRIC_CENTER:"GEOMETRIC_CENTER",APPROXIMATE:"APPROXIMATE"},t.Jg.prototype.equals=function(e){return!!e&&(t.ae(this.Ya,e.lat)&&t.ae(this.Ma,e.lng)&&t.ae(this.h,e.altitude))},t.Jg.prototype.toJSON=function(){return{lat:this.Ya,lng:this.Ma,altitude:this.h}},t.ca.Object.defineProperties(t.Jg.prototype,{lat:{configurable:!0,enumerable:!0,get:function(){return this.Ya}},lng:{configurable:!0,enumerable:!0,get:function(){return this.Ma}},altitude:{configurable:!0,enumerable:!0,get:function(){return this.h}}}),t.Jg.prototype.toJSON=t.Jg.prototype.toJSON,t.Jg.prototype.equals=t.Jg.prototype.equals,t.Jg.prototype.constructor=t.Jg.prototype.constructor,Object.defineProperties(t.Jg.prototype,{lat:{enumerable:!0},lng:{enumerable:!0},altitude:{enumerable:!0}}),t.jh=new t.R(0,0),t.R.prototype.toString=function(){return"("+this.x+", "+this.y+")"},t.R.prototype.toString=t.R.prototype.toString,t.R.prototype.equals=function(t){return!!t&&(t.x==this.x&&t.y==this.y)},t.R.prototype.equals=t.R.prototype.equals,t.R.prototype.equals=t.R.prototype.equals,t.R.prototype.round=function(){this.x=Math.round(this.x),this.y=Math.round(this.y)},t.R.prototype.Im=t.aa(14),t.kh=new t.Lg(0,0),t.Lg.prototype.toString=function(){return"("+this.width+", "+this.height+")"},t.Lg.prototype.toString=t.Lg.prototype.toString,t.Lg.prototype.equals=function(t){return!!t&&(t.width==this.width&&t.height==this.height)},t.Lg.prototype.equals=t.Lg.prototype.equals,t.Lg.prototype.equals=t.Lg.prototype.equals;var Ci=t.Ae(Nt,"not a valid InfoWindow anchor"),Mi=new t.x.Set;Mi.add("gm-style-iw-a");var Si={},Oi=t.we({source:t.Gk,webUrl:t.Ik,iosDeepLinkId:t.Ik}),xi=t.Ce(t.we({placeId:t.Ik,query:t.Ik,location:t.Le}),(function(e){if(e.placeId&&e.query)throw t.qe("cannot set both placeId and query");if(!e.placeId&&!e.query)throw t.qe("must set one of placeId or query");return e}));t.Pa(Dt,t.P),t.jg(Dt.prototype,{position:t.De(t.Le),title:t.Ik,icon:t.De(t.Be([t.Gk,t.Ae((function(e){var n=t.Pg("maps-pin-view");return!!e&&"element"in e&&e.element.classList.contains(n)}),"should be a PinView"),{oq:X("url"),then:t.we({url:t.Gk,scaledSize:t.De(Rt),size:t.De(Rt),origin:t.De(Pt),anchor:t.De(Pt),labelOrigin:t.De(Pt),path:t.Ae((function(t){return null==t}))},!0)},{oq:X("path"),then:t.we({path:t.Be([t.Gk,t.ye(yi)]),anchor:t.De(Pt),labelOrigin:t.De(Pt),fillColor:t.Ik,fillOpacity:t.Hg,rotation:t.Hg,scale:t.Hg,strokeColor:t.Ik,strokeOpacity:t.Hg,strokeWeight:t.Hg,url:t.Ae((function(t){return null==t}))},!0)}])),label:t.De(t.Be([t.Gk,{oq:X("text"),then:t.we({text:t.Gk,fontSize:t.Ik,fontWeight:t.Ik,fontFamily:t.Ik,className:t.Ik},!0)}])),shadow:t.db,shape:t.db,cursor:t.Ik,clickable:t.Jk,animation:t.db,draggable:t.Jk,visible:t.Jk,flat:t.db,zIndex:t.Hg,opacity:t.Hg,place:t.De(xi),attribution:t.De(Oi)});var Ii,Pi=t.db;Ft.prototype.get=function(){if(0<this.j){this.j--;var t=this.h;this.h=t.next,t.next=null}else t=this.C();return t},Bt.prototype.add=function(t,e){var n=Ri.get();n.set(t,e),this.j?this.j.next=n:this.h=n,this.j=n},Bt.prototype.remove=function(){var t=null;return this.h&&(t=this.h,this.h=this.h.next,this.h||(this.j=null),t.next=null),t};var Ri=new Ft((function(){return new Gt}),(function(t){return t.reset()}));Gt.prototype.set=function(t,e){this.fn=t,this.scope=e,this.next=null},Gt.prototype.reset=function(){this.next=this.scope=this.fn=null};var Ni,Di=!1,ki=new Bt;t.Zg.prototype.addListener=function(t,e){qt(this,t,e,!1)},t.Zg.prototype.addListenerOnce=function(t,e){qt(this,t,e,!0)},t.Zg.prototype.removeListener=function(e,n){this.listeners.length&&((e=t.v(this.listeners,"find").call(this.listeners,Vt(e,n)))&&this.listeners.splice(this.listeners.indexOf(e),1),this.listeners.length||this.Wg())};var Fi=null;t.n=t.$g.prototype,t.n.Jh=function(){},t.n.Wg=function(){},t.n.addListener=function(t,e){return this.listeners.addListener(t,e)},t.n.addListenerOnce=function(t,e){return this.listeners.addListenerOnce(t,e)},t.n.removeListener=function(t,e){return this.listeners.removeListener(t,e)},t.n.notify=function(e){var n=this;t.Sba(this.listeners,(function(t){t(n.get())}),e)},t.B(t.ah,t.$g),t.ah.prototype.set=function(t){this.D&&this.get()===t||(this.Iq(t),this.notify())},t.B(Wt,t.ah),Wt.prototype.get=function(){return this.value},Wt.prototype.Iq=function(t){this.value=t},t.Pa(t.eh,t.P);var Ui=t.De(t.xe(t.eh,"StreetViewPanorama")),Bi=function(){if(!t.C.addEventListener||!Object.defineProperty)return!1;var e=!1,n=Object.defineProperty({},"passive",{get:function(){e=!0}});try{t.C.addEventListener("test",(function(){}),n),t.C.removeEventListener("test",(function(){}),n)}catch(o){}return e}();t.Pa(t.fh,Dt),t.fh.prototype.map_changed=function(){var e=this.get("map");e=e&&e.__gm.Jj,this.__gm.set!==e&&(this.__gm.set&&this.__gm.set.remove(this),(this.__gm.set=e)&&t.Hh(e,this))},t.fh.MAX_ZINDEX=1e6,t.jg(t.fh.prototype,{map:t.Be([t.Mk,Ui])}),t.B(Jt,t.P),t.n=Jt.prototype,t.n.internalAnchor_changed=function(){var e=Xt(this.get("internalAnchor"));Zt(this,"attribution",e),Zt(this,"place",e),Zt(this,"pixelPosition",e),Zt(this,"internalAnchorMap",e,"map",!0),this.internalAnchorMap_changed(!0),Zt(this,"internalAnchorPoint",e,"anchorPoint"),e instanceof t.fh?Zt(this,"internalAnchorPosition",e,"internalPosition"):Zt(this,"internalAnchorPosition",e,"position")},t.n.internalAnchorPoint_changed=function(){Yt(this)},t.n.internalPixelOffset_changed=function(){Yt(this)},t.n.internalAnchorPosition_changed=function(){var t=this.get("internalAnchorPosition");t&&this.set("position",t)},t.n.internalAnchorMap_changed=function(t){t=void 0!==t&&t,this.get("internalAnchor")&&(t||this.get("internalAnchorMap")!==this.infoWindow.get("map"))&&this.infoWindow.set("map",this.get("internalAnchorMap"))},t.n.internalContent_changed=function(){var e,n=this.set;if(e=this.get("internalContent")){if("string"==typeof e){var o=document.createElement("div");t.Rd(o,t.Tb(e))}else e.nodeType===Node.TEXT_NODE?(o=document.createElement("div")).appendChild(e):o=e;e=o}else e=null;n.call(this,"content",e)},t.n.trigger=function(e){t.O(this.infoWindow,e)},t.n.close=function(){this.infoWindow.set("map",null)},t.B(t.lh,t.P),t.lh.prototype.open=function(e,n){var o=n;n={},"object"!=typeof e||!e||e instanceof t.eh||e instanceof t.Lf?(n.map=e,n.anchor=o):(n.map=e.map,n.shouldFocus=e.shouldFocus,n.anchor=o||e.anchor),e=(e=(e=Xt(n.anchor))&&e.get("map"))instanceof t.Lf||e instanceof t.eh,n.map;var i=t.v(Object,"assign").call(Object,{},n);e=i.map,n=i.anchor,o=this.set;var r=i.map,a=i.shouldFocus;r="boolean"==typeof a?a:!!(r=(i=Xt(i.anchor))&&i.get("map")||r)&&r.__gm.get("isInitialized"),o.call(this,"shouldFocus",r),this.set("anchor",n),n?!this.get("map")&&e&&this.set("map",e):this.set("map",e)},t.lh.prototype.close=function(){this.set("map",null)},t.lh.prototype.focus=function(){this.get("map")&&!this.get("pendingFocus")&&this.set("pendingFocus",!0)},t.lh.prototype.focus=t.lh.prototype.focus,t.lh.prototype.close=t.lh.prototype.close,t.lh.prototype.open=t.lh.prototype.open,t.lh.prototype.constructor=t.lh.prototype.constructor,t.jg(t.lh.prototype,{content:t.Be([t.Ik,t.Ae(Y)]),position:t.De(t.Le),size:t.De(Rt),map:t.Be([t.Mk,Ui]),anchor:t.De(t.Be([t.xe(t.P,"MVCObject"),Ci])),zIndex:t.Hg}),t.Pa(t.mh,t.P),t.mh.prototype.map_changed=function(){var e=this;t.ff("kml").then((function(t){t.h(e)}))},t.jg(t.mh.prototype,{map:t.Mk,url:null,bounds:null,opacity:t.Hg}),t.Pa(Kt,t.P),Kt.prototype.F=function(){var e=this;t.ff("kml").then((function(t){t.j(e)}))},Kt.prototype.url_changed=Kt.prototype.F,Kt.prototype.map_changed=Kt.prototype.F,Kt.prototype.zIndex_changed=Kt.prototype.F,t.jg(Kt.prototype,{map:t.Mk,defaultViewport:null,metadata:null,status:null,url:t.Ik,screenOverlays:t.Jk,zIndex:t.Hg}),t.Ok={UNKNOWN:"UNKNOWN",OK:"OK",INVALID_REQUEST:"INVALID_REQUEST",DOCUMENT_NOT_FOUND:"DOCUMENT_NOT_FOUND",FETCH_ERROR:"FETCH_ERROR",INVALID_DOCUMENT:"INVALID_DOCUMENT",DOCUMENT_TOO_LARGE:"DOCUMENT_TOO_LARGE",LIMITS_EXCEEDED:"LIMITS_EXECEEDED",TIMED_OUT:"TIMED_OUT"},t.oh.prototype.fromLatLngToPoint=function(e,n){n=void 0===n?new t.R(0,0):n,e=t.Le(e);var o=this.h;return n.x=o.x+e.lng()*this.o,e=t.Zd(Math.sin(t.Pd(e.lat())),-(1-1e-15),1-1e-15),n.y=o.y+.5*Math.log((1+e)/(1-e))*-this.C,n},t.oh.prototype.fromPointToLatLng=function(e,n){var o=this.h;return new t.He(t.Qd(2*Math.atan(Math.exp((e.y-o.y)/-this.C))-Math.PI/2),(e.x-o.x)/this.o,void 0!==n&&n)},t.pfa=Math.sqrt(2),t.ph.prototype.equals=function(t){return!!t&&(this.h===t.h&&this.j===t.j)},t.qh.prototype.wrap=function(t){return t-Math.floor((t-this.min)/this.length)*this.length},t.rh.prototype.wrap=function(e){return new t.ph(this.ij?this.ij.wrap(e.h):e.h,this.jk?this.jk.wrap(e.j):e.j)},t.qfa=new t.rh({ij:new t.qh(256)}),t.rfa=new t.oh,Qt.prototype.equals=function(t){return!!t&&(this.m11===t.m11&&this.m12===t.m12&&this.m21===t.m21&&this.m22===t.m22&&this.h===t.h)},t.Pa(t.uh,t.P),t.jg(t.uh.prototype,{map:t.Mk}),t.Pa($t,t.P),t.jg($t.prototype,{map:t.Mk}),t.Pa(te,t.P),t.jg(te.prototype,{map:t.Mk});var Gi=t.we({center:t.De(t.Me),zoom:t.Hg,heading:t.Hg,tilt:t.Hg});t.B(ee,t.P),ee.prototype.mapId_changed=function(){if(!this.j&&this.get("mapId")!==this.h){this.j=!0;try{this.set("mapId",this.h)}finally{this.j=!1}t.zg(window,"Miacu"),t.xg(window,149729)}},ee.prototype.styles_changed=function(){var e=this.get("styles");this.h&&e&&(this.set("styles",void 0),t.zg(window,"Miwsu"),t.xg(window,149731),e.length||(t.zg(window,"Miwesu"),t.xg(window,149730)))},oe.prototype.clone=function(){var t=new oe;return t.isAvailable=this.isAvailable,this.h.forEach((function(e){ie(t,e)})),t},t.Pa(re,t.P),t.B(ue,t.P),ue.prototype.log=function(e,n){e.sh,e.Kg&&t.zg(this.W,e.Kg),e.Vi&&t.xg(this.W,e.Vi)},ue.prototype.getMapCapabilities=function(t){t=void 0!==t&&t;var e=Object.freeze({});return t&&this.log({Kg:"Mcmi",Vi:153027}),e},ue.prototype.mapCapabilities_changed=function(){if(!this.C){this.C=!0;try{this.set("mapCapabilities",this.getMapCapabilities())}finally{this.C=!1}throw Error("Attempted to set read-only key: mapCapabilities")}};var zi,Hi,qi,Vi,Wi={},Ji=(Wi.ADVANCED_MARKERS={Kg:"Mcmea",Vi:153025},Wi.DATA_DRIVEN_STYLING={Kg:"Mcmed",Vi:153026},Wi);t.n=t.Gh.prototype,t.n.remove=function(e){var n=this.j,o=t.Cf(e);n[o]&&(delete n[o],--this.o,t.O(this,"remove",e),this.onRemove&&this.onRemove(e))},t.n.contains=function(e){return!!this.j[t.Cf(e)]},t.n.forEach=function(t){var e,n=this.j;for(e in n)t.call(this,n[e])},t.n.Cd=t.aa(15),t.n.Xa=function(){return this.o},t.B(t.Ih,z),t.Ih.prototype.Va=function(t,e){var n=Array(de(t));return ye(t,e,n,0),n.join("")},t.tfa=new t.Ih,zi=RegExp("(\\*)","g"),Hi=RegExp("(!)","g"),qi=RegExp("^[-A-Za-z0-9_.!~*() ]*$"),t.B(me,z),me.prototype.Va=function(t,e){var n=[];return be(t,e,n),n.join("&").replace(Vi,"%27")},t.fj=new me,Vi=RegExp("'","g"),t.vfa=(0,t.x.Symbol)(void 0),t.n=t.Lh.prototype,t.n.Bj=!1,t.n.Id=function(){return this.Bj},t.n.dispose=function(){this.Bj||(this.Bj=!0,this.Jb())},t.n.Xf=t.aa(16),t.n.Jb=function(){if(this.X)for(;this.X.length;)this.X.shift()()},t.Mh.prototype.stopPropagation=function(){this.j=!0},t.Mh.prototype.preventDefault=function(){this.defaultPrevented=!0},t.Pa(t.Ph,t.Mh);var Zi={2:"touch",3:"pen",4:"mouse"};t.Ph.prototype.stopPropagation=function(){t.Ph.Ne.stopPropagation.call(this),this.h.stopPropagation?this.h.stopPropagation():this.h.cancelBubble=!0},t.Ph.prototype.preventDefault=function(){t.Ph.Ne.preventDefault.call(this);var e=this.h;e.preventDefault?e.preventDefault():e.returnValue=!1};var Yi="closure_listenable_"+(1e6*Math.random()|0),Xi=0;je.prototype.add=function(t,e,n,o,i){var r=t.toString();(t=this.listeners[r])||(t=this.listeners[r]=[],this.h++);var a=Te(t,e,o,i);return-1<a?(e=t[a],n||(e.Yl=!1)):((e=new we(e,this.src,r,!!o,i)).Yl=n,t.push(e)),e},je.prototype.remove=function(e,n,o,i){if(!((e=e.toString())in this.listeners))return!1;var r=this.listeners[e];return-1<(n=Te(r,n,o,i))&&(Ae(r[n]),t.ib(r,n),0==r.length&&(delete this.listeners[e],this.h--),!0)};var Ki="closure_lm_"+(1e6*Math.random()|0),Qi={},$i="__closure_events_fn_"+(1e9*Math.random()>>>0);t.Pa(t.di,t.Lh),t.di.prototype[Yi]=!0,t.di.prototype.addEventListener=function(e,n,o,i){t.Wh(this,e,n,o,i)},t.di.prototype.removeEventListener=function(t,e,n,o){Me(this,t,e,n,o)},t.di.prototype.o=function(e){var n=this.Gb;if(n)for(var o=[],i=1;n;n=n.Gb)o.push(n),++i;if(n=this.tj,i=e.type||e,"string"==typeof e)e=new t.Mh(e,n);else if(e instanceof t.Mh)e.target=e.target||n;else{var r=e;e=new t.Mh(i,n),t.bb(e,r)}if(r=!0,o)for(var a=o.length-1;!e.j&&0<=a;a--){var s=e.currentTarget=o[a];r=Ie(s,i,!0,e)&&r}if(e.j||(s=e.currentTarget=n,r=Ie(s,i,!0,e)&&r,e.j||(r=Ie(s,i,!1,e)&&r)),o)for(a=0;!e.j&&a<o.length;a++)s=e.currentTarget=o[a],r=Ie(s,i,!1,e)&&r;return r},t.di.prototype.Jb=function(){t.di.Ne.Jb.call(this),this.qf&&t.tca(this.qf),this.Gb=null},Pe.prototype.reset=function(){this.context=this.j=this.o=this.h=null,this.C=!1};var tr=new Ft((function(){return new Pe}),(function(t){t.reset()}));t.li.prototype.then=function(t,e,n){return ke(this,"function"==typeof t?t:null,"function"==typeof e?e:null,n)},t.li.prototype.$goog_Thenable=!0,t.li.prototype.cancel=function(e){if(0==this.h){var n=new Ve(e);t.Yg((function(){Ne(this,n)}),this)}},t.li.prototype.J=function(t){this.h=0,Fe(this,2,t)},t.li.prototype.K=function(t){this.h=0,Fe(this,3,t)},t.li.prototype.H=function(){for(var t;t=Ge(this);)ze(this,t,this.h,this.G);this.F=!1};var er=t.Xb;t.Pa(Ve,t.Ra),Ve.prototype.name="cancel",t.Pa(t.oi,t.Lh),t.n=t.oi.prototype,t.n.Bk=0,t.n.Jb=function(){t.oi.Ne.Jb.call(this),this.stop(),delete this.h,delete this.j},t.n.start=function(e){this.stop(),this.Bk=t.ni(this.o,void 0!==e?e:this.C)},t.n.stop=function(){this.isActive()&&t.C.clearTimeout(this.Bk),this.Bk=0},t.n.Vc=function(){this.stop(),this.Jq()},t.n.isActive=function(){return 0!=this.Bk},t.n.Jq=function(){this.Bk=0,this.h&&this.h.call(this.j)},t.n=t.qi.prototype,t.n.isEmpty=function(){return!(this.Aa<this.Ha&&this.va<this.Ca)},t.n.extend=function(t){t&&(this.Aa=Math.min(this.Aa,t.x),this.Ha=Math.max(this.Ha,t.x),this.va=Math.min(this.va,t.y),this.Ca=Math.max(this.Ca,t.y))},t.n.Xa=function(){return new t.Lg(this.Ha-this.Aa,this.Ca-this.va)},t.n.getCenter=function(){return new t.R((this.Aa+this.Ha)/2,(this.va+this.Ca)/2)},t.n.equals=function(t){return!!t&&(this.Aa===t.Aa&&this.va===t.va&&this.Ha===t.Ha&&this.Ca===t.Ca)},t.n.bg=t.aa(12),t.Qk=t.ri(-1/0,-1/0,1/0,1/0),t.ri(0,0,0,0),t.Pa(t.ti,t.Lh),t.ti.prototype.Vc=function(e){this.o=arguments,this.h?this.j=t.Na()+this.D:this.h=t.ni(this.C,this.D)},t.ti.prototype.stop=function(){this.h&&(t.C.clearTimeout(this.h),this.h=null),this.j=null,this.o=[]},t.ti.prototype.Jb=function(){this.stop(),t.ti.Ne.Jb.call(this)},t.ti.prototype.G=function(){this.h&&(t.C.clearTimeout(this.h),this.h=null),this.j?(this.h=t.ni(this.C,this.j-t.Na()),this.j=null):this.F.apply(null,this.o)},t.Pa(t.vi,t.P),t.vi.prototype.getAt=function(t){return this.Uc[t]},t.vi.prototype.getAt=t.vi.prototype.getAt,t.vi.prototype.indexOf=function(t){for(var e=0,n=this.Uc.length;e<n;++e)if(t===this.Uc[e])return e;return-1},t.vi.prototype.forEach=function(t){for(var e=0,n=this.Uc.length;e<n;++e)t(this.Uc[e],e)},t.vi.prototype.forEach=t.vi.prototype.forEach,t.vi.prototype.setAt=function(e,n){var o=this.Uc[e],i=this.Uc.length;if(e<i)this.Uc[e]=n,t.O(this,"set_at",e,o),this.o&&this.o(e,o);else{for(o=i;o<e;++o)this.insertAt(o,void 0);this.insertAt(e,n)}},t.vi.prototype.setAt=t.vi.prototype.setAt,t.vi.prototype.insertAt=function(e,n){this.Uc.splice(e,0,n),Qe(this),t.O(this,"insert_at",e),this.h&&this.h(e)},t.vi.prototype.insertAt=t.vi.prototype.insertAt,t.vi.prototype.removeAt=function(e){var n=this.Uc[e];return this.Uc.splice(e,1),Qe(this),t.O(this,"remove_at",e,n),this.j&&this.j(e,n),n},t.vi.prototype.removeAt=t.vi.prototype.removeAt,t.vi.prototype.push=function(t){return this.insertAt(this.Uc.length,t),this.Uc.length},t.vi.prototype.push=t.vi.prototype.push,t.vi.prototype.pop=function(){return this.removeAt(this.Uc.length-1)},t.vi.prototype.pop=t.vi.prototype.pop,t.vi.prototype.getArray=function(){return this.Uc},t.vi.prototype.getArray=t.vi.prototype.getArray,t.vi.prototype.clear=function(){for(;this.get("length");)this.pop()},t.vi.prototype.clear=t.vi.prototype.clear,t.jg(t.vi.prototype,{length:null}),t.n=t.wi.prototype,t.n.Xd=t.aa(17),t.n.Hf=function(e){return(e=t.Uca(this,e)).length<this.h.length?new t.wi(e):this},t.n.forEach=function(e,n){t.gb(this.h,(function(t,o){e.call(n,t,o)}))},t.n.some=function(e,n){return t.taa(this.h,(function(t,o){return e.call(n,t,o)}))},t.n.size=function(){return this.h.length},t.cda={japan_prequake:20,japan_postquake2010:24};var nr=t.we({zoom:t.De(oi),heading:oi,pitch:oi});t.zi.prototype.remove=function(){if(this.h.removeEventListener)this.h.removeEventListener(this.C,this.j,this.o);else{var t=this.h;t.detachEvent&&t.detachEvent("on"+this.C,this.j)}};var or,ir,rr=!1;try{var ar=function(){};t.ca.Object.defineProperties(ar.prototype,{passive:{configurable:!0,enumerable:!0,get:function(){rr=!0}}}),t.C.addEventListener("test",null,new ar)}catch(No){}or=["mousedown","touchstart","pointerdown","MSPointerDown"],ir=["wheel","mousewheel"],t.Bi=void 0,t.Ai=!1;try{t.yi(document.createElement("div"),":focus-visible"),t.Ai=!0}catch(No){}if("undefined"!=typeof document){t.wf(document,"keydown",(function(){t.Bi=!0}),!0);for(var sr=t.A(or),hr=sr.next();!hr.done;hr=sr.next())t.wf(document,hr.value,(function(){t.Bi=!1}),!0);for(var ur=t.A(ir),cr=ur.next();!cr.done;cr=ur.next())t.wf(document,cr.value,(function(){t.Bi=!1}),!0)}var fr,lr,pr,gr=new t.x.Map([[3,"Google Chrome"],[2,"Microsoft Edge"]]),dr=new t.x.Map([[1,["msie"]],[2,["edge"]],[3,["chrome","crios"]],[5,["firefox","fxios"]],[4,["applewebkit"]],[6,["trident"]],[7,["mozilla"]]]),yr={},vr=(yr[0]="",yr[1]="x11",yr[2]="macintosh",yr[3]="windows",yr[4]="android",yr[6]="iphone",yr[5]="ipad",yr),mr=null;t.ca.Object.defineProperties(en.prototype,{C:{configurable:!0,enumerable:!0,get:function(){return 5===this.type||7===this.type}}}),t.ca.Object.defineProperties(on.prototype,{version:{configurable:!0,enumerable:!0,get:function(){if(this.C)return this.C;if(navigator.userAgentData&&navigator.userAgentData.brands)for(var e=t.A(navigator.userAgentData.brands),n=e.next();!n.done;n=e.next())if((n=n.value).brand===gr.get(this.type))return this.C=new tn(+n.version,0);return this.C=nn().version}},D:{configurable:!0,enumerable:!0,get:function(){return nn().D}},type:{configurable:!0,enumerable:!0,get:function(){if(this.o)return this.o;if(navigator.userAgentData&&navigator.userAgentData.brands)for(var e=navigator.userAgentData.brands.map((function(t){return t.brand})),n=t.A(gr),o=n.next();!o.done;o=n.next()){var i=t.A(o.value);if(o=i.next().value,i=i.next().value,t.v(e,"includes").call(e,i))return this.o=o}return this.o=nn().type}},j:{configurable:!0,enumerable:!0,get:function(){return 5===this.type||7===this.type}},h:{configurable:!0,enumerable:!0,get:function(){return 4===this.type||3===this.type}},V:{configurable:!0,enumerable:!0,get:function(){return this.j?nn().j:0}},N:{configurable:!0,enumerable:!0,get:function(){return nn().o}},od:{configurable:!0,enumerable:!0,get:function(){return 1===this.type}},X:{configurable:!0,enumerable:!0,get:function(){return 5===this.type}},F:{configurable:!0,enumerable:!0,get:function(){return 3===this.type}},H:{configurable:!0,enumerable:!0,get:function(){return 4===this.type}},G:{configurable:!0,enumerable:!0,get:function(){if(navigator.userAgentData&&navigator.userAgentData.platform)return"iOS"===navigator.userAgentData.platform;var t=nn();return 6===t.h||5===t.h}},K:{configurable:!0,enumerable:!0,get:function(){return navigator.userAgentData&&navigator.userAgentData.platform?"macOS"===navigator.userAgentData.platform:2===nn().h}},J:{configurable:!0,enumerable:!0,get:function(){return navigator.userAgentData&&navigator.userAgentData.platform?"Android"===navigator.userAgentData.platform:4===nn().h}}}),t.Ii=new on,t.Uk=new function(){this.h=t.Ii,this.j=b((function(){return void 0!==(new Image).crossOrigin})),this.o=b((function(){return void 0!==document.createElement("span").draggable}))},t.Pa(t.Ni,t.eh),t.Ni.prototype.visible_changed=function(){var e=this,n=!!this.get("visible"),o=!1;this.h.get()!=n&&(this.o&&(o=this.__gm).set("shouldAutoFocus",n&&o.get("isMapInitialized")),an(this,n),this.h.set(n),o=n),n&&(this.F=this.F||new t.x.Promise((function(n){t.ff("streetview").then((function(t){if(e.D)var o=e.D;e.__gm.set("isInitialized",!0),n(t.vz(e,e.h,e.o,o))}),(function(){t.sg(e.__gm.get("sloTrackingId"),13)}))})),o&&this.F.then((function(t){return t.gA()})))},t.Ni.prototype.H=function(e){var n,o;"Escape"===e.key&&(null!=(n=this.j)&&(null!=(o=n.Xg)&&o.contains(document.activeElement))&&this.get("enableCloseButton")&&this.get("visible")&&(e.stopPropagation(),t.O(this,"closeclick"),this.set("visible",!1)))},t.jg(t.Ni.prototype,{visible:t.Jk,pano:t.Ik,position:t.De(t.Le),pov:t.De(nr),motionTracking:ri,photographerPov:null,location:null,links:t.ze(t.Ae(t.ie)),status:null,zoom:t.Hg,enableCloseButton:t.Jk}),t.Ni.prototype.ce=t.aa(18),t.Ni.prototype.registerPanoProvider=function(t,e){this.set("panoProvider",{provider:t,options:e||{}})},t.Ni.prototype.registerPanoProvider=t.Ni.prototype.registerPanoProvider,t.Ni.prototype.focus=function(){var t=this.__gm;this.getVisible()&&!t.get("pendingFocus")&&t.set("pendingFocus",!0)},t.Ni.prototype.focus=t.Ni.prototype.focus,sn.prototype.register=function(t){var e=this.C,n=e.length;if(!n||t.zIndex>=e[0].zIndex)var o=0;else if(t.zIndex>=e[n-1].zIndex){for(o=0;1<n-o;){var i=o+n>>1;t.zIndex>=e[i].zIndex?n=i:o=i}o=n}else o=n;e.splice(o,0,t)},t.Dfa=Object.freeze(["exitFullscreen","webkitExitFullscreen","mozCancelFullScreen","msExitFullscreen"]),t.Efa=Object.freeze(["fullscreenchange","webkitfullscreenchange","mozfullscreenchange","MSFullscreenChange"]),t.Ffa=Object.freeze(["fullscreenEnabled","webkitFullscreenEnabled","mozFullScreenEnabled","msFullscreenEnabled"]),t.Gfa=Object.freeze(["requestFullscreen","webkitRequestFullscreen","mozRequestFullScreen","msRequestFullscreen"]),t.Pa(un,re),t.Pa(cn,t.P),cn.prototype.set=function(e,n){if(null!=n&&!(n&&t.he(n.maxZoom)&&n.tileSize&&n.tileSize.width&&n.tileSize.height&&n.getTile&&n.getTile.apply))throw Error("Expected value implementing google.maps.MapType");return t.P.prototype.set.apply(this,arguments)},cn.prototype.set=cn.prototype.set,t.B(fn,t.P),fn.prototype.renderingType_changed=function(){if(!this.h)throw ln(this),Error("Setting map 'renderingType' is not supported. RenderingType is decided internally and is read-only. If you wish to create a vector map please create a map ID in the cloud console as per https://developers.google.com/maps/documentation/javascript/vector-map")},t.B(pn,t.F),pn.prototype.Lc=function(e){t.D(this.m,8,e)},t.B(t.bj,t.F),t.bj.prototype.hc=t.aa(20),t.B(t.cj,t.F),t.cj.prototype.ra=t.aa(21),t.cj.prototype.td=function(e){t.D(this.m,1,e)},t.cj.prototype.la=t.aa(22),t.cj.prototype.ud=function(e){t.D(this.m,2,e)},t.B(t.dj,t.F),t.dj.prototype.Ia=t.aa(23),t.dj.prototype.Fa=t.aa(24),t.B(yn,t.F),yn.prototype.getZoom=function(){return t.I(this.m,3)},yn.prototype.setZoom=function(e){t.D(this.m,3,e)},t.B(mn,t.P),mn.prototype.changed=function(){var e=this.G(),n=An(this),o=wn(this),i=!!this.C();(e&&!e.equals(this.K)||this.Y!==n||this.Z!==o||this.H!==i)&&(this.o||t.kj(this.h),t.pi(this.Ga),this.Y=n,this.Z=o,this.H=i),this.K=e},mn.prototype.div_changed=function(){var e=this.get("div"),n=this.j;if(e)if(n)e.appendChild(n);else{(n=this.j=document.createElement("div")).style.overflow="hidden";var o=this.h=t.We("IMG");t.wf(n,"contextmenu",(function(e){t.jf(e),t.lf(e)})),o.ontouchstart=o.ontouchmove=o.ontouchend=o.ontouchcancel=function(e){t.kf(e),t.lf(e)},o.alt="",t.Ji(o,t.kh),e.appendChild(n),this.Ga.Vc()}else n&&(t.kj(n),this.j=null)};var br={roadmap:0,satellite:2,hybrid:3,terrain:4},Er={0:1,2:2,3:2,4:2};mn.prototype.G=t.hg("center"),mn.prototype.C=t.hg("size"),t.mj.prototype.addListener=function(e,n){return t.N(this,e,n)},t.mj.prototype.trigger=function(e,n){t.O(this,e,n)},t.mj.prototype.addListener=t.mj.prototype.addListener,t.Hfa=t.we({fillColor:t.De(t.Kk),fillOpacity:t.De(t.Ce(ii,t.Ig)),strokeColor:t.De(t.Kk),strokeOpacity:t.De(t.Ce(ii,t.Ig)),strokeWeight:t.De(t.Ce(ii,t.Ig)),pointRadius:t.De(t.Ce(ii,(function(e){if(128>=e)return e;throw t.qe("The max allowed pointRadius value is 128px.")})))},!1,"FeatureStyleOptions"),t.nj.prototype.next=function(){return t.Vk},t.Vk={done:!0,value:void 0},t.nj.prototype.uj=function(){return this},t.Pa(Ln,t.nj),t.n=Ln.prototype,t.n.setPosition=function(t,e,n){(this.node=t)&&(this.j="number"==typeof e?e:1!=this.node.nodeType?0:this.h?-1:1),"number"==typeof n&&(this.depth=n)},t.n.clone=function(){return new Ln(this.node,this.h,!this.o,this.j,this.depth)},t.n.next=function(){if(this.C){if(!this.node||this.o&&0==this.depth)return t.Vk;var e=this.node,n=this.h?-1:1;if(this.j==n){var o=this.h?e.lastChild:e.firstChild;o?this.setPosition(o):this.setPosition(e,-1*n)}else(o=this.h?e.previousSibling:e.nextSibling)?this.setPosition(o):this.setPosition(e.parentNode,-1*n);this.depth+=this.j*(this.h?-1:1)}else this.C=!0;return(e=this.node)?{value:e,done:!1}:t.Vk},t.n.equals=function(t){return t.node==this.node&&(!this.node||t.j==this.j)},t.n.splice=function(e){var n=this.node,o=this.h?1:-1;this.j==o&&(this.j=-1*o,this.depth+=this.j*(this.h?-1:1)),this.h=!this.h,Ln.prototype.next.call(this),this.h=!this.h;for(var i=(o=t.Ha(arguments[0])?arguments[0]:arguments).length-1;0<=i;i--)t.Xe(o[i],n);t.Ye(n)},t.Pa(Tn,Ln),Tn.prototype.next=function(){do{var t=Tn.Ne.next.call(this);if(t.done)return t}while(-1==this.j);return{value:this.node,done:!1}},_n.prototype.hash=function(t){for(var e=this.a,n=this.h,o=0,i=0,r=t.length;i<r;++i)o*=e,o+=t[i],o%=n;return o};var wr=RegExp("'","g"),Ar=null,jr=null;t.Pa(In,t.Lf),Object.freeze({latLngBounds:new t.fg(new t.He(-85,-180),new t.He(85,180)),strictBounds:!0}),In.prototype.streetView_changed=function(){var t=this.get("streetView");t?t.set("standAlone",!1):this.set("streetView",this.__gm.G)},In.prototype.getDiv=function(){return this.__gm.Ba},In.prototype.getDiv=In.prototype.getDiv,In.prototype.panBy=function(e,n){var o=this.__gm;jr?t.O(o,"panby",e,n):t.ff("map").then((function(){t.O(o,"panby",e,n)}))},In.prototype.panBy=In.prototype.panBy,In.prototype.moveCamera=function(e){var n=this.__gm;try{e=Gi(e)}catch(o){throw t.qe("invalid CameraOptions",o)}jr?t.O(n,"movecamera",e):t.ff("map").then((function(){t.O(n,"movecamera",e)}))},In.prototype.moveCamera=In.prototype.moveCamera,In.prototype.panTo=function(e){var n=this.__gm;e=t.Me(e),jr?t.O(n,"panto",e):t.ff("map").then((function(){t.O(n,"panto",e)}))},In.prototype.panTo=In.prototype.panTo,In.prototype.panToBounds=function(e,n){var o=this.__gm,i=t.eg(e);jr?t.O(o,"pantolatlngbounds",i,n):t.ff("map").then((function(){t.O(o,"pantolatlngbounds",i,n)}))},In.prototype.panToBounds=In.prototype.panToBounds,In.prototype.fitBounds=function(e,n){var o=this,i=t.eg(e);jr?jr.fitBounds(this,i,n):t.ff("map").then((function(t){t.fitBounds(o,i,n)}))},In.prototype.fitBounds=In.prototype.fitBounds;var Lr={bounds:null,center:t.De(t.Me),clickableIcons:ri,heading:t.Hg,mapTypeId:t.Ik,projection:null,renderingType:null,restriction:function(e){if(null==e)return null;var n=(e=t.we({strictBounds:t.Jk,latLngBounds:t.eg})(e)).latLngBounds;if(!(n.Ya.hi>n.Ya.lo))throw t.qe("south latitude must be smaller than north latitude");if((-180==n.Ma.hi?180:n.Ma.hi)==n.Ma.lo)throw t.qe("eastern longitude cannot equal western longitude");return e},streetView:Ui,tilt:t.Hg,zoom:t.Hg};t.jg(In.prototype,Lr),t.Ifa={BOUNCE:1,DROP:2,AB:3,wB:4},Dn.prototype.getMaxZoomAtLatLng=function(e,n){t.zg(window,"Mza"),t.xg(window,154332);var o=t.ff("maxzoom").then((function(t){return t.getMaxZoomAtLatLng(e,n)}));return n&&o.catch((function(){})),o},Dn.prototype.getMaxZoomAtLatLng=Dn.prototype.getMaxZoomAtLatLng,Dn.prototype.constructor=Dn.prototype.constructor,t.Pa(kn,t.P),t.jg(kn.prototype,{map:t.Mk,tableId:t.Hg,query:t.De(t.Be([t.Gk,t.Ae(t.ie,"not an Object")]))});var Tr=null;t.Pa(t.Aj,t.P),t.Aj.prototype.map_changed=function(){var e=this;Tr?Tr.Pq(this):t.ff("overlay").then((function(t){Tr=t,t.Pq(e)}))},t.Aj.preventMapHitsFrom=function(e){t.ff("overlay").then((function(t){Tr=t,t.preventMapHitsFrom(e)}))},t.Oa("module$contents$mapsapi$overlay$overlayView_OverlayView.preventMapHitsFrom",t.Aj.preventMapHitsFrom),t.Aj.preventMapHitsAndGesturesFrom=function(e){t.ff("overlay").then((function(t){Tr=t,t.preventMapHitsAndGesturesFrom(e)}))},t.Oa("module$contents$mapsapi$overlay$overlayView_OverlayView.preventMapHitsAndGesturesFrom",t.Aj.preventMapHitsAndGesturesFrom),t.jg(t.Aj.prototype,{panes:null,projection:null,map:t.Be([t.Mk,Ui])}),t.kea=t.we({center:function(e){return t.Le(e)},radius:t.Zf},!0);var _r=Bn(t.xe(t.He,"LatLng"));t.Pa(t.Dj,t.P),t.Dj.prototype.map_changed=t.Dj.prototype.visible_changed=function(){var e=this;t.ff("poly").then((function(t){t.h(e)}))},t.Dj.prototype.center_changed=function(){t.O(this,"bounds_changed")},t.Dj.prototype.radius_changed=t.Dj.prototype.center_changed,t.Dj.prototype.getBounds=function(){var e=this.get("radius"),n=this.get("center");if(n&&t.he(e)){var o=this.get("map");return o=o&&o.__gm.get("baseMapType"),t.$i(n,e/t.Cda(o))}return null},t.Dj.prototype.getBounds=t.Dj.prototype.getBounds,t.Dj.prototype.Bi=function(){for(var e={},n=t.A("map radius center strokeColor strokeOpacity strokeWeight strokePosition fillColor fillOpacity zIndex clickable editable draggable visible".split(" ")),o=n.next();!o.done;o=n.next())e[o=o.value]=this.get(o);return e},t.jg(t.Dj.prototype,{center:t.De(t.Le),draggable:t.Jk,editable:t.Jk,map:t.Mk,radius:t.Hg,visible:t.Jk}),t.Pa(Gn,t.P),Gn.prototype.map_changed=Gn.prototype.visible_changed=function(){var e=this;t.ff("poly").then((function(t){t.j(e)}))},Gn.prototype.getPath=function(){return this.get("latLngs").getAt(0)},Gn.prototype.getPath=Gn.prototype.getPath,Gn.prototype.setPath=function(e){try{this.get("latLngs").setAt(0,Un(e))}catch(n){t.re(n)}},Gn.prototype.setPath=Gn.prototype.setPath,t.jg(Gn.prototype,{draggable:t.Jk,editable:t.Jk,map:t.Mk,visible:t.Jk}),t.Pa(t.Fj,Gn),t.Fj.prototype.h=!0,t.Fj.prototype.getPaths=function(){return this.get("latLngs")},t.Fj.prototype.getPaths=t.Fj.prototype.getPaths,t.Fj.prototype.setPaths=function(e){try{var n=this.set;if(Array.isArray(e)||e instanceof t.vi)if(0==t.Wd(e))var o=!0;else{var i=e instanceof t.vi?e.getAt(0):e[0];o=Array.isArray(i)||i instanceof t.vi}else o=!1;var r=o?e instanceof t.vi?Bn(_r)(e):new t.vi(t.ze(Un)(e)):new t.vi([Un(e)]);n.call(this,"latLngs",r)}catch(a){t.re(a)}},t.Fj.prototype.setPaths=t.Fj.prototype.setPaths,t.Pa(t.Gj,Gn),t.Gj.prototype.h=!1,t.Pa(t.Hj,t.P),t.Hj.prototype.map_changed=t.Hj.prototype.visible_changed=function(){var e=this;t.ff("poly").then((function(t){t.o(e)}))},t.jg(t.Hj.prototype,{draggable:t.Jk,editable:t.Jk,bounds:t.De(t.eg),map:t.Mk,visible:t.Jk}),t.Pa(zn,t.P),zn.prototype.map_changed=function(){var e=this;t.ff("streetview").then((function(t){t.Mv(e)}))},t.jg(zn.prototype,{map:t.Mk}),t.Jfa={NEAREST:"nearest",BEST:"best"},t.Jj.prototype.getPanorama=function(e,n){return t.Gda(this,e,n)},t.Jj.prototype.getPanorama=t.Jj.prototype.getPanorama,t.Jj.prototype.getPanoramaByLocation=function(t,e,n){return this.getPanorama({location:t,radius:e,preference:50>(e||0)?"best":"nearest"},n)},t.Jj.prototype.getPanoramaById=function(t,e){return this.getPanorama({pano:t},e)},t.Kfa={DEFAULT:"default",OUTDOOR:"outdoor"},t.Pa(Hn,t.P),Hn.prototype.getTile=function(e,n,o){if(!e||!o)return null;var i=t.We("DIV");if(o={rb:e,zoom:n,Mf:null},i.__gmimt=o,t.Hh(this.h,i),this.j){var r=this.tileSize||new t.Lg(256,256),a=this.o(e,n);(o.Mf=this.j({oa:e.x,pa:e.y,za:n},r,i,a,(function(){t.O(i,"load")}))).setOpacity(qn(this))}return i},Hn.prototype.getTile=Hn.prototype.getTile,Hn.prototype.releaseTile=function(t){t&&this.h.contains(t)&&(this.h.remove(t),(t=t.__gmimt.Mf)&&t.release())},Hn.prototype.releaseTile=Hn.prototype.releaseTile,Hn.prototype.opacity_changed=function(){var t=qn(this);this.h.forEach((function(e){e.__gmimt.Mf.setOpacity(t)}))},Hn.prototype.triggersTileLoadEvent=!0,t.jg(Hn.prototype,{opacity:t.Hg}),t.Pa(t.Mj,t.P),t.Mj.prototype.getTile=t.raa,t.Mj.prototype.tileSize=new t.Lg(256,256),t.Mj.prototype.triggersTileLoadEvent=!0,t.Pa(t.Nj,t.Mj),Vn.prototype.log=function(){},Vn.prototype.px=function(){return this.logs.map(this.h).join("\n")},Vn.prototype.h=function(t){return t.timestamp+": "+t.message},Vn.prototype.getLogs=Vn.prototype.px,t.Xk=new Vn;var Cr=null;t.Pa(Wn,t.P),Wn.prototype.map_changed=function(){var e=this,n=this.getMap();Cr?n?Cr.Te(this,n):Cr.Gf(this):t.ff("webgl").then((function(t){Cr=t,(n=e.getMap())?t.Te(e,n):t.Gf(e)}))},Wn.prototype.kt=function(t,e){this.o=!0,this.onDraw({gl:t,transformer:e}),this.o=!1},Wn.prototype.onDrawWrapper=Wn.prototype.kt,Wn.prototype.requestRedraw=function(){if(this.h=!0,!this.o&&Cr){var t=this.getMap();t&&Cr.requestRedraw(t)}},Wn.prototype.requestRedraw=Wn.prototype.requestRedraw,Wn.prototype.requestStateUpdate=function(){if(this.C=!0,Cr){var t=this.getMap();t&&Cr.dv(t)}},Wn.prototype.requestStateUpdate=Wn.prototype.requestStateUpdate,Wn.prototype.j=-1,Wn.prototype.h=!1,Wn.prototype.C=!1,Wn.prototype.o=!1,t.jg(Wn.prototype,{map:t.Mk}),t.Pa(Jn,t.P),t.jg(Jn.prototype,{attribution:function(){return!0},place:function(){return!0}});var Mr={ControlPosition:t.Mi,LatLng:t.He,LatLngBounds:t.fg,MVCArray:t.vi,MVCObject:t.P,MapsRequestError:t.Od,MapsNetworkError:J,MapsNetworkErrorEndpoint:{PLACES_NEARBY_SEARCH:"PLACES_NEARBY_SEARCH",PLACES_LOCAL_CONTEXT_SEARCH:"PLACES_LOCAL_CONTEXT_SEARCH",MAPS_MAX_ZOOM:"MAPS_MAX_ZOOM",DISTANCE_MATRIX:"DISTANCE_MATRIX",ELEVATION_LOCATIONS:"ELEVATION_LOCATIONS",ELEVATION_ALONG_PATH:"ELEVATION_ALONG_PATH",GEOCODER_GEOCODE:"GEOCODER_GEOCODE",DIRECTIONS_ROUTE:"DIRECTIONS_ROUTE",PLACES_GATEWAY:"PLACES_GATEWAY",PLACES_DETAILS:"PLACES_DETAILS",PLACES_FIND_PLACE_FROM_PHONE_NUMBER:"PLACES_FIND_PLACE_FROM_PHONE_NUMBER",PLACES_FIND_PLACE_FROM_QUERY:"PLACES_FIND_PLACE_FROM_QUERY",STREETVIEW_GET_PANORAMA:"STREETVIEW_GET_PANORAMA",PLACES_AUTOCOMPLETE:"PLACES_AUTOCOMPLETE",FLEET_ENGINE_LIST_DELIVERY_VEHICLES:"FLEET_ENGINE_LIST_DELIVERY_VEHICLES",FLEET_ENGINE_LIST_TASKS:"FLEET_ENGINE_LIST_TASKS",FLEET_ENGINE_LIST_VEHICLES:"FLEET_ENGINE_LIST_VEHICLES",FLEET_ENGINE_GET_DELIVERY_VEHICLE:"FLEET_ENGINE_GET_DELIVERY_VEHICLE",FLEET_ENGINE_GET_TRIP:"FLEET_ENGINE_GET_TRIP",FLEET_ENGINE_GET_VEHICLE:"FLEET_ENGINE_GET_VEHICLE",FLEET_ENGINE_SEARCH_TASKS:"FLEET_ENGINE_SEARCH_TASKS",qB:"FLEET_ENGINE_GET_TASK_TRACKING_INFO"},MapsServerError:t.Nd,Point:t.R,Size:t.Lg,UnitSystem:t.Sj,Settings:void 0,SymbolPath:yi,LatLngAltitude:t.Jg,event:t.mf},Sr={BicyclingLayer:t.uh,Circle:t.Dj,Data:_t,GroundOverlay:t.mh,ImageMapType:Hn,KmlLayer:Kt,KmlLayerStatus:t.Ok,Map:In,MapTypeControlStyle:{DEFAULT:0,HORIZONTAL_BAR:1,DROPDOWN_MENU:2,INSET:3,INSET_LARGE:4},MapTypeId:t.Zea,MapTypeRegistry:cn,MaxZoomService:Dn,MaxZoomStatus:{OK:"OK",ERROR:"ERROR"},OverlayView:t.Aj,Polygon:t.Fj,Polyline:t.Gj,Rectangle:t.Hj,RenderingType:{UNINITIALIZED:"UNINITIALIZED",RASTER:"RASTER",VECTOR:"VECTOR"},StrokePosition:{CENTER:0,INSIDE:1,OUTSIDE:2},StyledMapType:t.Nj,TrafficLayer:$t,TransitLayer:te,FeatureType:void 0,InfoWindow:t.lh,WebGLOverlayView:Wn},Or={DirectionsRenderer:St,DirectionsService:Mt,DirectionsStatus:{OK:"OK",UNKNOWN_ERROR:"UNKNOWN_ERROR",OVER_QUERY_LIMIT:"OVER_QUERY_LIMIT",REQUEST_DENIED:"REQUEST_DENIED",INVALID_REQUEST:"INVALID_REQUEST",ZERO_RESULTS:"ZERO_RESULTS",MAX_WAYPOINTS_EXCEEDED:"MAX_WAYPOINTS_EXCEEDED",NOT_FOUND:"NOT_FOUND"},DistanceMatrixService:Ot,DistanceMatrixStatus:{OK:"OK",INVALID_REQUEST:"INVALID_REQUEST",OVER_QUERY_LIMIT:"OVER_QUERY_LIMIT",REQUEST_DENIED:"REQUEST_DENIED",UNKNOWN_ERROR:"UNKNOWN_ERROR",MAX_ELEMENTS_EXCEEDED:"MAX_ELEMENTS_EXCEEDED",MAX_DIMENSIONS_EXCEEDED:"MAX_DIMENSIONS_EXCEEDED"},DistanceMatrixElementStatus:{OK:"OK",NOT_FOUND:"NOT_FOUND",ZERO_RESULTS:"ZERO_RESULTS"},TrafficModel:t.gfa,TransitMode:t.hfa,TransitRoutePreference:t.ifa,TravelMode:t.Rj,VehicleType:{RAIL:"RAIL",METRO_RAIL:"METRO_RAIL",SUBWAY:"SUBWAY",TRAM:"TRAM",MONORAIL:"MONORAIL",HEAVY_RAIL:"HEAVY_RAIL",COMMUTER_TRAIN:"COMMUTER_TRAIN",HIGH_SPEED_TRAIN:"HIGH_SPEED_TRAIN",BUS:"BUS",INTERCITY_BUS:"INTERCITY_BUS",TROLLEYBUS:"TROLLEYBUS",SHARE_TAXI:"SHARE_TAXI",FERRY:"FERRY",CABLE_CAR:"CABLE_CAR",GONDOLA_LIFT:"GONDOLA_LIFT",FUNICULAR:"FUNICULAR",OTHER:"OTHER"}},xr={ElevationService:xt,ElevationStatus:{OK:"OK",UNKNOWN_ERROR:"UNKNOWN_ERROR",OVER_QUERY_LIMIT:"OVER_QUERY_LIMIT",REQUEST_DENIED:"REQUEST_DENIED",INVALID_REQUEST:"INVALID_REQUEST",hB:"DATA_NOT_AVAILABLE"}},Ir={Geocoder:It,GeocoderLocationType:t.lfa,GeocoderStatus:{OK:"OK",UNKNOWN_ERROR:"UNKNOWN_ERROR",OVER_QUERY_LIMIT:"OVER_QUERY_LIMIT",REQUEST_DENIED:"REQUEST_DENIED",INVALID_REQUEST:"INVALID_REQUEST",ZERO_RESULTS:"ZERO_RESULTS",ERROR:"ERROR"}},Pr={StreetViewCoverageLayer:zn,StreetViewPanorama:t.Ni,StreetViewPreference:t.Jfa,StreetViewService:t.Jj,StreetViewStatus:{OK:"OK",UNKNOWN_ERROR:"UNKNOWN_ERROR",ZERO_RESULTS:"ZERO_RESULTS"},StreetViewSource:t.Kfa,InfoWindow:t.lh,OverlayView:t.Aj},Rr={Animation:t.Ifa,Marker:t.fh,CollisionBehavior:void 0};t.gf("main",{}),t.Zk=new t.x.WeakMap,t.Lfa=RegExp("[֑-ۯۺ-ࣿ‏\ud802-\ud803\ud83a-\ud83bיִ-﷿ﹰ-ﻼ]"),t.Mfa=RegExp("[A-Za-zÀ-ÖØ-öø-ʸ̀-֐ऀ-῿‎Ⰰ-\ud801\ud804-\ud839\ud83c-\udbff豈-﬜︀-﹯﻽-￿]"),t.Nfa=RegExp("^[^A-Za-zÀ-ÖØ-öø-ʸ̀-֐ऀ-῿‎Ⰰ-\ud801\ud804-\ud839\ud83c-\udbff豈-﬜︀-﹯﻽-￿]*[֑-ۯۺ-ࣿ‏\ud802-\ud803\ud83a-\ud83bיִ-﷿ﹰ-ﻼ]"),t.Ofa=RegExp("[A-Za-zÀ-ÖØ-öø-ʸ̀-֐ऀ-῿‎Ⰰ-\ud801\ud804-\ud839\ud83c-\udbff豈-﬜︀-﹯﻽-￿][^֑-ۯۺ-ࣿ‏\ud802-\ud803\ud83a-\ud83bיִ-﷿ﹰ-ﻼ]*$"),t.Pfa=RegExp("[֑-ۯۺ-ࣿ‏\ud802-\ud803\ud83a-\ud83bיִ-﷿ﹰ-ﻼ][^A-Za-zÀ-ÖØ-öø-ʸ̀-֐ऀ-῿‎Ⰰ-\ud801\ud804-\ud839\ud83c-\udbff豈-﬜︀-﹯﻽-￿]*$");var Nr=t.C.google.maps,Dr=it.getInstance(),kr=(0,t.Ma)(Dr.Ih,Dr);Nr.__gjsload__=kr,t.Xd(Nr.modules,kr),delete Nr.modules;var Fr,Ur={main:[],common:["main"],util:["common"],adsense:["main"],controls:["util"],data:["util"],directions:["util","geometry"],distance_matrix:["util"],drawing:["main"],drawing_impl:["controls"],elevation:["util","geometry"],geocoder:["util"],imagery_viewer:["main"],geometry:["main"],journeySharing:["main"],infowindow:["util"],kml:["onion","util","map"],layers:["map"],localContext:["util"],log:["util"],map:["common"],marker:["util"],maxzoom:["util"],onion:["util","map"],overlay:["common"],panoramio:["main"],places:["main"],places_impl:["controls"],poly:["util","map","geometry"],search:["main"],search_impl:["onion"],stats:["util"],streetview:["util","geometry"],styleEditor:["common"],visualization:["main"],visualization_impl:["onion"],webgl:["util","map"],weather:["main"]},Br="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split("");t.Uj.prototype.constructor=t.Uj.prototype.constructor,t.Vj.prototype.j=null,t.Vj.prototype.Bi=function(){return this.j||(this.j=this.C())},t.Pa(Xn,t.Vj),Xn.prototype.h=function(){var t=Kn(this);return t?new ActiveXObject(t):new XMLHttpRequest},Xn.prototype.C=function(){var t={};return Kn(this)&&(t[0]=!0,t[1]=!0),t},Fr=new Xn,t.Pa(t.Xj,t.di);var Gr=/^https?$/i,zr=["POST","PUT"];t.n=t.Xj.prototype,t.n.hr=t.aa(25),t.n.send=function(e,n,o,i){if(this.h)throw Error("[goog.net.XhrIo] Object is active with another request="+this.N+"; newUri="+e);n=n?n.toUpperCase():"GET",this.N=e,this.F="",this.D=0,this.aa=!1,this.j=!0,this.h=this.Z?this.Z.h():Fr.h(),this.Y=this.Z?this.Z.Bi():Fr.Bi(),this.h.onreadystatechange=(0,t.Ma)(this.qt,this);try{this.getStatus(),this.ba=!0,this.h.open(n,String(e),!0),this.ba=!1}catch(s){return this.getStatus(),void $n(this,s)}if(e=o||"",o=new t.x.Map(this.headers),i)if(Object.getPrototypeOf(i)===Object.prototype)for(var r in i)o.set(r,i[r]);else{if("function"!=typeof t.v(i,"keys")||"function"!=typeof i.get)throw Error("Unknown input type for opt_headers: "+String(i));for(var a=(r=t.A(t.v(i,"keys").call(i))).next();!a.done;a=r.next())a=a.value,o.set(a,i.get(a))}for(i=(t.ng=t.v(Array,"from").call(Array,t.v(o,"keys").call(o)),t.v(t.ng,"find")).call(t.ng,(function(t){return"content-type"==t.toLowerCase()})),r=t.C.FormData&&e instanceof t.C.FormData,!t.hb(zr,n)||i||r||o.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8"),i=(n=t.A(o)).next();!i.done;i=n.next())i=(o=t.A(i.value)).next().value,o=o.next().value,this.h.setRequestHeader(i,o);this.V&&(this.h.responseType=this.V),"withCredentials"in this.h&&this.h.withCredentials!==this.G&&(this.h.withCredentials=this.G);try{oo(this),0<this.H&&(this.ca=Qn(this.h),this.getStatus(),this.ca?(this.h.timeout=this.H,this.h.ontimeout=(0,t.Ma)(this.Kq,this)):this.J=t.ni(this.Kq,this.H,this)),this.getStatus(),this.K=!0,this.h.send(e),this.K=!1}catch(s){this.getStatus(),$n(this,s)}},t.n.Kq=function(){void 0!==lo&&this.h&&(this.F="Timed out after "+this.H+"ms, aborting",this.D=8,this.getStatus(),this.o("timeout"),this.abort(8))},t.n.abort=function(t){this.h&&this.j&&(this.getStatus(),this.j=!1,this.C=!0,this.h.abort(),this.C=!1,this.D=t||7,this.o("complete"),this.o("abort"),no(this))},t.n.Jb=function(){this.h&&(this.j&&(this.j=!1,this.C=!0,this.h.abort(),this.C=!1),no(this,!0)),t.Xj.Ne.Jb.call(this)},t.n.qt=function(){this.Id()||(this.ba||this.K||this.C?eo(this):this.mz())},t.n.mz=function(){eo(this)},t.n.isActive=function(){return!!this.h},t.n.Zc=function(){return 4==t.kk(this)},t.n.getStatus=function(){try{return 2<t.kk(this)?this.h.status:-1}catch(No){return-1}},t.n.Og=t.aa(26);var Hr=arguments[0],qr=new t.Xj;t.C.google.maps.Load&&t.C.google.maps.Load(io)}.call(this,{})};
});
__maRoute='app';require("app.js");
__maRoute='component/communication-detail/index';require("component/communication-detail/index.js");
__maRoute='component/communication-detailItem/index';require("component/communication-detailItem/index.js");
__maRoute='component/detail/index';require("component/detail/index.js");
__maRoute='component/detailItem/index';require("component/detailItem/index.js");
__maRoute='macle_demo_EN/component/communication-detail/index';require("macle_demo_EN/component/communication-detail/index.js");
__maRoute='macle_demo_EN/component/communication-detailItem/index';require("macle_demo_EN/component/communication-detailItem/index.js");
__maRoute='macle_demo_EN/component/detail/index';require("macle_demo_EN/component/detail/index.js");
__maRoute='macle_demo_EN/component/detailItem/index';require("macle_demo_EN/component/detailItem/index.js");
__maRoute='macle_demo_EN/page/API/pages/application-event/application-event';require("macle_demo_EN/page/API/pages/application-event/application-event.js");
__maRoute='macle_demo_EN/page/API/pages/canIUse/canIUse';require("macle_demo_EN/page/API/pages/canIUse/canIUse.js");
__maRoute='macle_demo_EN/page/API/pages/chooseContact/chooseContact';require("macle_demo_EN/page/API/pages/chooseContact/chooseContact.js");
__maRoute='macle_demo_EN/page/API/pages/compressImage/compressImage';require("macle_demo_EN/page/API/pages/compressImage/compressImage.js");
__maRoute='macle_demo_EN/page/API/pages/downloadFile/downloadFile';require("macle_demo_EN/page/API/pages/downloadFile/downloadFile.js");
__maRoute='macle_demo_EN/page/API/pages/file/file';require("macle_demo_EN/page/API/pages/file/file.js");
__maRoute='macle_demo_EN/page/API/pages/get-battery-info/get-battery-info';require("macle_demo_EN/page/API/pages/get-battery-info/get-battery-info.js");
__maRoute='macle_demo_EN/page/API/pages/get-image-info/get-image-info';require("macle_demo_EN/page/API/pages/get-image-info/get-image-info.js");
__maRoute='macle_demo_EN/page/API/pages/get-location/get-location';require("macle_demo_EN/page/API/pages/get-location/get-location.js");
__maRoute='macle_demo_EN/page/API/pages/get-network-type/get-network-type';require("macle_demo_EN/page/API/pages/get-network-type/get-network-type.js");
__maRoute='macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync';require("macle_demo_EN/page/API/pages/get-system-info-sync/get-system-info-sync.js");
__maRoute='macle_demo_EN/page/API/pages/get-system-info/get-system-info';require("macle_demo_EN/page/API/pages/get-system-info/get-system-info.js");
__maRoute='macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect';require("macle_demo_EN/page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect.js");
__maRoute='macle_demo_EN/page/API/pages/gyroscope/gyroscope';require("macle_demo_EN/page/API/pages/gyroscope/gyroscope.js");
__maRoute='macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard';require("macle_demo_EN/page/API/pages/hideKeyboard/hideKeyboard.js");
__maRoute='macle_demo_EN/page/API/pages/loading/loading';require("macle_demo_EN/page/API/pages/loading/loading.js");
__maRoute='macle_demo_EN/page/API/pages/make-phone-call/make-phone-call';require("macle_demo_EN/page/API/pages/make-phone-call/make-phone-call.js");
__maRoute='macle_demo_EN/page/API/pages/mediaImage/mediaImage';require("macle_demo_EN/page/API/pages/mediaImage/mediaImage.js");
__maRoute='macle_demo_EN/page/API/pages/memory-warning/memory-warning';require("macle_demo_EN/page/API/pages/memory-warning/memory-warning.js");
__maRoute='macle_demo_EN/page/API/pages/modal/modal';require("macle_demo_EN/page/API/pages/modal/modal.js");
__maRoute='macle_demo_EN/page/API/pages/navigator/navigate';require("macle_demo_EN/page/API/pages/navigator/navigate.js");
__maRoute='macle_demo_EN/page/API/pages/navigator/navigator';require("macle_demo_EN/page/API/pages/navigator/navigator.js");
__maRoute='macle_demo_EN/page/API/pages/navigator/redirect';require("macle_demo_EN/page/API/pages/navigator/redirect.js");
__maRoute='macle_demo_EN/page/API/pages/network/network';require("macle_demo_EN/page/API/pages/network/network.js");
__maRoute='macle_demo_EN/page/API/pages/open-document/open-document';require("macle_demo_EN/page/API/pages/open-document/open-document.js");
__maRoute='macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh';require("macle_demo_EN/page/API/pages/pull-down-refresh/pull-down-refresh.js");
__maRoute='macle_demo_EN/page/API/pages/request/request';require("macle_demo_EN/page/API/pages/request/request.js");
__maRoute='macle_demo_EN/page/API/pages/scanCode/scanCode';require("macle_demo_EN/page/API/pages/scanCode/scanCode.js");
__maRoute='macle_demo_EN/page/API/pages/screen-brightness/screen-brightness';require("macle_demo_EN/page/API/pages/screen-brightness/screen-brightness.js");
__maRoute='macle_demo_EN/page/API/pages/set-background/set-background';require("macle_demo_EN/page/API/pages/set-background/set-background.js");
__maRoute='macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color';require("macle_demo_EN/page/API/pages/set-navigation-bar-color/set-navigation-bar-color.js");
__maRoute='macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title';require("macle_demo_EN/page/API/pages/set-navigation-bar-title/set-navigation-bar-title.js");
__maRoute='macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet';require("macle_demo_EN/page/API/pages/show-action-sheet/show-action-sheet.js");
__maRoute='macle_demo_EN/page/API/pages/storage-sync/storage-sync';require("macle_demo_EN/page/API/pages/storage-sync/storage-sync.js");
__maRoute='macle_demo_EN/page/API/pages/storage/storage';require("macle_demo_EN/page/API/pages/storage/storage.js");
__maRoute='macle_demo_EN/page/API/pages/toast/toast';require("macle_demo_EN/page/API/pages/toast/toast.js");
__maRoute='macle_demo_EN/page/API/pages/uploadFile/uploadFile';require("macle_demo_EN/page/API/pages/uploadFile/uploadFile.js");
__maRoute='macle_demo_EN/page/API/pages/vibrate/vibrate';require("macle_demo_EN/page/API/pages/vibrate/vibrate.js");
__maRoute='macle_demo_EN/page/API/pages/websocket/websocket';require("macle_demo_EN/page/API/pages/websocket/websocket.js");
__maRoute='macle_demo_EN/page/component/pages/audio/audio';require("macle_demo_EN/page/component/pages/audio/audio.js");
__maRoute='macle_demo_EN/page/component/pages/button/button';require("macle_demo_EN/page/component/pages/button/button.js");
__maRoute='macle_demo_EN/page/component/pages/camera/camera';require("macle_demo_EN/page/component/pages/camera/camera.js");
__maRoute='macle_demo_EN/page/component/pages/checkbox/checkbox';require("macle_demo_EN/page/component/pages/checkbox/checkbox.js");
__maRoute='macle_demo_EN/page/component/pages/cover-image/cover-image';require("macle_demo_EN/page/component/pages/cover-image/cover-image.js");
__maRoute='macle_demo_EN/page/component/pages/cover-view/cover-view';require("macle_demo_EN/page/component/pages/cover-view/cover-view.js");
__maRoute='macle_demo_EN/page/component/pages/form/form';require("macle_demo_EN/page/component/pages/form/form.js");
__maRoute='macle_demo_EN/page/component/pages/icon/icon';require("macle_demo_EN/page/component/pages/icon/icon.js");
__maRoute='macle_demo_EN/page/component/pages/image/image';require("macle_demo_EN/page/component/pages/image/image.js");
__maRoute='macle_demo_EN/page/component/pages/input/input';require("macle_demo_EN/page/component/pages/input/input.js");
__maRoute='macle_demo_EN/page/component/pages/label/label';require("macle_demo_EN/page/component/pages/label/label.js");
__maRoute='macle_demo_EN/page/component/pages/navigator/navigate';require("macle_demo_EN/page/component/pages/navigator/navigate.js");
__maRoute='macle_demo_EN/page/component/pages/navigator/navigator';require("macle_demo_EN/page/component/pages/navigator/navigator.js");
__maRoute='macle_demo_EN/page/component/pages/navigator/redirect';require("macle_demo_EN/page/component/pages/navigator/redirect.js");
__maRoute='macle_demo_EN/page/component/pages/navigator/reLaunch';require("macle_demo_EN/page/component/pages/navigator/reLaunch.js");
__maRoute='macle_demo_EN/page/component/pages/picker-view/picker-view';require("macle_demo_EN/page/component/pages/picker-view/picker-view.js");
__maRoute='macle_demo_EN/page/component/pages/picker/picker';require("macle_demo_EN/page/component/pages/picker/picker.js");
__maRoute='macle_demo_EN/page/component/pages/progress/progress';require("macle_demo_EN/page/component/pages/progress/progress.js");
__maRoute='macle_demo_EN/page/component/pages/radio/radio';require("macle_demo_EN/page/component/pages/radio/radio.js");
__maRoute='macle_demo_EN/page/component/pages/rich-text/rich-text';require("macle_demo_EN/page/component/pages/rich-text/rich-text.js");
__maRoute='macle_demo_EN/page/component/pages/scroll-view/scroll-view';require("macle_demo_EN/page/component/pages/scroll-view/scroll-view.js");
__maRoute='macle_demo_EN/page/component/pages/slider/slider';require("macle_demo_EN/page/component/pages/slider/slider.js");
__maRoute='macle_demo_EN/page/component/pages/swiper/swiper';require("macle_demo_EN/page/component/pages/swiper/swiper.js");
__maRoute='macle_demo_EN/page/component/pages/switch/switch';require("macle_demo_EN/page/component/pages/switch/switch.js");
__maRoute='macle_demo_EN/page/component/pages/text/text';require("macle_demo_EN/page/component/pages/text/text.js");
__maRoute='macle_demo_EN/page/component/pages/textarea/textarea';require("macle_demo_EN/page/component/pages/textarea/textarea.js");
__maRoute='macle_demo_EN/page/component/pages/video/video';require("macle_demo_EN/page/component/pages/video/video.js");
__maRoute='macle_demo_EN/page/component/pages/view/view';require("macle_demo_EN/page/component/pages/view/view.js");
__maRoute='macle_demo_EN/page/component/pages/web-view/web-view';require("macle_demo_EN/page/component/pages/web-view/web-view.js");
__maRoute='macle_demo_EN/page/framework/pages/communication/communication';require("macle_demo_EN/page/framework/pages/communication/communication.js");
__maRoute='macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n';require("macle_demo_EN/page/framework/pages/macle-i18n/macle-i18n.js");
__maRoute='macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n';require("macle_demo_EN/page/framework/pages/macle-sub-i18n/macle-sub-i18n.js");
__maRoute='macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag';require("macle_demo_EN/page/framework/pages/sjs-drag/sjs-drag.js");
__maRoute='macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter';require("macle_demo_EN/page/framework/pages/sjs-filter/sjs-filter.js");
__maRoute='macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar';require("macle_demo_EN/page/tabbar/api/components/set-tab-bar/set-tab-bar.js");
__maRoute='macle_demo_EN/page/tabbar/api/index';require("macle_demo_EN/page/tabbar/api/index.js");
__maRoute='macle_demo_EN/page/tabbar/component/index';require("macle_demo_EN/page/tabbar/component/index.js");
__maRoute='macle_demo_EN/page/tabbar/framework/index';require("macle_demo_EN/page/tabbar/framework/index.js");
__maRoute='page/tabbar/api/components/set-tab-bar/set-tab-bar';require("page/tabbar/api/components/set-tab-bar/set-tab-bar.js");
__maRoute='page/tabbar/api/index';require("page/tabbar/api/index.js");
__maRoute='page/tabbar/component/index';require("page/tabbar/component/index.js");
__maRoute='page/tabbar/framework/index';require("page/tabbar/framework/index.js");
__maRoute='page/tabbar/react/index';require("page/tabbar/react/index.js");
